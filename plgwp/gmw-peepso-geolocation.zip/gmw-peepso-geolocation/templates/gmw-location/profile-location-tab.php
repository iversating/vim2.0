<?php
/**
 * GEO my WP PeepSo Location tab template file.
 *
 * @author Eyal Fitoussi
 *
 * @since 1.0
 *
 * @package gmw-peepso-geolocation
 */

?>
<div class="gmw-peepso-location-tab peepso ps-page-profile">

	<?php PeepSoTemplate::exec_template( 'general', 'navbar' ); ?>
	<?php PeepSoTemplate::exec_template( 'profile', 'focus', array( 'current' => 'gmw_location' ) ); ?>

	<section id="mainbody" class="ps-page-unstyled ps-helloworld-profile">
		<section id="component" role="article" class="ps-clearfix">

			<?php

			// Logged in user view.
			if ( get_current_user_id() === absint( $user_id ) ) {

				if ( 'form' === $gmw_settings['member_location_tab']['usage'] ) {

					$tab_settings = $gmw_settings['member_location_tab'];

					$exclude_groups = ! empty( $tab_settings['exclude_fields_groups'] ) ? ' exclude_fields_groups="' . implode( ',', $tab_settings['exclude_fields_groups'] ) . '" ' : '';
					$exclude_fields = ! empty( $tab_settings['exclude_fields'] ) ? ' exclude_fields="' . implode( ',', $tab_settings['exclude_fields'] ) . '" ' : '';
					$template       = ! empty( $tab_settings['form_template'] ) ? ' form_template="' . $tab_settings['form_template'] . '" ' : '';

					$content = '[gmw_user_location_form user_id="' . $user_id . '" ' . $exclude_groups . ' ' . $exclude_fields . ' ' . $template . ']';

				} else {

					$content = '[gmw_user_location user_id="' . $user_id . '" elements="map,address" map_height="300px" map_width="100%" user_map_icon="0"]';
				}

				echo do_shortcode( apply_filters( 'gmw_peepso_member_location_tab_content', $content, $user_id ) );

				// When viewing other users.
			} else {

				if ( gmw_is_addon_active( 'single_location' ) ) {

					$tab_settings = $gmw_settings['displayed_member_location_tab'];

					$elements       = ! empty( $tab_settings['elements'] ) ? ' elements="' . implode( ',', $tab_settings['elements'] ) . '" ' : '';
					$address_fields = ! empty( $tab_settings['address_fields'] ) ? ' address_fields="' . implode( ',', $tab_settings['address_fields'] ) . '" ' : '';

					$content = '[gmw_user_location user_id="' . $user_id . '" ' . $elements . ' ' . $address_fields . ' map_height="300px" map_width="100%" user_map_icon="0"]';

					// otherwise, display only address field.
				} else {

					$content = '<div id="gmw-user-address"><i class="gmw-icon-location"></i>' . esc_attr( gmw_get_user_address() ) . '</div>';
				}

				echo do_shortcode( apply_filters( 'gmw_peepso_display_member_location_tab_content', $content, $user_id ) );
			}
			?>

		</section>
	</section>
</div>
<?php PeepSoTemplate::exec_template( 'activity', 'dialogs' ); ?>
