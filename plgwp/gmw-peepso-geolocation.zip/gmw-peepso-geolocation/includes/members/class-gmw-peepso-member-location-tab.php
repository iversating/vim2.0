<?php
/**
 * GEO my WP Peepso member location tab.
 *
 * @author Eyal Fitoussi
 *
 * @since 1.0
 *
 * @package gmw-peepso-geolocation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * GMW_PeepSo_Member_Location_Tab class.
 *
 * Generate the Location tab in the member profile page.
 *
 * @since 1.0
 *
 * @author Eyal Fitoussi
 */
class GMW_PeepSo_Member_Location_Tab {

	/**
	 * GMW PeepSo setings.
	 *
	 * @var array
	 */
	public $settings = array();

	/**
	 * The ID of the user being displayed.
	 *
	 * @var integer
	 */
	public $user_id = 0;

	/**
	 * __construct function.
	 *
	 * @access public
	 */
	public function __construct() {
		add_filter( 'peepso_navigation_profile', array( $this, 'location_tab' ), 50 );
	}

	/**
	 * Add Location tab to the Peepso member's profile page.
	 *
	 * @since 1.0.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @param  [type] $links [description].
	 *
	 * @return [type]        [description]
	 */
	public function location_tab( $links ) {

		$this->user_id  = PeepSoUrlSegments::get_view_id( PeepSoProfileShortcode::get_instance()->get_view_user_id() );
		$this->settings = gmw_get_options_group( 'peepso_geolocation' );

		// Check if this is the logged in member location tab.
		if ( get_current_user_id() === absint( $this->user_id ) ) {

			// Disable the Location tab of the logged in member if needed.
			if ( empty( $this->settings['member_location_tab']['usage'] ) || 'disabled' === $this->settings['member_location_tab']['usage'] ) {
				return $links;
			}

			// Otherwise, is the displayed member tab.
		} else {

			// Disable the location tab of the displayed member.
			if ( empty( $this->settings['displayed_member_location_tab']['elements'] ) ) {
				return $links;
			}
		}

		// Execute the tab segment.
		add_action( 'peepso_profile_segment_location', array( $this, 'location_tab_segment' ), 50 );

		$links['gmw_location'] = apply_filters(
			'gmw_peepso_location_tab_args',
			array(
				'href'  => 'location',
				'label' => __( 'Location', 'gmw-peepso-geolocation' ),
				'icon'  => 'gcis gci-map-marker',
			),
		);

		return $links;
	}

	/**
	 * Render the profile segment of the location tab.
	 *
	 * @since 1.0.
	 *
	 * @author Eyal Fitoussi
	 */
	public function location_tab_segment() {

		echo PeepSoTemplate::exec_template(
			'gmw-location',
			'profile-location-tab',
			array(
				'user_id'      => $this->user_id,
				'gmw_settings' => $this->settings,
			),
			false
		); // WPCS: XSS ok.
	}
}

new GMW_PeepSo_Member_Location_Tab();
