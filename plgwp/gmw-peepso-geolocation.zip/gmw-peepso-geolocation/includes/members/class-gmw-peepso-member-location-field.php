<?php
/**
 * GEO my WP Peepso location profile field.
 *
 * Use one of PeppSo profile fields as the address field that will get synced with GEO my WP.
 *
 * The class will update the location in GEO my WP when update the selected profile field and vice versa.
 *
 * @author Eyal Fitoussi
 *
 * @since 1.0
 *
 * @package gmw-peepso-geolocation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * GMW_PeepSo_Member_Location_Field.
 *
 * Use a PeepSo profile field as the location field that will update the location in GEO my WP.
 *
 * @since 1.0
 *
 * @author Eyal Fitoussi
 */
class GMW_Peepso_Member_Location_Field {

	/**
	 * __construct function.
	 *
	 * @access public
	 */
	public function __construct() {

		add_action( 'peepso_action_render_profile_field_edit_before', array( $this, 'enable_geo_features' ), 50 );
		add_action( 'gmw_save_user_location', array( $this, 'update_location_profile_field' ), 20 );
		add_action( 'gmw_before_user_location_deleted', array( $this, 'update_location_profile_field' ), 20 );
		add_action( 'peepso_action_profile_field_save', array( $this, 'update_gmw_location' ), 20 );
	}

	/**
	 * Enable address autocomplete and locator button in PeepSo's text profile field in profile page.
	 *
	 * @param  object $field PeepSo field.
	 *
	 * @since 1.0
	 *
	 * @author Eyal Fitoussi
	 *
	 * @return [type]        [description]
	 */
	public function enable_geo_features( $field ) {

		$options = gmw_get_option( 'peepso_geolocation', 'member_location_profile_field', array() );

		if ( 'text' !== $field->meta->class || empty( $options['field_id'] ) || absint( $options['field_id'] ) !== absint( $field->id ) ) {
			return;
		}

		// Autocomplete.
		if ( ! empty( $options['address_autocomplete'] ) ) {
			GMW_Maps_API::google_places_address_autocomplete( array( 'profile_field_' . $options['field_id'] ) );
		}

		// Locator.
		if ( ! empty( $options['locator_button'] ) ) {

			echo '<i class="gmw-peepso-locator-button inside gmw-icon-target-light"></i>';
			?>
			<script type="text/javascript">

				jQuery( document ).ready( function() {

					var field   = jQuery( '#' + 'profile_field_' + '<?php echo $options['field_id']; ?>' );
					var wrapper = field.closest( '.ps-profile__about-field-form' );
					var locator = wrapper.find( '.gmw-peepso-locator-button' );
					var inner   = wrapper.find( '.ps-input__wrapper' );

					field.addClass( 'gmw-peepso-address-field' );
					inner.addClass( 'gmw-peepso-locator-enabled' );

					locator.detach().prependTo( inner );
				});

			</script>
			<style type="text/css">
				.ps-input__wrapper.gmw-peepso-locator-enabled {
					display: flex;
					justify-content: flex-end;
					align-items: center;
					position: relative;
				}

				.ps-input__wrapper.gmw-peepso-locator-enabled input.ps-input {
					padding-left: 30px;
				}

				.ps-input__wrapper.gmw-peepso-locator-enabled .gmw-peepso-locator-button {
					position: absolute;
					cursor: pointer;
					color: var(--gmw-form-color-accent);
					z-index: 99;
					left: 0;
				}

				.ps-input__wrapper.gmw-peepso-locator-enabled .gmw-peepso-locator-button:before {
					display: inline-block;
					width: 30px;
					height: 100%;
				}
			</style>
			<?php
		}

	}

	/**
	 * Update PeepSo Member location profile field when updating the user's location via GEO my WP Location form.
	 *
	 * @param  int $location_id location ID.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @return [type]              [description]
	 */
	public function update_location_profile_field( $location_id ) {

		// Prevent infinite loop.
		remove_action( 'peepso_action_profile_field_save', array( $this, 'update_gmw_location' ), 20 );

		$options = gmw_get_option( 'peepso_geolocation', 'member_location_profile_field', array() );

		if ( empty( $options['field_id'] ) ) {
			return;
		}

		$location   = gmw_get_location( $location_id, ARRAY_A, false );
		$user_id    = $location['object_id'];
		$field_name = 'peepso_user_field_' . $options['field_id'];

		if ( 'gmw_before_user_location_deleted' === current_action() ) {

			delete_user_meta( $user_id, $field_name );

		} else {
			update_user_meta( $user_id, $field_name, $location['address'] );
		}
	}

	/**
	 * Update GEO my WP location via Peepso profile field.
	 *
	 * @param  obejct $field field object.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 */
	public function update_gmw_location( $field ) {

		// Prevent infinite loop.
		remove_action( 'gmw_save_user_location', array( $this, 'update_location_profile_field' ), 20 );
		remove_action( 'gmw_before_user_location_deleted', array( $this, 'update_location_profile_field' ), 20 );

		$options = gmw_get_option( 'peepso_geolocation', 'member_location_profile_field', array() );

		if ( empty( $options['field_id'] ) || absint( $options['field_id'] ) !== absint( $field->id ) ) {
			return;
		}

		$field_ok = (array) $field;
		$prefix   = chr( 0 ) . '*' . chr( 0 );
		$user_id  = $field_ok[ $prefix . 'user_id' ];

		// geocode and save the location in GEO my WP database.
		if ( ! empty( $field->value ) ) {

			if ( ! is_array( $field->value ) ) {

				$location = $field->value;

			} elseif ( ! empty( $field->value['name'] ) ) {

				$location = array(
					'lat' => $field->value['latitude'],
					'lng' => $field->value['longitude'],
				);
			}

			gmw_update_user_location( $user_id, $location );

			// Otherwise, if no address provided, delete the location from GEO my WP.
		} else {

			gmw_delete_user_location( $user_id );
		}
	}
}
new GMW_Peepso_Member_Location_Field();
