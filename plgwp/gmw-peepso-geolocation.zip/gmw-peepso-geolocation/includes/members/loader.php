<?php
/**
 * GEO my WP Peepso Members Geolocation loader.
 *
 * @author Eyal Fitoussi
 *
 * @since 1.0
 *
 * @package gmw-peepso-geolocation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// include in admin only.
if ( IS_ADMIN && ! defined( 'DOING_AJAX' ) ) {
	include_once 'admin/class-gmw-peepso-members-directory-geolocation-admin-settings.php';
}

require_once 'class-gmw-peepso-member-location-field.php';

require_once GMW_PEEPSO_GEO_PATH . '/includes/class-gmw-peepso-directory-geolocation.php';
require_once 'class-gmw-peepso-members-directory-geolocation.php';

// Requires the Users Locator extension.
if ( class_exists( 'GMW_Users_Locator_Addon' ) ) {
	include_once 'class-gmw-peepso-member-location-tab.php';
}
