<?php
/**
 * GEO my WP Peepso Members Directory Geolocation class.
 *
 * @author Eyal Fitoussi
 *
 * @since 1.0
 *
 * @package gmw-peepso-geolocation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * GMW_Peepso_Members_Directory_Geolocation class.
 *
 * @since 1.0
 *
 * @author Eyal Fitoussi
 */
class GMW_Peepso_Members_Directory_Geolocation extends GMW_Peepso_Directory_Geolocation {

	/**
	 * Component.
	 *
	 * @since 1.0
	 *
	 * @var string
	 */
	public $component = 'member';

	/**
	 * Get plugin's options.
	 *
	 * @since 1.0
	 *
	 * @return [type] [description]
	 */
	public function get_options() {
		return gmw_get_options_group( 'peepso_members_directory_geolocation' );
	}

	/**
	 * Constructor.
	 */
	public function __construct() {

		parent::__construct();

		add_action( 'peepso_action_render_member_search_fields', array( $this, 'extend_search_from' ) );
		add_filter( 'peepso_user_search_args', array( $this, 'execute_geolocation_functions' ), 50 );
		add_action( 'peepso_after_member_thumb', array( $this, 'add_elements_to_results' ) );
	}

	/**
	 * Extend search form with geolocation fields.
	 *
	 * We also use this filter to generate the map element which will be hidden by default.
	 *
	 * We then use a JavaScript function to detach the map from its original location and place it above the list of results.
	 *
	 * We do this since there is no other action hook that we could use for that at the moment.
	 *
	 * @since 1.0
	 *
	 * @author Eyal Fitoussi
	 */
	public function extend_search_from() {

		echo parent::extend_search_from(); // WPCS: XSS ok.

		// If map enabled.
		if ( ! empty( $this->options['map'] ) ) {
			echo $this->get_map_element(); // WPCS: XSS ok.
		}
	}

	/**
	 * Fire map locations filter.
	 *
	 * We use this filter to make sure that we execute our functions/filters only when needed.
	 *
	 * Which means only when the PeepSo's User Query is executed and not User Query by other plugins or custom functions.
	 *
	 * @param  [type] $args user query args.
	 *
	 * @since 1.0
	 *
	 * @author Eyal Fitoussi
	 *
	 * @return [type]       [description]
	 */
	public function execute_geolocation_functions( $args ) {

		remove_filter( 'peepso_user_search_args', array( $this, 'execute_geolocation_functions' ), 50 );

		add_filter( 'peepso_pre_user_query', array( $this, 'modify_user_query' ), 90 );
		add_filter( 'found_users_query', array( $this, 'collect_map_locations' ), 50, 2 );

		return $args;
	}

	/**
	 * Modify the user's search query and performe proximity search.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0.
	 *
	 * @param  [type] $user_query the user's search query object.
	 *
	 * @return [type]          [description]
	 */
	public function modify_user_query( $user_query ) {

		remove_filter( 'peepso_pre_user_query', array( $this, 'modify_user_query' ), 90 );

		// get proximate locations from GMW database based on form values.
		$objects_id = $this->get_locations();

		// If no locations were found, abort and fail the query.
		if ( empty( $objects_id ) ) {

			$user_query->query_where .= ' AND 1 = 0';

			return $user_query;
		}

		$users = implode( ',', $objects_id );

		// Modify the where clause to match users from locations.
		//if ( ! $this->enable_objects_without_location && ( empty( $this->form['address'] ) || empty( $this->form['lat'] ) || empty( $this->form['lng'] ) ) {
			$user_query->query_where .= " AND wp_users.ID IN ( {$users} ) ";
		//}

		// Order results by location when needed.
		if ( ! empty( $user_query->query_vars['orderby'] ) && 'distance' === $user_query->query_vars['orderby'] ) {
			$user_query->query_orderby = "ORDER BY FIELD( ID, {$users} )";
		}

		return $user_query;
	}

	/**
	 * Collect locations to then pass to the map.
	 *
	 * @param  [type] $found_users row_found SQL clause.
	 *
	 * @param  [type] $query       the user's search query object.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @return [type]              [description]
	 */
	public function collect_map_locations( $found_users, $query ) {

		remove_filter( 'found_users_query', array( $this, 'collect_map_locations' ), 50, 2 );

		foreach ( $query->results as $user_id ) {

			if ( isset( $this->locations_data[ $user_id ] ) ) {

				$member = $this->locations_data[ $user_id ];

				$peepso_member       = PeepSoUser::get_instance( $user_id );
				$member->ID          = $peepso_member->get_id();
				$member->name        = $peepso_member->get_fullname();
				$member->profile_url = $peepso_member->get_profileurl();
				//$member->avatar      = $peepso_member->get_avatar();

				$this->locations_data[ $user_id ] = $member;

				$this->member_map_location( $member );
			}
		}

		return $found_users;
	}

	/**
	 * Add object location to map.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @param object $member  the member object.
	 *
	 * Collect location data including info-window to later pass to the map.
	 */
	public function member_map_location( $member ) {

		$args = array(
			'object_type'  => 'user',
			'object_id'    => $member->object_id,
			'width'        => '100px',
			'height'       => 'auto',
			'show_grav'    => true,
			'show_default' => true,
			'where'        => 'info_window',
		);

		$info_window_args = array(
			'prefix'          => 'ppsomdg',
			'url'             => $member->profile_url,
			'title'           => wp_strip_all_tags( $member->name ),
			'image'           => $member->avatar,
			'iw_type'         => 'standard',
			'address'         => true,
			'directions_link' => false,
			'distance'        => true,
			'location_meta'   => '',
		);

		$info_window = gmw_get_info_window_content( $member, $info_window_args, $this->form );

		$this->map_locations[] = $this->get_map_location( $member, $info_window );
	}
}
new GMW_Peepso_Members_Directory_Geolocation();
