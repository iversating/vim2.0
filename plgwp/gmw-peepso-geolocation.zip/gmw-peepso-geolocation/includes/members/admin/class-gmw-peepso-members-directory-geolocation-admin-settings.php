<?php
/**
 * GEO my WP PeepSo Members Directory Geolocation admin settings.
 *
 * @since 1.0
 *
 * @author Eyal Fitoussi
 *
 * @package gmw-peepso-geolocation
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * GMW_Peepso_Members_Directory_Geolocation_Admin_Settings class.
 *
 * @since 1.0
 */
class GMW_Peepso_Members_Directory_Geolocation_Admin_Settings {

	/**
	 * __construct function.
	 *
	 * @access public
	 *
	 * @return void
	 */
	public function __construct() {

		include GMW_PEEPSO_GEO_PATH . '/includes/admin/class-gmw-peepso-directory-geolocation-admin-settings.php';

		add_filter( 'gmw_admin_settings_setup_defaults', array( $this, 'setup_defaults' ) );
		add_filter( 'gmw_peepso_members_directory_geolocation_admin_settings', array( $this, 'settings' ) );
	}

	/**
	 * Default settings if not exists.
	 *
	 * @param  array $defaults default settings.
	 *
	 * @since 1.0
	 *
	 * @author Eyal Fitoussi
	 *
	 * @return array           modified settings.
	 */
	public function setup_defaults( $defaults ) {

		$defaults['peepso_members_directory_geolocation'] = GMW_Peepso_Directory_Geolocation_Admin_Settings::get_defaults();

		return $defaults;
	}

	/**
	 * Addon settings page function.
	 *
	 * @access public
	 *
	 * @since 1.0
	 *
	 * @author Eyal Fitoussi
	 *
	 * @param array $settings settings.
	 *
	 * @return $settings
	 */
	public function settings( $settings ) {

		$settings = GMW_Peepso_Directory_Geolocation_Admin_Settings::get_settings( 'member' );

		return $settings;
	}
}
new GMW_Peepso_Members_Directory_Geolocation_Admin_Settings();
