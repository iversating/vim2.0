<?php
/**
 * GMW Peepso Geolocation Admin Settings class.
 *
 * @author Eyal Fitoussi
 *
 * @since 1.0
 *
 * @package gmw-peeso-geolocation
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * GMW_Peepso_Geolocation_Admin_Settings
 *
 * @since 1.0
 *
 * @author Eyal Fitoussi
 */
class GMW_Peepso_Geolocation_Admin_Settings {

	/**
	 * __construct function.
	 *
	 * @access public
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'gmw_admin_settings_setup_defaults', array( $this, 'setup_defaults' ) );
		add_filter( 'gmw_peepso_geolocation_admin_settings', array( $this, 'admin_settings' ), 20, 2 );
	}

	/**
	 * Generate default settings values
	 *
	 * @param  [type] $settings default settings.
	 *
	 * @return [type]           [description]
	 */
	public function setup_defaults( $settings ) {

		$settings['peepso_geolocation'] = array(
			'member_location_profile_field' => array(
				'field_id'             => '',
				'address_autocomplete' => 1,
				'locator_button'       => 1,
			),
			'member_location_tab'           => array(
				'usage'                 => 'form',
				'exclude_fields_groups' => array(),
				'exclude_fields'        => array(),
				'form_template'         => 'location-form-tabs-top',
			),
			'displayed_member_location_tab' => array(
				'elements'       => array(
					'address',
					'map',
					'directions_link',
				),
				'address_fields' => array(
					'address',
				),
			),
		);

		return $settings;
	}

	/**
	 * Form settings.
	 *
	 * @param  [type] $settings [description].
	 *
	 * @param  [type] $form     [description].
	 *
	 * @return [type]           [description]
	 */
	public function admin_settings( $settings, $form ) {

		$values = gmw_get_options_group( 'peepso_geolocation' );

		$profile_field = array(
			'disabled' => __( 'Disable', 'gmw-peeso-geolocation' ),
		);

		if ( ! empty( $values['member_location_profile_field']['field_id'] ) ) {
			$profile_field[ $values['member_location_profile_field']['field_id'] ] = $values['member_location_profile_field']['field_id'];
		}

		$settings['member_location_profile_field'] = gmw_get_admin_setting_args(
			array(
				'name'     => 'member_location_profile_field',
				'type'     => 'fields_group',
				'label'    => __( 'Member Location Profile Field', 'gmw-peepso-geolocation' ),
				'desc'     => __( 'Set up the PeepSo\'s profile field that will be used as the address field and will be synced with GEO my WP. Users will need to use this profile field to add and update their location.', 'gmw-peepso-geolocation' ),
				'fields'   => array(
					'field_id'             => gmw_get_admin_setting_args(
						array(
							'name'       => 'field_id',
							'default'    => '',
							'label'      => __( 'PeepSo Profile Field', 'gmw-peeso-geolocation' ),
							'desc'       => __( 'Select the PeepSo Profile field that you wish to use as the address field.', 'gmw-peeso-geolocation' ),
							'type'       => 'select',
							'attributes' => array(
								'data-gmw_ajax_load_options' => 'gmw_get_peepso_profile_fields',
							),
							'options'    => $profile_field,
							'class'      => 'gmw-options-toggle',
							'priority'   => 5,
							'sub_option' => 1,
						)
					),
					'locator_button'       => gmw_get_admin_setting_args(
						array(
							'name'       => 'locator_button',
							'type'       => 'checkbox',
							'default'    => '',
							'label'      => __( 'Locator Button', 'gmw-peeso-geolocation' ),
							'desc'       => __( 'Display a locator button inside the address field ( available with "Text" type profile field only ).', 'gmw-peeso-geolocation' ),
							'cb_label'   => __( 'Enable', 'gmw-peeso-geolocation' ),
							'priority'   => 15,
							'sub_option' => 1,
						)
					),
				),
				'priority' => 5,
			)
		);

		if ( 'google_maps' === GMW()->maps_provider ) {

			$settings['member_location_profile_field']['fields']['address_autocomplete'] = gmw_get_admin_setting_args(
				array(
					'name'       => 'address_autocomplete',
					'type'       => 'checkbox',
					'cb_label'   => 'Enabled',
					'default'    => '',
					'label'      => __( 'Address Autocomplete', 'gmw-peeso-geolocation' ),
					'desc'       => __( 'Enable the address autocomplete feature ( available with "Text" type profile field only ).', 'gmw-peeso-geolocation' ),
					'priority'   => 10,
					'sub_option' => 1,
				)
			);

			$settings['map_settings']['fields']['map_type'] = gmw_get_admin_setting_args(
				array(
					'option_type' => 'map_type',
					'name'        => 'map_type',
					'priority'    => 20,
				)
			);
		}

		// Requires the Users Locator extension.
		if ( class_exists( 'GMW_Users_Locator_Addon' ) ) {

			$settings['member_location_tab'] = gmw_get_admin_setting_args(
				array(
					'name'     => 'member_location_tab',
					'type'     => 'fields_group',
					'label'    => __( 'Logged-in Member Location Tab', 'gmw-peeso-geolocation' ),
					'desc'     => __( 'Use the settings below to setup the Location tab of the logged-in member. By deafult, GEO my WP adds a Location tab to the member\'s profile page where logged-in members can see and update their location.', 'gmw-peeso-geolocation' ),
					'fields'   => array(
						'usage'                 => gmw_get_admin_setting_args(
							array(
								'name'       => 'usage',
								'type'       => 'select',
								'default'    => 'form',
								'label'      => __( 'Location Tab Usage', 'gmw-peepso-geolocation' ),
								'desc'       => __( 'Choose if to displays the location form, a map only showing the member\'s location, or disable the location tab completely.', 'gmw-peeso-geolocation' ),
								'options'    => array(
									'form'     => __( 'Display the location form', 'gmw-peeso-geolocation' ),
									'map'      => __( 'Display map only', 'gmw-peeso-geolocation' ),
									'disabled' => __( 'Disable the location tab', 'gmw-peeso-geolocation' ),
								),
								'class'      => 'gmw-smartbox-not gmw-options-toggle',
								'priority'   => 5,
								'sub_option' => 1,
							)
						),
						'exclude_fields_groups' => gmw_get_admin_setting_args(
							array(
								'option_type' => 'location_form_exclude_fields_groups',
								'name'        => 'exclude_fields_groups',
								'priority'    => 10,
								'sub_option'  => 1,
							)
						),
						'exclude_fields'        => gmw_get_admin_setting_args(
							array(
								'option_type' => 'location_form_exclude_fields',
								'name'        => 'exclude_fields',
								'priority'    => 15,
								'sub_option'  => 1,
							)
						),
						'form_template'         => gmw_get_admin_setting_args(
							array(
								'option_type' => 'location_form_template',
								'name'        => 'form_template',
								'priority'    => 20,
								'sub_option'  => 1,
							)
						),
					),
					'priority' => 10,
				)
			);

			unset(
				$settings['member_location_tab']['fields']['exclude_fields_groups']['options']['contact'],
				$settings['member_location_tab']['fields']['exclude_fields_groups']['options']['days_hours']
			);

			$settings['displayed_member_location_tab'] = gmw_get_admin_setting_args(
				array(
					'name'     => 'displayed_member_location_tab',
					'type'     => 'fields_group',
					'label'    => __( 'Displayed Member Location Tab', 'gmw-peepso-geolocation' ),
					'desc'     => __( 'Setup the location tab that\'s showing when viewing the profile of another member.', 'gmw-peepso-geolocation' ),
					'fields'   => array(
						'elements'       => gmw_get_admin_setting_args(
							array(
								'name'       => 'elements',
								'type'       => 'multiselect',
								'default'    => array(),
								'label'      => __( 'Select elements to display', 'gmw-peepso-geolocation' ),
								'desc'       => __( 'Select the location elements that you would like to display, or leave blank to completely disable the Location tab of the displayed user.', 'gmw-peepso-geolocation' ),
								'options'    => array(
									'address'         => __( 'Address', 'gmw-peepso-geolocation' ),
									'map'             => __( 'Map', 'gmw-peepso-geolocation' ),
									'directions_link' => __( 'Directions link', 'gmw-peepso-geolocation' ),
								),
								'priority'   => 5,
								'sub_option' => 1,
							)
						),
						'address_fields' => gmw_get_admin_setting_args(
							array(
								'option_type' => 'address_fields_output',
								'name'        => 'address_fields',
								'default'     => array( 'address' ),
								'label'       => __( 'Address Fields', 'gmw-peepso-geolocation' ),
								'desc'        => __( 'Select the address fields that you wish to display ( the "address" option needs to be selected in the settings above ).', 'gmw-peepso-geolocation' ),
								'priority'    => 10,
								'sub_option'  => 1,
							)
						),
					),
					'priority' => 15,
				)
			);
		}

		return $settings;
	}
}
new GMW_Peepso_Geolocation_Admin_Settings();
