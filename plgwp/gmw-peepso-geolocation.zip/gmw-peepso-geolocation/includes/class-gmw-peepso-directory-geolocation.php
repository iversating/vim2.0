<?php
/**
 * GEO my WP Peepso Directory Geolocation class.
 *
 * @author Eyal Fitoussi
 *
 * @since 1.0
 *
 * @package gmw-peepso-geolocation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * GMW_Peepso_Directory_Geolocation class.
 *
 * @author Eyal Fitoussi
 *
 * @since 1.0
 */
class GMW_Peepso_Directory_Geolocation {

	/**
	 * Prefix.
	 *
	 * @since 1.0
	 *
	 * @var string
	 */
	public $prefix = 'ppsomdg';

	/**
	 * Peepso component.
	 *
	 * @since 1.0
	 *
	 * @var string
	 */
	public $component = 'member';

	/**
	 * Options/settings.
	 *
	 * @since 1.0
	 *
	 * @var array
	 */
	public $options = array();

	/**
	 * Gmw_location database fields that will be pulled in the search query
	 *
	 * The fields can be modified using the filter 'gmw_database_fields'
	 *
	 * @since 1.0
	 *
	 * @var array
	 */
	public $db_fields = array(
		'ID as location_id',
		'object_type',
		'object_id',
		'user_id',
		'latitude as lat',
		'longitude as lng',
		'street',
		'city',
		'region_name',
		'postcode',
		'country_code',
		'address',
		'formatted_address',
		'map_icon',
	);

	/**
	 * Form values.
	 *
	 * @since 1.0
	 *
	 * @var array
	 */
	public $form = array(
		'addon'    => '',
		'prefix'   => '',
		'address'  => '',
		'lat'      => '',
		'lng'      => '',
		'distance' => '',
		'radius'   => '', // Duplciate of distance, to support other queries and elements of the plugin.
		'units'    => 'imperial',
		'options'  => array(),
	);

	/**
	 * GEO my WP locations.
	 *
	 * @since 1.0
	 *
	 * @var array
	 */
	public $locations = array();

	/**
	 * Map locations holder.
	 *
	 * @since 1.0
	 *
	 * @var array
	 */
	public $map_locations = array();

	/**
	 * Objects without location enabled by default.
	 *
	 * @since 1.0
	 *
	 * @var boolean
	 */
	public $enable_objects_without_location = true;

	/**
	 * GEO my WP locations holder.
	 *
	 * @since 1.0
	 *
	 * @var array
	 */
	public $locations_data = array();

	/**
	 * IDs of objects with location.
	 *
	 * @since 1.0
	 *
	 * @var array
	 */
	public $objects_id = array();

	/**
	 * Check if map was already executed. We need to execute it only once per query.
	 *
	 * @since 1.0
	 *
	 * @var boolean
	 */
	public $map_executed = false;

	/**
	 * Get plugin options.
	 *
	 * @since 1.0
	 *
	 * @return [type] [description]
	 */
	public function get_options() {
		return array();
	}

	/**
	 * Constructor.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 */
	public function __construct() {

		// Get options.
		$this->options = $this->get_options();

		// Allow filtering the options.
		$this->options = apply_filters( 'gmw_' . $this->prefix . '_form_options', $this->options, $this );

		// abort if options disabled.
		if ( empty( $this->options['enabled'] ) ) {
			return;
		}

		$this->form['options'] = $this->options;
		$this->form['addon']   = 'gmw_peepso_' . $this->component . 's_directory_geolocation';
		$this->form['prefix']  = $this->prefix;
		$this->form['units']   = 'metric' === $this->options['units'] ? 'metric' : 'imperial';

		$this->labels        = $this->labels();
		$this->radius_values = str_replace( ' ', '', explode( ',', $this->options['radius'] ) );

		if ( isset( $_COOKIE[ 'gmw_' . $this->prefix . '_address' ] ) && 'undefined' !== $_COOKIE[ 'gmw_' . $this->prefix . '_address' ] ) {

			$this->form['address'] = urldecode( wp_unslash( $_COOKIE[ 'gmw_' . $this->prefix . '_address' ] ) ); // WPCS: sanitization ok.
		}

		// get the default latitude value from URL if exists.
		if ( isset( $_COOKIE[ 'gmw_' . $this->prefix . '_lat' ] ) && 'undefined' !== $_COOKIE[ 'gmw_' . $this->prefix . '_lat' ] ) {

			$this->form['lat'] = urldecode( wp_unslash( $_COOKIE[ 'gmw_' . $this->prefix . '_lat' ] ) ); // WPCS: sanitization ok.
		}

		// get the default latitude value from URL if exists.
		if ( isset( $_COOKIE[ 'gmw_' . $this->prefix . '_lng' ] ) && 'undefined' !== $_COOKIE[ 'gmw_' . $this->prefix . '_lng' ] ) {

			$this->form['lng'] = urldecode( wp_unslash( $_COOKIE[ 'gmw_' . $this->prefix . '_lng' ] ) ); // WPCS: sanitization ok.
		}

		// if single, default value get it from the options.
		if ( 1 === count( $this->radius_values ) ) {

			$this->form['distance'] = end( $this->radius_values );

			// check in URL if exists.
		} elseif ( isset( $_COOKIE[ 'gmw_' . $this->prefix . '_radius' ] ) && 'undefined' !== $_COOKIE[ 'gmw_' . $this->prefix . '_radius' ] ) {
			$this->form['distance'] = urldecode( wp_unslash( $_COOKIE[ 'gmw_' . $this->prefix . '_radius' ] ) ); // WPCS: sanitization ok.
		}

		$this->form['radius'] = $this->form['distance'];

		// action hooks/ filters.
		add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ) );
	}

	/**
	 * Enqueue scripts and styles.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 */
	public function register_scripts() {

		GMW_Maps_API::load_scripts( array( 'markers_clusterer' ) );

		wp_enqueue_style( 'gmw-peepso-geo' );
		wp_enqueue_script( 'gmw-peepso-geo' );

		$args = array(
			'prefix'                => $this->prefix,
			'component'             => $this->component,
			'sortby_distance_label' => esc_attr( $this->labels['sortby_distance'] ),
		);

		wp_localize_script( 'gmw-peepso-geo', 'gmwPeepsoGeo', $args );

		do_action( 'gmw_element_loaded', 'gmw_peepso_directory_geolocation', $this );
	}

	/**
	 * Form labels.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @return [type] [description]
	 */
	public function labels() {

		$output = apply_filters(
			'gmw_' . $this->prefix . '_labels',
			array(
				'address_field'       => __( 'Address', 'gmw-peepso-geolocation' ),
				'address_placeholder' => __( 'Enter Address...', 'gmw-peepso-geolocation' ),
				'radius_field'        => __( 'Radius', 'gmw-peepso-geolocation' ),
				'miles'               => __( 'Miles', 'gmw-peepso-geolocation' ),
				'kilometers'          => __( 'Kilometers', 'gmw-peepso-geolocation' ),
				'sortby_distance'     => __( 'Distance', 'gmw-peepso-geolocation' ),
				'get_directions'      => __( 'Get directions', 'gmw-peepso-geolocation' ),
			)
		);

		return $output;
	}

	/**
	 * Generate address field in the search form.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @return [type] [description]
	 */
	public function get_form_address_field() {

		$prefix = esc_attr( $this->prefix );
		$args   = array(
			'id'             => $this->prefix,
			'slug'           => 'address',
			'name'           => 'address',
			'is_array'       => false,
			'type'           => 'text',
			'label_disabled' => true,
			'placeholder'    => $this->labels['address_placeholder'],
			'value'          => $this->form['address'],
			'class'          => ! empty( $this->options['address_autocomplete'] ) ? 'gmw-peepso-address-field gmw-address-autocomplete ps-input' : 'ps-input',
			'inner_element'  => false,
			'wrapper_open'   => false,
			'wrapper_close'  => false,
		);

		$wrap_class = '';
		$locator    = '';

		if ( ! empty( $this->options['locator_button'] ) ) {
			$wrap_class .= ' gmw-locator-button-enabled';
			$locator     = '<i class="gmw-peepso-locator-button inside gmw-icon-target-light" data-locator_submit="1" data-form_id="' . $prefix . '"></i>';
		}

		$field  = '';
		$field .= '<div id="gmw-address-field-' . $prefix . '-wrapper" class="gmw-peepso-address-field-wrapper ps-members__filter' . $wrap_class . '">';
		$field .= '<div class="ps-members__filter-label">' . esc_attr( $this->labels['address_field'] ) . '</div>';
		$field .= '<div class="gmw-field-inner">';
		$field .= $locator;
		$field .= gmw_get_form_field( $args, $this->form );
		$field .= '</div>';
		$field .= '</div>';

		return $field;
	}

	/**
	 * Generate Radius field in the search form.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @return [type] [description]
	 */
	public function get_form_radius_field() {

		$prefix           = esc_attr( $this->prefix );
		$default_radius   = apply_filters( 'gmw_' . $prefix . '_search_form_default_radius_value', '', $this );
		$dropdown_enabled = count( $this->radius_values ) > 1 ? true : false;
		$options          = array();

		if ( $dropdown_enabled ) {

			$options[ $default_radius ] = 'metric' === $this->form['units'] ? $this->labels['kilometers'] : $this->labels['miles'];

			foreach ( $this->radius_values as $value ) {
				$options[ $value ] = $value;
			}
		}

		$args = array(
			'id'             => $prefix,
			'slug'           => 'distance',
			'name'           => 'distance',
			'type'           => $dropdown_enabled ? 'select' : 'hidden',
			'label_disabled' => true,
			'value'          => $this->form['distance'],
			'class'          => 'ps-input ps-input--sm ps-input--select gmw-peepso-distance-field',
			'wrapper_close'  => false,
			'wrapper_open'   => false,
			'inner_element'  => false,
			'options'        => $options,
		);

		$field = '';

		if ( $dropdown_enabled ) {

			$field .= '<div id="gmw-distance-field-' . $prefix . '-wrapper" class="gmw-peepso-distance-field-wrapper ps-members__filter">';
			$field .= '<div class="ps-members__filter-label">' . esc_attr( $this->labels['radius_field'] ) . '</div>';
			$field .= gmw_get_form_field( $args );
			$field .= '</div>';

		} else {
			$field .= gmw_get_form_field( $args );
		}

		return $field;
	}

	/**
	 * Extend the search form with geolocation fields.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @return [type] [description]
	 */
	public function extend_search_from() {

		$prefix                       = esc_attr( $this->prefix );
		$search_form                  = array();
		$search_form['wrapper']       = '<div id="gmw-' . $prefix . '-filters-inner" class="gmw-peepso-filters-inner ps-members__filters-inner">';
		$search_form['address_field'] = $this->get_form_address_field();
		$search_form['radius_field']  = $this->get_form_radius_field();
		$search_form['coords']        = '<input type="hidden" name="lat" id="gmw-lat-' . $prefix . '" class="gmw-peepso-latitude-field" value="' . esc_attr( $this->form['lat'] ) . '" />';
		$search_form['coords']       .= '<input type="hidden" name="lng" id="gmw-lng-' . $prefix . '" class="gmw-peepso-longitude-field" value="' . esc_attr( $this->form['lng'] ) . '" />';
		$search_form['/wrapper']      = '</div>';

		$search_form = apply_filters( 'gmw_' . $prefix . '_search_form_html', $search_form, $this );
		$search_form = implode( ' ', $search_form );

		return $search_form;
	}

	/**
	 * Generate the map element.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 */
	public function get_map_element() {

		// map args.
		$args = array(
			'map_id'     => $this->prefix,
			'map_type'   => $this->form['addon'],
			'prefix'     => $this->prefix,
			'map_width'  => $this->options['map_width'],
			'map_height' => $this->options['map_height'],
			'form_data'  => $this->form,
		);

		// display the map element.
		return '<div id="gmw-' . $this->prefix . '-results-map-holder">' . gmw_get_map_element( $args, $this->form ) . '</div>'; // WPCS XSS ok.
	}

	/**
	 * Execute the map.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 */
	public function execute_map() {

		// create the map object.
		$map_args = array(
			'map_id'               => $this->prefix,
			'map_type'             => $this->form['addon'],
			'prefix'               => $this->prefix,
			'info_window_type'     => 'standard',
			'info_window_ajax'     => false,
			'info_window_template' => 'default',
			'group_markers'        => 'markers_clusterer',
			'render_on_page_load'  => false,
		);

		$map_options = array(
			'zoom'      => 'auto',
			'mapTypeId' => ! empty( $this->options['map_type'] ) ? $this->options['map_type'] : 'ROADMAP',
		);

		$user_position = array(
			'lat'        => $this->form['lat'],
			'lng'        => $this->form['lng'],
			'address'    => $this->form['address'],
			'map_icon'   => GMW()->default_icons['user_location_icon_url'],
			'icon_size'  => GMW()->default_icons['user_location_icon_size'],
			'iw_content' => __( 'You are here', 'gmw-peepso-geolocation' ),
			'iw_open'    => false,
		);

		// triggers map on page load.
		$map_args = gmw_get_map_object( $map_args, $map_options, $this->map_locations, $user_position, array() );
		$map_args = wp_json_encode( $map_args );
		?>
		<script type="text/javascript">
			var gmwMapArgs = <?php echo $map_args; ?>;
		</script>
		<?php
	}

	/**
	 * Get locations from GEO my WP's database based on address and radius.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @return [type] [description]
	 */
	public function get_locations() {

		if ( ! empty( $this->form['address'] ) && ( empty( $this->form['lat'] ) || empty( $this->form['lng'] ) ) ) {

			include_once GMW_PATH . '/includes/gmw-geocoder.php';

			$geocoded_address = gmw_geocoder( $this->form['address'] );

			if ( empty( $geocoded_address ) || isset( $geocoded_address['error'] ) ) {

				// return no results if geocoding failed.
				$this->locations_data = array();
				$this->objects_id     = array();

				return $this->objects_id;
			}

			$this->form['lat'] = $geocoded_address['lat'];
			$this->form['lng'] = $geocoded_address['lng'];
		}

		$args = array(
			'object_type' => 'user',
			'lat'         => $this->form['lat'],
			'lng'         => $this->form['lng'],
			'radius'      => ! empty( $this->form['radius'] ) ? $this->form['radius'] : false,
			'units'       => $this->form['units'],
		);

		// get locations from GEO my WP db.
		$gmw_locations        = GMW_Location::get_locations_data( $args, array(), array(), 'gmw_locations', $this->db_fields );
		$this->locations_data = $gmw_locations['locations_data'];
		$this->objects_id     = $gmw_locations['objects_id'];

		return $this->objects_id;
	}

	/**
	 * Generate object location for map.
	 *
	 * @param  object $object      object data.
	 *
	 * @param  object $info_window object info-window.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @return [type]                  [description]
	 */
	public function get_map_location( $object, $info_window ) {

		// add lat/lng locations array to pass to map.
		return apply_filters(
			'gmw_' . $this->prefix . '_map_location',
			array(
				'ID'                  => $object->object_id,
				'lat'                 => $object->lat,
				'lng'                 => $object->lng,
				'map_icon'            => '',
				'icon_size'           => GMW()->default_icons['location_icon_size'],
				'info_window_content' => $info_window,
			),
			$object,
			$this
		);
	}

	/**
	 * Generate distance to each item in the results.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @param object $object  object ( group/member ) data.
	 */
	public function get_distance( $object ) {

		$output = '<span class="gmw-item gmw-item-distance">' . esc_attr( $object->distance ) . ' ' . esc_attr( $object->units ) . '</span>';

		// display the distance in results.
		return apply_filters( 'gmw_' . $this->prefix . '_' . $this->component . '_distance', $output, $object, $this ); // WPCS: XSS ok.
	}

	/**
	 * Generate object address.
	 *
	 * @param  object $object  object ( group/member ) data.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @return [type]         [description]
	 */
	public function get_address( $object ) {

		$address = gmw_get_location_address( $object, $this->options['address_fields'] );
		$output  = '';

		if ( ! empty( $address ) ) {
			$output .= '<span class="gmw-item gmw-item-address"><i class="gmw-icon-location-thin"></i>' . esc_attr( $address ) . '</span>'; // WPCS: XSS ok.
		}

		return apply_filters( 'gmw_' . $this->prefix . '_' . $this->component . '_address', $output, $object, $this );
	}

	/**
	 * Get location meta for each item in the results.
	 *
	 * @param object $object  object ( group/member ) data.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @return [type] [description]
	 */
	public function get_location_meta( $object ) {

		$output = '<div class="gmw-peepso-location-meta-wrapper">';

		if ( ! empty( $this->options['address_fields'] ) ) {
			$output .= self::get_address( $object );
		}

		if ( ! empty( $this->options['distance'] ) && ! empty( $object->distance ) ) {
			$output .= self::get_distance( $object );
		}

		if ( ! empty( $this->options['directions_link'] ) ) {

			$directions = gmw_get_directions_link( $object, $this->form, $this->labels['get_directions'] );

			$output .= '<span class="gmw-item gmw-directions-link-wrapper">' . $directions . '</span>';
		}

		$output .= '</div>';

		return $output;
	}

	/**
	 * Append location data to each item in teh results.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @since 1.0
	 *
	 * @param integer $object_id the object ID.
	 */
	public function add_elements_to_results( $object_id ) {

		$locations = $this->locations_data;

		if ( empty( $object_id ) || empty( $locations[ $object_id ] ) ) {
			return;
		}

		// Needs to be an object.
		$object = (object) $locations[ $object_id ];

		if ( ! $this->map_executed ) {

			$this->execute_map();

			$this->map_executed = true;
		}

		echo $this->get_location_meta( $object ); // WPCS: XSS ok.
	}
}
