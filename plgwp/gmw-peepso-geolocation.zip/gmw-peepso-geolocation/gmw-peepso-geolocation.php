<?php
/*
Plugin Name: GMW Add-on - Peepso Geolocation
Plugin URI: http://www.geomywp.com
Description: Enhance Peepso plugins with geolocation and mapping features.
Author: Eyal Fitoussi
Version: 0.1-beta1
Author URI: http://www.geomywp.com
Requires at least: 4.5
Tested up to: 6.0.0
GEO my WP: 4.0+
Buddypress: 2.8+
Text Domain: gmw-peepso-geolocation
Domain Path: /languages/
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// look for GMW add-on registration class.
if ( ! class_exists( 'GMW_Addon' ) ) {
	return;
}

/**
 * GMW_Groups_Locator
 */
class GMW_Peepso_Geolocation_Addon extends GMW_Addon {

	/**
	 * Slug.
	 *
	 * @var string
	 */
	public $slug = 'gmw_peepso_geolocation';

	/**
	 * Name.
	 *
	 * @var string
	 */
	public $name = 'Peepso Geolocation';

	/**
	 * Prefix.
	 *
	 * @var string
	 */
	public $prefix = 'peepso_geo';

	/**
	 * Version.
	 *
	 * @var string
	 */
	public $version = '0.1';

	/**
	 * License name.
	 *
	 * @var string
	 */
	public $license_name = 'gmw_peepso_geolocation';

	/**
	 * Item name.
	 *
	 * @var string
	 */
	public $item_name = 'Peepso Geolocation';

	/**
	 * Item ID.
	 *
	 * @var integer
	 */
	public $item_id = 0;

	/**
	 * Author.
	 *
	 * @var string
	 */
	public $author = 'Eyal Fitoussi';

	/**
	 * GMW required version.
	 *
	 * @var string
	 */
	public $gmw_min_version = '4.0';

	/**
	 * Text domain.
	 *
	 * @var string
	 */
	public $textdomain = 'gmw-peepso-geolocation';

	/**
	 * Full path.
	 *
	 * @var [type]
	 */
	public $full_path = __FILE__;

	/**
	 * Peepso extension page.
	 *
	 * @var string
	 */
	public $addon_page = 'https://geomywp.com/extensions/peepso-geolocation/';

	/**
	 * Support page.
	 *
	 * @var string
	 */
	public $support_page = 'https://geomywp.com/support/#gmw-premium-support';

	/**
	 * Docs page.
	 *
	 * @var string
	 */
	public $docs_page = 'http://docs.geomywp.com/';

	public $is_core = true;

	/**
	 * Plugin's description.
	 *
	 * @since 1.0
	 *
	 * @var string
	 */
	public function get_description() {
		return __( 'Enhance Peepso plugin with geolocation features.', 'gmw-peepso-geolocation' );
	}

	/**
	 * Required plugins.
	 *
	 * @since 1.0
	 *
	 * @return [type] [description]
	 */
	public function required() {
		return array(
			'plugins' => array(
				array(
					'function' => 'PeepSo',
					'notice'   => __( 'Peepso Geolocation extension requires Peepso plugin version 5.0 or higher.', 'gmw-peepso-geolocation' ),
				),
			),
		);
	}

	/**
	 * Settings groups
	 *
	 * @return [type] [description]
	 */
	public function admin_settings_groups() {

		return array(
			array(
				'slug'     => 'peepso_geolocation',
				'label'    => __( 'Peepso Geolocation', 'gmw-peepso-geolocation' ),
				'priority' => 20,
			),
			array(
				'slug'     => 'peepso_members_directory_geolocation',
				'label'    => __( 'Peepso Members Directory', 'gmw-bp-members-directory-geolocation' ),
				'fields'   => array(),
				'priority' => 20,
			),
		);
	}

	/**
	 * Instance of Peepso Geolocation.
	 *
	 * @since 1.0
	 *
	 * @var null
	 */
	private static $instance = null;

	/**
	 * Create new instance.
	 *
	 * @since 1.0
	 *
	 * @return [type] [description]
	 */
	public static function get_instance() {

		if ( self::$instance == null ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register scripts
	 */
	public function enqueue_scripts() {

		if ( ! IS_ADMIN ) {
			wp_register_script( 'gmw-peepso-geo', $this->plugin_url . '/assets/js/gmw.peepso.min.js', array( 'jquery', 'gmw' ), $this->version, true );
			wp_register_style( 'gmw-peepso-geo', $this->plugin_url . '/assets/css/gmw.peepso.min.css', array(), $this->version );
		}
	}

	/**
	 * Pre init functions.
	 *
	 * @since 1.0
	 */
	public function pre_init() {

		parent::pre_init();

		// Generate PeepSo tempaltes folder URL.
		//PeepSo::add_autoload_directory( dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR );
		PeepSoTemplate::add_template_directory( plugin_dir_path( __FILE__ ) );

		// include in admin only.
		if ( IS_ADMIN && ! defined( 'DOING_AJAX' ) ) {
			include_once 'includes/admin/class-gmw-peepso-geolocation-admin-settings.php';
		}

		include_once 'includes/members/loader.php';
	}
}
GMW_Addon::register( 'GMW_Peepso_Geolocation_Addon' );
