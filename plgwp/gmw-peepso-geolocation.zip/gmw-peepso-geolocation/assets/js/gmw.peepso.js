jQuery( document ).ready( function( $ ) {
	
	// Add "Distance" option to sort by filter. 	
	$( '.ps-input--select.ps-js-members-sortby' ).append(
		$('<option>', {
	    	value : 'distance',
	    	text  : gmwPeepsoGeo.sortby_distance_label
		}
	));

	// Update cookies.
	function gmw_psogeo_update_cookies( save ) {

		if ( save ) {

			GMW.set_cookie( 'gmw_' + gmwPeepsoGeo.prefix + '_address', jQuery( '#gmw-address-field-' + gmwPeepsoGeo.prefix ).val(), 1 );
			GMW.set_cookie( 'gmw_' + gmwPeepsoGeo.prefix + '_lat', jQuery( '#gmw-lat-' + gmwPeepsoGeo.prefix ).val(), 1 );	
			GMW.set_cookie( 'gmw_' + gmwPeepsoGeo.prefix + '_lng', jQuery( '#gmw-lng-' + gmwPeepsoGeo.prefix ).val(), 1 );
			GMW.set_cookie( 'gmw_' + gmwPeepsoGeo.prefix + '_radius', jQuery( '#gmw-distance-field-' + gmwPeepsoGeo.prefix ).val(), 1 );

		} else {

			GMW.set_cookie( 'gmw_' + gmwPeepsoGeo.prefix + '_address', '', 1 );
			GMW.set_cookie( 'gmw_' + gmwPeepsoGeo.prefix + '_lat', jQuery( '' ).val(), 1 );	
			GMW.set_cookie( 'gmw_' + gmwPeepsoGeo.prefix + '_lng', jQuery( '' ).val(), 1 );
			GMW.set_cookie( 'gmw_' + gmwPeepsoGeo.prefix + '_radius', jQuery( '' ).val(), 1 );
		}
	}

	function gmw_psogeo_submit_form() {
		jQuery( '.ps-js-members-gender' ).trigger( 'change' );
	}

	$( document ).ajaxComplete(function( event, request, settings ) {

		if ( typeof settings.url !== 'undefined' && settings.url.indexOf( 'peepsoajax/membersearch.search' ) >= 0 && typeof gmwMapArgs !== 'undefined' ) {
			
			var updateMap     = true;
			var appendResults = false;

			// Check if this is the first page of the results.
			// If so we do not append markers but start a new cycle of markers.
			if ( request.responseJSON.data.page == 1 ) {

				// If no results were found in the new page, we need to clear the map.
				if ( request.responseJSON.data.members_page == 0 ) {
					gmwMapArgs.locations = [];
				}

				// When not the first page and there are results, we need to append them to exising results.
			} else if ( request.responseJSON.data.members_page > 0 ) {

				appendResults = true;

				// Otherwise, if not first page and no results were found, no need to update the map.
			} else {
				updateMap = false;
			}

			if ( updateMap == true ) {

				// Generate mew map.
				if ( typeof GMW_Maps.peepsoGeo === 'undefined' ) {

					// New map object.
					GMW_Maps.peepsoGeo = new GMW_Map( gmwMapArgs.settings, gmwMapArgs.map_options, {} );

					// render the map.
					GMW_Maps.peepsoGeo.render( gmwMapArgs.locations, gmwMapArgs.user_location );

					// update an existing map.
				} else {
					GMW_Maps.peepsoGeo.update( gmwMapArgs.locations, gmwMapArgs.user_location, appendResults );
				}

				// Reset the locations object.
				gmwMapArgs.locations = [];
			}
		}
	}); 

	//$( '#gmw-peepso-geo-filters-wrapper' ).detach().show().insertBefore( '.ps-members__filters.ps-js-members-filters' );
	$( '#gmw-' +  gmwPeepsoGeo.prefix + '-filters-inner' ).detach().show().prependTo( '.ps-members__filters.ps-js-members-filters' );
	
	// Move map from its temporery holder to above the list of results.
	$( '#gmw-' + gmwPeepsoGeo.prefix + '-results-map-holder' ).children().detach().insertBefore( '.ps-members.ps-js-members' );
	$( '#gmw-' + gmwPeepsoGeo.prefix + '-results-map-holder' ).remove();

	// Populdate coordiantes and submit form when selecting from address autocomplete.
	GMW.add_action( 'gmw_address_autocomplete_place_changed', function( place, autocomplete, field_id, input_field, options ) {

		if ( ! place.geometry || 'gmw-address-field-' + gmwPeepsoGeo.prefix != field_id ) { 
			return false;
		}

		jQuery( '#gmw-lat-' + gmwPeepsoGeo.prefix ).val( place.geometry.location.lat() );
		jQuery( '#gmw-lng-' + gmwPeepsoGeo.prefix ).val( place.geometry.location.lng() );

		gmw_psogeo_submit_form();
	});

	// When click on the locator button.
    jQuery( '.gmw-peepso-locator-button' ).click( function() {

    	GMW.locator_button_success = function( results ) {
    	
    		// add coords value to hidden fields
    		$( '.gmw-peepso-address-field' ).val( results.formatted_address );
    		$( '.gmw-peepso-locator-button' ).removeClass( 'animate-spin' );

    		jQuery( '#gmw-lat-' + gmwPeepsoGeo.prefix ).val( results.latitude );
			jQuery( '#gmw-lng-' + gmwPeepsoGeo.prefix ).val( results.longitude );

    		gmw_psogeo_submit_form();
    	};

    	GMW.locator_button_failed = function( status ) {
    			
    		// alert failed message
        	alert( 'We were unable to detect your location. Please try again.' );

        	console.log( 'Geocoder failed due to: ' + status );

        	$( '.gmw-peepso-locator-button' ).removeClass( 'animate-spin' );
    	};

        GMW.locator_button( jQuery( this ) );
    });

	// Submit form when selecting radius value or when address changes.
	jQuery( '#gmw-distance-field-' + gmwPeepsoGeo.prefix + ',#gmw-address-field-' + gmwPeepsoGeo.prefix ).change( function() {
		gmw_psogeo_submit_form();
	});

	/**
	 * Geocode addess on enter key in address field
	 * 
	 * @return {[type]} [description]
	 */
	jQuery( '#gmw-address-field-' + gmwPeepsoGeo.prefix ).keyup( function( event ){

		if ( event.which != 13 ) {

		    jQuery( '#gmw-lat-' + gmwPeepsoGeo.prefix ).val( '' );
			jQuery( '#gmw-lng-' + gmwPeepsoGeo.prefix ).val( '' );
		   	
		   	// if enter key pressed submit the directory form.
		} else {

		    gmw_psogeo_submit_form();
		}

		return;
	});

	/**
	 * In case for submitted via page load.
	 *
	 * Save form values in cookies.
	 *
	 * #dir-groups-search-form for Nouveau template and #search-groups-form for Legacy.
	 *
	 * @return {[type]}  [description]
	 */
	$( '.ps-members__filter' ).find( 'input:text,select,input:checkbox' ).on( 'change', function() {

		gmw_psogeo_update_cookies( true );

		return true;
	});
});

// Add Google Marker Cluster
if ( gmwVars.mapsProvider === 'google_maps' ) { 

	GMW.add_filter( 'gmw_map_init', function( map ) {

		if ( typeof( map.markerGroupingTypes.markers_clusterer ) !== 'undefined' ) {
			return map;
		}

		map.markerGroupingTypes.markers_clusterer = {

			'init' : function( mapObject ) {

				// initialize markers clusterer if needed and if exists
			    if ( typeof MarkerClusterer === 'function' ) {
			    	
			    	// init new clusters object
					mapObject.clusters = new MarkerClusterer( 
						mapObject.map, 
						mapObject.markers,
						{
							imagePath    : mapObject.clustersPath,
							clusterClass : mapObject.prefix + '-cluster cluster',
							maxZoom 	 : 15 
						}
					);
				} 
			},

			'clear' : function( mapObject ) {

				// initialize markers clusterer if needed and if exists
			    if ( typeof MarkerClusterer === 'function' ) {

			    	// remove existing clusters
			    	if ( mapObject.clusters != false ) {		
			    		mapObject.clusters.clearMarkers();
			    	}
				} 
			},

			'addMarker' : function( marker, mapObject ) {

				mapObject.clusters.addMarker( marker );	
			},

			'markerClick' : function( marker, mapObject ) {

				google.maps.event.addListener( marker, 'click', function() {

					mapObject.markerClick( this );
				});	
			}
		};

		return map;
	} );
}

// Add Google Marker Cluster
if ( gmwVars.mapsProvider === 'leaflet' ) { 

	GMW.add_filter( 'gmw_map_init', function( map ) {

		if ( typeof( map.markerGroupingTypes.markers_clusterer ) !== 'undefined' ) {
			return map;
		}

		map.markerGroupingTypes.markers_clusterer = {

			// initiate clusters.
			'init' : function( mapObject ) {

				// initialize markers clusterer if needed and if exists
			    if ( typeof L.markerClusterGroup === 'function' ) {
			    		
			    	mapObject.clusters = L.markerClusterGroup( mapObject.options.markerClustersOptions );

			    	mapObject.map.addLayer( mapObject.clusters );
				} 
			},

			// Clear clusters.
			'clear' : function( mapObject ) {

			    if ( typeof L.markerClusterGroup === 'function' ) {

			    	// remove existing clusters
			    	if ( mapObject.clusters != false ) {		
			    		mapObject.clusters.clearLayers();
			    	}
				} 
			},

			// Add marker to the cluster.
			'addMarker' : function( marker, mapObject ) {
				mapObject.clusters.addLayer( marker );	
			},

			// marker click action to open info-window.
			'markerClick' : function( marker, mapObject ) {
				
				marker.on( 'click', function() {

					mapObject.markerClick( this );
				});
			}
		};

		return map;
	} );
}
