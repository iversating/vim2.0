# gmw-peepso-geolocation
Integration between PeepSo plugin and GEO my WP.
