<?php
if ( ! defined( 'WFACP_TEMPLATE_DIR' ) ) {
	return '';
}
?>
<div class="wfacp_qv-opac"></div>
<div class="wfacp_qv-panel">
    <div class="wfacp_qv-preloader wfacp_qv-opl">
        <div class="wfacp_qv-speeding-wheel"></div>
    </div>
    <div class="wfacp_qv-modal"></div>
</div>
