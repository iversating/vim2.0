<?php
/* Silence is golden, and we agree. */
