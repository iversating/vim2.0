<div class="wfocu_clear_20"></div>
 <div id="offer_settings_btn_bottom" class="wfocu_form_submit wfocu_btm_grey_area wfocu_clearfix" v-if="current_offer_id>0 ">

    <a href="javascript:void(0)" v-on:click="delete_offer" class="wfocu_del_offer_style wfocu_alert_btn wfocu_left"><?php _e( 'Remove', 'woofunnels-upstroke-one-click-upsell' ) ?></a>
    <div class=" wfocu_btm_save_wrap wfocu_clearfix">

    </div>
 </div>