=== FunnelKit One Click Upsells ===

= 3.4.2 (31/10/2022) =
* Added: New filter to modify shipping methods priority on upsell pages for dynamic shipping. (#1145)
* Improved: Compatibility with PYS CostOfGoods plugin updated. (#1452)
* Fixed: Offer payments issue with WooCommerce Payments. (#1436)
* Fixed: Admin menu not showing for user roles except adminstrator. (#3307)
* Fixed: Pass current user ID as external ID to Facebook pixel event to avoid mismatch of external_id. (#1458)
* Fixed: One Click Upsells: Order refund metabox was not showing in some cases. (#3266)

= 3.4.1 (05/10/2022) =
* Tweak: Re-branding related changes.

= 3.4.0 (29/09/2022) =
* Added: Compatibility with Bricks themes. (#1347)
* Added: Filter hook 'wfocu_script_tags' to allow dynamic attributes to the script tag for the tracking snippets. (#1322)
* Added: Shortcode added to display product original sale price. (#1360)
* Added: Javascript filters to skip tracking in favor of cookie consent plugins. (#1305)
* Added: Compatibility with Kadence theme. (#1412)
* Improved: Compatibility with elementor 3.7.0 version. (#455)
* Improved: WooCommerce multicurrency compatibility updated to check if enabled in settings before conversion. (#1320)
* Improved: Google ads enhanced e-commerce data pass with the purchase events. (#1324)
* Improved: The product description widget will now show product description from the parent in case of variation product. (#1335)
* Improved: Handle dynamic shipping taxes for the offers when tax is exempted in order. (#66)
* Improved: Behaviour for the cancel and upgrade feature modified in favor of processing fewer refunds. (#1331)
* Improved: Author support added for the offer post type. (#1376)
* Improved: Method to get the client IP address to improve event match quality for Facebook conversion events. (#1391)
* Improved: Facebook events will now have external_id param for the logged-in user to improve event match quality. (#1371)
* Improved: Facebook conversion api events improved to pass _fbc param in cases when pixels were not dropped. (#1354)
* Fixed: Issue with the WooCommerce Payments, refunding offer was not working. (#1318)
* Fixed: Block Compatibility issues with WordPress v6.0 (#1316)
* Fixed: An issue of reporting data not getting inserted properly in MySQL table due to column length. (#1333)
* Fixed: Few Styling-related bug fixes for the Gutenberg image gallery block. (#1334)
* Fixed: Few PHP notices resolved for PHP v8.1. (#1369)
* Fixed: Offer refund was failing in some cases for the authorize.net CIM gateway v3.7.2 (#1392)
* Fixed: Tax on upsell offers not getting applied for some cases with default customer address set add shop address. (#1396)
* Fixed: Deprecated PHP warning showing up during Facebook pixel after WooCommerce v6.0.0 when coupon used in the order. (#1414)
* Fixed: Offer payments were failing for WooCommerce PayPal payments in some cases when subscriptions in the primary order. (#1423)
* Fixed: Javascript error showing up when jquery is loaded deferred for the checkout. (#1426)

= 3.3.6 (10/05/2022) =
* Fixed: Offer Payments were failing with WooCommerce Square gateway v3.0.0 in case of different shipping address than billing. (#1312)

= 3.3.5 (09/05/2022) =
* Added: Support for Featured image for the offer post type. (#1289)
* Improved: Compatibility updated with Woodmart theme. (#1288)
* Improved: Avoid setting up upsell sessions multiple times in any case of conflict. (#1285).
* Improved: Facebook conversion API events failing in some cases of the backward cache of browsers. (#1295)
* Fixed: Pass item-total instead of item subtotal to cover discount cases at the item level in GA analytics. (#1277)
* Fixed: Offer Payments and primary checkout payments were not working with WooCommerce Square gateway v3.0.0 (#1306)
* Fixed: Checkout payments done by WooCommerce PayPal payment's credit card method was not working in case of 3ds since v4.1.0. (#1308)

= 3.3.4 (06/04/2022) =
* Fixed: Offer payments were failing for the WooCommerce Payments v3.9.0. (#1279)

= 3.3.3 (29/03/2022) =
* Added: Compatibility with Woodmart theme. (#1267)
* Improved: Improved Google Tag execution to prevent double events in case of Backward/Forward browser cache. (#1262)
* Fixed: Offer payments were failing for the WooCommerce Payments v3.9.0. (#1269)

= 3.3.2 (23/02/2022) =
* [Critical] Fixed: PHP Errors showing up on offer pages built using elementor on elementor version 3.6.0. (#1130)
* Fixed: Google ads conversion label passing with the custom events. (#1261)

= 3.3.1 (16/02/2022) =
* Fixed: Issue with a variable product purchase, variation ID was not getting attached as item meta since the last release. (#1251)
* Fixed: Issue with Upsell Payments failing for WooCommerce PayPal Payments gateway returning invalid token in some rare cases. (#1254)
* Fixed: A PHP notice showing up on update_order_review ajax request in some scenarios when WP_DEBUG set to TRUE. (#1256)

= 3.3.0 (11/02/2022) =
* Compatible with WordPress 5.9.2.
* Compatible with WooCommerce 6.3.1.
* Added: Support for WordPress revision feature for the offer post type. (#1211)
* Added: Few more controls in Gutenberg quantity selector widget. (#1218)
* Added: Compatibility with 'Cost of Goods by PixelYourSite' plugin. (#1215)
* Improved: Snapchat events firing add billing along with the purchase. (#1203)
* Improved: Application of quantity selector improved to add qty instead of multiple line items. (#1233)
* Improved: Fire PageView event even if storewide settings are ON by funnel builder. (#1209)
* Fixed: PayPal standard primary payments were throwing PHP error on WooCommerce version 6.3.1. (#1248)
* Fixed: Fatal error showing up while accessible past oxygen template after oxygen builder deactivated. (#1227)
* Fixed: Error while tracking custom events due to special characters in bump name. (#1223)
* Fixed: A fatal error while importing templates with few cases when WPML is active. (#1200)
* Fixed: Issue with Paypal payments offer payments showing incorrect total errors in a few cases. (#1180)
* Fixed: Issue with fresh elementor setups requiring toolkit generation. (#1213)
* Fixed: Remove extra line items getting added in square order for offer payments in a few cases. (#1230)
* Fixed: Snapchat tracking not working with native thankyou page. (#1243)

= 3.2.0 (01/02/2022) =
* Compatible with WordPress 5.9.0.
* Compatible with WooCommerce 6.1.1.
* Added: Support for Funnel Builder v2.0. (#1132)
* Added: Tracking events now supports TikTok and Snapchat. (#1132)
* Improved: Elementor and Divi: Templates importing speed is improved. (#1188)
* Improved: Default output shows for all page builder widgets even when no product is selected. (#1168)
* Improved: Compatibility updated with 'AffiliateWP' plugin. A PHP notice was coming, fixed. (#1177)
* Improved: esc_sql() method used as suggested by the WordFence for post meta query during upsell duplicate action. (#1176)
* Fixed: Issue with offer getting skipped if stock is not managed and same product in the primary order. (#1159)
* Fixed: Elementor `Accept button` block, icon position wasn't working, fixed. (#1185)
* Fixed: Compatibility updated with 'AffiliateWP' plugin, a PHP error in a case. (#1178)
* Fixed: PHP 8.1 compatibility fixes. (#1190)

= 3.1.0 (27/12/2021) =
* Added: Filter hook added to allow custom fonts for the Gutenberg blocks. (#1119)
* Added: Filter hook added to allow modification in offers that could cancel the primary order(#1129)
* Added: Filter hook added to allow modification in stripe refund post data (#1147)
* Fixed: Elementor widget settings were not getting saved in a few cases. (#1124)
* Fixed: Offer reject Link for the gutenberg templates was working incorrectly in few cases. (#1117)
* Fixed: Offer accept button styling breaks when price merge tag added. (#1122)
* Fixed: Google ads conversion tracking events was not getting fired correctly when used along with Google analytics. (#1126)
* Fixed: Quantity selector widget was not showing up any select when offer gets duplicated. (#1138)
* Fixed: Resolved jQuery conflict when jQuery migrate option checked in Divi theme settings. (#1143)
* Fixed: Licenses were not getting activated in multisite when funnel builder PRO activated network wide. (#1148)
* Fixed: Elementor template import was not working when setting "Improved Asset Loading" is turned ON in elementor. (#1108)
* Fixed: Offer accept/reject request failing for some server when JSON content was not getting returned. (#1150)
* Fixed: Elementor widgets alignment settings icons were missing in a few sites. (#1158)



[See changelog for all versions](https://myaccount.funnelkit.com/changelog/changelog-upstroke/).