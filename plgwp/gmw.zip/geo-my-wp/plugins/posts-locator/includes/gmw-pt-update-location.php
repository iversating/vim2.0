<?php
/**
 * The function gmw_pt_update_location() does not exist here anymore. 
 * 
 * The function is deprecated and replaced with gmw_update_post_location() which can be
 * 
 * found in geo-my-wp/plugins/posts-locator/includes/gmw-posts-locator-functions.php
 */
