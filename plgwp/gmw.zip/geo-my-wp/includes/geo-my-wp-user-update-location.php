<?php
/**
 * 
 * If you are looking for the function gmw_update_user_location() 
 * it was moved to geo-my-wp/includes/gmw-user-location-functions.php
 */