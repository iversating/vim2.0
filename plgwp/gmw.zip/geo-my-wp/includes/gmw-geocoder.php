<?php
/**
 * The content of this file moved to class-gmw-geocoder.php
 */
?>
