<span class="<?php echo esc_attr( $field['class'] ); ?>" id="<?php echo esc_attr( $field['id'] ); ?>" <?php echo esc_attr( $field['attributes'] ); ?>>
	<span></span>
</span>
