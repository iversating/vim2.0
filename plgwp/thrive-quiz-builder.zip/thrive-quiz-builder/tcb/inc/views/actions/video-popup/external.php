<div class="control-grid no-space wrap">
	<label for="v-eh-url"><?php echo __( 'URL', 'thrive-cb' ) ?></label>
	<input type="text" data-setting="url" class="eh-url fill" id="v-eh-url">
</div>
<div class="eh-url-validate inline-message"></div>

<div class="extra-settings">
	<div class="inline-checkboxes">
		<label class="tcb-checkbox"><input type="checkbox" data-setting="a" value="1" checked="checked"><span><?php echo __( 'Autoplay', 'thrive-cb' ) ?></span></label>
	</div>
</div>
