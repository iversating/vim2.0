<?php echo 'function(trigger,action,config){' ?>
ThriveGlobal.$j( '.tve_p_lb_close' ).click();
<?php echo 'return false;}';
