<?php

/**
 * Interface TQB_Export_Step
 * - what should an export step do
 */
interface TQB_Export_Step {
	public function execute();
}
