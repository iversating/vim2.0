<?php
/*
 * Triggers a jQuery event once this script is loaded in DOM
 * - usually used on ajax requests (TL Lazy Load)
 */
/**
 * @var int $quiz_id
 */
?>
<script type="text/javascript">
	( function ( $ ) {
		$( document ).ready( function () {
			$( this ).trigger( 'tqb_quiz_loaded', {
				quiz_id: '<?php echo $quiz_id; ?>'
			} )
		} );
	} )( jQuery );
</script>
