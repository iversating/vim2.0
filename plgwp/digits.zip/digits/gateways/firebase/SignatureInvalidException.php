<?php
namespace Firebase\Dig_Firebase;

use UnexpectedValueException;

class SignatureInvalidException extends UnexpectedValueException
{

}
