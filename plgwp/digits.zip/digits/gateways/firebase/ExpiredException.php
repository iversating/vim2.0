<?php
namespace Firebase\Dig_Firebase;

use UnexpectedValueException;

class ExpiredException extends UnexpectedValueException
{

}
