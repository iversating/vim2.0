/**
 * LearnDash Exam Context
 *
 * @since 4.0.0
 * @package LearnDash
 */

import { createContext } from "react";

export const ExamContext = createContext( {} );
