<?php
/**
 * Interface file for ParseCSV Library.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once 'parsecsv-for-php/parsecsv.lib.php';

/**
 * Class for lmsParseCSV.
 */
class lmsParseCSV extends ParseCsv\Csv {

}
