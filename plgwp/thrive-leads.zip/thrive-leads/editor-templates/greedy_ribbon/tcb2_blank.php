<div class="thrv-greedy-ribbon tve_no_drag tve_no_icons thrv_wrapper tve_editor_main_content tve_empty_dropzone" data-css="tve-u-15d9e8a985b">
	<div class="thrv_wrapper thrv-page-section tve-draggable tve-droppable">
		<div class="tve-page-section-out"></div>
		<div class="tve-page-section-in tve_empty_dropzone" data-css="tve-u-15d9e8baec8"></div>
	</div>
	<div class="thrv_wrapper thrv_icon tve-draggable tve-droppable tcb-icon-display edit_mode active_delete tve_evt_manager_listen tve_et_click tve_ea_thrive_leads_form_close"
		 data-css="tve-u-15d9e892d9c" data-tcb-events="__TCB_EVENT_[{&quot;a&quot;:&quot;thrive_leads_form_close&quot;,&quot;t&quot;:&quot;click&quot;}]_TNEVE_BCT__">
		<svg class="tcb-icon" viewBox="0 0 26 28" data-name="arrow-down">
			<title>arrow-down</title>
			<path d="M25.172 13c0 0.531-0.219 1.047-0.578 1.406l-10.172 10.187c-0.375 0.359-0.891 0.578-1.422 0.578s-1.047-0.219-1.406-0.578l-10.172-10.187c-0.375-0.359-0.594-0.875-0.594-1.406s0.219-1.047 0.594-1.422l1.156-1.172c0.375-0.359 0.891-0.578 1.422-0.578s1.047 0.219 1.406 0.578l4.594 4.594v-11c0-1.094 0.906-2 2-2h2c1.094 0 2 0.906 2 2v11l4.594-4.594c0.359-0.359 0.875-0.578 1.406-0.578s1.047 0.219 1.422 0.578l1.172 1.172c0.359 0.375 0.578 0.891 0.578 1.422z"></path>
		</svg>
	</div>
</div>