/*! Thrive Leads - The ultimate Lead Capture solution for wordpress - 2020-05-20
* https://thrivethemes.com 
* Copyright (c) 2020 * Thrive Themes */

var ThriveLeads=ThriveLeads||{};jQuery(document).ready(function(){ThriveLeads.router.navigate("#reporting",{trigger:!0})});