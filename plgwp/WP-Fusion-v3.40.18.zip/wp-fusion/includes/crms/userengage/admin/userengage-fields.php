<?php

$userengage_fields = array();

$userengage_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'first_name'
);

$userengage_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'last_name'
);

$userengage_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email'
);

$userengage_fields['phone_number'] = array(
	'crm_label' => 'Phone',
	'crm_field' => 'phone_number'
);

$userengage_fields['billing_city'] = array(
	'crm_label' => 'City',
	'crm_field' => 'city'
);

$userengage_fields['website'] = array(
	'crm_label' => 'Website',
	'crm_field' => 'website'
);

$userengage_fields['billing_country'] = array(
	'crm_label' => 'Country',
	'crm_field' => 'country'
);

