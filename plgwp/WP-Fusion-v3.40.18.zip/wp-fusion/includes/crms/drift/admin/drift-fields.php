<?php

$drift_fields = array();

$drift_fields['first_name'] = array(
	'crm_field' => 'first_name'
);

$drift_fields['last_name'] = array(
	'crm_field' => 'last_name'
);

$drift_fields['user_email'] = array(
	'crm_field' => 'email'
);

$drift_fields['billing_city'] = array(
	'crm_field' => 'city'
);

$drift_fields['billing_state'] = array(
	'crm_field' => 'state'
);

$drift_fields['billing_postcode'] = array(
	'crm_field' => 'postal_code'
);

$drift_fields['billing_country'] = array(
	'crm_field' => 'country'
);

$drift_fields['phone_number'] = array(
	'crm_field' => 'phone'
);

$drift_fields['billing_phone'] = array(
	'crm_field' => 'phone'
);