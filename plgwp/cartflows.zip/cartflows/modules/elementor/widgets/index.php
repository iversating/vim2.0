<?php
/**
 * Silence is golden.
