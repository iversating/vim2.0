<div class="thrv_wrapper thrv_columns" style="margin-bottom: 0;margin-top: 40px;">
	<div class="tve_colm tve_twc">
		<div class="thrv_wrapper tve_image_caption aligncenter" style="margin-top: 0;margin-bottom: 0;width: 331px;">
            <span class="tve_image_frame">
                <img class="tve_image"
                     src="<?php echo TVE_LANDING_PAGE_TEMPLATE . '/css/images/review_5.png' ?>"
                     style="width: 331px;"/>
            </span>
		</div>
	</div>
	<div class="tve_colm tve_twc tve_lst">
		<h4 style="color: #333333; font-size: 32px;margin-top: 0;margin-bottom: 20px;" class="rft">Sign Up now and get Your Awesome Product!</h4>
		<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_red" data-tve-style="1" style="">
			<div class="thrv_lead_generation_code" style="display: none;"></div>
			<div class="thrv_lead_generation_container tve_clearfix">
				<div class="tve_lead_generated_inputs_container tve_clearfix">
					<div class="tve_lead_fields_overlay" style="width: 100%; height: 100%;"></div>
					<div class=" tve_lg_input_container ">
						<input type="text" data-placeholder="First Name" placeholder="Your Name" value="" name="first_name"/>
					</div>
					<div class="tve_lg_input_container">
						<input type="text" data-placeholder="Last Name" placeholder="Your Email" value="" name="last_name"/>
					</div>
					<div class="tve_lg_input_container tve_submit_container">
						<button type="Submit">Get Instant Access &rtrif;</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>