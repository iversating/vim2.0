<h1 style="color: #333333; margin-top: 0; font-size: 32px; font-weight: 300;" class="tve_p_center">
	Sign Up & We’ll Send You Your <span class="bold_text">Free Report</span> Instantly
</h1>
<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_black" data-tve-style="1" style="margin-bottom:18px">
	<div class="thrv_lead_generation_code" style="display: none;"></div>
	<div class="thrv_lead_generation_container tve_clearfix">
		<div class="tve_lead_generated_inputs_container tve_clearfix">
			<div class="tve_lead_fields_overlay" style="width: 100%; height: 100%;"></div>
			<div class=" tve_lg_input_container ">
				<input type="text" data-placeholder="First Name" placeholder="First Name" value="" name="first_name"/>
			</div>
			<div class="tve_lg_input_container">
				<input type="text" data-placeholder="Last Name" placeholder="Last Name" value="" name="last_name"/>
			</div>
			<div class="tve_lg_input_container">
				<input type="text" data-placeholder="Email" placeholder="Email" value="" name="email"/>
			</div>
			<div class="tve_lg_input_container tve_submit_container">
				<div style="font-size: 20px; color: #305584" class="thrv_wrapper thrv_icon aligncenter tve-draggable" draggable="true">
					<span style="" class="tve_sc_icon minimal-video-offer-download" data-tve-icon="minimal-video-offer-download"></span>
				</div>
				<button type="Submit">Start Download</button>
			</div>
		</div>
	</div>
</div>