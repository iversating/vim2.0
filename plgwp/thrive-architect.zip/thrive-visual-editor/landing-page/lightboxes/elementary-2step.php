<h4 style="color: #555555; font-size: 30px;margin-top: 40px;margin-bottom: 35px;" class="tve_p_center">
	Sign Up to Get Instant Access to Our Landing Page Demo:
</h4>
<div
	class="thrv_wrapper thrv_lead_generation thrv_lead_generation_vertical tve_clearfix tve_blue tve_centerBtn"
	style="max-width: 350px;margin-bottom: 40px;" data-tve-style="1">
	<div class="thrv_lead_generation_code" style="display: none;"></div>
	<div class="thrv_lead_generation_container tve_clearfix">
		<div class="tve_lead_generated_inputs_container tve_clearfix">
			<div class="tve_lead_fields_overlay"></div>
			<div class=" tve_lg_input_container ">
				<input type="text" data-placeholder="" value="" name="name"
				       placeholder="Name"/>
			</div>
			<div class="tve_lg_input_container">
				<input type="text" data-placeholder="" value="" name="email"
				       placeholder="Email"/>
			</div>
			<div class="tve_lg_input_container tve_submit_container">
				<button type="Submit">YES, SIGN ME UP!</button>
			</div>
		</div>
	</div>
</div>