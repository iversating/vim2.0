<h3 class="tve_p_center" style="color: #333; font-size: 34px;margin-top: 0;margin-bottom: 30px;">
	<span class="bold_text">Sign Up</span> and download the
	<span class="bold_text"><font color="#ed4a18">Bonus Episode</font></span>
</h3>
<div style="width: 278px;margin-top: 0;margin-bottom: 0;" class="thrv_wrapper tve_image_caption aligncenter">
    <span class="tve_image_frame">
        <img class="tve_image"
             src="<?php echo TVE_LANDING_PAGE_TEMPLATE . '/css/images/phonic_podcast_icon.png' ?>"
             style="width: 278px;"/>
    </span>
</div>
<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_orange tve_fullwidthBtn tve_2 thrv_lead_generation_vertical"
     data-inputs-count="2" data-tve-style="1" style="margin-bottom: 0;">
	<div class="thrv_lead_generation_code" style="display: none;"></div>
	<div class="thrv_lead_generation_container tve_clearfix">
		<div class="tve_lead_generated_inputs_container tve_clearfix">
			<div class="tve_lead_fields_overlay"></div>
			<div class=" tve_lg_input_container tve_lg_3 tve_lg_input">
				<input type="text" data-placeholder="Email address..." placeholder="Email address..." value=""
				       name="last_name"/>
			</div>
			<div class="tve_lg_input_container tve_submit_container tve_lg_3 tve_lg_submit">
				<button type="Submit">GET INSTANT ACCESS</button>
			</div>
		</div>
	</div>
</div>