<h2 style="color: #000; margin-top: 0;margin-bottom: 50px;font-size: 36px" class="tve_p_center">
	Sign Up to Get the Guide Sent to Your Inbox!
</h2>
<div style="width: 90px;margin-top: 0;margin-bottom: 0;" class="thrv_wrapper tve_image_caption aligncenter">
    <span class="tve_image_frame">
        <a href="">
	        <img class="tve_image"
	             src="<?php echo TVE_LANDING_PAGE_TEMPLATE . '/css/images/lime-download-lightbox.png' ?>"
	             style="width: 90px"/>
        </a>
    </span>
</div>
<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_green tve_3 thrv_lead_generation_vertical" data-inputs-count="3" data-tve-style="1" style="margin-bottom:18px">
	<div class="thrv_lead_generation_code" style="display: none;"></div>
	<div class="thrv_lead_generation_container tve_clearfix">
		<div class="tve_lead_generated_inputs_container tve_clearfix">
			<div class="tve_lead_fields_overlay"></div>
			<div class=" tve_lg_input_container tve_lg_3 tve_lg_input">
				<input type="text" data-placeholder="Full Name" placeholder="Full Name" value="" name="first_name"/>
			</div>
			<div class="tve_lg_input_container tve_lg_3 tve_lg_input">
				<input type="text" data-placeholder="Email" placeholder="Email" value="" name="email"/>
			</div>
			<div class="tve_lg_input_container tve_submit_container tve_lg_3 tve_lg_submit">
				<button type="Submit">Download ebook</button>
			</div>
		</div>
	</div>
</div>