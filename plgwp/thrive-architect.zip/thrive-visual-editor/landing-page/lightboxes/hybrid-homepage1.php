<div class="thrv_wrapper thrv_columns tve_clearfix" style="margin-top: 0;margin-bottom: 0;">
	<div class="tve_colm tve_oth">
		<div style="width: 213px;margin-top: 30px;" class="thrv_wrapper tve_image_caption aligncenter">
                <span class="tve_image_frame">
                    <img class="tve_image"
                         src="<?php echo TVE_LANDING_PAGE_TEMPLATE . '/css/images/hybrid-homepage-lightbox.png' ?>"
                         style="width: 213px;"/>
                </span>
		</div>
	</div>
	<div class="tve_colm tve_tth tve_lst">
		<h3 style="color: #095fbb; font-size: 30px;margin-top: 0;margin-bottom: 15px;">
			Sign Up Below to get notified
			about our latest articles
		</h3>

		<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_green thrv_lead_generation_vertical"
		     data-tve-style="1" style="margin-top: 0;margin-bottom: 0;">
			<div class="thrv_lead_generation_code" style="display: none;"></div>
			<div class="thrv_lead_generation_container tve_clearfix">
				<div class="tve_lead_generated_inputs_container tve_clearfix">
					<div class="tve_lead_fields_overlay" style="width: 100%; height: 100%;"></div>
					<div class=" tve_lg_input_container ">
						<input type="text" data-placeholder="Your Name" placeholder="Your name" value=""
						       name="first_name"/>
					</div>
					<div class="tve_lg_input_container">
						<input type="text" data-placeholder="Last Name" placeholder="Your email" value=""
						       name="last_name"/>
					</div>
					<div class="tve_lg_input_container tve_submit_container">
						<button type="Submit">GET ACCESS TO THE LATEST ARTICLES</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
