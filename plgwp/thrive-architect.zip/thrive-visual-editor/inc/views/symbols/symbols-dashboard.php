<div class="symbols-dashboard-container">
	<?php echo __( 'Symbols', 'thrive-cb' ) ?>
</div>