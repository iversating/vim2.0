<div class="control-grid full-width">
	<label for="a-custom-url">URL</label>
	<input type="text" data-setting="url" class="click audio-url tve_provider_url" data-fn="changeCustom" id="a-custom-url" placeholder="e.g. pula mea">
</div>
<div class="url-validate inline-message"></div>