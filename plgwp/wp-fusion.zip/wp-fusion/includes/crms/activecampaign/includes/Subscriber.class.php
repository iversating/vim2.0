<?php

class WPF_AC_Subscriber extends WPF_AC_Contact {
}

?>