<?php

$sendinblue_fields = array();

$sendinblue_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'FIRSTNAME'
);

$sendinblue_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'LASTNAME'
);

$sendinblue_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email'
);