<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class WPF_wpForo extends WPF_Integrations_Base {

	/**
	 * Gets things started
	 *
	 * @access  public
	 * @since   1.0
	 * @return  void
	 */

	public function init() {

		$this->slug = 'wpforo';

		// Redirect if they don't have access
		add_action( 'template_redirect', array( $this, 'template_redirect' ), 15 );

		// Hide if they don't have access
		add_filter( 'wpforo_permissions_forum_can', array( $this, 'permissions_forum_can' ), 10, 5 );

		add_action( 'wpforo_action_wpforo_profile_update', array( $this, 'profile_update' ), 5 );

		// WPF stuff
		add_filter( 'wpf_meta_field_groups', array( $this, 'add_meta_field_group' ) );
		add_filter( 'wpf_meta_fields', array( $this, 'prepare_meta_fields' ) );

		// Admin settings
		add_action( 'admin_menu', array( $this, 'admin_menu' ), 40 );

	}


	/**
	 * Handles redirects for locked content
	 *
	 * @access public
	 * @return bool
	 */

	public function template_redirect() {

		$current_object = WPF()->current_object;

		if ( ! isset( $current_object['forumid'] ) ) {
			return;
		}

		$settings = get_option( 'wpf_wpforo_settings', array() );

		if ( empty( $settings ) || ! isset( $settings[ $current_object['forumid'] ] ) ) {
			return;
		}

		if ( empty( $settings[ $current_object['forumid'] ]['required_tags'] ) || empty( $settings[ $current_object['forumid'] ]['redirect'] ) ) {
			return;
		}

		// If admins are excluded from restrictions
		if ( wp_fusion()->settings->get( 'exclude_admins' ) == true && current_user_can( 'manage_options' ) ) {
			return;
		}

		$redirect = get_permalink( $settings[ $current_object['forumid'] ]['redirect'] );

		$has_access = true;

		if ( ! wpf_is_user_logged_in() ) {

			$has_access = false;

		} else {

			$user_tags = wp_fusion()->user->get_tags();

			if ( empty( $user_tags ) ) {

				$has_access = false;

			} else {

				$result = array_intersect( $user_tags, $settings[ $current_object['forumid'] ]['required_tags'] );

				if ( empty( $result ) ) {

					$has_access = false;

				}
			}
		}

		if ( ! $has_access ) {

			wp_redirect( $redirect );
			exit();

		}

	}

	/**
	 * Hide restricted forums
	 *
	 * @access public
	 * @return bool
	 */

	public function permissions_forum_can( $can, $do, $forumid, $groupid, $second_usergroupids ) {

		if ( empty( $forumid ) ) {
			return $can;
		}

		$settings = get_option( 'wpf_wpforo_settings', array() );

		if ( empty( $settings ) || ! isset( $settings[ $forumid ] ) ) {
			return $can;
		}

		if ( empty( $settings[ $forumid ]['required_tags'] ) || empty( $settings[ $forumid ]['hide'] ) ) {
			return $can;
		}

		// If admins are excluded from restrictions
		if ( wp_fusion()->settings->get( 'exclude_admins' ) == true && current_user_can( 'manage_options' ) ) {
			return $can;
		}

		if ( ! wpf_is_user_logged_in() ) {

			$can = false;

		} else {

			$user_tags = wp_fusion()->user->get_tags();

			if ( empty( $user_tags ) ) {

				$can = false;

			} else {

				$result = array_intersect( $user_tags, $settings[ $forumid ]['required_tags'] );

				if ( empty( $result ) ) {

					$can = false;

				}
			}
		}

		return $can;

	}

	/**
	 * Sync profile updates
	 *
	 * @access  public
	 * @return  void
	 */

	public function profile_update() {

		$update_data = $_POST['member'];

		if ( ! empty( $_POST['data'] ) ) {
			$update_data = array_merge( $update_data, $_POST['data'] );
		}

		wp_fusion()->user->push_user_meta( $update_data['userid'], $update_data );

	}

	/**
	 * Adds field group to meta fields list
	 *
	 * @access  public
	 * @return  array Field groups
	 */

	public function add_meta_field_group( $field_groups ) {

		$field_groups['wpforo'] = array(
			'title'  => 'wpForo',
			'fields' => array(),
		);

		return $field_groups;

	}


	/**
	 * Adds meta fields to WPF contact fields list
	 *
	 * @access  public
	 * @return  array Meta Fields
	 */

	public function prepare_meta_fields( $meta_fields ) {

		$custom_fields = get_option( 'wpfucf_custom_fields' );

		if ( empty( $custom_fields ) ) {
			return $meta_fields;
		}

		foreach ( $custom_fields as $key => $field ) {

			if ( ! isset( $field['label'] ) ) {
				continue;
			}

			$meta_fields[ $key ] = array(
				'label' => $field['label'],
				'type'  => $field['type'],
				'group' => 'wpforo',
			);

		}

		return $meta_fields;

	}

	/**
	 * Creates WPF submenu item
	 *
	 * @access public
	 * @return void
	 */

	public function admin_menu() {

		$id = add_submenu_page(
			'wpforo-community',
			wp_fusion()->crm->name . ' Integration',
			'WP Fusion',
			'manage_options',
			'wpforo-wpf-settings',
			array( $this, 'render_admin_menu' )
		);

		add_action( 'load-' . $id, array( $this, 'enqueue_scripts' ) );

	}

	/**
	 * Enqueues WPF scripts and styles on CW options page
	 *
	 * @access public
	 * @return void
	 */

	public function enqueue_scripts() {

		wp_enqueue_style( 'bootstrap', WPF_DIR_URL . 'includes/admin/options/css/bootstrap.min.css' );
		wp_enqueue_style( 'options-css', WPF_DIR_URL . 'includes/admin/options/css/options.css' );
		wp_enqueue_style( 'wpf-options', WPF_DIR_URL . 'assets/css/wpf-options.css' );

	}

	/**
	 * Renders CW submenu item
	 *
	 * @access public
	 * @return mixed
	 */

	public function render_admin_menu() {

		?>

		<div class="wrap">

			<h1><?php echo wp_fusion()->crm->name; ?> Integration</h1>

			<?php

			// Save settings
			if ( isset( $_POST['wpf_wpforo_settings_nonce'] ) && wp_verify_nonce( $_POST['wpf_wpforo_settings_nonce'], 'wpf_wpforo_settings' ) ) {
				update_option( 'wpf_wpforo_settings', $_POST['wpf-settings'] );
				echo '<div id="message" class="updated fade"><p><strong>Settings saved.</strong></p></div>';
			}

			// Get settings
			$settings = get_option( 'wpf_wpforo_settings', array() );

			// Get registered forums / categories
			$forums = WPF()->db->get_col( 'SELECT * FROM ' . WPF()->tables->forums . ' ORDER BY `forumid` ASC' );

			// Get pages for dropdown
			$post_types      = get_post_types( array( 'public' => true ) );
			$available_posts = array();

			unset( $post_types['attachment'] );
			$post_types = apply_filters( 'wpf_redirect_post_types', $post_types );

			foreach ( $post_types as $post_type ) {

				$posts = get_posts(
					array(
						'post_type'      => $post_type,
						'posts_per_page' => 200,
						'orderby'        => 'post_title',
						'order'          => 'ASC',
					)
				);

				foreach ( $posts as $post ) {
					$available_posts[ $post_type ][ $post->ID ] = $post->post_title;
				}
			}

			?>

			<form id="wpf-wpforo-settings" action="" method="post" style="width: 100%; max-width: 1200px;">

				<?php wp_nonce_field( 'wpf_wpforo_settings', 'wpf_wpforo_settings_nonce' ); ?>

				<h4>Categories and Forums</h4>
				<p class="description">You can restrict access to categories and forums by a logged in user's tags. If they don't have the required tags, they'll be redirected to the page you choose in the dropdown.</p>
				<br/>

				<input type="hidden" name="action" value="update">	

					<table class="table table-hover" id="wpf-settings-table">
						<thead>
							<tr>

								<th scope="row" style="text-align:left;"><?php _e( 'Forum / Category', 'wp-fusion' ); ?></th>

								<th scope="row" style="text-align:left;"><?php _e( 'Required tags (any)', 'wp-fusion' ); ?></th>

								<th scope="row" style="text-align:left;"><?php _e( 'Hide if access is denied', 'wp-fusion' ); ?></th>

								<th scope="row" style="text-align:left;"><?php _e( 'Redirect if access is denied', 'wp-fusion' ); ?></th>

							</tr> 
						</tread>
						<tbody>

						<?php
						foreach ( $forums as $forum_id ) :

							$defaults = array(
								'required_tags' => array(),
								'hide'			=> false,
								'redirect'      => false,
							);

							if ( ! isset( $settings[ $forum_id ] ) ) {
								$settings[ $forum_id ] = array();
							}

							$settings[ $forum_id ] = array_merge( $defaults, $settings[ $forum_id ] );

							$name = WPF()->db->get_var( 'SELECT `title` FROM `' . WPF()->tables->forums . '` WHERE `forumid` = ' . $forum_id );

							?>

							<tr>
								<td><?php echo $name; ?></td>
								<td>
								<?php

									$args = array(
										'setting'      => $settings[ $forum_id ],
										'meta_name'    => 'wpf-settings',
										'field_id'     => $forum_id,
										'field_sub_id' => 'required_tags',
									);

									wpf_render_tag_multiselect( $args );

									?>
								</td>

								<td><input type="checkbox" name="wpf-settings[<?php echo $forum_id; ?>][hide]" value="1" <?php checked( $settings[ $forum_id ]['hide'], true ); ?> /></td>

								<td>

									<p class="wpf-page-redirect-select">

										<select id="wpf-redirect-<?php echo $forum_id; ?>" class="select4-search" style="width: 100%;" data-placeholder="None" name="wpf-settings[<?php echo $forum_id; ?>][redirect]">

											<option></option>

											<?php foreach ( $available_posts as $post_type => $data ) : ?>

												<optgroup label="<?php echo $post_type; ?>">

												<?php foreach ( $available_posts[ $post_type ] as $id => $post_name ) : ?>
													<option value="<?php echo $id; ?>" <?php selected( $id, $settings[ $forum_id ]['redirect'] ); ?> ><?php echo $post_name; ?></option>
												<?php endforeach; ?>

												</optgroup>

											<?php endforeach; ?>

										</select>

									</p>

								</td>

							</tr>

						<?php endforeach; ?>

					</tbody>
				</table> 

				<p class="submit"><input name="Submit" type="submit" class="button-primary" value="Save Changes"/></p>

			</form>
		</div>
	<?php
	}

}

new WPF_wpForo();
