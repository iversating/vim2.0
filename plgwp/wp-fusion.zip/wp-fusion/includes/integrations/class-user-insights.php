<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


class WPF_User_Insights extends WPF_Integrations_Base {

	/**
	 * Gets things started
	 *
	 * @access  public
	 * @since   1.0
	 * @return  void
	 */

	public function init() {

		$this->slug = 'user-insights';

		add_filter( 'usin_fields', array( $this, 'add_module_fields' ) );
		add_filter( 'usin_user_db_data', array( $this, 'get_tags_data' ) );

	}

	/**
	 * Adds CRM tags field to filters
	 *
	 * @access public
	 * @return array Fields
	 */

	public function add_module_fields( $fields ) {

		$available_tags = wp_fusion()->settings->get( 'available_tags', array() );

		$data = array();

		foreach ( $available_tags as $id => $label ) {

			if ( is_array( $label ) ) {
				$label = $label['label'];
			}

			$data[] = array(
				'key' => $id,
				'val' => $label,
			);

		}

		$fields[] = array(
			'name'      => sprintf( __( '%s tags', 'wp-fusion' ), wp_fusion()->crm->name ),
			'id'        => 'activecampaign_tags',
			'order'     => false,
			'show'      => true,
			'fieldType' => 'general',
			'filter'    => array(
				'type'    => 'include_exclude',
				'options' => $data,
			),
		);

		return $fields;

	}

	/**
	 * Gets CRM tags for display
	 *
	 * @access public
	 * @return array Data
	 */

	public function get_tags_data( $data ) {

		$tag_ids = wp_fusion()->user->get_tags( $data->ID );

		$tag_names = array_map( array( wp_fusion()->user, 'get_tag_label' ), $tag_ids );

		$data->activecampaign_tags = implode( ', ', $tag_names );

		return $data;

	}

}

new WPF_User_Insights();
