<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}



class WPF_Restrict_Content_Pro extends WPF_Integrations_Base {

	/**
	 * Gets things started
	 *
	 * @access  public
	 * @since   1.0
	 * @return  void
	 */

	public function init() {

		$this->slug = 'restrict-content-pro';

		// Meta fields
		add_filter( 'wpf_meta_field_groups', array( $this, 'add_meta_field_group' ), 20 );
		add_filter( 'wpf_meta_fields', array( $this, 'prepare_meta_fields' ) );

		// Registration and updates
		add_filter( 'wpf_user_register', array( $this, 'user_register' ), 10, 2 );
		add_filter( 'wpf_user_update', array( $this, 'user_update' ), 10, 2 );
		add_action( 'wpf_user_created', array( $this, 'user_created' ), 10, 3 );
		add_filter( 'wpf_watched_meta_fields', array( $this, 'register_watched_fields' ) );
		add_action( 'wpf_tags_modified', array( $this, 'change_level' ), 10, 2 );

		// Add interfaces to admin
		add_action( 'rcp_edit_subscription_form', array( $this, 'subscription_settings' ) );
		add_action( 'rcp_add_subscription_form', array( $this, 'subscription_settings' ) );
		add_action( 'rcp_edit_subscription_level', array( $this, 'save_subscription_settings' ), 10, 2 );
		add_action( 'rcp_add_subscription', array( $this, 'save_subscription_settings_new' ), 10, 2 );

		// Registrations and future profile updates
		add_action( 'rcp_member_post_set_subscription_id', array( $this, 'subscription_id_changed' ), 1000, 3 );
		add_action( 'rcp_set_status', array( $this, 'status_changed' ), 10, 4 );
		add_action( 'rcp_recurring_payment_failed', array( $this, 'recurring_payment_failed' ), 10, 2 );

		// Batch operations
		add_filter( 'wpf_export_options', array( $this, 'export_options' ) );
		add_action( 'wpf_batch_rcp_init', array( $this, 'batch_init' ) );
		add_action( 'wpf_batch_rcp', array( $this, 'batch_step' ) );

	}


	/**
	 * Maps RCP specific POST fields to standard ones
	 *
	 * @access  public
	 * @return  array Post Data
	 */

	public function user_register( $post_data, $user_id ) {

		$field_map = array(
			'rcp_user_pass'  => 'user_pass',
			'rcp_user_login' => 'user_login',
		);

		$post_data = $this->map_meta_fields( $post_data, $field_map );

		if( isset( $post_data['rcp_level'] ) ) {
			$post_data['rcp_level'] = rcp_get_subscription_name( $post_data['rcp_level'] );
		}

		return $post_data;

	}

	/**
	 * Maps RCP specific POST fields to standard ones
	 *
	 * @access  public
	 * @return  array Post Data
	 */

	public function user_update( $post_data, $user_id ) {

		$field_map = array(
			'rcp_first_name'    => 'first_name',
			'rcp_last_name'		=> 'last_name',
			'rcp_display_name'	=> 'display_name',
			'rcp_email'			=> 'user_email',
			'rcp_new_user_pass1' => 'user_pass'
		);

		$post_data = $this->map_meta_fields( $post_data, $field_map );

		return $post_data;

	}

	/**
	 * Send data after contact has been added if RCP auto-register is enabled
	 *
	 * @access  public
	 * @return  void
	 */

	public function user_created( $user_id, $contact_id, $post_data ) {

		global $rcp_options;

		if ( empty( $rcp_options['auto_add_users'] ) || empty( $rcp_options['auto_add_users_level'] ) ) {
			return;
		}

		$member = new RCP_Member( $user_id );

		// Apply tags

		$this->subscription_id_changed( $member->get_subscription_id(), $user_id, $member );

		// Update fields

		$update_data = array(
			'rcp_subscription_level' => $member->get_subscription_id(),
			'rcp_status'             => $member->get_status(),
			'rcp_expiration'         => $member->get_expiration_date(),
			'rcp_notes'              => $member->get_notes(),
		);

		wp_fusion()->user->push_user_meta( $user_id, $update_data );

	}

	/**
	 * Registers RCP user_meta fields for automatic sync when change detected
	 *
	 * @access public
	 * @return array Watched Fields
	 */

	public function register_watched_fields( $watched_fields ) {

		$rcp_fields = array( 'rcp_subscription_level', 'rcp_status', 'rcp_expiration', 'rcp_signup_method', 'rcp_notes', 'rcp_has_trialed' );

		return array_merge( $watched_fields, $rcp_fields );

	}

	/**
	 * Adds RCP field group to meta fields list
	 *
	 * @access  public
	 * @return  array Field groups
	 */

	public function add_meta_field_group( $field_groups ) {

		if( !isset( $field_groups['rcp'] ) ) {
			$field_groups['rcp'] = array( 'title' => 'Restrict Content Pro', 'fields' => array() );
		}

		return $field_groups;

	}


	/**
	 * Adds RCP meta fields to WPF contact fields list
	 *
	 * @access  public
	 * @return  array Meta Fields
	 */

	public function prepare_meta_fields( $meta_fields ) {

		$meta_fields['rcp_subscription_level'] 	= array( 'label' => 'Subscription Level ID', 'type' => 'text', 'group' => 'rcp' );
		$meta_fields['rcp_level'] 				= array( 'label' => 'Subscription Level Name', 'type' => 'text', 'group' => 'rcp' );
		$meta_fields['rcp_status'] 				= array( 'label' => 'Account Status', 'type' => 'text', 'group' => 'rcp' );
		$meta_fields['rcp_expiration'] 			= array( 'label' => 'Expiration Date', 'type' => 'date', 'group' => 'rcp' );
		$meta_fields['rcp_signup_method'] 		= array( 'label' => 'Signup Method', 'type' => 'text', 'group' => 'rcp' );
		$meta_fields['rcp_notes'] 				= array( 'label' => 'Notes', 'type' => 'date', 'group' => 'rcp' );

		return $meta_fields;

	}

	/**
	 * Adds CRM tag association field to edit view for single Subscription
	 *
	 * @access  public
	 * @return  mixed
	 */

	public function subscription_settings( $level = false ) { ?>

		<tr class="form-field">
			<th scope="row" valign="top">
				<label for="rcp-role"><?php _e( 'Apply tags', 'wp-fusion' ); ?></label>
			</th>
			<td>
				<?php $saved_settings = get_option( 'wpf_rcp_tags', array() ); ?>

				<?php

				$settings = array(
					'apply_tags'			=> array(),
					'tag_link'				=> array(),
					'status_active'			=> array(),
					'status_cancelled'		=> array(),
					'status_expired'		=> array(),
					'status_free'			=> array(),
					'status_payment_failed'	=> array()
				);

				if ( is_object( $level ) && isset( $saved_settings[ $level->id ] ) ) {

					$settings = array_merge( $settings, $saved_settings[ $level->id ] );

				}

				?>

				<?php 
				
					$args = array(
						'setting' 		=> $settings['apply_tags'],
						'meta_name'		=> 'wpf-settings',
						'field_id'		=> 'apply_tags'
					);

					wpf_render_tag_multiselect( $args );

				?>

				<p class="description"><?php _e( 'These tag will be applied to the user when they register or are added to the subscription level.', 'wp-fusion' ); ?></p>
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row" valign="top">
				<label for="rcp-role"><?php _e( 'Link with tag', 'wp-fusion' ); ?></label>
			</th>
			<td>
				<?php
				
					$args = array(
						'setting' 		=> $settings['tag_link'],
						'meta_name'		=> 'wpf-settings',
						'field_id'		=> 'tag_link',
						'limit'			=> 1,
						'placeholder'	=> 'Select a tag'
					);

					wpf_render_tag_multiselect( $args );

				?>

				<p class="description"><?php _e( 'This tag will be applied to the user when they register or are added to the subscription level. You can also grant any user this subscription level by manually applying the tag. If the tag is removed the level will be removed.', 'wp-fusion' ); ?></p>

			</td>
		</tr>

		</table>

		<hr />

		<h3>Status tagging</h3>
		<p class="description"><?php _e( 'For each membership status you can select additional tags to be applied. These are in addition to the more general "Apply tags" setting above.', 'wp-fusion' ); ?></p>

		<table class="form-table">
			<tbody>

				<tr class="form-field">
					<th scope="row" valign="top">
						<label for="rcp-role"><?php _e( 'Active', 'wp-fusion' ); ?></label>
					</th>
					<td>
						<?php
						
							$args = array(
								'setting' 		=> $settings['status_active'],
								'meta_name'		=> 'wpf-settings',
								'field_id'		=> 'status_active'
							);

							wpf_render_tag_multiselect( $args );

						?>

						<p class="description"><?php _e( 'These tags will be applied when a user\'s membership status is set to active.', 'wp-fusion' ); ?></p>

					</td>
				</tr>

				<tr class="form-field">
					<th scope="row" valign="top">
						<label for="rcp-role"><?php _e( 'Cancelled', 'wp-fusion' ); ?></label>
					</th>
					<td>
						<?php

							$args = array(
								'setting' 		=> $settings['status_cancelled'],
								'meta_name'		=> 'wpf-settings',
								'field_id'		=> 'status_cancelled'
							);

							wpf_render_tag_multiselect( $args );

						?>

						<p class="description"><?php _e( 'These tags will be applied when a user\'s membership is cancelled.', 'wp-fusion' ); ?></p>

					</td>
				</tr>

				<tr class="form-field">
					<th scope="row" valign="top">
						<label for="rcp-role"><?php _e( 'Expired', 'wp-fusion' ); ?></label>
					</th>
					<td>
						<?php
						
							$args = array(
								'setting' 		=> $settings['status_expired'],
								'meta_name'		=> 'wpf-settings',
								'field_id'		=> 'status_expired'
							);

							wpf_render_tag_multiselect( $args );

						?>

						<p class="description"><?php _e( 'These tags will be applied when a user\'s membership expires.', 'wp-fusion' ); ?></p>

					</td>
				</tr>

				<tr class="form-field">
					<th scope="row" valign="top">
						<label for="rcp-role"><?php _e( 'Free', 'wp-fusion' ); ?></label>
					</th>
					<td>
						<?php
						
							$args = array(
								'setting' 		=> $settings['status_free'],
								'meta_name'		=> 'wpf-settings',
								'field_id'		=> 'status_free'
							);

							wpf_render_tag_multiselect( $args );

						?>

						<p class="description"><?php _e( 'These tags will be applied when a user registers for a free membership.', 'wp-fusion' ); ?></p>

					</td>
				</tr>

				<tr class="form-field">
					<th scope="row" valign="top">
						<label for="rcp-role"><?php _e( 'Trial', 'wp-fusion' ); ?></label>
					</th>
					<td>
						<?php

							$args = array(
								'setting' 		=> $settings['status_trial'],
								'meta_name'		=> 'wpf-settings',
								'field_id'		=> 'status_trial'
							);

							wpf_render_tag_multiselect( $args );

						?>

						<p class="description"><?php _e( 'These tags will be applied when a member signs up for a trial.', 'wp-fusion' ); ?></p>

					</td>
				</tr>

				<tr class="form-field">
					<th scope="row" valign="top">
						<label for="rcp-role"><?php _e( 'Renewal Payment Failed', 'wp-fusion' ); ?></label>
					</th>
					<td>
						<?php
						
							$args = array(
								'setting' 		=> $settings['status_payment_failed'],
								'meta_name'		=> 'wpf-settings',
								'field_id'		=> 'status_payment_failed'
							);

							wpf_render_tag_multiselect( $args );

						?>

						<p class="description"><?php _e( 'These tags will be applied when a renewal payment fails.', 'wp-fusion' ); ?></p>

					</td>
				</tr>

			</tbody>

		</table>

		<hr />

		<table class="form-table">
			<tbody>

		<?php

	}

	/**
	 * Saves changes to WPF fields on the subscription edit screen
	 *
	 * @access  public
	 * @return  void
	 */

	public function save_subscription_settings( $id, $args ) {

		if ( ! isset( $args['wpf-settings'] ) ) {
			return;
		}

		$settings           = get_option( 'wpf_rcp_tags', array() );
		$settings[ $id ] 	= $args['wpf-settings'];

		update_option( 'wpf_rcp_tags', $settings );

	}


	/**
	 * Saves WPF settings for new subscription levels
	 *
	 * @access  public
	 * @return  void
	 */

	public function save_subscription_settings_new( $id, $args ) {

		if ( ! isset( $_POST['wpf-settings'] ) ) {
			return;
		}

		$settings        = get_option( 'wpf_rcp_tags', array() );
		$settings[ $id ] = $_POST['wpf-settings'];
		update_option( 'wpf_rcp_tags', $settings );

	}


	/**
	 * Triggered when a user's status is changed in RCP
	 *
	 * @access  public
	 * @return  void
	 */

	public function subscription_id_changed( $subscription_id, $user_id, $member ) {

		$status = $member->get_status();

		$tags  = get_option( 'wpf_rcp_tags', array() );

		if ( ! empty( $tags[ $subscription_id ] ) ) {

			// Disable tag link function
			remove_action( 'wpf_tags_modified', array( $this, 'change_level' ), 10, 2 );

			// Apply / remove tags
			if ( $status == 'active' || $status == 'free' ) {

				if ( ! empty( $tags[ $subscription_id ]['apply_tags'] ) ) {
					wp_fusion()->user->apply_tags( $tags[ $subscription_id ]['apply_tags'], $user_id );
				}

				if ( ! empty( $tags[ $subscription_id ]['tag_link'] ) ) {
					wp_fusion()->user->apply_tags( $tags[ $subscription_id ]['tag_link'], $user_id );
				}
			} elseif ( $status == 'expired' && ! empty( $tags[ $subscription_id ]['tag_link'] ) ) {
				wp_fusion()->user->remove_tags( $tags[ $subscription_id ]['tag_link'], $user_id );
			}

			add_action( 'wpf_tags_modified', array( $this, 'change_level' ), 10, 2 );

		}

		// Remove any linked tags from other levels

		if ( ! function_exists( 'rcp_multiple_memberships_enabled' ) || ! rcp_multiple_memberships_enabled() ) {

			foreach ( $tags as $level_id => $settings ) {

				if ( $level_id == $subscription_id ) {
					continue;
				}

				if ( ! empty( $settings['tag_link'] ) ) {

					remove_action( 'wpf_tags_modified', array( $this, 'change_level' ), 10, 2 );

					wp_fusion()->user->remove_tags( $settings['tag_link'], $user_id );

					add_action( 'wpf_tags_modified', array( $this, 'change_level' ), 10, 2 );

				}

			}

		}

		// Update sub name
		wp_fusion()->user->push_user_meta( $user_id, array( 'rcp_level' => rcp_get_subscription_name( $subscription_id ) ) );

	}


	/**
	 * Triggered when a user's status is changed
	 *
	 * @access  public
	 * @return  void
	 */

	public function status_changed( $new_status, $user_id, $old_status, $member ) {

		$subscription_id = $member->get_subscription_id();
		$tags  = get_option( 'wpf_rcp_tags', array() );
		$apply_tags = array();

		if ( ! empty( $tags[ $subscription_id ] ) ) {

			// Disable tag link function
			remove_action( 'wpf_tags_modified', array( $this, 'change_level' ), 10, 2 );

			// Apply / remove tags
			if( $new_status == 'active' || $new_status == 'free' ) {

				if( ! empty( $tags[ $subscription_id ]['apply_tags'] ) ) {
					$apply_tags = array_merge( $apply_tags, $tags[ $subscription_id ]['apply_tags'] );
				}

				if( ! empty( $tags[ $subscription_id ]['tag_link'] ) ) {
					$apply_tags = array_merge( $apply_tags, $tags[ $subscription_id ]['tag_link'] );
				}

				// Remove tags from old status if switched back to active

				if ( ! empty( $old_status ) && ! empty( $tags[ $subscription_id ][ 'status_' .  $old_status ] ) ) {

					wp_fusion()->user->remove_tags( $tags[ $subscription_id ][ 'status_' .  $old_status ], $user_id );

				}

				// Remove Payment Failed tags

				if ( ! empty( $tags[ $subscription_id ]['status_payment_failed'] ) ) {

					wp_fusion()->user->remove_tags( $tags[ $subscription_id ]['status_payment_failed'], $user_id );

				}

			} elseif( $new_status == 'expired' && ! empty( $tags[ $subscription_id ]['tag_link'] ) ) {

				// "Cancelled" means it was admin or user cancelled but it is still active until the end of the period, so we'll only remove linked tags when it actually becomes Expired

				wp_fusion()->user->remove_tags( $tags[ $subscription_id ]['tag_link'], $user_id );

			}

			// Apply tags based on current status

			if( ! empty( $tags[ $subscription_id ][ 'status_' .  $new_status ] ) ) {
				$apply_tags = array_merge( $apply_tags, $tags[ $subscription_id ][ 'status_' . $new_status ] );
			}

			// Trials

			if( $member->is_trialing() && ! empty( $tags[ $subscription_id ]['status_trial'] ) ) {
				$apply_tags = array_merge( $apply_tags, $tags[ $subscription_id ]['status_trial'] );
			}

			if( ! empty( $apply_tags ) ) {
				wp_fusion()->user->apply_tags( $apply_tags, $user_id );
			}

			add_action( 'wpf_tags_modified', array( $this, 'change_level' ), 10, 2 );

		}

		// Remove any linked tags from other levels

		if ( ! function_exists( 'rcp_multiple_memberships_enabled' ) || ! rcp_multiple_memberships_enabled() ) {

			foreach ( $tags as $level_id => $settings ) {

				if ( $level_id == $subscription_id ) {
					continue;
				}

				if ( ! empty( $settings['tag_link'] ) ) {

					remove_action( 'wpf_tags_modified', array( $this, 'change_level' ), 10, 2 );

					wp_fusion()->user->remove_tags( $settings['tag_link'], $user_id );

					add_action( 'wpf_tags_modified', array( $this, 'change_level' ), 10, 2 );

				}
			}
		}

		// Send meta data

		$update_data = array(
			'rcp_level'              => $member->get_subscription_name(),
			'rcp_subscription_level' => $subscription_id,
			'rcp_status'             => $new_status,
			'rcp_expiration'         => $member->get_expiration_date(),
			'rcp_notes'              => $member->get_notes(),
		);

		$membership = $member->get_membership();

		if ( ! empty( $membership ) ) {
			$update_data['rcp_signup_method'] = $membership->get_signup_method();
		}

		wp_fusion()->user->push_user_meta( $user_id, $update_data );

	}


	/**
	 * Triggered when a recurring payment fails
	 *
	 * @access  public
	 * @return  void
	 */

	public function recurring_payment_failed( $member, $gateway ) {

		$membership_id = $member->get_subscription_id();

		$tags = get_option( 'wpf_rcp_tags', array() );

		if ( isset( $tags[ $membership_id ] ) && ! empty( $tags[ $membership_id ]['status_payment_failed'] ) ) {

			wp_fusion()->user->apply_tags( $tags[ $membership_id ]['status_payment_failed'], $member->ID );

		}

	}


	/**
	 * Triggered when a user's tags are modified
	 *
	 * @access  public
	 * @return  void
	 */

	public function change_level( $user_id, $user_tags ) {

		$rcp_tag_map = get_option( 'wpf_rcp_tags', array() );

		$user_current_level = rcp_get_subscription_id( $user_id );

		foreach ( $rcp_tag_map as $level_id => $tags ) {

			if( empty( $tags['tag_link'] ) ) {
				continue;
			}

			$tag = $tags['tag_link'][0];

			if ( in_array( $tag, (array) $user_tags ) && $level_id != $user_current_level ) {

				wpf_log( 'info', $user_id, 'User added to RCP subscription <strong>' . rcp_get_subscription_name( $level_id ) . '</strong> by tag <strong>' . wp_fusion()->user->get_tag_label( $tag ) . '</strong>', array( 'source' => 'restrict-content-pro' ) );
				
				$args = array('subscription_id'	=> $level_id );
				rcp_add_user_to_subscription( $user_id, $args );

			}

		}

	}


	/**
	 * //
	 * // BATCH TOOLS
	 * //
	 **/

	/**
	 * Adds PMPro checkbox to available export options
	 *
	 * @access public
	 * @return array Options
	 */

	public function export_options( $options ) {

		$options['rcp'] = array(
			'label'   => __( 'Restrict Content Pro memberships', 'wp-fusion' ),
			'title'   => __( 'Members', 'wp-fusion' ),
			'tooltip' => sprintf( __( 'Updates tags for all members based on their current membership level and pushes Restrict Content Pro membership fields (level, status, expiration) to %s.', 'wp-fusion' ), wp_fusion()->crm->name ),
		);

		return $options;

	}

	/**
	 * Counts total number of members to be processed
	 *
	 * @access public
	 * @return array Members
	 */

	public function batch_init() {

		$user_ids = array();

		$members = rcp_get_members( $status = false );

		if ( ! empty( $members ) ) {

			foreach ( $members as $member ) {
				$user_ids[] = $member->ID;
			}

		}

		wpf_log( 'info', 0, 'Beginning <strong>Restrict Content Pro</strong> batch operation on ' . count( $user_ids ) . ' members', array( 'source' => 'batch-process' ) );

		return $user_ids;

	}

	/**
	 * Processes member actions in batches
	 *
	 * @access public
	 * @return void
	 */

	public function batch_step( $user_id ) {

		$member = new RCP_Member( $user_id );

		$this->status_changed( $member->get_status(), $user_id, false, $member );

	}

}

new WPF_Restrict_Content_Pro;
