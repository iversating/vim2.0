<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}



class WPF_PMP extends WPF_Integrations_Base {

	/**
	 * Gets things started
	 *
	 * @access  public
	 * @return  void
	 */

	public function init() {

		$this->slug = 'pmpro';

		// Admin settings
		add_action( 'pmpro_membership_level_after_other_settings', array( $this, 'membership_level_settings' ) );
		add_action( 'pmpro_save_membership_level', array( $this, 'save_level_settings' ) );

		add_action( 'pmpro_discount_code_after_settings', array( $this, 'discount_code_settings' ) );
		add_action( 'pmpro_save_discount_code', array( $this, 'save_discount_code_settings' ) );

		// New Order
		add_action( 'pmpro_after_checkout', array( $this, 'after_checkout' ), 10, 2 );

		// Change membership level
		add_action( 'pmpro_before_change_membership_level', array( $this, 'before_change_membership_level' ), 10, 4 );
		add_action( 'pmpro_after_change_membership_level', array( $this, 'after_change_membership_level' ), 10, 2 );
		add_action( 'pmpro_membership_post_membership_expiry', array( $this, 'membership_expiry' ), 10, 2 );

		if ( class_exists( 'PMPro_Approvals' ) ) {

			// Approvals support
			add_filter( 'wpf_meta_fields', array( $this, 'prepare_approval_meta_fields' ) );
			add_action( 'pmpro_before_change_membership_level', array( $this, 'sync_approval_status' ), 30, 4 );

			// Set approval from CRM
			add_filter( 'wpf_pulled_user_meta', array( $this, 'pulled_approval_meta' ), 10, 2 );

		}

		// WPF Stuff
		add_filter( 'wpf_meta_field_groups', array( $this, 'add_meta_field_group' ), 15 );
		add_filter( 'wpf_meta_fields', array( $this, 'prepare_meta_fields' ) );
		add_filter( 'wpf_user_register', array( $this, 'user_register' ), 10, 2 );
		add_filter( 'wpf_user_update', array( $this, 'user_update' ), 10, 2 );
		add_action( 'wpf_tags_modified', array( $this, 'update_membership' ), 10, 2 );

		add_action( 'wpf_user_updated', array( $this, 'user_updated' ), 10, 2 );
		add_action( 'wpf_user_imported', array( $this, 'user_updated' ), 10, 2 );

		// Batch operations
		add_filter( 'wpf_export_options', array( $this, 'export_options' ) );
		add_action( 'wpf_batch_pmpro_init', array( $this, 'batch_init' ) );
		add_action( 'wpf_batch_pmpro', array( $this, 'batch_step' ) );

	}


	/**
	 * Adds options to PMP membership level settings
	 *
	 * @access  public
	 * @return  mixed
	 */

	public function membership_level_settings() {

		$edit = $_GET['edit'];
		global $wpdb;

		$level = $wpdb->get_row( "SELECT * FROM $wpdb->pmpro_membership_levels WHERE id = '$edit' LIMIT 1", OBJECT );

		$settings = array(
			'remove_tags'          => 0,
			'tag_link'             => array(),
			'apply_tags'           => array(),
			'apply_tags_expired'   => array(),
			'apply_tags_cancelled' => array(),
		);

		if ( get_option( 'wpf_pmp_' . $edit ) ) {
			$settings = array_merge( $settings, get_option( 'wpf_pmp_' . $edit ) );
		}

		?>

		<h3 class="topborder">WP Fusion <?php _e( 'Settings', 'wpfusion' ); ?></h3>
		<table class="form-table" id="wp_fusion_tab">
			<tbody>
			<tr>
				<th scope="row" valign="top"><label><?php _e( 'Apply Tags', 'wp-fusion' ); ?>:</label></th>
				<td>
					<?php
					wpf_render_tag_multiselect(
						array(
							'setting'   => $settings['apply_tags'],
							'meta_name' => 'wpf-settings',
							'field_id'  => 'apply_tags',
							'no_dupes'  => array( 'tag_link' ),
						)
					);
?>
					<br/>
					<small>The selected tags will be applied to the contact in <?php echo wp_fusion()->crm->name; ?> at registration.</small>
				</td>
			</tr>
			<tr>
				<th scope="row" valign="top"><label><?php _e( 'Remove Tags', 'wp-fusion' ); ?>:</label></th>
				<td>
					<input class="checkbox" type="checkbox" id="wpf-remove-tags" name="wpf-settings[remove_tags]"
						   value="1" <?php echo checked( $settings['remove_tags'], 1, false ); ?> />
					<label for="wpf-remove-tags">Remove the tags above if membership is cancelled, changed, or expires.</label>
				</td>
			</tr>
			<tr>
				<th scope="row" valign="top"><label><?php _e( 'Link With Tag', 'wp-fusion' ); ?>:</label></th>
				<td>
					<?php

						$args = array(
							'setting'     => $settings['tag_link'],
							'meta_name'   => 'wpf-settings',
							'field_id'    => 'tag_link',
							'placeholder' => 'Select a Tag',
							'limit'       => 1,
							'no_dupes'    => array( 'apply_tags' ),
						);

						wpf_render_tag_multiselect( $args );

					?>
					<br/>
					<small>Select a tag to link with this membership level. When this tag is applied, the user will be enrolled in the membership. When this tag is removed, the user will be removed from the membership. <br />Likewise, when a user is added to this membership, the tag will be applied, and when a user leaves the membership the tag will be removed.</small>
				</td>
			</tr>
			<tr>
				<th scope="row" valign="top"><label><?php _e( 'Apply Tags - Cancelled', 'wp-fusion' ); ?>:</label></th>
				<td>
					<?php
					wpf_render_tag_multiselect(
						array(
							'setting'   => $settings['apply_tags_cancelled'],
							'meta_name' => 'wpf-settings',
							'field_id'  => 'apply_tags_cancelled',
						)
					);
?>
					<br/>
					<small>Apply the selected tags when a membership is cancelled.</small>
				</td>
			</tr>
			<tr class="expiration_info" 
			<?php
			if ( ! pmpro_isLevelExpiring( $level ) ) {
				echo 'style="display: none;"';
			}
			?>
			>
				<th scope="row" valign="top"><label><?php _e( 'Apply Tags - Expired', 'wp-fusion' ); ?>:</label>
				</th>
				<td>
					<?php
					wpf_render_tag_multiselect(
						array(
							'setting'   => $settings['apply_tags_expired'],
							'meta_name' => 'wpf-settings',
							'field_id'  => 'apply_tags_expired',
						)
					);
?>
					<br/>
					<small>Apply the selected tags when a membership expires.</small>
				</td>
			</tr>
			</tbody>
		</table>

		<?php

	}

	/**
	 * Saves changes to membership level settings
	 *
	 * @access  public
	 * @return  void
	 */

	public function save_level_settings( $saveid ) {

		if ( isset( $_POST['wpf-settings'] ) ) {
			update_option( 'wpf_pmp_' . $saveid, $_POST['wpf-settings'] );
		} else {
			delete_option( 'wpf_pmp_' . $saveid );
		}

	}

	/**
	 * Adds options to PMP discount code settings
	 *
	 * @access  public
	 * @return  mixed
	 */

	public function discount_code_settings( $edit ) {

		$settings = get_option( 'wpf_pmp_discount_' . $edit );

		if ( empty( $settings ) ) {
			$settings = array( 'apply_tags' => array() );
		}

		?>
		<table class="form-table">
			<tr>
				<th scope="row" valign="top"><label><?php _e( 'Apply Tags', 'wp-fusion' ); ?>:</label></th>
				<td>
					<?php
					wpf_render_tag_multiselect(
						array(
							'setting'   => $settings['apply_tags'],
							'meta_name' => 'wpf-settings',
							'field_id'  => 'apply_tags',
						)
					);
?>
					<br/>
					<small>Apply the selected tags in <?php echo wp_fusion()->crm->name; ?> when the coupon is used.</small>
				</td>
			</tr>

		   </table>

		<?php

	}

	/**
	 * Saves changes to discount code settings
	 *
	 * @access  public
	 * @return  void
	 */

	public function save_discount_code_settings( $saveid ) {

		if ( isset( $_POST['wpf-settings'] ) ) {
			update_option( 'wpf_pmp_discount_' . $saveid, $_POST['wpf-settings'] );
		}

	}

	/**
	 * Triggered when new order is placed, sends purchase gateway (rest of data is collected from after_change_membership_level)
	 *
	 * @access  public
	 * @return  void
	 */

	public function after_checkout( $user_id, $order ) {

		$user_meta = array(
			'pmpro_payment_method' => $order->gateway,
		);

		wp_fusion()->user->push_user_meta( $user_id, $user_meta );

		// Discount codes
		global $discount_code_id;

		if ( ! empty( $discount_code_id ) ) {

			$settings = get_option( 'wpf_pmp_discount_' . $discount_code_id );

			if ( ! empty( $settings ) && ! empty( $settings['apply_tags'] ) ) {
				wp_fusion()->user->apply_tags( $settings['apply_tags'], $user_id );
			}
		}

	}

	/**
	 * Triggered before a user's membership level is changed
	 *
	 * @access  public
	 * @return  void
	 */

	public function before_change_membership_level( $level_id, $user_id, $old_levels, $cancel_level ) {

		// Disable tag link function
		remove_action( 'wpf_tags_modified', array( $this, 'update_membership' ), 10, 2 );

		// Check if this is a user profile edit page and remove actions as necessary
		global $pagenow;

		if ( $pagenow == 'profile.php' || $pagenow == 'user-edit.php' ) {
			remove_action( 'profile_update', array( wp_fusion()->admin_interfaces->user_profile, 'user_profile_update' ), 5 );
		}

		if ( ! empty( $old_levels[0] ) ) {

			$old_level = $old_levels[0];

			$old_level_settings = get_option( 'wpf_pmp_' . $old_level->ID );

			// Remove tags / perform actions on previous level
			if ( ! empty( $old_level_settings ) ) {

				wpf_log( 'info', $user_id, 'User left Paid Memberships Pro level <strong>' . $old_level->name . '</strong>.', array( 'source' => 'pmpro' ) );

				if ( $old_level_settings['remove_tags'] == true && ! empty( $old_level_settings['apply_tags'] ) ) {
					wp_fusion()->user->remove_tags( $old_level_settings['apply_tags'], $user_id );
				}

				if ( ! empty( $old_level_settings['tag_link'] ) ) {
					wp_fusion()->user->remove_tags( $old_level_settings['tag_link'], $user_id );
				}

				if ( $level_id == 0 && ! empty( $old_level_settings['apply_tags_cancelled'] ) ) {
					wp_fusion()->user->apply_tags( $old_level_settings['apply_tags_cancelled'], $user_id );
				}
			}
		}

		add_action( 'wpf_tags_modified', array( $this, 'update_membership' ), 10, 2 );

	}


	/**
	 * Triggered when a user's membership level is changed
	 *
	 * @access  public
	 * @return  void
	 */

	public function after_change_membership_level( $level_id, $user_id ) {

		// Disable tag link function
		remove_action( 'wpf_tags_modified', array( $this, 'update_membership' ), 10, 2 );

		// Get new level
		$membership_level = pmpro_getMembershipLevelForUser( $user_id );

		if ( empty( $membership_level ) ) {

			$update_data = array(
				'pmpro_membership_level' => null,
				'pmpro_status'           => 'inactive',
			);

			wp_fusion()->user->push_user_meta( $user_id, $update_data );

			return;
		}

		$update_data = array_map( array( wp_fusion()->user, 'map_user_meta' ), get_user_meta( $user_id ) );

		// Fix for messed up expiration dates saved in usermeta
		unset( $update_data['pmpro_expiration_date'] );

		// Update level meta
		$update_data['pmpro_membership_level'] = $membership_level->name;
		$update_data['pmpro_start_date']       = date( get_option( 'date_format' ), $membership_level->startdate );

		if ( ! empty( $membership_level->enddate ) ) {

			// Take it out of UNIX time
			$update_data['pmpro_expiration_date'] = date( get_option( 'date_format' ), $membership_level->enddate );

		} else {

			// Never expires
			$update_data['pmpro_expiration_date'] = null;

		}

		global $wpdb;

		// Update level status meta field
		$level_status = $wpdb->get_row(
			"SELECT
				status as status
				FROM {$wpdb->pmpro_memberships_users}
				WHERE user_id = $user_id
				ORDER BY id DESC
				LIMIT 1"
		);

		if ( ! empty( $level_status ) ) {

			$update_data['pmpro_status'] = $level_status->status;

		}

		// Send the updated data
		wp_fusion()->user->push_user_meta( $user_id, $update_data );

		// New level apply tags
		$new_level_settings = get_option( 'wpf_pmp_' . $membership_level->ID );

		if ( ! empty( $new_level_settings ) ) {

			wpf_log( 'info', $user_id, 'User joined Paid Memberships Pro level <strong>' . $membership_level->name . '</strong>.', array( 'source' => 'pmpro' ) );

			if ( ! empty( $new_level_settings['apply_tags'] ) ) {
				wp_fusion()->user->apply_tags( $new_level_settings['apply_tags'], $user_id );
			}

			if ( ! empty( $new_level_settings['tag_link'] ) ) {
				wp_fusion()->user->apply_tags( $new_level_settings['tag_link'], $user_id );
			}

			// Remove Cancelled and Expired tags

			if ( ! empty( $new_level_settings['apply_tags_expired'] ) ) {
				wp_fusion()->user->remove_tags( $new_level_settings['apply_tags_expired'], $user_id );
			}

			if ( ! empty( $new_level_settings['apply_tags_cancelled'] ) ) {
				wp_fusion()->user->remove_tags( $new_level_settings['apply_tags_cancelled'], $user_id );
			}

		}

		add_action( 'wpf_tags_modified', array( $this, 'update_membership' ), 10, 2 );

	}


	/**
	 * Triggered when a user's membership expires
	 *
	 * @access  public
	 * @return  void
	 */

	public function membership_expiry( $user_id, $level_id ) {

		$settings = get_option( 'wpf_pmp_' . $level_id );

		if ( ! empty( $settings ) || ! empty( $settings['apply_tags_expired'] ) ) {
			wp_fusion()->user->apply_tags( $settings['apply_tags_expired'], $user_id );
		}

		if ( $settings['remove_tags'] == true && ! empty( $settings['apply_tags'] ) ) {
			wp_fusion()->user->remove_tags( $settings['apply_tags'], $user_id );
		}

		// Update level meta
		$update_data = array(
			'pmpro_status'           => 'expired',
			'pmpro_membership_level' => null,
		);

		// Send the updated data
		wp_fusion()->user->push_user_meta( $user_id, $update_data );

	}


	/**
	 * Updates user's memberships if a linked tag is added/removed
	 *
	 * @access public
	 * @return void
	 */

	public function update_membership( $user_id, $user_tags ) {

		global $wpdb;

		$membership_levels = $wpdb->get_results(
			"
		    SELECT option_name, option_value 
		    FROM {$wpdb->prefix}options 
		    WHERE option_name 
		    LIKE 'wpf_pmp_%'
		    ",
			ARRAY_N
		);

		if ( empty( $membership_levels ) ) {
			return;
		}

		// Update role based on user tags
		foreach ( $membership_levels as $level ) {

			$level_id = str_replace( 'wpf_pmp_', '', $level[0] );
			$settings = unserialize( $level[1] );

			if ( empty( $settings['tag_link'] ) ) {
				continue;
			}

			$tag_id = $settings['tag_link'][0];

			if ( in_array( $tag_id, $user_tags ) && pmpro_hasMembershipLevel( $level_id, $user_id ) == false ) {

				// Prevent looping
				remove_action( 'pmpro_before_change_membership_level', array( $this, 'before_change_membership_level' ), 10, 4 );
				remove_action( 'pmpro_after_change_membership_level', array( $this, 'after_change_membership_level' ), 10, 2 );

				$pmpro_level = pmpro_getLevel( $level_id );

				$startdate = current_time( 'mysql' );

				if ( ! empty( $pmpro_level->expiration_number ) ) {
					$enddate = date_i18n( 'Y-m-d', strtotime( '+ ' . $pmpro_level->expiration_number . ' ' . $pmpro_level->expiration_period, current_time( 'timestamp' ) ) );
				} else {
					$enddate = 'NULL';
				}

				$level_data = array(
					'user_id'         => $user_id,
					'membership_id'   => $level_id,
					'code_id'         => 0,
					'initial_payment' => 0,
					'billing_amount'  => 0,
					'cycle_number'    => 0,
					'cycle_period'    => 0,
					'billing_limit'   => 0,
					'trial_amount'    => 0,
					'trial_limit'     => 0,
					'startdate'       => $startdate,
					'enddate'         => $enddate,
				);

				// Logger
				wpf_log( 'info', $user_id, 'Adding user to PMPro membership <strong>' . $pmpro_level->name . '</strong> by tag <strong>' . wp_fusion()->user->get_tag_label( $tag_id ) . '</strong>', array( 'source' => 'pmpro' ) );

				// Add user to level
				pmpro_changeMembershipLevel( $level_data, $user_id, $old_level_status = 'inactive', $cancel_level = null );

			} elseif ( ! in_array( $tag_id, $user_tags ) && pmpro_hasMembershipLevel( $level_id, $user_id ) == true ) {

				$pmpro_level = pmpro_getLevel( $level_id );

				// Logger
				wpf_log( 'info', $user_id, 'Removing user from PMPro membership <strong>' . $pmpro_level->name . '</strong> by tag <strong>' . wp_fusion()->user->get_tag_label( $tag_id ) . '</strong>', array( 'source' => 'pmpro' ) );

				// Remove user from level
				pmpro_cancelMembershipLevel( $level_id, $user_id, $old_level_status = 'inactive' );

			}
		}

	}

	/**
	 * Runs when meta data is loaded from the CRM. Updates the start date and expiry date if found
	 *
	 * @access public
	 * @return void
	 */

	public function user_updated( $user_id, $user_meta ) {

		if ( ! empty( $user_meta['pmpro_start_date'] ) || ! empty( $user_meta['pmpro_expiration_date'] ) ) {

			global $wpdb;
			$membership_level = pmpro_getMembershipLevelForUser( $user_id );

			if ( ! empty( $user_meta['pmpro_start_date'] ) ) {

				$start_date = strtotime( $user_meta['pmpro_start_date'] );

				if ( ! empty( $start_date ) ) {

					$start_date = date( 'Y-m-d 00:00:00', $start_date );

					$wpdb->query(
						$wpdb->prepare(
							"UPDATE $wpdb->pmpro_memberships_users SET `startdate`='%s' WHERE `id`=%d",
							array(
								$start_date,
								$membership_level->subscription_id,
							)
						)
					);

				}
			}

			if ( ! empty( $user_meta['pmpro_expiration_date'] ) ) {

				$expiration_date = strtotime( $user_meta['pmpro_expiration_date'] );

				if ( $expiration_date > time() ) {

					$expiration_date = date( 'Y-m-d 00:00:00', $expiration_date );

					$wpdb->query(
						$wpdb->prepare(
							"UPDATE $wpdb->pmpro_memberships_users SET `enddate`='%s' WHERE `id`=%d",
							array(
								$expiration_date,
								$membership_level->subscription_id,
							)
						)
					);

				}
			}
		}

	}


	/**
	 * Updates user meta after checkout
	 *
	 * @access  public
	 * @return  array Post Data
	 */

	public function user_register( $post_data, $user_id ) {

		$field_map = array(
			'bfirstname'      => 'first_name',
			'blastname'       => 'last_name',
			'bemail'          => 'user_email',
			'username'        => 'user_login',
			'password'        => 'user_pass',
			'baddress1'       => 'billing_address_1',
			'baddress2'       => 'billing_address_2',
			'bcity'           => 'billing_city',
			'bstate'          => 'billing_state',
			'bzipcode'        => 'billing_postcode',
			'bcountry'        => 'billing_country',
			'bphone'          => 'phone_number',
			'pmpro_baddress1' => 'billing_address_1',
			'pmpro_baddress2' => 'billing_address_2',
			'pmpro_bcity'     => 'billing_city',
			'pmpro_bstate'    => 'billing_state',
			'pmpro_bzipcode'  => 'billing_postcode',
			'pmpro_bcountry'  => 'billing_country',
			'pmpro_bphone'    => 'phone_number',
		);

		$post_data = $this->map_meta_fields( $post_data, $field_map );

		return $post_data;

	}

	/**
	 * Filters data when pushing user meta
	 *
	 * @access  public
	 * @return  array Post Data
	 */

	public function user_update( $post_data, $user_id ) {

		$field_map = array(
			'pmpro_bemail'    => 'user_email',
			'pmpro_baddress1' => 'billing_address_1',
			'pmpro_baddress2' => 'billing_address_2',
			'pmpro_bcity'     => 'billing_city',
			'pmpro_bstate'    => 'billing_state',
			'pmpro_bzipcode'  => 'billing_postcode',
			'pmpro_bcountry'  => 'billing_country',
			'pmpro_bphone'    => 'phone_number',
		);

		$post_data = $this->map_meta_fields( $post_data, $field_map );

		return $post_data;

	}

	/**
	 * Adds PMP field group to meta fields list
	 *
	 * @access  public
	 * @return  array Field groups
	 */

	public function add_meta_field_group( $field_groups ) {

		if ( ! isset( $field_groups['pmp'] ) ) {
			$field_groups['pmp'] = array(
				'title'  => 'Paid Memberships Pro',
				'fields' => array(),
			);
		}

		return $field_groups;

	}

	/**
	 * Adds PMP meta fields to WPF contact fields list
	 *
	 * @access  public
	 * @return  array Meta Fields
	 */

	public function prepare_meta_fields( $meta_fields ) {

		$meta_fields['billing_address_1'] = array(
			'label' => 'Billing Address 1',
			'type'  => 'text',
			'group' => 'pmp',
		);
		$meta_fields['billing_address_2'] = array(
			'label' => 'Billing Address 2',
			'type'  => 'text',
			'group' => 'pmp',
		);
		$meta_fields['billing_city']      = array(
			'label' => 'Billing City',
			'type'  => 'text',
			'group' => 'pmp',
		);
		$meta_fields['billing_state']     = array(
			'label' => 'Billing State',
			'type'  => 'text',
			'group' => 'pmp',
		);
		$meta_fields['billing_country']   = array(
			'label' => 'Billing Country',
			'type'  => 'text',
			'group' => 'pmp',
		);
		$meta_fields['billing_postcode']  = array(
			'label' => 'Billing Postcode',
			'type'  => 'text',
			'group' => 'pmp',
		);
		$meta_fields['phone_number']      = array(
			'label' => 'Phone Number',
			'type'  => 'text',
			'group' => 'pmp',
		);

		global $pmprorh_registration_fields;

		if ( ! empty( $pmprorh_registration_fields ) ) {

			foreach ( $pmprorh_registration_fields as $section ) {

				foreach ( $section as $field ) {

					$meta_fields[ $field->id ] = array(
						'label' => $field->label,
						'type'  => $field->type,
						'group' => 'pmp',
					);

				}
			}
		}

		$meta_fields['pmpro_membership_level'] = array(
			'label' => 'Membership Level',
			'type'  => 'text',
			'group' => 'pmp',
		);
		$meta_fields['pmpro_status']           = array(
			'label' => 'Membership Status',
			'type'  => 'text',
			'group' => 'pmp',
		);
		$meta_fields['pmpro_payment_method']   = array(
			'label' => 'Payment Method',
			'type'  => 'text',
			'group' => 'pmp',
		);
		$meta_fields['pmpro_start_date']       = array(
			'label' => 'Start Date',
			'type'  => 'date',
			'group' => 'pmp',
		);
		$meta_fields['pmpro_expiration_date']  = array(
			'label' => 'Expiration Date',
			'type'  => 'date',
			'group' => 'pmp',
		);

		return $meta_fields;

	}

	/**
	 * //
	 * // APPROVALS
	 * //
	 **/


	/**
	 * Adds PMP Approvals meta fields to WPF contact fields list
	 *
	 * @access  public
	 * @return  array Meta Fields
	 */

	public function prepare_approval_meta_fields( $meta_fields ) {

		$meta_fields['pmpro_approval'] = array(
			'label' => 'Approval',
			'type'  => 'text',
			'group' => 'pmp',
		);

		return $meta_fields;

	}

	/**
	 * Filter user meta at registration
	 *
	 * @access  public
	 * @return  void
	 */

	public function sync_approval_status( $level_id, $user_id, $old_levels, $cancel_level ) {

		$approval_status = get_user_meta( $user_id, 'pmpro_approval_' . $level_id, true );

		if ( ! empty( $approval_status ) ) {
			wp_fusion()->user->push_user_meta( $user_id, array( 'pmpro_approval' => $approval_status['status'] ) );
		}

	}

	/**
	 * Filter user meta at registration
	 *
	 * @access  public
	 * @return  array User Meta
	 */

	public function pulled_approval_meta( $user_meta, $user_id ) {

		if ( ! empty( $user_meta['pmpro_approval'] ) ) {

			$level = pmpro_getMembershipLevelForUser( $user_id );

			if ( ! empty( $level ) ) {

				$status = get_user_meta( $user_id, 'pmpro_approval_' . $level->id, true );

				$status['status']    = $user_meta['pmpro_approval'];
				$status['timestamp'] = current_time( 'timestamp' );

				$user_meta[ 'pmpro_approval_' . $level->id ] = $status;

				unset( $user_meta['pmpro_approval'] );

			}
		}

		return $user_meta;

	}


	/**
	 * //
	 * // BATCH TOOLS
	 * //
	 **/

	/**
	 * Adds PMPro checkbox to available export options
	 *
	 * @access public
	 * @return array Options
	 */

	public function export_options( $options ) {

		$options['pmpro'] = array(
			'label'   => 'Paid Memberships Pro members',
			'title'   => 'Members',
			'tooltip' => 'Updates tags for all active members based on their current membership level and pushes PMPro membership fields (start date, expiration date, and membership level) to ' . wp_fusion()->crm->name,
		);

		return $options;

	}

	/**
	 * Counts total number of members to be processed
	 *
	 * @access public
	 * @return array Members
	 */

	public function batch_init() {

		global $wpdb;
		$members = array();

		$query = "
					SELECT u.ID FROM $wpdb->users u 
					LEFT JOIN $wpdb->pmpro_memberships_users mu ON u.ID = mu.user_id 
					LEFT JOIN $wpdb->pmpro_membership_levels m ON mu.membership_id = m.id 
					WHERE mu.membership_id > 0 AND mu.status = 'active' 
					GROUP BY u.ID 
					ORDER BY u.user_registered DESC
					";

		$result = $wpdb->get_results( $query, ARRAY_A );

		if ( ! empty( $result ) ) {
			foreach ( $result as $member ) {
				$members[] = $member['ID'];
			}
		}

		wpf_log( 'info', 0, 'Beginning <strong>Paid Memberships Pro</strong> batch operation on ' . count( $members ) . ' members', array( 'source' => 'batch-process' ) );

		return $members;

	}

	/**
	 * Processes member actions in batches
	 *
	 * @access public
	 * @return void
	 */

	public function batch_step( $user_id ) {

		$this->after_change_membership_level( false, $user_id );

	}

}

new WPF_PMP();
