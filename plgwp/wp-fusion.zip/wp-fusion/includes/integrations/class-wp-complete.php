<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


class WPF_WPComplete extends WPF_Integrations_Base {

	/**
	 * Gets things started
	 *
	 * @access  public
	 * @since   1.0
	 * @return  void
	 */

	public function init() {

		$this->slug = 'wpep';

		// Apply tags on course completion
		add_action( 'wpcomplete_mark_completed', array( $this, 'button_complete' ), 10, 1 );

		// Auto complete items when tags modified
		add_action( 'wpf_tags_modified', array( $this, 'auto_complete_items' ), 10, 2 );

		// Settings
		add_action( 'wpf_meta_box_content', array( $this, 'meta_box_content' ), 40, 2 );

	}

	/**
	 * Triggered when course / lesson / button marked complete
	 *
	 * @access public
	 * @return void
	 */

	public function button_complete( $button_info ) {

		$wpf_settings = get_post_meta( $button_info['post_id'], 'wpf-settings', true );

		if ( ! empty( $wpf_settings ) && ! empty( $wpf_settings['apply_tags_wpc_complete'] ) ) {
			wp_fusion()->user->apply_tags( $wpf_settings['apply_tags_wpc_complete'], $button_info['user_id'] );
		}

	}

	/**
	 * Auto complete linked items when tags modified
	 *
	 * @access public
	 * @return void
	 */

	public function auto_complete_items( $user_id, $user_tags ) {

		$wpcomplete = new WPComplete_Common( false, false );

		$completable_items = $wpcomplete->get_completable_posts();

		if ( ! empty( $completable_items ) ) {

			foreach ( $completable_items as $post_id => $nothing ) {

				$settings = get_post_meta( $post_id, 'wpf-settings', true );

				if ( ! empty( $settings ) && ! empty( $settings[ 'wpc_linked_tag' ] ) ) {

					$tag_id = $settings['wpc_linked_tag'][0];

					if ( in_array( $tag_id, $user_tags ) ) {

						// Mark complete
						


					} else {

						// Mark incomplete


					}

				}

			}

		}

	}


	/**
	 * Adds wp-complete fields to WPF meta box
	 *
	 * @access public
	 * @return void
	 */

	public function meta_box_content( $post, $settings ) {

		echo '<hr />';
		echo '<p><strong>WPComplete:</strong></p>';

		echo '<p><label for="wpf-apply-tags-wpc-complete"><small>' . __( 'Apply these tags when marked complete', 'wp-fusion' ) . ':</small></label>';

		if( ! isset( $settings['apply_tags_wpc_complete'] ) ) {
			$settings['apply_tags_wpc_complete'] = array();
		}

		wpf_render_tag_multiselect( array( 'setting' => $settings['apply_tags_wpc_complete'], 'meta_name' => 'wpf-settings', 'field_id' => 'apply_tags_wpc_complete' ) );

		echo '</p>';

		/* echo '<p><label for="wpf-apply-tags-wpc-complete"><small>' . __( 'Auto-complete this item when this tag is applied', 'wp-fusion' ) . ':</small></label>';

		if( ! isset( $settings['wpc_linked_tag'] ) ) {
			$settings['wpc_linked_tag'] = array();
		}

		wpf_render_tag_multiselect( array( 'setting' => $settings['wpc_linked_tag'], 'meta_name' => 'wpf-settings', 'field_id' => 'wpc_linked_tag', 'limit' => 1, 'placeholder' => __( 'Select tag', 'wp-fusion' ) ) );

		echo '</p>'; */


	}

}

new WPF_WPComplete;
