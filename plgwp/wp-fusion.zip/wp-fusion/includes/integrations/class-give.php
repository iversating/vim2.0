<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


class WPF_Give extends WPF_Integrations_Base {

	/**
	 * Gets things started
	 *
	 * @access  public
	 * @since   1.0
	 * @return  void
	 */

	public function init() {

		$this->slug = 'give';

		add_action( 'give_insert_payment', array( $this, 'insert_payment' ), 10, 2 );
		add_action( 'give_update_payment_status', array( $this, 'update_status' ), 10, 3 );

		// Custom Fields
		add_filter( 'wpf_meta_field_groups', array( $this, 'add_meta_field_group' ) );
		add_filter( 'wpf_meta_fields', array( $this, 'add_meta_fields' ) );

		// Settings
		add_filter( 'give_metabox_form_data_settings', array( $this, 'add_settings' ), 20 );
		add_action( 'save_post', array( $this, 'save_meta_box_data' ) );

	}

	/**
	 * Send data to CRM and apply tags on payment insert
	 *
	 * @access  public
	 * @return  void
	 */

	public function insert_payment( $payment_id, $payment_data = array() ) {

		$settings = get_post_meta( $payment_data['give_form_id'], 'wpf_settings_give', true );

		if ( empty( $settings ) || $settings['enabled'] != 'enabled' ) {
			return;
		}

		$update_data = array(
			'user_email' => $payment_data['user_email'],
			'first_name' => $payment_data['user_info']['first_name'],
			'last_name'  => $payment_data['user_info']['last_name'],
		);

		// Merge in custom fields
		if ( ! empty( $_POST ) ) {
			$update_data = array_merge( $update_data, $_POST );
		}

		$apply_tags = array();

		if ( ! empty( $settings['apply_tags'] ) ) {
			$apply_tags = array_merge( $apply_tags, $settings['apply_tags'] );
		}

		if ( ! empty( $settings['apply_tags_level'][ $payment_data['give_price_id'] ] ) ) {
			$apply_tags = array_merge( $apply_tags, $settings['apply_tags_level'][ $payment_data['give_price_id'] ] );
		}

		if ( ! empty( $payment_data['user_info']['id'] ) ) {

			if ( $payment_data['status'] == 'pending' ) {
				wp_fusion()->user->push_user_meta( $payment_data['user_info']['id'], $update_data );
			}

			if ( $payment_data['status'] == 'publish' ) {
				wp_fusion()->user->apply_tags( $apply_tags, $payment_data['user_info']['id'] );
			}

			$contact_id = wp_fusion()->user->get_contact_id( $payment_data['user_info']['id'] );

		} else {

			$contact_id = wp_fusion()->crm->get_contact_id( $update_data['user_email'] );

			if ( $payment_data['status'] == 'pending' ) {

				// All Give payments pass through pending before their status is set to Publish, so we'll only update the contact data during that stage to avoid it being sent twice during a transaction

				wpf_log(
					'info', 0, 'Give <a href="' . admin_url() . '/post.php?post=' . $payment_data['give_form_id'] . '&action=edit">' . get_the_title( $payment_data['give_form_id'] ) . '</a> donation:', array(
						'meta_array_nofilter' => $update_data,
						'source'              => 'give',
					)
				);

				if ( ! is_wp_error( $contact_id ) && empty( $contact_id ) ) {

					// Add new contact
					$contact_id = wp_fusion()->crm->add_contact( $update_data );

					if ( is_wp_error( $contact_id ) ) {

						wpf_log( $contact_id->get_error_code(), 0, 'Error adding contact to ' . wp_fusion()->crm->name . ': ' . $contact_id->get_error_message(), array( 'source' => 'give' ) );

					}
				} elseif ( ! is_wp_error( $contact_id ) && ! empty( $contact_id ) ) {

					wp_fusion()->crm->update_contact( $contact_id, $update_data );

				}

			}

			if ( $payment_data['status'] == 'publish' ) {

				wpf_log(
					'info', 0, 'Give applying tags: ', array(
						'tag_array' => $apply_tags,
						'source'    => 'give',
					)
				);

				wp_fusion()->crm->apply_tags( $apply_tags, $contact_id );

			}
		}

		if ( $payment_data['status'] == 'publish' ) {

			do_action( 'wpf_give_payment_complete', $payment_id, $contact_id, $payment_data );

		}

	}

	/**
	 * Maybe trigger payment complete actions when status updated
	 *
	 * @access  public
	 * @return  void
	 */

	public function update_status( $payment_id, $status, $old_status ) {

		$payment = new Give_Payment( $payment_id );

		if ( $status == 'publish' ) {

			$payment_data = array(
				'give_form_id'  => $payment->form_id,
				'give_price_id' => $payment->price_id,
				'status'        => 'publish',
				'user_email'    => $payment->email,
				'user_info'     => array(
					'id'         => $payment->user_id,
					'first_name' => false,
					'last_name'  => false,
					'email'      => $payment->email,
				),
				'price'         => $payment->subtotal,
				'currency'      => $payment->currency,
				'date'          => $payment->date,
			);

			$this->insert_payment( $payment_id, $payment_data );

		}

	}


	/**
	 * Adds Give field group to meta fields list
	 *
	 * @access  public
	 * @return  array Field groups
	 */

	public function add_meta_field_group( $field_groups ) {

		$field_groups['give'] = array(
			'title'  => 'Give',
			'fields' => array(),
		);

		return $field_groups;

	}

	/**
	 * Add Give fields
	 *
	 * @access  public
	 * @return  array Meta Fields
	 */

	public function add_meta_fields( $meta_fields ) {

		$forms_query = new Give_Forms_Query(
			array(
				'number'      => 30,
				'post_status' => 'publish',
			)
		);

		// Fetch the donation forms.
		$forms = $forms_query->get_forms();

		if ( ! empty( $forms ) ) {

			foreach ( $forms as $form ) {

				$fields = give_get_meta( $form->ID, 'give-form-fields', true, false, 'form' );

				if ( ! empty( $fields ) ) {

					foreach ( $fields as $field ) {

						$meta_fields[ $field['name'] ] = array(
							'label' => $field['label'],
							'type'  => $field['input_type'],
							'group' => 'give',
						);

					}
				}
			}
		}

		return $meta_fields;

	}


	/**
	 * Add settings to admin form editor
	 *
	 * @access  public
	 * @return  array Settings
	 */

	public function add_settings( $settings ) {

		$fields = array(
			array(
				'name'    => __( 'Create Contacts', 'wp-fusion' ),
				'desc'    => sprintf( __( 'Create contacts in %s when donations are given?', 'give' ), wp_fusion()->crm->name ),
				'id'      => 'wpf_settings_give_enabled',
				'type'    => 'radio_inline',
				'default' => 'enabled',
				'options' => array(
					'enabled'  => __( 'Enabled', 'wp-fusion' ),
					'disabled' => __( 'Disabled', 'wp-fusion' ),
				),
			),
			array(
				'name'     => __( 'Apply Tags', 'wp-fusion' ),
				'desc'     => sprintf( __( 'Apply these tags in %s when a donation is given.', 'wp-fusion' ), wp_fusion()->crm->name ),
				'id'       => 'apply_tags',
				'type'     => 'select4',
				'callback' => array( $this, 'select_callback' ),
			),
		);

		$settings['wp_fusion'] = array(
			'id'        => 'wp_fusion',
			'title'     => 'WP Fusion',
			'icon-html' => '<span class="dashicons dashicons-tag"></span>',
			'fields'    => $fields,
		);

		// Add donation options settings
		foreach ( $settings['form_field_options']['fields'] as $i => $field ) {

			if ( isset( $field['id'] ) && $field['id'] == '_give_donation_levels' ) {

				$settings['form_field_options']['fields'][ $i ]['fields'][] = array(
					'name'     => __( 'Apply Tags', 'wp-fusion' ),
					'desc'     => sprintf( __( 'Apply these tags in %s when a donation is given at this level.', 'wp-fusion' ), wp_fusion()->crm->name ),
					'id'       => 'apply_tags',
					'type'     => 'select4',
					'callback' => array( $this, 'select_callback' ),
				);

			}
		}

		return $settings;

	}

	/**
	 * Render WPF select box
	 *
	 * @access  public
	 * @return  mixed HTML Output
	 */

	public function select_callback( $field ) {

		global $post;

		$settings = get_post_meta( $post->ID, 'wpf_settings_give', true );

		if ( empty( $settings ) ) {
			$settings = array();
		}

		$defaults = array(
			'apply_tags'       => array(),
			'apply_tags_level' => array(),
		);

		$settings = array_merge( $defaults, $settings );

		$field['name'] = isset( $field['name'] ) ? $field['name'] : $field['id'];

		wp_nonce_field( 'wpf_meta_box_give', 'wpf_meta_box_give_nonce' );

		echo '<fieldset class="give-field-wrap ' . esc_attr( $field['id'] ) . '_field"><span class="give-field-label">' . wp_kses_post( $field['name'] ) . '</span><legend class="screen-reader-text">' . wp_kses_post( $field['name'] ) . '</legend>';

		$args = array(
			'setting'   => $settings['apply_tags'],
			'meta_name' => 'wpf_settings_give',
			'field_id'  => 'apply_tags',
		);

		if ( isset( $field['repeat'] ) ) {

			$field_sub_id = str_replace( '_give_donation_levels_', '', $field['id'] );
			$field_sub_id = str_replace( '_apply_tags', '', $field_sub_id );

			$args['field_id']     = 'apply_tags_level';
			$args['field_sub_id'] = $field_sub_id;

			$args['setting'] = $settings['apply_tags_level'];

			if ( ! isset( $args['setting'][ $field_sub_id ] ) ) {
				$args['setting'][ $field_sub_id ] = array();
			}
		}

		wpf_render_tag_multiselect( $args );

		echo give_get_field_description( $field );
		echo '</fieldset>';

	}


	/**
	 * Saves WPF configuration to product
	 *
	 * @access public
	 * @return mixed
	 */

	public function save_meta_box_data( $post_id ) {

		// Check if our nonce is set.
		if ( ! isset( $_POST['wpf_meta_box_give_nonce'] ) ) {
			return;
		}

		// Verify that the nonce is valid.
		if ( ! wp_verify_nonce( $_POST['wpf_meta_box_give_nonce'], 'wpf_meta_box_give' ) ) {
			return;
		}

		// If this is an autosave, our form has not been submitted, so we don't want to do anything.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Don't update on revisions
		if ( $_POST['post_type'] == 'revision' ) {
			return;
		}

		if ( isset( $_POST['wpf_settings_give'] ) ) {
			$data = $_POST['wpf_settings_give'];
		} else {
			$data = array();
		}

		if ( isset( $_POST['wpf_settings_give_enabled'] ) ) {
			$data['enabled'] = $_POST['wpf_settings_give_enabled'];
		}

		// Update the meta field in the database.
		update_post_meta( $post_id, 'wpf_settings_give', $data );

	}

}

new WPF_Give();
