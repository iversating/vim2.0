<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


class WPF_WishListMember extends WPF_Integrations_Base {

	/**
	 * Gets things started
	 *
	 * @access  public
	 * @return  void
	 */

	public function init() {

		$this->slug = 'wishlist-member';

		// WPF hooks
		add_filter( 'wpf_meta_field_groups', array( $this, 'add_meta_field_group' ), 10 );
		add_filter( 'wpf_meta_fields', array( $this, 'prepare_meta_fields' ), 20 );
		add_filter( 'wpf_user_register', array( $this, 'user_register' ) );
		add_filter( 'wpf_tags_modified', array( $this, 'update_levels' ), 10, 2 );

		// Create Sub-Menu
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );

		// Making Custom contact fields for WPF settings
		add_action( 'wishlistmember_add_user_levels', array( $this, 'add_user_levels' ), 10, 3 );
		add_action( 'wishlistmember_pre_remove_user_levels', array( $this, 'remove_user_levels' ), 99, 2 );

	}

	public function add_meta_field_group( $field_groups ) {

		if ( ! isset( $field_groups['wishlist_member'] ) ) {
			$field_groups['wishlist_member'] = array(
				'title'  => 'Wishlist Member',
				'fields' => array(),
			);
		}

		return $field_groups;

	}

	/**
	 * Sets field labels and types for EDD custom fields
	 *
	 * @access  public
	 * @return  array Meta fields
	 */

	public function prepare_meta_fields( $meta_fields ) {

		$meta_fields['company']  = array(
			'label' => 'Company',
			'type'  => 'text',
			'group' => 'wishlist_member',
		);
		$meta_fields['address1'] = array(
			'label' => 'Address (First Line)',
			'type'  => 'text',
			'group' => 'wishlist_member',
		);
		$meta_fields['address2'] = array(
			'label' => 'Adress (Second Line)',
			'type'  => 'text',
			'group' => 'wishlist_member',
		);
		$meta_fields['city']     = array(
			'label' => 'City',
			'type'  => 'text',
			'group' => 'wishlist_member',
		);
		$meta_fields['state']    = array(
			'label' => 'State',
			'type'  => 'text',
			'group' => 'wishlist_member',
		);
		$meta_fields['zip']      = array(
			'label' => 'Zip Code',
			'type'  => 'text',
			'group' => 'wishlist_member',
		);
		$meta_fields['country']  = array(
			'label' => 'Country',
			'type'  => 'text',
			'group' => 'wishlist_member',
		);

		global $WishListMemberInstance;
		$registration_forms = $WishListMemberInstance->GetOption( 'regpage_form' );

		if ( empty( $registration_forms ) ) {
			return $meta_fields;
		}

		foreach ( $registration_forms as $form_key ) {

			$form_data = $WishListMemberInstance->GetOption( $form_key );

			if ( empty( $form_data ) ) {
				continue;
			}

			foreach ( $form_data['form_dissected']['fields'] as $data ) {

				if ( isset( $data['system_field'] ) || isset( $data['wp_field'] ) ) {
					continue;
				}

				$meta_fields[ $data['attributes']['name'] ] = array(
					'label' => $data['label'],
					'type'  => $data['type'],
					'group' => 'wishlist_member',
				);

			}
		}

		return $meta_fields;

	}

	/**
	 * Triggered when level changes
	 *
	 * @access public
	 * @return void
	 */

	function add_user_levels( $user_id, $addlevels ) {

		$settings = get_option( 'wpf_wlm_settings' );

		if ( empty( $settings ) ) {
			return;
		}

		foreach ( $settings as $level_id => $level_settings ) {

			foreach ( $addlevels as $add_level_id ) {

				if ( $add_level_id == $level_id ) {

					wp_fusion()->user->apply_tags( $level_settings['apply_tags'], $user_id );
					wp_fusion()->user->apply_tags( $level_settings['tag_link'], $user_id );

				}
			}
		}

	}

	/**
	 * Getting and Prepping info from registration forms
	 *
	 * @access public
	 * @return void
	 */

	function remove_user_levels( $user_id, $removed_levels ) {

		$settings = get_option( 'wpf_wlm_settings' );

		if ( empty( $settings ) ) {
			return;
		}

		foreach ( $settings as $level_id => $level_settings ) {

			foreach ( $removed_levels as $removed_levels_id ) {

				if ( $removed_levels_id == $level_id ) {

					wp_fusion()->user->remove_tags( $level_settings['apply_tags'], $user_id );
					wp_fusion()->user->remove_tags( $level_settings['tag_link'], $user_id );

				}
			}
		}

	}

	/**
	 * Adapt registration form fields to IS fields after creating user
	 *
	 * @access public
	 * @return array Post Data
	 */

	public function user_register( $post_data ) {

		$field_map = array(
			'password1' => 'user_pass',
		);

		$post_data = $this->map_meta_fields( $post_data, $field_map );

		return $post_data;

	}

	/**
	 * Update user levels when linked tags are modified
	 *
	 * @access public
	 * @return void
	 */

	public function update_levels( $user_id, $user_tags ) {

		remove_action( 'wishlistmember_add_user_levels', array( $this, 'add_user_levels' ), 10, 3 );
		remove_action( 'wishlistmember_pre_remove_user_levels', array( $this, 'remove_user_levels' ), 99, 2 );

		$settings = get_option( 'wpf_wlm_settings' );

		if ( ! empty( $settings ) ) {

			$levels_to_add    = array();
			$levels_to_remove = array();

			if ( function_exists( 'wlmapi_get_member_levels' ) ) {

				// Wishlist v3

				$levels = wlmapi_get_member_levels( $user_id );

				$user_levels = array();

				foreach ( $levels as $level ) {
					$user_levels[] = $level->Level_ID;
				}

			} else {

				// Wishlist v2x

				global $WishListMemberInstance;
				$user_levels = $WishListMemberInstance->GetMembershipLevels( $user_id );

			}

			foreach ( $settings as $level_id => $tags ) {

				if ( empty( $tags['tag_link'] ) ) {
					continue;
				}

				$tag_id = $tags['tag_link'][0];

				if ( in_array( $tag_id, $user_tags ) && ! in_array( $level_id, $user_levels ) ) {
					$levels_to_add[] = $level_id;
				}

				if ( in_array( $level_id, $user_levels ) && ! in_array( $tag_id, $user_tags ) ) {
					$levels_to_remove[] = $level_id;
				}
			}

			if ( function_exists( 'wlmapi_update_member' ) ) {

				// Wishlist v3

				if ( ! empty( $levels_to_add ) ) {
					wlmapi_update_member( $user_id, array( 'Levels' => $levels_to_add ) );
				}

				if ( ! empty( $levels_to_remove ) ) {
					wlmapi_update_member( $user_id, array( 'RemoveLevels' => $levels_to_remove ) );
				}

			} else {

				// Wishlist v2x

				if ( ! empty( $levels_to_add ) ) {
					$wlmapi = new WLMAPI();
					$wlmapi->AddUserLevels( $user_id, $levels_to_add );
					$wlmapi->MakeSequential( $user_id ); // Enables sequential upgrade
				}

				if ( ! empty( $levels_to_remove ) ) {
					$wlmapi = new WLMAPI();
					$wlmapi->DeleteUserLevels( $user_id, $levels_to_remove );
				}

			}

		}

		add_action( 'wishlistmember_add_user_levels', array( $this, 'add_user_levels' ), 10, 3 );
		add_action( 'wishlistmember_pre_remove_user_levels', array( $this, 'remove_user_levels' ), 99, 2 );

	}

	/**
	 * Creates WLM submenu item
	 *
	 * @access public
	 * @return void
	 */

	public function admin_menu() {

		$crm = wp_fusion()->crm->name;

		$id = add_submenu_page(
			'WishListMember',
			$crm . ' Integration',
			'WP Fusion',
			'manage_options',
			'wp-submenu',
			array( $this, 'render_admin_menu' )
		);

		add_action( 'load-' . $id, array( $this, 'enqueue_scripts' ) );

	}


	/**
	 * Enqueues WPF scripts and styles on WLM options page
	 *
	 * @access public
	 * @return void
	 */

	public function enqueue_scripts() {

		wp_enqueue_style( 'bootstrap', WPF_DIR_URL . 'includes/admin/options/css/bootstrap.min.css' );
		wp_enqueue_style( 'options-css', WPF_DIR_URL . 'includes/admin/options/css/options.css' );
		wp_enqueue_style( 'wpf-options', WPF_DIR_URL . 'assets/css/wpf-options.css' );

	}

	/**
	 * Renders WLM submenu item
	 *
	 * @access public
	 * @return mixed
	 */

	public function render_admin_menu() {

		// Save settings
		if ( isset( $_POST['wpf_wlm_settings_nonce'] ) && wp_verify_nonce( $_POST['wpf_wlm_settings_nonce'], 'wpf_wlm_settings' ) ) {
			update_option( 'wpf_wlm_settings', $_POST['wpf-settings'] );
			echo '<div id="message" class="updated fade"><p><strong>Settings saved.</strong></p></div>';
		}

		?>

		<div class="wrap">
			<h2><?php echo wp_fusion()->crm->name; ?> Integration</h2>

			<form id="wpf-mm-settings" action="" method="post">
				<?php wp_nonce_field( 'wpf_wlm_settings', 'wpf_wlm_settings_nonce' ); ?>
				<input type="hidden" name="action" value="update">

				<h4>Product Tags</h4>
				<p class="description">For each product below, specify tags to be applied in <?php echo wp_fusion()->crm->name; ?> when purchased.</p>
				<br/>

				<?php global $WishListMemberInstance; ?>
				<?php $levels   = $WishListMemberInstance->GetOption( 'wpm_levels' ); ?>
				<?php $settings = get_option( 'wpf_wlm_settings' ); ?>

				<?php
				if ( empty( $settings ) ) {
					$settings = array();}
?>

				<table class="table table-hover wpf-settings-table" id="wpf-wishlist-levels-table">
					<thead>
					<tr>
						<th>Membership Level</th>
						<th>Apply Tags</th>
						<th>Tag Link</th>
					</tr>
					</thead>
					<tbody>

					<?php foreach ( $levels as $level_id => $level ) : ?>

						<?php
						if ( ! isset( $settings[ $level_id ] ) ) {
							$settings[ $level_id ] = array(
								'apply_tags' => array(),
								'tag_link'   => array(),
							);
						}
						?>

						<tr>
							<td><?php echo $level['name']; ?></td>
							<td>
								<?php

								$args = array(
									'setting'      => $settings[ $level_id ],
									'meta_name'    => 'wpf-settings',
									'field_id'     => $level_id,
									'field_sub_id' => 'apply_tags',
								);

								wpf_render_tag_multiselect( $args );

								?>
								
							</td>
							<td>
								<?php

								$args = array(
									'setting'      => $settings[ $level_id ],
									'meta_name'    => 'wpf-settings',
									'field_id'     => $level_id,
									'field_sub_id' => 'tag_link',
									'limit'        => 1,
									'no_dupes'     => array( 'apply_tags' ),
								);

								wpf_render_tag_multiselect( $args );

								?>
								
							</td>
						</tr>

					<?php endforeach; ?>

					</tbody>

				</table>

				<p class="submit"><input name="Submit" type="submit" class="button-primary" value="Save Changes"/>
				</p>

			</form>

		</div>

		<?php

	}


}

new WPF_WishListMember();
