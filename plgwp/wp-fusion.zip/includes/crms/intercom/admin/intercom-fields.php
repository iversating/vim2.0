<?php

$intercom_fields = array();

$intercom_fields['first_name'] = array(
	'crm_label' => 'Name',
	'crm_field' => 'name'
);

$intercom_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email'
);

$intercom_fields['phone_number'] = array(
	'crm_label' => 'Phone',
	'crm_field' => 'phone'
);