<?php

$aweber_fields = array();

$aweber_fields['first_name'] = array(
	'crm_label' => 'Name',
	'crm_field' => 'name'
);

$aweber_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email'
);

$aweber_fields['billing_postcode'] = array(
	'crm_label' => 'Postal Code',
	'crm_field' => 'postal_code'
);

$aweber_fields['billing_city'] = array(
	'crm_label' => 'City',
	'crm_field' => 'city'
);

$aweber_fields['billing_country'] = array(
	'crm_label' => 'Country',
	'crm_field' => 'country'
);
