<div class="thrv_wrapper thrv_tvo_display_testimonials tcb-elem-placeholder">
	<span class="tcb-inline-placeholder-action with-icon">
		<?php tcb_icon( 'add', false, 'editor' ); ?>
		<?php echo __( 'Select Testimonials', 'thrive-cb' ); ?>
	</span>
</div>
