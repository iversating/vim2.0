<?php
/**
 * Created by PhpStorm.
 * User: Danut
 * Date: 6/9/2015
 * Time: 7:14 PM
 */

require_once( dirname( __FILE__ ) . '/admin.php' );