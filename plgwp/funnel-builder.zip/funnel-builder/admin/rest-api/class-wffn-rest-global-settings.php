<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class WFFN_REST_Global_Settings
 *
 * * @extends WP_REST_Controller
 */
if ( ! class_exists( 'WFFN_REST_Global_Settings' ) ) {
	class WFFN_REST_Global_Settings extends WP_REST_Controller {

		public static $_instance = null;

		/**
		 * Route base.
		 *
		 * @var string
		 */

		protected $namespace = 'woofunnels-admin';
		protected $rest_base = 'funnels/settings';

		public function __construct() {
			add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		}

		public static function get_instance() {
			if ( null === self::$_instance ) {
				self::$_instance = new self;
			}

			return self::$_instance;
		}

		/**
		 * Register the routes for taxes.
		 */
		public function register_routes() {
			register_rest_route( $this->namespace, '/' . $this->rest_base . '/(?P<tab>[\w-]+)', array(
				'args' => array(
					'tab' => array(
						'description' => __( 'Unique tab for the resource.', 'funnel-builder' ),
						'type'        => 'string',
						'required'    => true,
					),
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'woofunnels_global_settings' ),
					'permission_callback' => array( $this, 'get_api_permission_check' ),
					'args'                => array(
						'settings' => array(
							'description'       => __( 'settings', 'funnel-builder' ),
							'type'              => 'string',
							'validate_callback' => 'rest_validate_request_arg',
							'sanitize_callback' => array( $this, 'sanitize_custom' ),
						),
					),
				),
			) );
			register_rest_route( $this->namespace, '/funnels/global-settings', array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_funnel_global_settings' ),
					'permission_callback' => array( $this, 'get_api_permission_check' ),
					'args'                => [],
				),
			) );
		}

		public function get_funnel_global_settings() {
			$License = WooFunnels_licenses::get_instance();
			$License->get_data();
			$data                        = [];

			if(!function_exists('get_current_screen')) {
				require_once ABSPATH . 'wp-admin/includes/screen.php';
			}
			$get_all_registered_settings = apply_filters( 'woofunnels_global_settings', [] );

			if ( is_array( $get_all_registered_settings ) && count( $get_all_registered_settings ) > 0 ) {
				usort( $get_all_registered_settings, function ( $a, $b ) {
					if ( $a['priority'] === $b['priority'] ) {
						return 0;
					}

					return ( $a['priority'] < $b['priority'] ) ? - 1 : 1;
				} );
				$data['global_settings_tabs'] = $get_all_registered_settings;
			}
			$data['global_settings'] = apply_filters( 'woofunnels_global_settings_fields', [] );

			return rest_ensure_response( $data );
		}

		public function get_api_permission_check() {

			return current_user_can( 'manage_options' );
		}




		public function woofunnels_global_settings( WP_REST_Request $request ) {
			$resp = array(
				'success' => false,
				'msg'     => __( 'Failed', 'funnel-builder' )
			);

			$settings = $request->get_param( 'settings' );
			$tab      = $request->get_param( 'tab' );

			if ( ! is_array( $settings ) || count( $settings ) === 0 ) {
				return rest_ensure_response( $resp );
			}

			do_action( 'bwf_global_save_settings_' . $tab, $settings );

			$resp = array(
				'success' => true,
				'msg'     => __( 'Settings Updated', 'funnel-builder' )
			);

			return rest_ensure_response( $resp );
		}

		public function sanitize_custom( $data ) {
			return json_decode( $data, true );
		}

	}

	if ( ! function_exists( 'wffn_rest_global_settings' ) ) {

		function wffn_rest_global_settings() {  //@codingStandardsIgnoreLine
			return WFFN_REST_Global_Settings::get_instance();
		}
	}

	wffn_rest_global_settings();
}