<?php //phpcs:ignore WordPress.WP.TimezoneChange.DeprecatedSniff ?>
<div id="wffn_design_container">
	<?php
	$data = get_option('_bwf_fb_templates');
	if( !is_array($data) || count($data) === 0 ){ ?>
		<div class="empty_template_error">
			<div class="bwf-c-global-error" style="display: flex; align-items: center; justify-content: center; height: 60vh;">
				<div class="bwf-c-global-error-center" style="text-align: center; background-color: rgb(255, 255, 255); width: 500px; padding: 50px;">
					<span class="dashicon dashicons dashicons-warning" style="font-size: 70px; height: 70px; width: 70px;"></span>
					<p><?php esc_html_e( 'It seems there are some technical difficulties. Press F12 to open console. Take Screenshot of the error and send it to support.', 'funnel-builder' ) ?></p>
					<a herf="#" class="button button-primary is-primary"><span class="dashicon dashicons dashicons-image-rotate"></span>&nbsp;<?php esc_html_e( 'Refresh', 'funnel-builder' ) ?></a>
				</div>
			</div>
		</div>
	<?php }else {?>
		<div class="wffn_tab_container wffn-hide" v-if="'no'==template_active" v-bind:class="'no'==template_active?'wffn-show':''">
			<div class="wffn_template_header">
				<div class="wffn_template_header_item" v-for="(templates,type) in designs" v-if="(current_template_type==type) && (_.size(templates)>0)">
					<div class="wffn_filter_container" v-if="(`undefined`!==typeof filters) && _.size(filters)>0 && `wp_editor`!==type">
						<div v-for="(name,i) in filters" :data-filter-type="i" v-bind:class="'wffn_filter_container_inner'+(currentStepsFilter==i?' wffn_selected_filter':'')" v-on:click="currentStepsFilter = i">
							<div class="wffn_template_filters">{{name}}</div>
						</div>
					</div>
				</div>

				<div class="wffn_template_header_item wffn_template_editor_wrap wffn_ml_auto">
					<div class="wffn_template_editor">
						<span class="wffn_editor_field_label"><?php esc_html_e( 'Page Builder:', 'funnel-builder' ) ?></span>
						<div class="wffn_editor_field wffn_field_select_dropdown">
							<span class="wffn_editor_label wffn_field_select_label" v-on:click="show_template_dropdown">
								{{design_types[current_template_type]}}
								<i class="dashicons dashicons-arrow-down-alt2"></i>
							</span>
							<div class="wffn_field_dropdown wffn-hide">
								<div class="wffn_dropdown_header">
									<label class="wffn_dropdown_header_label"><?php esc_html_e( 'Select Page Builder', 'funnel-builder' ) ?></label>
								</div>
								<div class="wffn_dropdown_body">
									<label v-for="(design_name,type) in design_types" v-on:click="setTemplateType(type)" class="wffn_dropdown_fields">
										<input type="radio" name="wffn_po" v-bind:value="type" :checked="current_template_type==type"/>
										<span>{{design_name}}</span>
									</label>
								</div>
								<div class="wffn_dropdown_footer">

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<section id="wffn_content1" class="wffn_tab-content wf_funnel_tab-content" style="display: block" v-for="(templates,type) in designs" v-if="(current_template_type==type) && (_.size(templates)>0)">
				<div class="wffn_pick_template">
					<div v-for="(template,slug) in templates" v-on:data-slug="slug" class="wffn_temp_card wf_funnel_temp_card" v-if="((`undefined`=== typeof currentStepsFilter) ||(`undefined`!==typeof currentStepsFilter) && (currentStepsFilter === 'all' || checkInArray(template.group, currentStepsFilter) != ''))">
						<div class="wffn_template_sec wffn_build_from_scratch" v-if="template.build_from_scratch">
							<div class="wffn_template_sec_design" v-on:click="triggerImport(template,slug,type,$event)">
								<div class="wffn_temp_overlay">
									<div class="wffn_temp_middle_align">
										<div class="wffn_add_tmp_se">
											<a href="javascript:void(0)" class="wffn_template_btn_add">
												<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 26">
													<g fill="none" fill-rule="evenodd">
														<g fill-rule="nonzero">
															<g>
																<path d="M18 11.526c-.321-.045-.653-.067-.985-.067-3.897 0-7.058 3.195-7.058 7.134 0 1.23.31 2.389.852 3.401L10.8 22H3.435C2.09 22 1 20.898 1 19.538V2.462C1 1.102 2.09 0 3.436 0h8.934v4.073c0 1.052.842 1.903 1.882 1.903H18v5.55z" transform="translate(-511 -232) translate(511 232)"></path>
																<path fill="#FFF" fill-opacity=".25" d="M12 1l5 6h-3.328C12.747 7 12 6.146 12 5.09V1z" transform="translate(-511 -232) translate(511 232)"></path>
																<path fill="#FFF" d="M17.983 11.255v-4.92c0-.141-.066-.271-.159-.374L12.225.168C12.121.06 11.972 0 11.825 0H2.947C1.309 0 0 1.317 0 2.932V19.47c0 1.615 1.309 2.91 2.948 2.91h7.006c1.364 2.276 3.817 3.62 6.484 3.62C20.607 26 24 22.662 24 18.549c0-1.81-.654-3.55-1.864-4.91-1.095-1.224-2.558-2.059-4.153-2.384zm-5.609-9.353l3.756 3.896h-2.436c-.726 0-1.32-.59-1.32-1.306v-2.59zM1.1 19.47V2.932c0-1.02.82-1.848 1.848-1.848h8.326v3.408c0 1.317 1.084 2.39 2.42 2.39h3.19v4.232c-.165-.005-.297-.027-.44-.027-1.92 0-3.685.726-5.016 1.864H4.444c-.303 0-.55.244-.55.542 0 .298.247.542.55.542h5.961c-.39.542-.715 1.084-.968 1.68H4.444c-.303 0-.55.244-.55.542 0 .298.247.542.55.542H9.08c-.138.542-.21 1.143-.21 1.745 0 .948.182 1.885.534 2.752H2.948c-1.029 0-1.848-.813-1.848-1.826zm15.338 5.452c-2.37 0-4.554-1.28-5.686-3.333-.512-.927-.781-1.973-.781-3.035 0-3.511 2.898-6.367 6.462-6.367.302 0 .605.022.901.06 1.53.211 2.937.959 3.96 2.108 1.034 1.16 1.6 2.65 1.6 4.2.006 3.51-2.892 6.367-6.456 6.367z" transform="translate(-511 -232) translate(511 232)"></path>
																<path fill="#FFF" d="M4.577 11h5.846c.317 0 .577-.225.577-.5s-.26-.5-.577-.5H4.577c-.317 0-.577.225-.577.5s.26.5.577.5zM18.607 18.617h-1.204v-1.224c0-.216-.177-.393-.393-.393-.217 0-.393.177-.393.393v1.224h-1.224c-.216 0-.393.176-.393.393 0 .216.177.393.393.393h1.224v1.204c0 .216.176.393.393.393.216 0 .393-.177.393-.393v-1.204h1.204c.216 0 .393-.177.393-.393 0-.217-.177-.393-.393-.393z" transform="translate(-511 -232) translate(511 232)"></path>
															</g>
														</g>
													</g>
												</svg>
											</a>
										</div>
										<div class="wffn_p wffn_import_template">
											<span class="wffn_import_text"><?php esc_html_e( 'Start from scratch', 'funnel-builder' ); ?></span>
											<span class="wffn_importing_text"> <?php esc_html_e( 'Importing...', 'funnel-builder' ) ?></span>
											<div class="wffn_clear_20"></div>
											<span class="wffn_import_description"><?php esc_html_e( 'Create your Page from scratch', 'funnel-builder' ); ?></span>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="wffn_template_sec" v-else>
							<div class="wffn_template_sec_ribbon" v-bind:class="`yes`===template.pro?`wffn-pro`:``" v-if="`yes`===template.pro">{{wffn.i18n.ribbons.pro}}</div>
							<div v-bind:class="(template.is_pro?'wffn_template_sec_design_pro':'wffn_template_sec_design')">   <!-- USE THIS CLASS FOR PRO   and Use This Template btn will be Get Pro -->
								<img v-bind:src="template.thumbnail" class="wffn_img_temp">
								<div class="wffn_tmp_pro_tab"><?php esc_html_e( 'PRO', 'funnel-builder' ) ?></div>
								<div class="wffn_temp_overlay">
									<div class="wffn_temp_middle_align">
										<div class="wffn_pro_template" v-if="`yes`===template.pro&&false===template.license_exist">
											<a class="wffn_btn_white wffn_display_block">{{template.name}}</a>
											<a href="javascript:void(0)" v-on:click="triggerPreview(template,slug,type)" class="wffn_steps_btn wffn_steps_btn_success"><?php esc_html_e( 'Preview', 'funnel-builder' ) ?></a>
											<a target="_blank" href="<?php echo esc_url( 'https://buildwoofunnels.com/exclusive-offer/' ) ?>" class="wffn_steps_btn wf_funnel_btn_danger"><?php esc_html_e( 'Get PRO', 'funnel-builder' ); ?></a>
										</div>
										<div class="wffn_pro_template" v-else>
											<a href="javascript:void(0)" v-on:click="triggerPreview(template,slug,type)" class="wffn_steps_btn wffn_steps_btn_success"><?php esc_html_e( 'Preview', 'funnel-builder' ) ?></a>
											<a href="javascript:void(0)" class="wffn_steps_btn wffn_import_template wffn_btn_blue" v-on:click="triggerImport(template,slug,type,$event)"><span class="dashicons dashicons-update"></span><span class="wffn_import_text"><?php esc_html_e( 'Import', 'funnel-builder' ) ?></span><span class="wffn_importing_text"><?php esc_html_e( 'Importing...', 'funnel-builder' ) ?></span></a>
										</div>
									</div>
								</div>
							</div>
							<div class="wffn_template_sec_meta">
								<div class="wffn_template_meta_left">
									{{template.name}}
								</div>
								<div class="wffn_template_meta_right"></div>
							</div>
							<div v-if="true===ShouldPreview(slug,type)" class="wffn-preview-overlay">
								<div class="wffn_template_preview_wrap">
									<div class="wffn_template_preview_header">
										<div>
											<img src="<?php echo esc_url( plugin_dir_url( WFFN_PLUGIN_FILE ) . 'admin/assets/img/menu/WooFunnels-Logo.svg' ); ?>" alt="Funnel Builder for WordPress" width="148">
										</div>
										<div class="wffn_template_viewport">
											<div class="wffn_template_viewport_inner">
												<span class="wffn_viewport_icons active" v-on:click="setViewport('desktop', $event)" title="Desktop Viewport">
													<span class="dashicon dashicons dashicons-desktop"></span>
												</span>
												<span class="wffn_viewport_icons" v-on:click="setViewport('tablet', $event)" title="Tablet Viewport">
													<span class="dashicon dashicons dashicons-tablet"></span>
												</span>
												<span class="wffn_viewport_icons" v-on:click="setViewport('mobile', $event)" title="Mobile Viewport">
													<span class="dashicon dashicons dashicons-smartphone"></span>
												</span>
											</div>
										</div>
										<div class="bwf-t-center">

											<div v-if="`yes`===template.pro&&false===template.license_exist">
												<a target="_blank" href="<?php echo esc_url( 'https://buildwoofunnels.com/exclusive-offer/' ) ?>" class="wffn_steps_btn wf_funnel_btn_danger"><?php esc_html_e( 'Get PRO', 'funnel-builder' ); ?></a>
											</div>
											<div class="wffn_pro_template" v-else>
												<a href="javascript:void(0)" class="button button-primary wffn-import-template-btn is-primary wffn_steps_btn wffn_import_template" v-on:click="triggerImport(template,slug,type,$event)"><span class="wffn_import_text"><?php esc_html_e( 'Import', 'funnel-builder' ) ?></span><span class="wffn_importing_text"><?php esc_html_e( 'Importing...', 'funnel-builder' ) ?></span></a>
											</div>


										</div>
										<div class="wffn_template_preview_close">
											<button type="button" v-on:click="previewClosed()" class="components-button">
												<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14"><path d="M9.46702 7.99987L15.6972 1.76948C16.1027 1.36422 16.1027 0.708964 15.6972 0.303702C15.292 -0.10156 14.6367 -0.10156 14.2315 0.303702L8.00106 6.5341L1.77084 0.303702C1.36539 -0.10156 0.710327 -0.10156 0.305065 0.303702C-0.100386 0.708964 -0.100386 1.36422 0.305065 1.76948L6.53528 7.99987L0.305065 14.2303C-0.100386 14.6355 -0.100386 15.2908 0.305065 15.696C0.507032 15.8982 0.772588 15.9998 1.03795 15.9998C1.30332 15.9998 1.56869 15.8982 1.77084 15.696L8.00106 9.46565L14.2315 15.696C14.4336 15.8982 14.699 15.9998 14.9643 15.9998C15.2297 15.9998 15.4951 15.8982 15.6972 15.696C16.1027 15.2908 16.1027 14.6355 15.6972 14.2303L9.46702 7.99987Z" fill="#353030"></path></svg>
											</button>
										</div>
									</div>
									<div class="wffn_template_preview_content">
										<div class="wffn_template_preview_inner wffn_funnel_preview">
											<div class="wffn-web-preview wffn_template_preview_frame">
												<div class="wffn-web-preview__iframe-wrapper">
													<div class="wffn_global_loader">
														<div class="spinner"></div>
													</div>
													<iframe v-bind:src="getPreviewUrl(template.slug, type)" width="100%" height="100%"></iframe>
												</div>
											</div>
										</div>
										<div class="wffn_template_preview_sidebar">
											<div v-for="(template,slug) in templates" v-on:data-slug="slug" v-if="template.build_from_scratch !== true && ((`undefined`=== typeof currentStepsFilter) ||(`undefined`!==typeof currentStepsFilter) && (currentStepsFilter === 'all' || checkInArray(template.group, currentStepsFilter) != ''))">
												<label class="wffn_template_page_options" v-bind:pre_slug="template.slug" v-on:click="triggerPreview(template,slug,type)">
													<img v-bind:src="template.thumbnail">
													<span class="wffn_template_name">{{template.name}}</span>
												</label>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="wffn_clear_20"></div>
					<div class="wffn_clear_20"></div>
			</section>
		</div>
	<?php } ?>
</div>
<!------  WITH TEMPLATES  ------->
