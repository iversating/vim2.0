<?php

abstract class WFACP_OXY_HTML_BLOCK extends WFACP_OXY_Field {


	public function __construct() {
		parent::__construct();

		WFACP_OXY::set_locals( $this->get_local_slug(), $this->get_id() );
		add_filter( 'pre_do_shortcode_tag', [ $this, 'pick_data' ], 10, 3 );
	}

	public function options() {
		return [ 'rebuild_on_dom_change' => true ];
	}

	final public function render( $setting, $defaults, $content ) {

		if ( apply_filters( 'wfacp_print_oxy_widget', true, $this->get_id(), $this ) ) {
			if ( WFACP_OXY::is_template_editor() ) {
				$this->preview_shortcode();

				return;
			}
			$this->parse_render_settings();
			$this->settings = $setting;
			$id             = $this->get_id();
			WFACP_Common::set_session( $id, $this->settings );
			$this->html( $setting, $defaults, $content );
			if ( isset( $_REQUEST['action'] ) && false !== strpos( $_REQUEST['action'], 'oxy_render' ) ) {//phpcs:ignore
				exit;
			}
		}

	}

	protected function html( $setting, $defaults, $content ) { //phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedParameter

	}

	protected function preview_shortcode() {
		echo '';
	}

	protected function available_html_block() {
		$block = [ 'product_switching', 'order_total' ];

		return apply_filters( 'wfacp_html_block_elements', $block );
	}

	public function get_title() {
		return __( 'Checkout Form', 'woofunnels-aero-checkout' );
	}

	protected function order_summary( $field_key ) {


		$tab_id = $this->add_tab( __( 'Order Summary', 'woofunnels-aero-checkout' ) );
		$this->add_heading( $tab_id, 'Product' );

		$this->add_switcher( $tab_id, 'order_summary_enable_product_image', __( 'Enable Image', 'woofunnels-aero-checkout' ), 'on' );

		$cart_item_color = [
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody .wfacp_order_summary_item_name',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody .product-name .product-quantity',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody td.product-total',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody .cart_item .product-total span',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody .cart_item .product-total span bdi',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody .cart_item .product-total span.amount',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody .cart_item .product-total small',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody .wfacp_order_summary_container dl',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody .wfacp_order_summary_container dd',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody .wfacp_order_summary_container dt',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody .wfacp_order_summary_container p',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody tr span.amount',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody dl',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody dd',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody dt',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody p',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody tr td span:not(.wfacp-pro-count)',
		];
		$cart_item_color = implode( ',', $cart_item_color );
		$this->add_typography( $tab_id, $field_key . '_cart_item_typo', $cart_item_color, 'Product Typography' );
		$this->add_border_color( $tab_id, 'mini_product_image_border_color', '#wfacp-e-form table.shop_table.woocommerce-checkout-review-order-table tr.cart_item .product-image img', '', __( 'Image Border Color', 'woofunnels-aero-checkout' ), false, [ 'order_summary_enable_product_image' => 'on' ] );


		$cart_subtotal_color_option = [
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.cart-subtotal th',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot .shipping_total_fee td',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.cart-subtotal td',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.cart-subtotal td span.woocommerce-Price-amount.amount',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.cart-subtotal td p',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.cart-subtotal td span',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.shipping_total_fee td span.amount',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.shipping_total_fee td span',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.shipping_total_fee td span bdi',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.cart-discount td',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.cart-discount th',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.cart-discount td span',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.cart-discount td span bdi',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.cart-discount td span.amount',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.cart-discount td p',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total)',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) td',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) td span',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) td span bdi',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) td small',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) td p',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) th',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) th span',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) th small',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) ul',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) ul li',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) ul li label',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr:not(.order-total) td span.woocommerce-Price-amount.amount',
		];


		$cart_subtotal_color_option = implode( ',', $cart_subtotal_color_option );
		$this->add_typography( $tab_id, 'order_summary_product_meta_typo', $cart_subtotal_color_option, 'Subtotal Typography' );

		$cart_total_color_option = [
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total th',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total td',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total td span.woocommerce-Price-amount.amount',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total td p',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total td span',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total td span bdi',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total td',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total td span',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total td small',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total td p',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total th',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total th span',
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table.woocommerce-checkout-review-order-table tfoot tr.order-total th small',
		];


		$cart_total_color_option = implode( ',', $cart_total_color_option );
		$this->add_typography( $tab_id, $field_key . '_cart_subtotal_heading_typo', $cart_total_color_option, 'Total Typography' );

		$this->add_heading( $tab_id, __( 'Divider', 'woocommerce' ) );
		$divider_line_color = [
			'#wfacp-e-form .wfacp_main_form.woocommerce table.shop_table tbody .wfacp_order_summary_item_name',
			'#wfacp-e-form table.shop_table.woocommerce-checkout-review-order-table tr.cart_item',
			'#wfacp-e-form table.shop_table.woocommerce-checkout-review-order-table tr.cart-subtotal',
			'#wfacp-e-form table.shop_table.woocommerce-checkout-review-order-table tr.order-total',
		];
		$this->add_border_color( $tab_id, $field_key . '_divider_line_color', implode( ',', $divider_line_color ), '' );

	}

	/**
	 * @param $field STring
	 * @param $this \Elementor\Widget_Base
	 */
	protected function generate_html_block( $field_key ) {
		if ( method_exists( $this, $field_key ) ) {
			$this->{$field_key}( $field_key );
		}
	}

	protected function divider_field() {
		return [
			'wfacp_start_divider_billing',
			'wfacp_start_divider_shipping',
			'wfacp_end_divider_billing',
			'wfacp_end_divider_shipping'
		];
	}

	public function pick_data( $status, $tag, $attr ) {

		if ( ( $tag === 'oxy-' . $this->slug() ) && ! empty( $attr ) && ! empty( $attr['ct_options'] ) ) {
			$ct_options = json_decode( $attr['ct_options'], true );
			if ( is_array( $ct_options ) && isset( $ct_options['media'] ) ) {

				$this->media_settings = $ct_options['media'];
			}


		}

		return $status;
	}

	public function parse_render_settings() {
		if ( ! defined( 'OXY_ELEMENTS_API_AJAX' ) ) {
			return;
		}

		oxygen_vsb_ajax_request_header_check();

		$component_json      = file_get_contents( 'php://input' );//phpcs:ignore
		$component           = json_decode( $component_json, true );
		$options             = $component['options']['original'];
		$options['selector'] = $component['options']['selector'];

		if ( is_array( $component['options']['media'] ) && count( $component['options']['media'] ) > 0 ) {
			$this->media_settings = $component['options']['media'];
		}

	}


}