<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WooCommerce Buy One Get One Free By Oscar Gare
 * Plugin URI: https://woocommerce.com/products/buy-one-get-one-free/
 */
class WFACP_Compatibility_With_WC_Buy_One_Get_One_Free {

	public function __construct() {
		$this->remove_actions();
	}

	public function remove_actions() {
		WFACP_Common::remove_actions( 'template_redirect', 'WC_BOGOF_Cart', 'refresh_cart_rules_items' );
	}
}

if ( ! class_exists( 'WC_BOGOF_Cart' ) ) {
	return;
}
WFACP_Plugin_Compatibilities::register( new WFACP_Compatibility_With_WC_Buy_One_Get_One_Free(), 'wfacp-bogof' );
