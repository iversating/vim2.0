<?php

class WFACP_Razorpay {
	public function __construct() {
		add_filter( 'woocommerce_get_checkout_url', [ $this, 'change_redirect_url' ],999 );
	}

	public function change_redirect_url( $url ) {
		if ( ! isset( $_GET['wc-api'] ) || 'razorpay' !== $_GET['wc-api'] ) {
			return $url;
		}
		if ( is_null( WC()->session ) ) {
			return $url;
		}
		global $woocommerce;
		$order_id = $woocommerce->session->get( WC_Razorpay::SESSION_KEY );
		$source   = get_post_meta( $order_id, '_wfacp_source', true );
		if ( ! empty( $source ) ) {
			$url = $source;
		}

		return $url;
	}
}

add_action( 'plugins_loaded', function () {
	if ( ! function_exists( 'woocommerce_razorpay_init' ) ) {
		return;
	}
	WFACP_Plugin_Compatibilities::register( new WFACP_Razorpay(), 'wfacp-razorpay' );

}, 15 );
