<?php return array('dependencies' => array('wp-dom-ready'), 'version' => 'c9983a06634dc03a68dd');
