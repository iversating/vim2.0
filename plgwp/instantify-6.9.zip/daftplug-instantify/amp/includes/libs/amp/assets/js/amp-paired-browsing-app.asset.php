<?php return array('dependencies' => array('wp-url'), 'version' => '709047f698d97c2b574b');
