<?php return array('dependencies' => array('lodash', 'wp-api-fetch'), 'version' => '7cde6c171349416ebc52');
