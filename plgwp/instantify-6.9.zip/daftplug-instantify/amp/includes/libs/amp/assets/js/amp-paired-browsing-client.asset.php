<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '0c223ffe0274ce418a33');
