<?php return array('dependencies' => array('lodash', 'wp-i18n'), 'version' => '98e47f8cb7b9199c60d8');
