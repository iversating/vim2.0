<?php return array('dependencies' => array('lodash', 'wp-dom-ready', 'wp-i18n'), 'version' => 'bd9bacd92a8c85e23514');
