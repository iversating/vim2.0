<?php return array('dependencies' => array('lodash'), 'version' => '2dd2b3fa9941b2186181');
