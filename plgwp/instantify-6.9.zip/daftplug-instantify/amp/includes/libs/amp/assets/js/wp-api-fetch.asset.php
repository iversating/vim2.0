<?php return array('dependencies' => array('lodash', 'wp-i18n'), 'version' => '8129fd7ffda5e92a7342');
