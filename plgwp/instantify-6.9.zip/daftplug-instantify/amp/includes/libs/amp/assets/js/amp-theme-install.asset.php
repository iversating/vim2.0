<?php return array('dependencies' => array('wp-dom-ready', 'wp-i18n'), 'version' => 'dbf595887b195b5e6002');
