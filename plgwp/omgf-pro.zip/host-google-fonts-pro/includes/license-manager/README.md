# Description

Plugin for managing Daan.dev Licenses and automatic updates for Daan.dev Plugins.

## Installation

This plugin is packaged with all Daan.dev premium plugins as a Git submodule. No additional installation steps are required.
