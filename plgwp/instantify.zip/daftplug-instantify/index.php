<?php 

// Silence is golden ;)