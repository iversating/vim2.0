<?php return array('dependencies' => array(), 'version' => '50bab23409164c67f0b9');
