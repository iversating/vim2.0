<?php return array('dependencies' => array(), 'version' => 'b1246face79350e7c99e');
