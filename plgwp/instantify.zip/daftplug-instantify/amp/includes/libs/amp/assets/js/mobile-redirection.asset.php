<?php return array('dependencies' => array(), 'version' => 'f997d051be9dc444c866');
