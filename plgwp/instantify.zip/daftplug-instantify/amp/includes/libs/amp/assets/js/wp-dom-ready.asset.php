<?php return array('dependencies' => array(), 'version' => '30516bffd89649a59c66');
