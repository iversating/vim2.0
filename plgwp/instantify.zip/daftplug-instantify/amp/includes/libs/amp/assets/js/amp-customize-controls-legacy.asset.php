<?php return array('dependencies' => array('wp-i18n'), 'version' => '6d5094dc1d6d30482359');
