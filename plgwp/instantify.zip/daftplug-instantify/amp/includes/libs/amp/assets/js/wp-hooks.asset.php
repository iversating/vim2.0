<?php return array('dependencies' => array(), 'version' => '1fe44e3cdcb733576471');
