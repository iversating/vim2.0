<?php return array('dependencies' => array('wp-dom-ready', 'wp-i18n'), 'version' => '9cf09c320d2dd8e2a2eb');
