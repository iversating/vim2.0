<?php return array('dependencies' => array('wp-dom-ready', 'wp-i18n'), 'version' => '89907e4b7f323123a0ed');
