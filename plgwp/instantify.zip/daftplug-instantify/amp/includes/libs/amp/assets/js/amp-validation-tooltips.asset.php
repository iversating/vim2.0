<?php return array('dependencies' => array('wp-dom-ready', 'wp-pointer'), 'version' => 'd330884ccd220d44f064');
