<?php return array('dependencies' => array(), 'version' => '1345161a3c224bd557e1');
