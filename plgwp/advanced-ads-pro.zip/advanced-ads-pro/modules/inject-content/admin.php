<?php

new Advanced_Ads_Pro_Module_Inject_Content_Admin;
