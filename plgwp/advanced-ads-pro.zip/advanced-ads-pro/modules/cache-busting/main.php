<?php
Advanced_Ads_Pro_Module_Cache_Busting::get_instance();
