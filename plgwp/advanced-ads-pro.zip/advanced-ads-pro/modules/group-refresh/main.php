<?php
new Advanced_Ads_Pro_Group_Refresh();