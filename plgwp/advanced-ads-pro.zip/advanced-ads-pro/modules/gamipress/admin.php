<?php

if ( ! class_exists( 'GamiPress' ) ) {
	return;
}

new Advanced_Ads_Pro_Module_GamiPress_Admin();
