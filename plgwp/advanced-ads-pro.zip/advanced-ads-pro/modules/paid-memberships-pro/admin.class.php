<?php

class Advanced_Ads_Pro_Module_PaidMembershipsPro_Admin {

}
