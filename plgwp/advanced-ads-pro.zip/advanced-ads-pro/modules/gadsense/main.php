<?php
new Advanced_Ads_Pro_AdSense_Public;
