<?php

namespace AdvancedAdsPro\GeoIp2\Exception;

/**
 * This class represents a generic error.
 */
class AuthenticationException extends GeoIp2Exception
{
}
