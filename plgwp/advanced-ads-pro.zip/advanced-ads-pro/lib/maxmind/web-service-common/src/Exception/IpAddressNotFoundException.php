<?php

namespace AdvancedAdsPro\MaxMind\Exception;

class IpAddressNotFoundException extends InvalidRequestException
{
}
