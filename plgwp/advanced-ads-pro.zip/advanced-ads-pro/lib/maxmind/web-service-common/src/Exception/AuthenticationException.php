<?php

namespace AdvancedAdsPro\MaxMind\Exception;

/**
 * This class represents an error authenticating.
 */
class AuthenticationException extends InvalidRequestException
{
}
