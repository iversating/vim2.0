<?php

class BWFAN_Model_Syncrecords extends BWFAN_Model {
	static $primary_key = 'ID';

}
