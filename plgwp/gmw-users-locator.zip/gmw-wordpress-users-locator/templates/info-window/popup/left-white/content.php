<?php
/**
 * The content of this file will be displayed in the map markers' info-window.
 *
 * This file can be overridden by copying it to
 *
 * your-theme's-or-child-theme's-folder/geo-my-wp/users-locator/ajax-forms/info-window/popup/
 *
 * @param $gmw  - the form being used ( array )
 *
 * @param $user - the user being displayed ( object )
 *
 * @package gmw-ajax-forms
 */

?>
<?php do_action( 'gmw_info_window_before', $user, $gmw ); ?>  

<div id="gmw-toggle-button-wrapper">
	<?php gmw_left_element_toggle_button( '#gmw-popup-info-window', '-320px' ); ?>
</div>

<div class="gmw-info-window-header">

	<?php gmw_element_close_button( 'gmw-icon-cancel' ); ?>

	<?php do_action( 'gmw_info_window_before_title', $user, $gmw ); ?>

	<?php gmw_ul_user_title( $user, $gmw ); ?>

	<?php gmw_info_window_distance( $user, $gmw ); ?>

</div>

<div class="gmw-info-window-inner popup template-content-wrapper">

	<?php do_action( 'gmw_info_window_start', $user, $gmw ); ?>

	<?php gmw_info_window_user_avatar( $user, $gmw ); ?>	

	<?php do_action( 'gmw_info_window_before_address', $user, $gmw ); ?>

	<?php gmw_info_window_address( $user, $gmw ); ?>

	<?php gmw_info_window_directions_link( $user, $gmw ); ?>

	<?php do_action( 'gmw_info_window_before_location_meta', $user, $gmw ); ?>

	<?php gmw_info_window_location_meta( $user, $gmw, false ); ?>

	<?php gmw_info_window_directions_system( $user, $gmw ); ?>

	<?php do_action( 'gmw_info_window_end', $user, $gmw ); ?>	

</div>  

<?php do_action( 'gmw_info_window_after', $user, $gmw ); ?>
