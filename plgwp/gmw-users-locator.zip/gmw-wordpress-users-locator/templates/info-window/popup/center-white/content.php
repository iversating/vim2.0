<?php
/**
 * GEO my WP Info-Window Template ( NOTE: this template is deprecated and is no longer being supported ).
 *
 * To modify this template file, copy this folder with all its content and place it
 *
 * in the theme's or child theme's folder of your site under:
 *
 * your-theme's-or-child-theme's-folder/geo-my-wp/users-locator/info-window/popup/
 *
 * You will then be able to select your custom template from the "Templates" select dropdown option in the "Info Window" tab of the form editor.
 *
 * It will be named as "Custom: %folder-name%".
 *
 * @param $gmw    ( array )  GEO my WP's form.
 *
 * @param $user ( object ) the user's object.
 *
 * @author Eyal Fitoussi
 *
 * @package gmw-wordpress-users-locator
 */

?>
<?php do_action( 'gmw_info_window_before', $user, $gmw ); ?>  

<div class="buttons-wrapper">
	<?php gmw_element_dragging_handle(); ?>
	<?php gmw_element_toggle_button(); ?>
	<?php gmw_element_close_button( 'gmw-icon-cancel' ); ?>
</div>

<div class="gmw-info-window-inner popup template-content-wrapper">

	<?php do_action( 'gmw_info_window_start', $user, $gmw ); ?>

	<?php gmw_info_window_user_avatar( $user, $gmw ); ?>	

	<?php do_action( 'gmw_info_window_before_title', $user, $gmw ); ?>

	<?php gmw_ul_user_title( $user, $gmw ); ?>

	<?php do_action( 'gmw_info_window_before_address', $user, $gmw ); ?>

	<?php gmw_info_window_address( $user, $gmw ); ?>

	<?php gmw_info_window_directions_link( $user, $gmw ); ?>

	<?php gmw_info_window_distance( $user, $gmw ); ?>

	<?php do_action( 'gmw_info_window_before_location_meta', $user, $gmw ); ?>

	<?php gmw_info_window_location_meta( $user, $gmw, false ); ?>

	<?php gmw_info_window_directions_system( $user, $gmw ); ?>

	<?php do_action( 'gmw_info_window_end', $user, $gmw ); ?>	

</div>  

<?php do_action( 'gmw_info_window_after', $user, $gmw ); ?>
