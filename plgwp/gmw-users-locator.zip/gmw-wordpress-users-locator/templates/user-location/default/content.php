<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="gmw-user-location-wrapper">
	<?php

	if ( isset( $_GET['user_id'] ) ) {
		$url_param = 'user_id';
	} else {
		$url_param = 'uid';
	}

	$url_param = apply_filters( 'gmw_ul_displayed_user_location_url_param', $url_param );
	$user_id   = isset( $_GET[ $url_param ] ) ? $_GET[ $url_param ] : get_current_user_id();

	// Single Location add-on must be activated to display full location details.
	if ( gmw_is_addon_active( 'single_location' ) ) {

		// Get elements to display.
		$elements = gmw_get_option( 'users_locator', 'displayed_user_location_elements', array( 'address', 'map', 'directions_link' ) );

		$elements       = implode( ',', $elements );
		$address_fields = gmw_get_option( 'users_locator', 'displayed_user_location_address_fields', array( 'address' ) );
		$address_fields = ( in_array( 'address', $address_fields ) || 6 == count( $address_fields ) ) ? 'formatted_address' : implode( ',', $address_fields );
		$map_width      = gmw_get_option( 'users_locator', 'displayed_user_location_map_width', '100%' );
		$map_height     = gmw_get_option( 'users_locator', 'displayed_user_location_map_height', '300px' );

		// Modify the shortcode.
		$content = '[gmw_user_location user_id="' . $user_id . '" elements="' . esc_attr( $elements ) . '" address_fields="' . esc_attr( $address_fields ) . '" map_height="' . $map_height . '" map_width="' . $map_width . '" user_map_icon="0" item_info_window="0"]';

		echo do_shortcode( apply_filters( 'gmw_ul_displayed_user_location_content', $content ) );

		// Otherwise, display only address field.
	} else {
		echo '<div id="gmw-user-address"><i class="gmw-icon-location"></i>' . esc_attr( gmw_get_user_address( array( 'user_id' => $user_id ) ) ) . '</div>';
	}
	?>
</div>
