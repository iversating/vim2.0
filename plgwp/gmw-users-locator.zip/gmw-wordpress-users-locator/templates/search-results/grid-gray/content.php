<?php
/**
 * This is the search results template files ( NOTE: this template is deprecated and is no longer being supported ).
 *
 * To modify this template file copy-paste this folder with all its content and place it
 *
 * in the theme's or child theme's folder of your site under:
 *
 * your-theme's-or-child-theme's-folder/geo-my-wp/users-locator/search-results/
 *
 * You will then be able to select your custom folder from the form editor, under the "Search Results Template" dropdown menu.
 *
 * It will be labed with "Custom: %folder-name% ".
 *
 * @param $gmw  ( array ) the form being used
 *
 * @param $gmw_form ( object ) the form object
 *
 * @param $user ( object ) the user's object in the loop
 *
 * @package gmw-wordpress-users-locator
 */

?>
<div class="gmw-results-wrapper grid-gray <?php echo esc_attr( $gmw['prefix'] ); ?> gmw-ug-grid-gray-results-wrapper" data-id="<?php absint( $gmw['ID'] ); ?>" data-prefix="<?php echo esc_attr( $gmw['prefix'] ); ?>">

	<?php if ( $gmw_form->has_locations() ) : ?>

		<?php do_action( 'gmw_search_results_start', $gmw ); ?>

		<div class="gmw-results">

			<div class="gmw-results-message">
				<span><?php gmw_results_message( $gmw ); ?></span>
				<?php do_action( 'gmw_search_results_after_results_message', $gmw ); ?>
			</div>

			<?php do_action( 'gmw_search_results_before_top_pagination', $gmw ); ?>

			<div class="pagination-per-page-wrapper top">		
				<?php gmw_per_page( $gmw ); ?>
				<?php gmw_pagination( $gmw ); ?>
			</div> 

			<?php gmw_results_map( $gmw ); ?>

			<?php do_action( 'gmw_search_results_before_loop', $gmw ); ?>

			<ul class="users-list-wrapper">

				<?php global $user; ?>

				<?php foreach ( $gmw_query->results as $user ) { ?>

					<li id="single-user-<?php echo absint( $user->ID ); ?>" class="<?php echo esc_attr( $user->location_class ); ?>">

						<div class="wrapper-inner">

							<?php do_action( 'gmw_search_results_loop_item_start', $gmw, $user ); ?>

							<div class="top-wrapper">

								<h2 class="user-name">
									<a href="<?php gmw_search_results_user_permalink( $user, $gmw ); ?>">
										<?php gmw_search_results_title( $user->display_name, $user, $gmw ); ?>
									</a>
								</h2>
								<?php gmw_search_results_distance( $user, $gmw ); ?>
							</div>

							<div class="user-content">

								<?php do_action( 'gmw_search_results_before_image', $gmw, $user ); ?>

								<?php gmw_search_results_user_avatar( $user, $gmw ); ?>

								<?php do_action( 'gmw_search_results_before_get_directions', $gmw, $user ); ?>

								<?php gmw_search_results_directions_link( $user, $gmw ); ?>

								<?php do_action( 'gmw_search_results_before_contact_info', $user, $gmw ); ?>

								<?php gmw_search_results_location_meta( $user, $gmw ); ?>

							</div>

							<div class="bottom-wrapper">										
								<span class="address">
									<?php gmw_search_results_address( $user, $gmw ); ?>	
								</span>				    		
							</div>

							<?php do_action( 'gmw_search_results_loop_item_end', $gmw, $user ); ?>
						</div>

					</li>

				<?php } ?>
			</ul>

			<?php do_action( 'gmw_search_results_after_loop', $gmw ); ?>

			<div class="pagination-per-page-wrapper bottom">
				<?php gmw_per_page( $gmw ); ?>
				<?php gmw_pagination( $gmw ); ?>
			</div> 

			<?php do_action( 'gmw_search_results_end', $gmw ); ?>

		</div>

	<?php else : ?>

		<div class="gmw-no-results">

			<?php do_action( 'gmw_no_results_start', $gmw ); ?>

			<?php gmw_no_results_message( $gmw ); ?>

			<?php do_action( 'gmw_no_results_end', $gmw ); ?> 
		</div>

	<?php endif; ?>

</div>
