<?php
/**
 * GEO my WP Search Results Template.
 *
 * To modify this template file, copy this folder with all its content and place it
 *
 * in the theme's or child theme's folder of your site under:
 *
 * your-theme's-or-child-theme's-folder/geo-my-wp/users-locator/search-results/
 *
 * You will then be able to select your custom template from the "Search Results Templates" select dropdown option in the "Search Results" tab of the form editor.
 *
 * It will be named as "Custom: %folder-name%".
 *
 * @param $gmw  ( array ) the form being used
 *
 * @param $gmw_form ( object ) the form object
 *
 * @param $user ( object ) the user's object in the loop
 *
 * @package gmw-wordpress-users-locator
 */

?>
<div id="gmw-single-user-<?php echo absint( $user->ID ); ?>" class="<?php echo esc_attr( $user->location_class ); ?>">

	<div class="gmw-item-inner">

		<?php do_action( 'gmw_search_results_loop_item_start', $user, $gmw ); ?>

		<div class="gmw-item-content">

			<?php gmw_search_results_distance( $user, $gmw ); ?>

			<h3 class="gmw-item gmw-item-title">
				<?php gmw_search_results_linked_title( gmw_get_search_results_user_permalink( $user, $gmw ), $user->display_name, $user, $gmw ); ?>
			</h3>

			<?php do_action( 'gmw_search_results_loop_content_start', $user, $gmw ); ?>

			<?php gmw_search_results_location_meta( $user, $gmw ); ?>

			<?php gmw_search_results_hours_of_operation( $user, $gmw ); ?>

			<?php gmw_search_results_directions_link( $user, $gmw ); ?>

			<?php do_action( 'gmw_search_results_loop_content_end', $user, $gmw ); ?>
		</div>

		<div class="gmw-item-footer">
			<?php gmw_search_results_linked_address( $user, $gmw ); ?>
			<?php gmw_search_results_user_avatar( $user, $gmw ); ?>
		</div>

		<?php do_action( 'gmw_search_results_loop_item_end', $user, $gmw ); ?>
	</div>
</div>
