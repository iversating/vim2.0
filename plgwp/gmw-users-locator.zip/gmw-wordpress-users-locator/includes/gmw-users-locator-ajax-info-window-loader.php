<?php
/**
 * GMW AJAX Forms - Users Locator info-window.
 *
 * @package geo-my-wp
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// get the user's location + user data.
$user = gmw_get_user_location_data( $location->location_id, true );

// The function above returns $user->ID as the location ID,
// and not as the user ID. So here we change that.
$user->ID = $user->user_id;

// get location meta if needed and append it to the member.
if ( ! empty( $gmw['info_window']['location_meta'] ) ) {
	$user->location_meta = gmw_get_location_meta( $location->location_id, $gmw['info_window']['location_meta'] );
}

$user->distance = isset( $location->distance ) ? $location->distance : '';
$user->units    = isset( $location->units ) ? $location->units : '';

// modify form and member.
$user = apply_filters( 'gmw_ajaxfmsul_user_before_info_window', $user, $gmw );

require $gmw['info_window_template']['content_path'];

do_action( 'gmw_ajaxfmsul_after_user_info_window', $user, $gmw );
