<?php
/**
 * GMW User Locator Registration form.
 *
 * @author Eyal Fitoussi
 *
 * @since 1.3.1
 *
 * @package gmw-multiple-locations
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * GMW_Users_Locator_Registration_Form_Address class.
 *
 * Create address field in WordPress registration form.
 *
 * @since 1.3.1
 */
class GMW_Users_Locator_Registration_Form_Location {

	/**
	 * User Locator settings.
	 *
	 * @var array
	 */
	public $settings = array();

	/**
	 * Is advanced form enabled?
	 *
	 * @var boolean
	 */
	public $is_advanced_location = false;

	/**
	 * __construct.
	 */
	public function __construct() {

		$this->settings = gmw_get_options_group( 'users_locator' );

		if ( isset( $this->settings['registration_location_form_usage'] ) && 'advanced' === $this->settings['registration_location_form_usage'] ) {
			$this->is_advanced_location = true;
		}

		add_action( 'register_form', array( $this, 'address_field' ), 20 );
		add_filter( 'registration_errors', array( $this, 'validate' ), 15, 3 );
		add_action( 'user_register', array( $this, 'update' ) );
		add_action( 'login_enqueue_scripts', array( $this, 'enqueue_script' ) );
	}

	/**
	 * Enqueue scripts and styles.
	 *
	 * @since 1.3.1
	 */
	public function enqueue_script() {

		gmw_enqueue_scripts();

		if ( ! wp_script_is( 'gmw', 'enqueued' ) ) {
			wp_enqueue_script( 'gmw' );
		}

		// Abort if not using advacned form.
		if ( ! $this->is_advanced_location ) {
			return;
		}
		?>
		<style type="text/css">

			#TB_window {
				border-radius: 8px ! important;
				overflow: hidden ! important;
			}

			@media only screen and (max-width: 600px) {

				#TB_window { 
					width: 100% ! important;
					left: 0 ! important;
					margin-left: 0 ! important;
				}
			}

			#TB_title {
				height: 0 ! important;
				padding: 0 ! important;
				border: 0 ! important;
			}

			#TB_ajaxContent {
				padding: 0 ! important;
				margin: 0 ! important;
				height: 90% ! important;
				width: 100% ! important;
			}

			.tb-close-icon {
				top: 15px ! important;
				right: 15px ! important;
				border: 1px solid transparent ! important;
				border-radius: 100% ! important;
				border: 1px solid var( --gmw-color-primary ) ! important;
				color: var( --gmw-color-primary ) ! important;
			}

			.tb-close-icon:hover {
				background: var( --gmw-color-primary ) ! important;
				color: white ! important;
			}

			#gmw-ul-registration-location-form-background {
				display: none;
				background: #333;
				width: 100%;
				height: 100%;
				position: fixed;
				top: 0;
				left: 0;
				opacity: 0.8;
			}

			#gmw-ul-registration-location-form-wrapper {
				display: none;
			}

			#gmw-location-form-wrapper {
				border: 0 ! important;
			}

			#gmw-ul-registration-location-form-wrapper #gmw-location-form-wrapper .gmw-ul-registration-location-form-close-button {
				float: right;
			}

			body.login #gmw-user-registration-address-field {
				margin-bottom:  5px;
			}

			body.login #gmw-ul-clear-address-button {
				width: 100%;
				display: inline-block;
				text-align: right;
				font-size: 12px;
				margin-bottom: 15px;
				cursor: pointer;
				line-height: 13px;
				color:;
			}

			body.login #gmw-ul-clear-address-button {
				width: 100%;
				display: inline-block;
				text-align: right;
				font-size: 12px;
				margin-bottom: 15px;
				cursor: pointer;
				line-height: 13px;
				color: #555;
			}

			body.login #gmw-ul-clear-address-button:hover {
				color: #888;
			}

			body.login #gmw-ul-clear-address-button i {
				font-size: 10px;
				vertical-align: top;
				display: inline-block;
			}
		</style>
		<?php
	}

	/**
	 * Add address field to the registraion form.
	 *
	 * @since 1.3.1
	 */
	public function address_field() {

		$address     = ! empty( $_POST['gmw_address'] ) ? sanitize_text_field( wp_unslash( $_POST['gmw_address'] ) ) : ''; // WPCS: CSRF ok.
		$address_ac  = ( ! $this->is_advanced_location && ! empty( $this->settings['registration_location_form_address_autocomplete'] ) ) ? ' gmw-address-autocomplete' : '';
		$placeholder = ! empty( $this->settings['registration_location_form_field_placeholder'] ) ? 'placeholder="' . esc_attr( $this->settings['registration_location_form_field_placeholder'] ) . '"' : '';
		?>
		<?php add_thickbox(); ?>
		<p>
			<?php if ( ! empty( $this->settings['registration_location_form_field_label'] ) ) { ?>
				<label for="gmw-user-registration-address-field"><?php echo esc_attr( $this->settings['registration_location_form_field_label'] ); ?></label>
			<?php } ?>

			<input 
				id="gmw-user-registration-address-field"
				type="text" 
				name="gmw_address" 
				class="input<?php echo $address_ac; // WPCS: XSS ok. ?>" 
				value="<?php echo esc_attr( $address ); ?>" 
				size="25"
				<?php echo $placeholder; // WPCS: XSS ok. ?>
			/>

			<?php if ( $this->is_advanced_location ) { ?>
				<span id="gmw-ul-clear-address-button">
					<i class="gmw-icon-cancel-circled"></i><?php esc_attr_e( 'Clear address', 'gmw-wp-users-locator' ); ?>
				</span>
			<?php } ?>
		</p>

		<?php
		// Abort if not using the advacned form.
		if ( ! $this->is_advanced_location ) {
			return;
		}
		?>
		<script type="text/javascript">

			jQuery( 'document' ).ready( function($) {

				$( '#gmw-ul-clear-address-button' ).on( 'click', function() {
					$( '#gmw-user-registration-address-field, #gmw-location-form-wrapper input.gmw-lf-field[type="text"], #gmw-location-form-wrapper .gmw-lf-submission-field.group_coordinates, #gmw-location-form-wrapper .gmw-lf-submission-field.group_address' ).val( '' );
				});

				// Show location form when focus on address field.
				$( '#gmw-user-registration-address-field' ).on( 'focus', function() {

					tb_show( '', '#TB_inline?&width=600&height=550&inlineId=gmw-ul-registration-location-form-wrapper' );

					// if map exists, resize it in case it was not rendered properly
					// because the form is hidden.
					if ( typeof( GMW_Location_Form.map ) !== 'undefined' ) {

						var form = GMW_Location_Form;

						form.resizeMap( form.map );
						form.setCenter( form.getPosition( form.map_marker ), form.map );
					}

					$( '#gmw-user-registration-address-field' ).blur();
					$( '.gmw-lf-field.gmw-lf-address-autocomplete' ).focus();
				}); 

				// Fill selected address in the address field of the registration form.
				GMW.add_action( 'gmw_lf_geocoded_location_data', function( result, response, location_form ) { 

					if ( typeof result.formatted_address !== 'undefined' ) {
						$( '#gmw-user-registration-address-field' ).val( result.formatted_address );
					}
				});
			});
		</script>
		<?php

		$exclude_fields = gmw_get_option( 'users_locator', 'registration_location_form_exclude_fields', array() );

		if ( ! is_array( $exclude_fields ) ) {
			$exclude_fields = array();
		}

		// default args.
		$defaults = array(
			'object_id'                 => 0,
			'exclude_fields_groups'     => gmw_get_option( 'users_locator', 'registration_location_form_exclude_fields_groups', array() ),
			'exclude_fields'            => array_merge( $exclude_fields, array( 'delete_location' ) ),
			'form_template'             => gmw_get_option( 'users_locator', 'registration_location_form_template', 'location-form-tabs-top' ),
			'submit_enabled'            => 0,
			'stand_alone'               => 0,
			'ajax_enabled'              => 0,
			'auto_confirm'              => 0,
			'update_on_submission'      => 0,
			'preserve_submitted_values' => 1,
		);

		if ( ! class_exists( 'GMW_User_Location_Form' ) ) {
			include 'class-gmw-user-location-form.php';
		}

		// Generate new location form.
		$location_form = new GMW_User_Location_Form( $defaults );

		// Display the location form.
		echo '<div id="gmw-ul-registration-location-form-wrapper">';

		// Display location form.
		$location_form->display_form();

		// load scripts and styles.
		$location_form->enqueue_scripts();

		echo '</div>';
	}

	/**
	 * Validate address field.
	 *
	 * @param  object $errors               [description].
	 *
	 * @param  [type] $sanitized_user_login [description].
	 *
	 * @param  [type] $user_email           [description].
	 *
	 * @return [type]                       [description]
	 */
	public function validate( $errors, $sanitized_user_login, $user_email ) {

		if ( ! empty( $this->settings['registration_location_form_mandatory'] ) && ( empty( $_POST['gmw_address'] ) || '' === trim( $_POST['gmw_address'] ) ) ) { // WPCS: CSRF ok, sanitization ok.
			$errors->add( 'address_error', sprintf( '<strong>%s</strong>: %s', __( 'ERROR', 'gmw-wp-users-locator' ), __( 'Please enter an address.', 'gmw-wp-users-locator' ) ) );
		}

		return $errors;
	}

	/**
	 * Geocode the address and save in database.
	 *
	 * @param  int $user_id user ID.
	 *
	 * @since 1.3.1
	 */
	public function update( $user_id ) {

		if ( empty( $_POST ) ) {
			return;
		}

		// Verify GEO my WP location form submission.
		if ( $this->is_advanced_location && ( empty( $_POST['gmw_lf_update_location'] ) || ! wp_verify_nonce( $_POST['gmw_lf_update_location'], 'gmw_lf_update_location' ) ) ) { // WPCS: CSRF ok, sanitization ok.

			return;

		} elseif ( ! $this->is_advanced_location && empty( $_POST['gmw_address'] ) ) {
			return;
		}

		// Update location when using address field only.
		if ( ! $this->is_advanced_location ) {

			if ( function_exists( 'gmw_update_user_location' ) ) {

				$address = apply_filters( 'gmw_ul_registration_form_address', $_POST['gmw_address'] ); // WPCS: CSRF ok, sanitization ok.

				gmw_update_user_location( $user_id, sanitize_text_field( wp_unslash( $address ) ) );
			}

			// Update location when using advanced location form.
		} else {

			// update some values to pass to the update() function.
			$location              = isset( $_POST['gmw_location_form'] ) ? $_POST['gmw_location_form'] : array(); // WPCS: CSRF ok, sanitization ok. Will be sanitized before saved into database.
			$location['object_id'] = $user_id;
			$location['user_id']   = $user_id;
			$location['title']     = isset( $_POST['user_login'] ) ? sanitize_text_field( wp_unslash( $_POST['user_login'] ) ) : '';

			unset( $location['auto_update'] );

			// update location.
			GMW_Location::update( $location );
		}
	}
}
new GMW_Users_Locator_Registration_Form_Location();
