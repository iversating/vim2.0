<?php
/**
 * GEO my WP WP Users Locator functions.
 *
 * @package gmw-wordpress-users-locator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Modify the location form args based on the settings page.
 *
 * This only happens when location form loads via ajax.
 *
 * @param  array $args function arguments.
 *
 * @return $args
 */
function gmw_ul_modify_location_form_args( $args ) {

	if ( defined( 'DOING_AJAX' ) && 'users_locator' === $args['slug'] ) {

		$args['exclude_fields_groups'] = gmw_get_option( 'users_locator', 'location_form_exclude_fields_groups', array() );
		$args['exclude_fields']        = gmw_get_option( 'users_locator', 'location_form_exclude_fields', array() );
		$args['form_template']         = gmw_get_option( 'users_locator', 'location_form_template', 'location-form-tabs-top' );
	}

	return $args;
}
add_filter( 'gmw_location_form_args', 'gmw_ul_modify_location_form_args', 20 );

/**
 * Generate the user location form
 *
 * @param  array $args function arguments.
 *
 * @return [type]       [description]
 */
function gmw_ul_user_location_form( $args = array() ) {

	if ( isset( $args['user_id'] ) ) {
		$args['object_id'] = $args['user_id'];
	}

	// default args.
	$defaults = array(
		'object_id'             => 0,
		'exclude_fields_groups' => gmw_get_option( 'users_locator', 'location_form_exclude_fields_groups', array() ),
		'exclude_fields'        => gmw_get_option( 'users_locator', 'location_form_exclude_fields', array() ),
		'form_template'         => gmw_get_option( 'users_locator', 'location_form_template', 'location-form-tabs-top' ),
		'submit_enabled'        => 1,
		'stand_alone'           => 1,
		'ajax_enabled'          => 1,
		'auto_confirm'          => 1,
	);

	$args = wp_parse_args( $args, $defaults );
	$args = apply_filters( 'gmw_user_location_form_args', $args );

	if ( ! absint( $args['object_id'] ) ) {

		if ( get_current_user_id() ) {
			$args['object_id'] = get_current_user_id();
		} else {
			return;
		}
	}

	include_once 'class-gmw-user-location-form.php';

	if ( ! class_exists( 'GMW_User_Location_Form' ) ) {
		return;
	}

	// generate new location form.
	$location_form = new GMW_User_Location_Form( $args );

	// display the location form.
	$location_form->display_form();
}

/**
 * Generate the user location form using shortcode
 *
 * @param  array $atts shortcode attributes.
 *
 * @return [type]       [description]
 */
function gmw_ul_user_location_form_shortcode( $atts = array() ) {

	if ( empty( $atts ) ) {
		$atts = array();
	}

	ob_start();

	gmw_ul_user_location_form( $atts );

	$content = ob_get_clean();

	return $content;
}
add_shortcode( 'gmw_user_location_form', 'gmw_ul_user_location_form_shortcode' );

/**
 * Display the displayed user location.
 *
 * Can be generated dynamically when setup in the settings page
 *
 * or using a shortcode.
 *
 * Works only When specific page selected in the settings page.
 *
 * @param  string $content location content.
 *
 * @return [type]          [description]
 */
function gmw_ul_displayed_user_location( $content = false ) {

	global $post;

	$page_id = gmw_get_option( 'users_locator', 'user_permalink_page_id', 0 );

	if ( empty( $post ) || absint( $page_id ) !== $post->ID ) {
		return $content;
	}

	ob_start();

	$args = array(
		'component'     => 'users_locator',
		'folder_name'   => 'user-location',
		'template_name' => 'default',
	);

	$template = gmw_get_template( $args );

	include $template['content_path'];

	$content = ob_get_clean();

	return $content;
}
add_shortcode( 'gmw_displayed_user_location', 'gmw_ul_displayed_user_location' );

/**
 * Verify if displayed user location needs to dynamically generated
 *
 * @return [type] [description]
 */
function gmw_ul_user_location_page_init() {

	// uid parameter is required to display the user's location.
	if ( ! isset( $_GET['uid'] ) ) { // WPCS: CSRF ok.
		return;
	}

	if ( ! gmw_get_option( 'users_locator', 'displayed_user_location_enabled', false ) ) {
		return;
	}

	if ( 'page' !== gmw_get_option( 'users_locator', 'user_permalink_usage', '' ) ) {
		return;
	}

	add_filter( 'the_title', 'gmw_ul_author_title_filter', 10, 2 );
	add_filter( 'the_content', 'gmw_ul_displayed_user_location', 20 );
}
add_action( 'init', 'gmw_ul_user_location_page_init' );

/**
 * Modify the author page title
 *
 * Only when page ID selected in the settings page.
 *
 * @param  string  $title   author title.
 *
 * @param  integer $post_id post ID.
 *
 * @return [type]          [description]
 */
function gmw_ul_author_title_filter( $title, $post_id ) {

	$id = gmw_get_option( 'users_locator', 'user_permalink_page_id', 0 );

	if ( absint( $id ) !== $post_id || empty( $_GET['uid'] ) ) { // WPCS: CSRF ok.
		return $title;
	}

	$user_id = absint( $_GET['uid'] ); // WPCS: CSRF ok.
	$title   = get_the_author_meta( 'display_name', $user_id );

	return $title;
}

/**
 * Update GEO my WP location via User Meta fields.
 *
 * @param  int $user_id user ID.
 *
 * @author Eyal Fitoussi
 *
 * @create 7/10/19
 *
 * @since 1.4.3
 */
function gmw_ul_update_user_location_via_user_meta( $user_id ) {

	if ( ! current_user_can( 'edit_user', $user_id ) ) {
		return false;
	}

	$address_fields = apply_filters( 'gmw_ul_user_meta_location_fields', array() );

	if ( empty( $address_fields ) ) {
		return;
	}

	if ( ! is_array( $address_fields ) ) {
		$address_fields = explode( ',', $address_fields );
	}

	$address = array();

	foreach ( $address_fields as $field ) {

		if ( ! empty( $_POST[ $field ] ) ) { // WPCS: CSRF ok.
			$address[] = sanitize_text_field( wp_unslash( $_POST[ $field ] ) ); // WPCS: CSRF ok.
		}
	}

	$address = implode( ' ', $address );

	if ( empty( $address ) ) {
		return;
	}

	gmw_update_user_location( $user_id, $address );
}
add_action( 'personal_options_update', 'gmw_ul_update_user_location_via_user_meta' );
add_action( 'edit_user_profile_update', 'gmw_ul_update_user_location_via_user_meta' );

if ( class_exists( 'PeepSo' ) ) {

	/**
	 * Update GEO my WP location via Peepso profile field.
	 *
	 * @param  obejct $field field object.
	 *
	 * @author Eyal Fitoussi
	 *
	 * @create 7/10/19
	 *
	 * @since 1.4.3
	 */
	function gmw_ul_sync_peepso_address_field( $field ) {

		$address_field_id = apply_filters( 'gmw_ul_peepso_address_field_id', 0 );

		if ( empty( $address_field_id ) ) {
			return;
		}

		// Abort if not address field.
		if ( $address_field_id !== $field->id ) {
			return;
		}

		// Get the user ID.
		$user_id = get_current_user_id();

		// geocode and save the location in GEO my WP database.
		if ( ! empty( $field->value ) ) {

			if ( ! is_array( $field->value ) ) {

				gmw_update_user_location( $user_id, $field->value );

			} elseif ( ! empty( $field->value['latitude'] ) ) {
				gmw_update_user_location(
					$user_id,
					array(
						'lat' => $field->value['latitude'],
						'lng' => $field->value['longitude'],
					)
				);
			}

			// Otherwise, if no address provided, delete the location from GEO my WP.
		} else {
			gmw_delete_user_location( $user_id );
		}
	}
	add_action( 'peepso_action_profile_field_save', 'gmw_ul_sync_peepso_address_field' );
}
