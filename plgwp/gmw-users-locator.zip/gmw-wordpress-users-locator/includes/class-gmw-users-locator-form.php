<?php
/**
 * GMW Users Locator - GMW_Users_Locator_Form class.
 *
 * @package gmw-wordpress-users-locator
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Search queries for Memebrs Locator Forms classes.
 */
trait GMW_Users_Locator_Form_Trait {

	/**
	 * Query clauses.
	 *
	 * Filter users based on location.
	 *
	 * We hook into the WP_User_Query
	 *
	 * @since 1.3
	 *
	 * @param  [type] $clauses [description].
	 *
	 * @return [type]          [description]
	 */
	public function query_clauses( $clauses ) {

		global $wpdb;

		$fields       = ', gmw_locations.' . implode( ', gmw_locations.', $this->db_fields );
		$join         = "INNER JOIN {$wpdb->base_prefix}gmw_locations gmw_locations ON {$wpdb->prefix}users.ID = gmw_locations.object_id AND gmw_locations.object_type = 'user' ";
		$where        = '';
		$having       = '';
		$units        = '';
		$distance_sql = "'' AS distance";

		// get address filters query.
		$address_filters = gmw_get_address_fields_filters_sql( $this->get_address_filters(), $this->form );

		if ( ! empty( $this->form['form_values']['nelatlng'] ) && ! empty( $this->form['form_values']['swlatlng'] ) ) {

			$where .= gmw_get_locations_within_bounderies_sql( $this->form['form_values']['swlatlng'], $this->form['form_values']['nelatlng'] );

			// when address provided, and not filtering based on address fields, we will do proximity search.
		} elseif ( '' === $address_filters && ! empty( $this->form['lat'] ) && ! empty( $this->form['lng'] ) ) {

			// generate some radius/units data.
			if ( 'imperial' === $this->form['units'] ) {

				$earth_radius = 3959;
				$units        = 'mi';
				$degree       = 69.0;
			} else {
				$earth_radius = 6371;
				$units        = 'km';
				$degree       = 111.045;
			}

			// since these values are repeatable, we escape them previous
			// the query instead of running multiple prepares.
			$lat          = esc_sql( $this->form['lat'] );
			$lng          = esc_sql( $this->form['lng'] );
			$distance     = ! empty( $this->form['radius'] ) ? esc_sql( $this->form['radius'] ) : '';
			$distance_sql = "ROUND( {$earth_radius} * acos( cos( radians( {$lat} ) ) * cos( radians( gmw_locations.latitude ) ) * cos( radians( gmw_locations.longitude ) - radians( {$lng} ) ) + sin( radians( {$lat} ) ) * sin( radians( gmw_locations.latitude ) ) ),1 ) AS distance";

			if ( ! empty( $distance ) ) {

				if ( ! apply_filters( 'gmw_disable_query_clause_between', false, 'gmw_' . $this->form['prefix'], $this->form ) ) {

					// calculate the between point.
					$bet_lat1 = $lat - ( $distance / $degree );
					$bet_lat2 = $lat + ( $distance / $degree );
					$bet_lng1 = $lng - ( $distance / ( $degree * cos( deg2rad( $lat ) ) ) );
					$bet_lng2 = $lng + ( $distance / ( $degree * cos( deg2rad( $lat ) ) ) );

					$where .= " AND gmw_locations.latitude BETWEEN {$bet_lat1} AND {$bet_lat2}";
					$where .= " AND gmw_locations.longitude BETWEEN {$bet_lng1} AND {$bet_lng2}";
				}

				// filter locations based on the distance.
				$having = "Having distance <= {$distance} OR distance IS NULL";
			}

			// if we order by the distance.
			if ( 'distance' === $this->form['query_args']['orderby'] ) {
				$clauses->query_orderby = 'ORDER BY distance';
			}
		} else {

			// if showing members without location.
			if ( ! empty( $this->enable_objects_without_location ) ) {

				// left join the location table into the query to display posts with no location as well.
				$join = str_replace( 'INNER', 'LEFT', $join );

			} else {

				$where .= ' AND ( gmw_locations.latitude != 0.000000 && gmw_locations.longitude != 0.000000 )';
			}

			$where .= ' ' . $address_filters;
		}

		$fields .= ", {$distance_sql}, '{$units}' AS units";

		$clauses->query_fields .= $fields;
		$clauses->query_where  .= $where;

		/**
		 * We add these 4 additional query clauses to the query vars
		 *
		 * To allow plugin modify it. We do so since we are unable to add them
		 *
		 * as properties to the class.
		 */
		$clauses->query_vars['query_join']     = $join;
		$clauses->query_vars['query_having']   = $having;
		$clauses->query_vars['query_distinct'] = false;
		$clauses->query_vars['query_groupby']  = "GROUP BY {$wpdb->prefix}users.ID";

		// modify the clauses.
		$clauses = apply_filters( 'gmw_users_locator_locations_query_clauses', $clauses, $this->form, $this );
		$clauses = apply_filters( 'gmw_' . $this->form['prefix'] . '_users_query_clauses', $clauses, $this->form, $this );

		if ( $clauses->query_vars['query_distinct'] ) {
			$clauses->query_fields = ' DISTINCT ' . $clauses->query_fields;
		}

		// add join clause to query.
		if ( ! empty( $clauses->query_vars['query_join'] ) ) {
			$clauses->query_from .= ' ' . $clauses->query_vars['query_join'];
		}

		// Add custom groupby and having clauses to the where clause.
		$clauses->query_where .= " {$clauses->query_vars['query_groupby']} {$clauses->query_vars['query_having']} ";

		// No need these past this point.
		unset(
			$clauses->query_vars['query_join'],
			$clauses->query_vars['query_having'],
			$clauses->query_vars['query_groupby'],
			$clauses->query_vars['query_distinct']
		);

		return $clauses;
	}
}

/**
 * Users Locator search query class
 *
 * @author Eyal Fitoussi
 *
 * @since 2.0
 */
class GMW_Users_Locator_Form extends GMW_Form {

	/**
	 * Inherit search queries.
	 */
	use GMW_Users_Locator_Form_Trait;

	/**
	 * Results message
	 *
	 * @var array
	 */
	public function results_message_placeholders() {
		return array(
			'count_message'    => __( 'Viewing {from_count} - {to_count} of {total_results} users', 'gmw-wp-users-locator' ),
			'location_message' => __( ' within {radius}{units} from {address}', 'gmw-wp-users-locator' ),
		);
	}

	/**
	 * Get_info_window_args
	 *
	 * @param  object $user [description].
	 *
	 * @return [type]           [description]
	 */
	public function get_info_window_args( $user ) {

		if ( isset( $this->form['info_window']['image'] ) ) {

			if ( empty( $this->form['info_window']['image']['enabled'] ) ) {

				$avatar = false;

			} else {

				$args = array(
					'width'  => '120px',
					'height' => '120px',
				);

				$avatar = gmw_get_user_avatar( $args, $user, $this->form );
			}
		} else {
			$args = array(
				'width'  => '120px',
				'height' => '120px',
			);

			$avatar = gmw_get_user_avatar( $args, $user, $this->form );
		}

		return array(
			'prefix' => $this->prefix,
			'type'   => ! empty( $this->form['info_window']['iw_type'] ) ? $this->form['info_window']['iw_type'] : 'standard',
			'image'  => $avatar,
			'url'    => gmw_get_search_results_user_permalink( $user ),
			'title'  => $user->display_name,
		);
	}

	/**
	 * Query results
	 *
	 * @return [type] [description]
	 */
	public function search_query() {

		// query args.
		$this->form['query_args'] = apply_filters(
			'gmw_ul_search_query_args',
			array(
				'blog_id'  => get_current_blog_id(),
				'orderby'  => 'distance',
				'number'   => $this->form['get_per_page'],
				'paged'    => $this->form['paged'],
				'fields'   => array( 'ID', 'user_login', 'user_nicename', 'user_email', 'display_name', 'user_url' ),
				'gmw_args' => $this->query_cache_args,
			),
			$this->form,
			$this
		);

		// filter the form object.
		$this->form     = apply_filters( 'gmw_users_locator_form_before_users_query', $this->form, $this );
		$this->form     = apply_filters( 'gmw_ul_form_before_users_query', $this->form, $this );
		$internal_cache = GMW()->internal_cache;
		$this->query    = false;

		if ( $internal_cache ) {

			// prepare for cache.
			$hash            = md5( wp_json_encode( $this->form['query_args'] ) );
			$query_args_hash = 'gmw' . $hash . GMW_Cache_Helper::get_transient_version( 'gmw_get_object_user_query' );
			$this->query     = get_transient( $query_args_hash );
		}

		if ( ! $internal_cache || empty( $this->query ) ) {

			add_filter( 'pre_user_query', array( $this, 'query_clauses' ) );

			// query Groups.
			$this->query = new WP_User_Query( $this->form['query_args'] );

			remove_filter( 'pre_user_query', array( $this, 'query_clauses' ) );

			// set new query in transient.
			if ( $internal_cache ) {

				/**
				 * This is a temporary solution for an issue with caching SQL requests
				 *
				 * For some reason when LIKE is being used in SQL WordPress replace the % of the LIKE
				 *
				 * with long random numbers. This SQL is still being saved in the transient. Hoever,
				 *
				 * it is not being pulled back properly when GEO my WP trying to use it.
				 *
				 * It shows an error "unserialize(): Error at offset " and the value returns blank.
				 *
				 * As a temporary work around, we remove the [request] value, which contains the long numbers, from the WP_Query and save it in the transien without it.
				 */
				$request     = $this->query->request;
				$query_where = $this->query->query_where;

				unset( $this->query->request, $this->query->query_where );
				set_transient( $query_args_hash, $this->query, GMW()->internal_cache_expiration );

				$this->query->request     = $request;
				$this->query->query_where = $query_where;
			}
		}

		// Modify the form after the search query.
		$this->form  = apply_filters( 'gmw_ul_form_after_users_query', $this->form, $this );
		$this->query = apply_filters( 'gmw_ul_users_before_users_loop', $this->query, $this->form, $this );

		$this->form['results']       = $this->query->results;
		$this->form['results_count'] = 0;
		$this->form['total_results'] = 0;
		$this->form['max_pages']     = 0;

		if ( isset( $this->query->results ) ) {
			$this->form['results_count'] = count( $this->query->results );
			$this->form['total_results'] = $this->query->total_users;
			$this->form['max_pages']     = ceil( $this->form['total_results'] / $this->form['get_per_page'] );
		}

		$temp_array = array();

		foreach ( $this->form['results'] as $user ) {
			$temp_array[] = parent::the_location( $user->ID, $user );
		}

		$this->form['results'] = $temp_array;

		// Load the marker clusterer sctipt when needed.
		/*if ( ! gmw_is_addon_active( 'premium_settings' ) && ! empty( $this->form['map_enabled'] ) && ! empty( $this->form['map_markers']['grouping'] ) && 'markers_clusterer' === $this->form['map_markers']['grouping'] ) {
			add_action( 'wp_footer', array( $this, 'map_scripts' ) );
		}*/

		return $this->form['results'];
	}

	/**
	 * Marker Clusters map scripts.
	 */
	public function map_scripts() {
		?>
		<script type="text/javascript">
			jQuery(document).ready(function(){"google_maps"===gmwVars.mapsProvider&&GMW.add_filter("gmw_map_init",function(r){return"undefined"!=typeof r.markerGroupingTypes.markers_clusterer?r:(r.markerGroupingTypes.markers_clusterer={init:function(r){"function"==typeof MarkerClusterer&&(r.clusters=new MarkerClusterer(r.map,r.markers,{imagePath:r.clustersPath,clusterClass:r.prefix+"-cluster cluster",maxZoom:15}))},clear:function(r){"function"==typeof MarkerClusterer&&0!=r.clusters&&r.clusters.clearMarkers()},addMarker:function(r,e){e.clusters.addMarker(r)},markerClick:function(r,e){google.maps.event.addListener(r,"click",function(){e.markerClick(this)})}},r)}),"leaflet"===gmwVars.mapsProvider&&GMW.add_filter("gmw_map_init",function(r){return"undefined"!=typeof r.markerGroupingTypes.markers_clusterer?r:(r.markerGroupingTypes.markers_clusterer={init:function(r){"function"==typeof L.markerClusterGroup&&(r.clusters=L.markerClusterGroup(r.options.markerClustersOptions),r.map.addLayer(r.clusters))},clear:function(r){"function"==typeof L.markerClusterGroup&&0!=r.clusters&&r.clusters.clearLayers()},addMarker:function(r,e){e.clusters.addLayer(r)},markerClick:function(r,e){r.on("click",function(){e.markerClick(this)})}},r)})});
		</script>
		<?php
	}
}
