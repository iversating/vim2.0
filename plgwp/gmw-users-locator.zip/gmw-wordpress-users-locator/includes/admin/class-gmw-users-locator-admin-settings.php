<?php
/**
 * Users Locator Settings page.
 *
 * @package gmw-wordpress-users-locator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * GMW_Users_Locator_Admin_Settings class
 */
class GMW_Users_Locator_Admin_Settings {

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {
		add_filter( 'gmw_admin_settings_setup_defaults', array( $this, 'setup_defaults' ), 8 );
		add_filter( 'gmw_users_locator_admin_settings', array( $this, 'settings' ), 8 );
		add_action( 'admin_footer', array( $this, 'javascript' ) );
	}

	/**
	 * Default options will setup when no options exist.
	 *
	 * Usually when plugin first installed.
	 *
	 * @param  [type] $defaults [description].
	 * @return [type]           [description]
	 */
	public function setup_defaults( $defaults ) {

		$defaults['users_locator'] = array(
			'registration_location_form_usage'             => '',
			'registration_location_form_mandatory'         => 0,
			'registration_location_form_address_autocomplete' => 1,
			'registration_location_form_field_label'       => __( 'Address', 'gmw-wp-users-locator' ),
			'registration_location_form_field_placeholder' => __( 'Enter adress', 'gmw-wp-users-locator' ),
			'registration_location_form_exclude_fields_groups' => array(),
			'registration_location_form_exclude_fields'    => array(),
			'registration_location_form_template'          => 'location-form-tabs-top',
			'location_form_exclude_fields_groups'          => array(),
			'location_form_exclude_fields'                 => array(),
			'location_form_template'                       => 'location-form-tabs-top',
			'user_permalink_usage'                         => 'query_string',
			'user_permalink_page_id'                       => 0,
			'user_permalink_query_string'                  => '',
			'displayed_user_location_elements'             => array( 'name', 'address', 'map', 'directions_link' ),
			'displayed_user_location_address_fields'       => array( 'address' ),
			'displayed_user_location_map_width'            => '100%',
			'displayed_user_location_map_height'           => '350px',
			'displayed_user_location_map_type'             => 'ROADMAP',
		);

		return $defaults;
	}

	/**
	 * Admin settings
	 *
	 * @access public
	 *
	 * @param array $settings form settings.
	 *
	 * @return $settings
	 */
	public function settings( $settings ) {

		$exclude_field_groups = array(
			'name'        => 'registration_location_form_exclude_fields_groups',
			'type'        => 'multiselect',
			'label'       => __( 'Exclude Fields Group', 'gmw-wp-users-locator' ),
			'placeholder' => __( 'Select field groups', 'gmw-wp-users-locator' ),
			'default'     => array(),
			'options'     => array(
				'location'    => __( 'Location', 'gmw-wp-users-locator' ),
				'address'     => __( 'Address', 'gmw-wp-users-locator' ),
				'coordinates' => __( 'Coordinates', 'gmw-wp-users-locator' ),
			),
			'desc'        => __( 'Select the field groups that you wish to exclude from the location form.', 'gmw-wp-users-locator' ),
			'attributes'  => array(),
			'wrap_class'  => 'advanced-registration-option',
			'priority'    => 20,
		);

		$exclude_fields = array(
			'name'        => 'registration_location_form_exclude_fields',
			'type'        => 'multiselect',
			'label'       => __( 'Exclude Location Form Fields', 'gmw-wp-users-locator' ),
			'placeholder' => __( 'Select form fields', 'gmw-wp-users-locator' ),
			'default'     => array(),
			'options'     => array(
				'address'      => __( 'Address ( with autocomplete )', 'gmw-wp-users-locator' ),
				'map'          => __( 'Map', 'gmw-wp-users-locator' ),
				'street'       => __( 'Street', 'gmw-wp-users-locator' ),
				'premise'      => __( 'Apt/Suit ', 'gmw-wp-users-locator' ),
				'city'         => __( 'City', 'gmw-wp-users-locator' ),
				'region_name'  => __( 'State', 'gmw-wp-users-locator' ),
				'postcode'     => __( 'Postcode', 'gmw-wp-users-locator' ),
				'country_code' => __( 'Country', 'gmw-wp-users-locator' ),
				'latitude'     => __( 'Latitude', 'gmw-wp-users-locator' ),
				'longitude'    => __( 'Longitude', 'gmw-wp-users-locator' ),
			),
			'desc'        => __( 'Select specific form fields that you wish to exclude from the location form.', 'gmw-wp-users-locator' ),
			'attributes'  => array(),
			'wrap_class'  => 'advanced-registration-option',
			'priority'    => 25,
		);

		$template = array(
			'name'       => 'registration_location_form_template',
			'type'       => 'select',
			'default'    => 'location-form-tabs-top',
			'label'      => __( 'Location Form Template', 'gmw-wp-users-locator' ),
			'options'    => array(
				'location-form-tabs-top'  => __( 'Tabs Top ', 'gmw-wp-users-locator' ),
				'location-form-tabs-left' => __( 'Tabs Left', 'gmw-wp-users-locator' ),
				'location-form-no-tabs'   => __( 'No Tabs', 'gmw-wp-users-locator' ),
			),
			'desc'       => __( 'Select the location form template.', 'gmw-wp-users-locator' ),
			'wrap_class' => 'advanced-registration-option',
			'class'      => 'gmw-smartbox-not',
			'priority'   => 30,
		);

		$settings['registration_location_form_options'] = array(
			'name'     => 'registration_location_form_options',
			'type'     => 'fields_group',
			'label'    => __( 'User Location In WordPress Registration Page', 'gmw-wp-users-locator' ),
			'desc'     => __( 'Enable location in WordPress\'s registration page.', 'gmw-wp-users-locator' ),
			'fields'   => array(
				'registration_location_form_usage'       => gmw_get_admin_setting_args(
					array(
						'option_type' => 'usage_select',
						'name'        => 'registration_location_form_usage',
						'default'     => '',
						'options'     => array(
							''         => __( 'Disable', 'gmw-wp-users-locator' ),
							'simple'   => __( 'Address field only', 'gmw-wp-users-locator' ),
							'advanced' => __( 'Advanced location form', 'gmw-wp-users-locator' ),
						),
						'desc'        => __( 'Select "Address field only" to display an address field only or "Advanced location form" to display the location form of GEO my WP.', 'gmw-wp-users-locator' ),
						'class'       => 'gmw-smartbox-not',
						'priority'    => 5,
					)
				),
				'registration_location_form_address_autocomplete' => gmw_get_admin_setting_args(
					array(
						'name'       => 'registration_location_form_address_autocomplete',
						'type'       => 'checkbox',
						'default'    => '',
						'label'      => __( 'Address Autocomplete', 'gmw-wp-users-locator' ),
						'cb_label'   => __( 'Enable', 'gmw-wp-users-locator' ),
						'desc'       => __( 'Enable Google Maps address autocompelte feature.', 'gmw-wp-users-locator' ),
						'attributes' => array(),
						'wrap_class' => 'simple-registration-option',
						'priority'   => 10,
					)
				),
				'registration_location_form_field_label' => gmw_get_admin_setting_args(
					array(
						'option_type' => 'label',
						'name'        => 'registration_location_form_field_label',
						'label'       => __( 'Address field label', 'gmw-wp-users-locator' ),
						'wrap_class'  => 'simple-registration-option advanced-registration-option',
						'priority'    => 15,
					)
				),
				'registration_location_form_field_placeholder' => gmw_get_admin_setting_args(
					array(
						'option_type' => 'placeholder',
						'name'        => 'registration_location_form_field_placeholder',
						'label'       => __( 'Address field placeholder', 'gmw-wp-users-locator' ),
						'wrap_class'  => 'simple-registration-option advanced-registration-option',
						'priority'    => 20,
					)
				),
				'registration_location_form_mandatory'   => gmw_get_admin_setting_args(
					array(
						'option_type' => 'required',
						'name'        => 'registration_location_form_mandatory',
						'label'       => __( 'Required Location', 'gmw-wp-users-locator' ),
						'desc'        => __( 'Force users to enter a location during registration.', 'gmw-wp-users-locator' ),
						'wrap_class'  => 'simple-registration-option advanced-registration-option',
						'priority'    => 20,
					)
				),
				'registration_location_form_exclude_fields_groups' => gmw_get_admin_setting_args( $exclude_field_groups ),
				'registration_location_form_exclude_fields' => gmw_get_admin_setting_args( $exclude_fields ),
				'registration_location_form_template'    => gmw_get_admin_setting_args( $template ),
			),
			'priority' => 5,
		);

		$exclude_field_groups['name']     = 'location_form_exclude_fields_groups';
		$exclude_field_groups['priority'] = 5;
		$exclude_fields['name']           = 'location_form_exclude_fields';
		$exclude_fields['priority']       = 10;
		$template['name']                 = 'location_form_template';
		$template['priority']             = 15;

		unset( $exclude_field_groups['wrap_class'], $exclude_fields['wrap_class'], $template['wrap_class'] );

		$settings['location_form_options'] = array(
			'name'     => 'location_form_options',
			'type'     => 'fields_group',
			'label'    => __( 'User Location Form', 'gmw-wp-users-locator' ),
			'desc'     => __( 'Setup the location form that users use when adding and updating their location. To display the form on any page, post, or text widget of your site use the shortcode <code>[gmw_user_location_form]</code>. The form will be available when a user is logged in only.', 'gmw-wp-users-locator' ),
			'fields'   => array(
				'location_form_exclude_fields_groups' => gmw_get_admin_setting_args( $exclude_field_groups ),
				'location_form_exclude_fields'        => gmw_get_admin_setting_args( $exclude_fields ),
				'location_form_template'              => gmw_get_admin_setting_args( $template ),
			),
			'priority' => 10,
		);

		$page_id = gmw_get_option( 'users_locator', 'user_permalink_page_id', 0 );

		$selected_page = array();

		if ( ! empty( $page_id ) ) {
			$selected_page[ $page_id ] = get_the_title( $page_id );
		}

		$settings['user_permalink_options'] = array(
			'name'     => 'user_permalink_options',
			'type'     => 'fields_group',
			'label'    => __( 'User ( Author ) Details Page', 'gmw-wp-users-locator' ),
			'desc'     => __( 'Generate the permalink that you wish to use for the user\'s profile page. This link will be used when navigating from GEO my WP\'s search results to view a single user details.', 'gmw-wp-users-locator' ),
			'fields'   => array(
				'user_permalink_usage'        => gmw_get_admin_setting_args(
					array(
						'name'     => 'user_permalink_usage',
						'type'     => 'select',
						'default'  => 'query_string',
						'label'    => __( 'Permalink Usage', 'gmw-wp-users-locator' ),
						'desc'     => sprintf(
							/* translators: %s: shortcode */
							__( '<b>Options Description:</b><br />&#8226; <u>URL query string only:</u> Will use the home URL as the base for the query string. This can be useful when using together with the query string options below to generate a permalink to a specifc profile page ( maybe generated by another plugin or the theme ).<br />&#8226; <u>Page:</u> select a specific page from the dropdown list below. When using a page you can either enable the plugin to dynamically replace the content of that page with the user location ( using the "Displayed User Location" settings below ), or by placing the shortcode %s in the content of that page.<br />&#8226; <u>Author template page:</u> link to the original author page generated by the theme that you are using ( when available ).', 'gmw-wp-users-locator' ),
							'<code>[gmw_displayed_user_location]</code>'
						),
						'options'  => array(
							'query_string' => __( 'URL query string only', 'gmw-wp-users-locator' ),
							'page'         => __( 'Page', 'gmw-wp-users-locator' ),
							'theme'        => __( 'Theme\'s author template page', 'gmw-wp-users-locator' ),
						),
						'class'    => 'gmw-smartbox-not',
						'priority' => 5,
					)
				),
				'user_permalink_page_id'      => gmw_get_admin_setting_args(
					array(
						'name'        => 'user_permalink_page_id',
						'type'        => 'select',
						'default'     => '',
						'label'       => __( 'Select Page', 'gmw-wp-users-locator' ),
						'desc'        => __( 'Select the page that you wish to use when displaying the details of a specific user.', 'gmw-wp-users-locator' ),
						'options'     => $selected_page,
						'priority'    => 10,
						'placeholder' => __( 'Select page', 'gmw-wp-users-locator' ),
						'attributes'  => array(
							'data-gmw_ajax_load_options' => 'gmw_get_pages',
						),
					)
				),
				'user_permalink_query_string' => gmw_get_admin_setting_args(
					array(
						'name'        => 'user_permalink_query_string',
						'type'        => 'text',
						'default'     => '',
						'placeholder' => 'Example: ?user_id={id}&username={username}',
						'label'       => __( 'Query String', 'gmw-wp-users-locator' ),
						'desc'        => __( 'Generate a custom URL query string. You can use the placeholders below to pass some user data as URL parameters:<br />&#8226; {id}: user ID <br /> &#8226; {username}: user name <br /> &#8226; {email}: User email<br /> &#8226; {nicename}: user nicename<br /><b>Example:</b> ?user_id={id}&username={username}', 'gmw-wp-users-locator' ),
						'priority'    => 15,
					)
				),
			),
			'priority' => 20,
		);

		$settings['displayed_user_location'] = array(
			'name'     => 'displayed_user_location',
			'type'     => 'fields_group',
			'label'    => __( 'Displayed User Location', 'gmw-wp-users-locator' ),
			'desc'     => __( 'Set the location elements that will be displayed when viewing the location of another user.<br /><div class="gmw-admin-notice-box gmw-admin-notice-warning">To use the settings below the "User Permalink Usage" option in the section above must be set as "Page".</div>', 'gmw-wp-users-locator' ),
			'fields'   => array(
				'displayed_user_location_enabled'        => gmw_get_admin_setting_args(
					array(
						'name'       => 'displayed_user_location_enabled',
						'type'       => 'checkbox',
						'default'    => '',
						'label'      => __( 'Replace page content dynamically', 'gmw-wp-users-locator' ),
						'cb_label'   => __( 'Enable', 'gmw-wp-users-locator' ),
						'desc'       => __( 'Check this checkbox to dynamically replace the content of the user\'s page with his location. Otherwise, you can manually place the shortcode <code>[gmw_displayed_user_location]</code> anywhere in the content of that page.', 'gmw-wp-users-locator' ),
						'attributes' => array(),
						'priority'   => 5,
					)
				),
				'displayed_user_location_elements'       => gmw_get_admin_setting_args(
					array(
						'name'       => 'displayed_user_location_elements',
						'type'       => 'multiselect',
						'default'    => array( 'name', 'address', 'map', 'directions_link' ),
						'label'      => __( 'Include location elements', 'gmw-wp-users-locator' ),
						'options'    => array(
							'name'            => __( 'User display name', 'gmw-wp-users-locator' ),
							'address'         => __( 'Address', 'gmw-wp-users-locator' ),
							'map'             => __( 'Map', 'gmw-wp-users-locator' ),
							'directions_link' => __( 'Directions link', 'gmw-wp-users-locator' ),
						),
						'desc'       => __( 'Select the location elements that you wish to display.', 'gmw-wp-users-locator' ),
						'attributes' => array(),
						'priority'   => 10,
					)
				),
				'displayed_user_location_address_fields' => gmw_get_admin_setting_args(
					array(
						'name'       => 'displayed_user_location_address_fields',
						'type'       => 'multiselect',
						'default'    => array( 'address' ),
						'label'      => __( 'Select address fields', 'gmw-wp-users-locator' ),
						'desc'       => __( 'Select the address fields that you wish to display.', 'gmw-wp-users-locator' ),
						'options'    => array(
							'address'      => __( 'Formatted address ( full address )', 'gmw-wp-users-locator' ),
							'street'       => __( 'Street', 'gmw-wp-users-locator' ),
							'premise'      => __( 'Apt/Suit ', 'gmw-wp-users-locator' ),
							'city'         => __( 'City', 'gmw-wp-users-locator' ),
							'region_name'  => __( 'State', 'gmw-wp-users-locator' ),
							'postcode'     => __( 'Postcode', 'gmw-wp-users-locator' ),
							'country_code' => __( 'Country', 'gmw-wp-users-locator' ),
						),
						'attributes' => array( 'data' => 'multiselect_address_fields' ),
						'priority'   => 15,
					)
				),
				'displayed_user_location_map_width'      => gmw_get_admin_setting_args(
					array(
						'name'        => 'displayed_user_location_map_width',
						'type'        => 'text',
						'default'     => '100%',
						'placeholder' => __( 'Map width in px or %', 'gmw-wp-users-locator' ),
						'label'       => __( 'Map width', 'gmw-wp-users-locator' ),
						'desc'        => __( 'Enter the map width in pixels or percentage.', 'gmw-wp-users-locator' ),
						'attributes'  => array(),
						'priority'    => 20,
					)
				),
				'displayed_user_location_map_height'     => gmw_get_admin_setting_args(
					array(
						'name'        => 'displayed_user_location_map_height',
						'type'        => 'text',
						'default'     => '300px',
						'placeholder' => __( 'Map height in px or %', 'gmw-wp-users-locator' ),
						'label'       => __( 'Map height', 'gmw-wp-users-locator' ),
						'desc'        => __( 'Enter the map height in pixels or percentage.', 'gmw-wp-users-locator' ),
						'attributes'  => array(),
						'priority'    => 25,
					)
				),
				'displayed_user_location_map_type'       => gmw_get_admin_setting_args(
					array(
						'name'       => 'displayed_user_location_map_type',
						'type'       => 'select',
						'default'    => 'ROADMAP',
						'label'      => __( 'Map type', 'gmw-wp-users-locator' ),
						'desc'       => __( 'Select the map type.', 'gmw-wp-users-locator' ),
						'options'    => array(
							'ROADMAP'   => __( 'ROADMAP', 'gmw-wp-users-locator' ),
							'SATELLITE' => __( 'SATELLITE', 'gmw-wp-users-locator' ),
							'HYBRID'    => __( 'HYBRID', 'gmw-wp-users-locator' ),
							'TERRAIN'   => __( 'TERRAIN', 'gmw-wp-users-locator' ),
						),
						'attributes' => array(),
						'priority'   => 30,
					)
				),
			),
			'priority' => 30,
		);

		return $settings;
	}

	/**
	 * JavaScript for admin settings.
	 */
	public function javascript() {
		?>
		<script type="text/javascript">

			jQuery( document ).ready( function( $ ) {

				$( '#setting-users_locator-registration_location_form_usage' ).change( function() {

					var wrapper = jQuery( this ).closest( '.gmw-settings-multiple-fields-wrapper' );
					var value   = $( this ).val();

					if ( value != '' ) {
						wrapper.find( '.gmw-settings-panel-field' ).not( ':first' ).hide();
						wrapper.find( '.' + value + '-registration-option' ).slideDown();
					} else {
						wrapper.find( '.gmw-settings-panel-field' ).not( ':first' ).slideUp();
					}
				});

				$( '#setting-users_locator-user_permalink_usage' ).change( function() {

					if ( jQuery( this ).val() == 'page' ) {

						$( '.single-option.option-user_permalink_page_id' ).slideDown( 'fast' );

					} else {
						$( '.single-option.option-user_permalink_page_id' ).slideUp( 'fast' );
					}
				});

				$( '#setting-users_locator-registration_location_form_usage, #setting-users_locator-user_permalink_usage' ).trigger( 'change' );
			});
		</script>
		<?php
	}
}
new GMW_Users_Locator_Admin_Settings();
