<?php
/**
 * GEO my WP Users Locator Location in User Profile page ( dashboard ).
 *
 * @package gmw-wordpress-users-locator
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * GMW_User_Location_Admin_Profile_Page
 */
class GMW_User_Location_Admin_Profile_Page {

	/**
	 * Logged in user object.
	 *
	 * @var integer
	 */
	public $current_user = 0;

	/**
	 * User Roles allowed to manage other users' location.
	 *
	 * @var array
	 */
	public $allowed_roles = array( 'administrator' );

	/**
	 * Current user manage location status.
	 *
	 * @var boolean
	 */
	public $is_user_allowed = false;

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'init' ) );
	}

	/**
	 * Init class
	 */
	public function init() {

		// User object.
		$this->current_user = wp_get_current_user();

		// Modify the user roles that can edit the location in the admin's dashboard.
		$this->allowed_roles = apply_filters( 'gmw_ul_can_manage_location_user_roles', $this->allowed_roles );

		// Check if user allowed to manage locations of other users.
		if ( array_intersect( $this->allowed_roles, $this->current_user->roles ) ) {
			$this->is_user_allowed = true;
		}

		add_action( 'admin_menu', array( $this, 'location_submenu_item' ) );

		if ( ! apply_filters( 'disable_user_profile_location_section', false ) ) {
			add_action( 'show_user_profile', array( $this, 'user_profile_location_section' ), 3 );
			add_action( 'edit_user_profile', array( $this, 'user_profile_location_section' ), 3 );
		}

		if ( $this->is_user_allowed ) {
			add_filter( 'manage_users_columns', array( $this, 'location_column' ), 50 );
			add_filter( 'manage_users_custom_column', array( $this, 'location_column_content' ), 10, 3 );
		}
	}

	/**
	 * Location menu item
	 */
	public function location_submenu_item() {

		$url = admin_url( 'profile.php?gmw_show_form=1#gmw-user-profile-location-section' );
		add_submenu_page( 'users.php', 'Location', __( 'Location', 'gmw-wp-users-locator' ), 'read', $url, '', 3 );
	}

	/**
	 * Add location column to Users page.
	 *
	 * @param array $columns existing columns.
	 */
	public function location_column( $columns ) {

		$columns['gmw_location'] = '<span class="gmw-icon-location"></span>' . esc_html__( 'Location', 'gmw-wp-users-locator' );

		return $columns;
	}

	/**
	 * Add content to the Location column.
	 *
	 * @param string $output      original column output.
	 *
	 * @param string $column_name column name.
	 *
	 * @param int    $user_id     user ID.
	 */
	public function location_column_content( $output, $column_name, $user_id ) {

		if ( 'gmw_location' === $column_name ) {

			$output  = '';
			$address = gmw_get_user_location( $user_id );

			if ( ! empty( $address->address ) ) {

				$address = esc_attr( $address->address );

				$output .= '<span class="gmw-icon-location" style="color:#005C9D"></span><a style="color:#005C9D" target="_blank" href="https://maps.google.com/maps?q=' . $address . '&size=512x512&maptype=roadmap&sensor=false">' . $address . '</a>';

			} else {

				$output .= '<span class="gmw-icon-cancel-circled" style="color:orange"></span>' . esc_html__( 'No location found', 'gmw-wp-users-locator' );
			}

			$url = admin_url( 'user-edit.php?user_id=' . $user_id . '&gmw_show_form=1#gmw-user-profile-location-section' );

			$output .= ' ( <a href=" ' . esc_url( $url ) . '" style="color:green;">' . __( 'Update location', 'gmw-wp-users-locator' ) . '</a> )';

			return $output;
		}
	}

	/**
	 * Create Your Location section in user profile page.
	 *
	 * @param  object $user user object.
	 *
	 * @since 1.4.3
	 */
	public function user_profile_location_section( $user ) {

		$output     = '';
		$address    = gmw_get_user_location( $user->ID );
		$no_address = __( 'No location found.', 'gmw-wp-users-locator' );
		$address    = ! empty( $address->address ) ? $address->address : $no_address;
		$link       = '<a id="gmw-user-location-form-toggle" href="#" class="gmw-popup-element-toggle" data-element="#gmw-user-location-form-popup-element">' . esc_html__( 'Update location', 'gmw-wp-users-locator' ) . '</a>';
		$show_form  = ! empty( $_GET['gmw_show_form'] ) ? true : false; // WPCS: CSRF ok.

		wp_enqueue_script( 'gmw-admin' );
		?>
		<style type="text/css">
			#gmw-user-location-form-popup-element .gmw-popup-element-inner {
				padding: 0;
				max-height: initial;
			}

			#gmw-user-location-form-popup-element #gmw-location-form-wrapper {
				border: 0;
			}

			#gmw-location {
				padding: 0;
				border: 0;
			}

			#gmw-location:focus {
				outline:none !important;
				outline-width: 0 !important;
				box-shadow: none;
				-moz-box-shadow: none;
				-webkit-box-shadow: none;
			}
		</style>
		<script type="text/javascript">

			jQuery( document ).ready( function( $) {

				var show_form      = '<?php echo esc_attr( $show_form ); // WPCS: XSS ok. ?>';
				var noLocationText = '<?php echo esc_attr( $no_address ); ?>';

				// Dynamically show the form when needed.
				if ( show_form ) {
					jQuery( '#gmw-user-location-form-popup-element' ).fadeIn( 'fast' );
				}

				// Fill selected address in the address field when location updated.
				GMW.add_action( 'gmw_lf_location_saved', function( response, form_values, form ) {

					$( '#gmw-location' ).val( jQuery( '#gmw_lf_address' ).val() );

					setTimeout( function() {
						jQuery( '#gmw-user-location-form-popup-element' ).fadeOut( 'fast' );
					}, 1500 );
				});

				// Remove address from field when location deleted.
				GMW.add_action( 'gmw_lf_location_deleted', function( response, formValues ) {
					$( '#gmw-location' ).val( noLocationText );
				});
			});
		</script>

		<div id="gmw-user-profile-location-section">

			<h3><?php esc_html_e( 'Location', 'gmw-wp-users-locator' ); ?></h3>

			<table class="form-table">
				<tr>
					<th><label for="gmw-location"><?php esc_html_e( 'Address', 'gmw-wp-users-locator' ); ?></label></th>
					<td>
						<input type="text" readonly="readonly" id="gmw-location" value="<?php echo esc_attr( $address ); ?>" class="regular-text" /><br />

						<span class="description"><?php echo $link; // WPCS: XSS ok. ?></span>

						<div id="gmw-user-location-form-popup-element" class="gmw-popup-element-wrapper">

							<div class="gmw-popup-element-inner">

								<span class="gmw-popup-element-close-button gmw-icon-cancel-light"></span>

								<?php
								gmw_ul_user_location_form(
									array(
										'user_id'      => $user->ID,
										'stand_alone'  => 0,
										'form_element' => '#your-profile',
									)
								);
								?>
							</div>

						</div>

					</td>
				</tr>
			</table>
		</div>
		<?php
	}
}
new GMW_User_Location_Admin_Profile_Page();
