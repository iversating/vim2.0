<?php
/**
 * Users Locator Form editor.
 *
 * @package gmw-wordpress-users-locator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * GMW_Users_Locator_Form_Settings class.
 */
class GMW_Users_Locator_Form_Settings {

	/**
	 * __construct function.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {

		add_filter( 'gmw_form_default_settings', array( $this, 'set_defaults' ), 15, 2 );
		add_filter( 'gmw_form_settings', array( $this, 'form_settings' ), 15, 2 );

		// Mashup map form tasks.
		add_filter( 'gmw_users_locator_mashup_map_form_settings', array( $this, 'form_settings' ), 5, 2 );
	}

	/**
	 * Default settings
	 *
	 * @param  [type] $settings [description].
	 *
	 * @param  array  $form     form args.
	 *
	 * @return [type]           [description]
	 */
	public function set_defaults( $settings, $form ) {

		if ( 'users_locator' !== $form['component'] ) {
			return $settings;
		}

		$settings['map_markers'] = array(
			'grouping' => 'markers_clusterer',
		);

		return $settings;
	}

	/**
	 * Form settings.
	 *
	 * @param  [type] $settings [description].
	 *
	 * @param  array  $form     form settings.
	 *
	 * @return [type]           [description]
	 */
	public function form_settings( $settings, $form ) {

		if ( 'users_locator' !== $form['component'] ) {
			return $settings;
		}

		unset( $settings['search_results']['image']['fields']['no_image_url'] );

		if ( ! class_exists( 'GMW_Premium_Settings_Addon' ) ) {
			$settings['map_markers']['grouping'] = gmw_get_admin_setting_args( 'marker_grouping' );
		}

		return $settings;
	}
}
new GMW_Users_Locator_Form_Settings();
