<?php
/**
 * GEO my WP WP Users Locator - template functions.
 *
 * @package gmw-wordpress-users-locator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Generate user permalink.
 *
 * @param  object  $user            user object.
 *
 * @param  string  $url             url type.
 *
 * @param  integer $page_id         page ID when url type is 'page'.
 *
 * @param  string  $query_string    query strging, if provided.
 *
 * @param  boolean $replace_content true when dynamically replacing the content of the page with user's location.
 *
 * @return unescaped url. Escape on output.
 */
function gmw_get_user_permalink( $user, $url = '', $page_id = 0, $query_string = '', $replace_content = false ) {

	if ( empty( $url ) || 'query_string' === $url ) {

		$permalink = get_home_url() . '/';

	} elseif ( 'theme' === $url ) {

		$permalink = get_author_posts_url( $user->ID );

	} else {
		$permalink = get_permalink( $page_id );
	}

	$base_permalink = $permalink;

	// generate the query string.
	if ( ! empty( $query_string ) ) {

		$permalink .= str_replace(
			array( '{id}', '{username}', '{email}', '{nicename}', '{disaplyname}' ),
			array( $user->ID, $user->user_login, $user->user_email, $user->user_nicename, $user->display_name ),
			$query_string
		);
	}

	// if the URL set to 'page' and 'replace page content' is enabled,
	// then we need to add uid with user ID is in the URL.
	if ( 'page' === $url && $replace_content ) {
		$permalink = add_query_arg( 'uid', $user->ID, $permalink );
	}

	// need escaping on output.
	return apply_filters( 'gmw_ul_get_user_permalink', $permalink, $base_permalink, $user, $url, $page_id, $query_string, $replace_content );
}

/**
 * Get the permalink in the search results.
 *
 * Generated based on the settings page
 *
 * @param  object $user user object.
 *
 * @param  array  $gmw  gmw form.
 *
 * unescaped url. Escape on output.
 */
function gmw_get_search_results_user_permalink( $user, $gmw = array() ) {

	$url             = gmw_get_option( 'users_locator', 'user_permalink_usage', 'query_string' );
	$page_id         = gmw_get_option( 'users_locator', 'user_permalink_page_id', 0 );
	$query_string    = gmw_get_option( 'users_locator', 'user_permalink_query_string', '' );
	$replace_content = gmw_get_option( 'users_locator', 'displayed_user_location_enabled', false );

	// escape on output.
	return gmw_get_user_permalink( $user, $url, $page_id, $query_string, $replace_content );
}

/**
 * Echo the user's permalink in search results
 *
 * @param  object $user user object.
 *
 * @param  array  $gmw  gmw form.
 */
function gmw_search_results_user_permalink( $user, $gmw = array() ) {

	$url = gmw_get_search_results_user_permalink( $user, $gmw );

	echo esc_url( $url );
}

/**
 * Display user name linked to its profile
 *
 * @param  object $user user object.
 *
 * @param  array  $gmw  gmw form.
 *
 * @return escaped linked title.
 */
function gmw_ul_get_user_title( $user, $gmw = array() ) {

	$args = array(
		'url'  => gmw_get_search_results_user_permalink( $user, $gmw ),
		'name' => gmw_get_search_results_title( $user->display_name, $user, $gmw ),
	);

	$args = apply_filters( 'gmw_ul_get_user_title_args', $args, $user, $gmw );

	return '<a class="title ' . $args['name'] . '-name" href="' . esc_url( $args['url'] ) . '">' . $args['name'] . '</a>';
}

/**
 * Output the user title.
 *
 * @param  object $user user object.
 *
 * @param  array  $gmw  gmw form.
 */
function gmw_ul_user_title( $user, $gmw = array() ) {
	echo gmw_ul_get_user_title( $user, $gmw ); // WPCS: XSS ok.
}

/**
 * Generate user avatar.
 *
 * @param  array $args arguments.
 *
 * @param  array $user user object.
 *
 * @param  array $gmw  gmw form.
 *
 * @return [type]       [description]
 */
function gmw_get_user_avatar( $args = array(), $user = array(), $gmw = array() ) {

	$args = apply_filters( 'gmw_get_avatar_args', $args, $user, $gmw );
	$args = wp_parse_args(
		$args,
		array(
			'object_type'  => 'user',
			'object_id'    => 0,
			'permalink'    => true,
			'width'        => '150px',
			'height'       => '150px',
			'where'        => 'search_results',
			'class'        => '',
			'no_image_url' => '',
		)
	);

	$avatar_args = array(
		'size' => '350',
	);

	$avatar_url = get_avatar_url( $user->ID, $avatar_args );

	//if ( strpos( $avatar_url, 'd=blank' ) === false ) {

		$args['image_url'] = $avatar_url;

	/*} else {

		$args['image_url'] = $args['no_image_url'];
		$args['class']    .= ' gmw-no-image';
	}*/

	$args['permalink'] = ! empty( $args['permalink'] ) ? gmw_get_search_results_user_permalink( $user, $gmw ) : false;

	return gmw_get_image_element( $args, $user, $gmw );
}

/**
 * Display user avatar in search results.
 *
 * @param  object $user the user object.
 *
 * @param  array  $gmw  gmw form.
 */
function gmw_search_results_user_avatar( $user, $gmw = array(), $where = 'search_results' ) {

	if ( empty( $gmw[ $where ]['image']['enabled'] ) ) {
		return;
	}

	$settings = $gmw[ $where ]['image'];
	$args     = array(
		'object_type'  => 'user',
		'object_id'    => $user->ID,
		'width'        => ! empty( $settings['width'] ) ? $settings['width'] : '150px',
		'height'       => ! empty( $settings['height'] ) ? $settings['height'] : '150px',
		'no_image_url' => ! empty( $settings['no_image_url'] ) ? $settings['no_image_url'] : '',
		'where'        => 'search_results',
	);

	echo gmw_get_user_avatar( $args, $user, $gmw ); // WPCS: XSS ok.
}
