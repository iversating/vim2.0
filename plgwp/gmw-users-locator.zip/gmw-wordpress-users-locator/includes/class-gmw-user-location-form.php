<?php
/**
 * GEO my WP Users Locator - location form class.
 *
 * @package gmw-wp-users-locator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'GMW_User_Location_Form' ) ) {

	/**
	 * GMW_FL_Location_Form Class extends GMW_Location_Form class
	 *
	 * Location form for Location tab of BuddyPress member's profile page.
	 *
	 * @since 3.0
	 */
	class GMW_User_Location_Form extends GMW_Location_Form {

		/**
		 * Addon slug
		 *
		 * @var string
		 */
		public $slug = 'users_locator';

		/**
		 * Object type
		 *
		 * @var string
		 */
		public $object_type = 'user';

		/**
		 * Run the form class
		 *
		 * @param array $attr shortcode attributes.
		 */
		public function __construct( $attr = array() ) {

			parent::__construct( $attr );

			// add custom tab panels.
			add_action( 'gmw_lf_content_end', array( $this, 'create_tabs_panels' ) );
		}

		/**
		 * Generate custom tabs panels
		 *
		 * @return void
		 */
		public function create_tabs_panels() {
			do_action( 'gmw_user_location_tabs_panels', $this );
		}
	}
}
