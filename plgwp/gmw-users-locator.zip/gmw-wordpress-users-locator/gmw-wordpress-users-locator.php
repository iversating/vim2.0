<?php
/**
 * Plugin Name: GMW Add-on - WordPress Users Locator
 * Plugin URI: http://www.geomywp.com
 * Description: Extend WordPress users with geolocation and mapping features.
 * Version: 2.0-beta1
 * Author: Eyal Fitoussi
 * Author URI: http://www.geomywp.com
 * Requires at least: 4.5
 * Tested up to: 4.9.5
 * GEO my WP: 3.0+
 * Text Domain: gmw-wp-users-locator
 * Domain Path: /languages/
 *
 * @package gmw-wordpress-users-locator
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// look for GMW add-on registration class.
if ( ! class_exists( 'GMW_Addon' ) ) {
	return;
}

/**
 * GMW_Users_Locator_Addon class.
 */
class GMW_Users_Locator_Addon extends GMW_Addon {

	/**
	 * Slug.
	 *
	 * @var string
	 */
	public $slug = 'users_locator';

	/**
	 * Name.
	 *
	 * @var string
	 */
	public $name = 'WordPress Users Locator';

	/**
	 * Prefix.
	 *
	 * @var string
	 */
	public $prefix = 'ul';

	/**
	 * Version.
	 *
	 * @var string
	 */
	public $version = '1.99';

	/**
	 * Object.
	 *
	 * @var string
	 */
	public $object = 'user';

	/**
	 * Object type.
	 *
	 * @var string
	 */
	public $object_type = 'user';

	/**
	 * License name.
	 *
	 * @var string
	 */
	public $license_name = 'users_locator';

	/**
	 * Item name.
	 *
	 * @var string
	 */
	public $item_name = 'WordPress Users Locator';

	/**
	 * Item ID.
	 *
	 * @var string
	 */
	public $item_id = 11188;

	/**
	 * Author.
	 *
	 * @var string
	 */
	public $author = 'Eyal Fitoussi';

	/**
	 * Required GMW Version.
	 *
	 * @var string
	 */
	public $gmw_min_version = '4.0';

	/**
	 * Text Domain.
	 *
	 * @var string
	 */
	public $textdomain = 'gmw-wp-users-locator';

	/**
	 * Full Path.
	 *
	 * @var string
	 */
	public $full_path = __FILE__;

	/**
	 * Template folders.
	 *
	 * @var string
	 */
	public $templates_folder = 'users-locator';

	/**
	 * Description.
	 *
	 * @var string
	 */
	public $description = 'Extend WordPress users with geolocation and mapping features.';

	/**
	 * Addon's page.
	 *
	 * @var string
	 */
	public $addon_page = 'https://geomywp.com/extensions/wordpress-users-locator/';

	/**
	 * Support Page.
	 *
	 * @var string
	 */
	public $support_page = 'https://geomywp.com/support/#gmw-premium-support';

	/**
	 * Docs page.
	 *
	 * @var string
	 */
	public $docs_page = 'https://docs.geomywp.com';

	/**
	 * Settings groups
	 *
	 * @return [type] [description]
	 */
	public function admin_settings_groups() {
		return array(
			'slug'     => 'users_locator',
			'label'    => __( 'WP Users Locator', 'gmw-wp-users-locator' ),
			'icon'     => 'users',
			'priority' => 8,
		);
	}

	/**
	 * Form button
	 *
	 * @return [type] [description]
	 */
	public function form_buttons() {
		return array(
			array(
				'slug'      => 'users_locator',
				'name'      => __( 'Users Locator Form', 'gmw-wp-users-locator' ),
				'component' => 'users_locator',
				'prefix'    => 'ul',
				'priority'  => 20,
			),
			array(
				'slug'      => 'users_locator_mashup_map',
				'name'      => __( 'Users Mashup Map', 'gmw-wp-users-locator' ),
				'component' => 'users_locator',
				'prefix'    => 'ulmmap',
				'priority'  => 22,
			),
		);
	}

	/**
	 * Form settings groups.
	 *
	 * @return [type] [description]
	 */
	public function form_settings_groups() {

		return array(
			array(
				'slug'     => 'map_markers',
				'label'    => __( 'Map Markers', 'gmw-wp-users-locator' ),
				'fields'   => array(),
				'priority' => 50,
			),
		);
	}

	/**
	 * Instance of GMW WP Users Locator.
	 *
	 * @var null
	 */
	private static $instance = null;

	/**
	 * Create new instance
	 *
	 * @return [type] [description]
	 */
	public static function get_instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Pre init functions
	 *
	 * @return [type] [description]
	 */
	public function pre_init() {

		parent::pre_init();

		include_once 'includes/gmw-users-locator-functions.php';

		if ( IS_ADMIN ) {

			if ( ! defined( 'DOING_AJAX' ) ) {
				include_once 'includes/admin/class-gmw-users-locator-admin-settings.php';
			}
			include_once 'includes/admin/class-gmw-user-location-admin-profile-page.php';
			//include_once 'includes/admin/class-gmw-users-locator-form-settings.php';

			add_action( 'personal_options_update', array( $this, 'clear_users_cache' ) );
			add_action( 'edit_user_profile_update', array( $this, 'clear_users_cache' ) );
		}

		include_once 'includes/gmw-users-locator-template-functions.php';
		include_once 'includes/class-gmw-user-location-form.php';

		// Include file only if location during registration is enabled.
		if ( 'disabled' !== gmw_get_option( 'users_locator', 'registration_location_form_usage', 'disabled' ) ) {
			include 'includes/class-gmw-users-locator-registration-form-location.php';
		}

		if ( gmw_is_addon_active( 'single_location' ) ) {

			if ( IS_ADMIN ) {

				/**
				 * Add post object to objects dropdown in single location widget
				 *
				 * @param  array $args single location widget options.
				 *
				 * @return new options.
				 */
				function gmw_ul_single_location_widget_object( $args ) {

					$args['user'] = __( 'WordPress User', 'gmw-wp-users-locator' );

					return $args;
				}
				add_filter( 'gmw_single_location_widget_objects', 'gmw_ul_single_location_widget_object', 15 );

			}
			if ( ! IS_ADMIN || defined( 'DOING_AJAX' ) ) {
				include_once 'includes/class-gmw-single-user-location.php';
			}
		}

		if ( ! IS_ADMIN || defined( 'DOING_AJAX' ) ) {
			include_once 'includes/class-gmw-users-locator-form.php';
			include_once 'includes/class-gmw-users-locator-mashup-map-form.php';
		}
	}

	/**
	 * Clear GEO my WP's users internal cache.
	 *
	 * @since 1.4.5
	 */
	public function clear_users_cache() {

		// Handle members cache.
		if ( GMW()->internal_cache ) {
			GMW_Cache_Helper::flush_cache_by_object( 'user' );
		}
	}
}
GMW_Addon::register( 'GMW_Users_Locator_Addon' );
