<?php
/**
 * Item price
 *
 * @package cartflows
 */

?>
<div class="wcf-price">
	<div class="wcf-display-price wcf-field-label"><?php echo $price_data['original_price']; ?></div>
</div>
