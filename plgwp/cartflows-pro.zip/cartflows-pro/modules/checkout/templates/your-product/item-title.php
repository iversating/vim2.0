<?php
/**
 * Title and Subtext
 *
 * @package cartflows
 */

?>
<div class="wcf-item-wrap">
<?php

$actual_product_name = $rc_product_obj->get_name();
$display_title       = '';

if ( ! empty( $data['product_name'] ) ) {
	$display_title = $data['product_name'];
} else {
	$display_title = '{{product_name}}{{quantity}}';
}

if ( $data['variable'] ) {

	$actual_product_name = $current_product->get_name();
	$attribute_data      = $this->get_selected_attributes( $current_product, $rc_product_obj );

	if ( is_array( $attribute_data ) && ! empty( $attribute_data ) ) {

		$display_title .= '<div class="wcf-display-attributes">';
		foreach ( $attribute_data as $att_slug => $att_data ) {

			$att_value = $att_data['value'];

			if ( empty( $att_value ) ) {
				$att_value = '<a class="wcf-select-variation-attribute wcf-invalid-variation" href="#"><span>' . __( 'Select', 'cartflows-pro' ) . '</span></a>';
			}

			$display_title .= '<span class="wcf-att-inner">';
			$display_title .= $att_data['label'] . ': ' . $att_value;
			$display_title .= '<span class="wcf-att-sep">,</span>';
			$display_title .= '</span>';
		}
		$display_title .= '</div>';
	}
}

$to_replace = array(
	'{{product_name}}',
	'{{quantity}}',
);

$with_replace = array(
	'<span class="wcf-display-title">' . $actual_product_name . '</span>',
	'<span class="wcf-display-title-quantity"><span class="dashicons dashicons-no-alt"></span><span class="wcf-display-quantity">' . $data['quantity'] . '</span></span>',
);

echo str_replace( $to_replace, $with_replace, $display_title );
?>
</div>

