<?php
/**
 * Frontend view
 *
 * @package cartflows-pro
 */

?>
<div class="cartflows-pro-bb__offer-product-price">
	<?php
		echo do_shortcode( '[cartflows_offer_product_price]' );
	?>
</div>
