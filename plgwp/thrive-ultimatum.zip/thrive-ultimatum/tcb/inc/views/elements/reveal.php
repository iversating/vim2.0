<?php
/**
 * Created by PhpStorm.
 * User: Ovidiu
 * Date: 4/12/2017
 * Time: 2:22 PM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>

<div class="thrv_wrapper thrv_content_reveal tve-elem-default-pad" data-after="5" data-redirect-url="">
	<div class="tve_reveal_container tcb-parent-placeholder-empty"><div class="tcb-replaceable-placeholder"><?php echo __( 'Click to add text or drag and drop element from right hand panel', 'thrive-cb' ); ?></div></div>
</div>
