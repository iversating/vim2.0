<div class="control-grid full-width">
	<label for="a-soundcloud-url">URL</label>
	<input type="text" data-setting="url" class="change audio-url tve_provider_url" data-fn="changeInput" id="a-soundcloud-url" placeholder="e.g. https://soundcloud.com/djmartindus/dancehall-party-march-2019">
</div>
<div class="url-validate inline-message"></div>
