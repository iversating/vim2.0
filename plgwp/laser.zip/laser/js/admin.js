/**
 * Laser
 * Page Loading Progress Bar.
 * Exclusively on https://1.envato.market/laser
 *
 * @encoding        UTF-8
 * @version         1.1.0
 * @copyright       (C) 2018 - 2020 Merkulove ( https://merkulov.design/ ). All rights reserved.
 * @license         Envato License https://1.envato.market/KYbje
 * @contributors    Alexander Khmelnitskiy (info@alexander.khmelnitskiy.ua), Dmitry Merkulov (dmitry@merkulov.design)
 * @support         help@merkulov.design
 **/

( function ( $ ) {

    "use strict";

    /** Document Ready. */
    $( document ).ready( function () {

        /** Show hide the Gradient color-picer depends to the Style changes */

        let mdpStyleId = '#mdp_laser_general_settings_style';
        let mdpStyleTarget = '#mdp_laser_general_settings_gradient';

        // Initial
        if ( $( mdpStyleId ).val() === 'gradient' ) {
            $( mdpStyleTarget ).closest( 'tr' ).show();
        } else {
            $( mdpStyleTarget ).closest( 'tr' ).hide();
        }

        // On style changes
        $( mdpStyleId ).on( 'change', function() {

            if ( $( this ).val() === 'gradient' ) {
                $( mdpStyleTarget ).closest( 'tr' ).fadeIn();
            } else {
                $( mdpStyleTarget ).closest( 'tr' ).fadeOut();
            }

        } );

        /** Move preview after tab heading on the General Tab */
        const $previewWrap = document.createElement( 'div' );

        if( document.querySelector( '.mdp-tab-name-general' ) !== null ) {

            $previewWrap.classList.add( 'mdp-preview' );
            $previewWrap.innerHTML = '<div id="mdp-laser-wrap">' +
                '<div id="mdp-laser-bar"></div></div>' +
                '<div class="mdc-text-field-helper-line"><div class="mdc-text-field-helper-text mdc-text-field-helper-text--persistent">Change some settings to see how the progress bar will look</div></div>';
            $( '.mdp-tab-name-general h3' ).after( $previewWrap );

        }

        /** Live preview */

        setInterval( function () {

            let $mdpLaserWrap = $( $previewWrap ).children( '#mdp-laser-wrap' );
            let $mdpLaserBar = $( $mdpLaserWrap ).children( '#mdp-laser-bar' );
            let $color = $( '#mdp_laser_general_settings_color' );
            let $gradient = $( '#mdp_laser_general_settings_gradient' );
            let $bgColor = $( '#mdp_laser_general_settings_bg_color' );
            let $height = $( '#mdp_laser_general_settings_height-input' );
            let $shadow = $( '#mdp_laser_general_settings_shadow' );
            let $reverse = $( '#mdp_laser_general_settings_reverse' );
            let $easing = $( '#mdp_laser_general_settings_easing' );
            let $style = $( '#mdp_laser_general_settings_style' );

            /** Wrap styles */
            $mdpLaserWrap.css( 'height', $height.val() + "px" );
            $mdpLaserWrap.css( 'background', $bgColor.val() );

            /** Bar styles */
            $mdpLaserBar.css( 'height', $height.val() + "px" );
            $mdpLaserBar.css( 'background', $color.val() );
            $mdpLaserBar.css( 'animation-timing-function', $easing.val() );

            // Shadow
            if ( $shadow.closest( '.mdc-switch' ).hasClass( 'mdc-switch--checked' ) ) {
                $mdpLaserBar.css( 'box-shadow', '0 0 5px ' + $color.val() + ', 0 0 10px ' + $color.val() );
            } else {
                $mdpLaserBar.css( 'box-shadow', 'none' );
            }

            // Reverse
            if ( $reverse.closest( '.mdc-switch' ).hasClass( 'mdc-switch--checked' ) ) {
                $mdpLaserBar.addClass( 'mdp-laser-reverse' );
            } else {
                $mdpLaserBar.removeClass( 'mdp-laser-reverse' );
            }

            //Gradient
            if ( "gradient" === $style.val() ) {
                $mdpLaserBar.css( 'background', 'linear-gradient(to left, ' + $color.val() + ', ' + $gradient.val() + ')' );
            }

            // Pulse
            if ( "pulse" === $style.val() ) {
                $mdpLaserBar.addClass( 'mdp-laser-pulse' );
            } else {
                $mdpLaserBar.removeClass( 'mdp-laser-pulse' );
            }

        }, 100 );

    } );

} ( jQuery ) );