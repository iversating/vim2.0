<?php
/**
 * Laser
 * Page Loading Progress Bar.
 * Exclusively on https://1.envato.market/laser
 *
 * @encoding        UTF-8
 * @version         1.1.0
 * @copyright       (C) 2018 - 2020 Merkulove ( https://merkulov.design/ ). All rights reserved.
 * @license         Envato License https://1.envato.market/KYbje
 * @contributors    Alexander Khmelnitskiy (info@alexander.khmelnitskiy.ua), Dmitry Merkulov (dmitry@merkulov.design)
 * @support         help@merkulov.design
 **/

namespace Merkulove\Laser;

use Merkulove\Laser\Unity\Plugin;
use Merkulove\Laser\Unity\Settings;

/** Exit if accessed directly. */
if ( ! defined( 'ABSPATH' ) ) {
	header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
	exit;
}

/**
 * SINGLETON: Settings class used to modify default plugin settings.
 * @since 1.0.0
 **/
final class Config {

	/**
	 * The one true Settings.
	 *
     * @since 1.0.0
     * @access private
	 * @var Config
	 **/
	private static $instance;

    /**
     * Prepare plugin settings by modifying the default one.
     *
     * @since 1.0.0
     * @access public
     *
     * @return void
     **/
    public function prepare_settings() {

        /** Get default plugin settings. */
        $tabs = Plugin::get_tabs();

        /** Short hand access to plugin settings. */
        $options = Settings::get_instance()->options;

        // Change General tab label.
        // $tabs['general']['label'] = esc_html__( 'Ave General', 'laser' );
        // $tabs['general']['title'] = esc_html__( 'Awesome General', 'laser' );

        // Remove 'Delete plugin, settings and data' option from Uninstall tab.
        // unset( $tabs['uninstall']['fields']['delete_plugin']['options']['plugin+settings+data'] );

        $tabs['general']['fields']['position'] = [
            'type'              => 'select',
            'label'             => esc_html__( 'Position:', 'laser' ),
            'show_label'        => true,
            'placeholder'       => esc_html__( 'Position', 'laser' ),
            'description'       => esc_html__( 'Choose where to place the loader bar', 'laser' ),
            'show_description'  => true,
            'default'           => 'top',
            'options'           => [
                'top'       => esc_html__( 'Top', 'laser' ),
                'bottom'    => esc_html__( 'Bottom', 'laser' ),
                'left'      => esc_html__( 'Left', 'laser' ),
                'right'     => esc_html__( 'Right', 'laser' ),
            ]
        ];

        $tabs['general']['fields']['style'] = [
            'type'              => 'select',
            'label'             => esc_html__( 'Style:', 'laser' ),
            'show_label'        => true,
            'placeholder'       => esc_html__( 'Style', 'laser' ),
            'description'       => esc_html__( 'Choose bar style', 'laser' ),
            'show_description'  => true,
            'default'           => 'gradient',
            'options'           => [
                'mono'      => esc_html__( 'Monochrome', 'laser' ),
                'gradient'  => esc_html__( 'Gradient', 'laser' ),
                'pulse'     => esc_html__( 'Pulse', 'laser' )
            ]
        ];

        $tabs['general']['fields']['color'] = [
            'type'              => 'colorpicker',
            'label'             => esc_html__( 'Color:', 'laser' ),
            'show_label'        => true,
            'placeholder'       => esc_html__( 'Color', 'laser' ),
            'description'       => esc_html__( 'Select color for laser bar', 'laser' ),
            'show_description'  => true,
            'default'           => '#f13d00',
            'attr'              => [
                'readonly'      => 'readonly',
            ]
        ];

        $tabs['general']['fields']['gradient'] = [
            'type'              => 'colorpicker',
            'label'             => esc_html__( 'Gradient Color:', 'laser' ),
            'show_label'        => true,
            'placeholder'       => esc_html__( 'Gradient Color', 'laser' ),
            'description'       => esc_html__( 'Select gradient for the progress bar', 'laser' ),
            'show_description'  => true,
            'default'           => '#ff0004',
            'attr'              => [
                'readonly'      => 'readonly',
            ]
        ];

        $tabs['general']['fields']['bg_color'] = [
            'type'              => 'colorpicker',
            'label'             => esc_html__( 'Background Color:', 'laser' ),
            'show_label'        => true,
            'placeholder'       => esc_html__( 'Background Color', 'laser' ),
            'description'       => esc_html__( 'Select the background color', 'laser' ),
            'show_description'  => true,
            'default'           => 'rgba( 204, 204, 204, .5 )',
            'attr'              => [
                'readonly'      => 'readonly',
            ]
        ];

        $key = 'height';
        $default = 5;
        $tabs['general']['fields'][$key] = [
            'type'              => 'slider',
            'label'             => esc_html__( 'Height', 'laser' ),
            'show_label'        => true,
            'description'       => esc_html__( 'Current height:', 'laser' ) .
                ' <strong>' .
                esc_html( ( isset( $options[$key] ) ) ? $options[$key] : $default ) .
                '</strong>' .
                esc_html__( ' px', 'laser' ),
            'show_description'  => true,
            'min'               => 1,
            'max'               => 50,
            'step'              => 1,
            'default'           => $default,
            'discrete'          => true,
        ];

        $key = 'speed';
        $default = 200;
        $tabs['general']['fields'][$key] = [
            'type'              => 'slider',
            'label'             => esc_html__( 'Speed:', 'laser' ),
            'show_label'        => true,
            'description'       => esc_html__( 'Current speed:', 'laser' ) .
                ' <strong>' .
                esc_html( ( isset( $options[$key] ) ) ? $options[$key] : $default ) .
                '</strong>' .
                esc_html__( ' ms', 'laser' ),
            'show_description'  => true,
            'min'               => 100,
            'max'               => 3000,
            'step'              => 100,
            'default'           => $default,
            'discrete'          => true,
        ];

        $tabs['general']['fields']['easing'] = [
            'type'              => 'select',
            'label'             => esc_html__( 'Easing:', 'laser' ),
            'show_label'        => true,
            'placeholder'       => esc_html__( 'Easing', 'laser' ),
            'description'       => esc_html__( 'Choose easing for animation', 'laser' ),
            'show_description'  => true,
            'default'           => 'linear',
            'options'           => [
                'linear'        => esc_html__( 'Linear', 'laser' ),
                'ease'          => esc_html__( 'Ease', 'laser' ),
                'ease-in'       => esc_html__( 'Ease-In', 'laser' ),
                'ease-out'      => esc_html__( 'Ease-Out', 'laser' ),
                'ease-in-out'   => esc_html__( 'Ease-In-Out', 'laser' )
            ]
        ];

        $tabs['general']['fields']['shadow'] = [
            'type'              => 'switcher',
            'label'             => esc_html__( 'Shadow:', 'laser' ),
            'show_label'        => true,
            'placeholder'       => esc_html__( 'Box-shadow', 'laser' ),
            'description'       => esc_html__( 'Displays a shadow for a progress bar', 'laser' ),
            'show_description'  => true,
            'default'           => 'on',
        ];

        $tabs['general']['fields']['reverse'] = [
            'type'              => 'switcher',
            'label'             => esc_html__( 'Reverse Direction:', 'laser' ),
            'show_label'        => true,
            'placeholder'       => esc_html__( 'Opposite Direction', 'laser' ),
            'description'       => esc_html__( 'Starts the progress of the bar in the opposite direction', 'laser' ),
            'show_description'  => true,
            'default'           => 'off',
        ];

        $tabs['general']['fields']['trickle'] = [
            'type'              => 'switcher',
            'label'             => esc_html__( 'Trickle:', 'laser' ),
            'show_label'        => true,
            'placeholder'       => esc_html__( 'Trickle', 'laser' ),
            'description'       => esc_html__( 'The automatic incrementing to show that something happening', 'laser' ),
            'show_description'  => true,
            'default'           => 'on',
        ];

        /** Set updated tabs. */
        Plugin::set_tabs( $tabs );

        /** Refresh settings. */
        Settings::get_instance()->get_options();

    }

	/**
	 * Main Settings Instance.
	 * Insures that only one instance of Settings exists in memory at any one time.
	 *
	 * @static
     * @since 1.0.0
     * @access public
     *
	 * @return Config
	 **/
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof self ) ) {

			self::$instance = new self;

		}

		return self::$instance;

	}

}
