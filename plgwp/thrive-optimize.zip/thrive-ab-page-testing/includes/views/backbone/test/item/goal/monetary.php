<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden
}
?>

<span class="click" data-fn="view_conversion_goal_details">
	<?php tcb_icon( 'monetary-2' ) ?><?php echo __( 'Revenue Conversion Goal', 'thrive-ab-page-testing' ); ?>
</span>
