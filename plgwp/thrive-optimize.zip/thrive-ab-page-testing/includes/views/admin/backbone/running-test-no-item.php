<?php
/**
 * Created by PhpStorm.
 * User: Ovidiu
 * Date: 1/19/2018
 * Time: 10:17 AM
 */
?>
<tr>
	<td style="text-align: center;" colspan="7"><?php echo __( 'You have no running tests, yet.', 'thrive-ab-page-testing' ); ?></td>
</tr>
