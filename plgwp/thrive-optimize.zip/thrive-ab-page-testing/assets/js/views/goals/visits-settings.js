var settings = require( './settings' );

module.exports = settings.extend( {

	template: TVE_Dash.tpl( 'goals/visits-settings' )
} );