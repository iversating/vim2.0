=== FunnelKit Automations Pro ===
Contributors: WooFunnels
Tested up to: 6.0.3
Stable tag: 2.3.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html


== Change log ==

= 2.3.0 (Oct 18, 2022) =
* New: Re-branding related changes from WooFunnels to FunnelKit and Autonami to FunnelKit Automations.
* Added: Elastic Email: Email Bounce handling option added. (#1365)
* Improved: Disallow click tracking from the unsubscribe links. (#1355)
* Improved: Mailgun bounce handling code improved, considering failed, complaints events. (#1340)
* Improved: Thrive leads older versions are throwing a PHP error, code improved. (#1342)
* Improved: Automation: Link trigger clicked event is not working when link trigger doesn't have any actions, fixed. (#1344)
* Improved: Single Contact screen, longer tag or list overlap issue, CSS improvement. (->#1896)
* Improved: Contact filter: User role is not code improved. (#1348)
* Improved: Automation Event: WC Subscription created event wasn't triggering when a subscription is created manually. (#1351)
* Improved: Automation Event: WPForms form submit event, first name and last name field type value wasn't saving, fixed. (#1360)
* Improved: Automation Merge Tags: Contact Total Spend & WC Subscription Total merge tag now has 3 options, display raw output, formatted output & currency formatted output. (#1362)
* Fixed: Contacts: Import button wasn't working when there were no contacts, fixed. (->#1871)
* Fixed: Broadcast: Engages filter, In the period option preview was wrong, corrected. (#1898)
* Fixed: Contact fields were not updating with field types checkout and radio. Fixed. (#1329)
* Fixed: WooCommerce dependency handling improved. (#1330)
* Fixed: Broadcast: The Listing screen 'created at' column was showing the wrong value. (#1346)
* Dev: Broadcast: Filter hook to disallow business name, and unsubscribe link in the broadcast email. (#1900)
* Dev: Action hook 'bwfan_contact_email_changed' added after contact email changed. (#1324)

= 2.2.0 (Sep 23, 2022) =
* Compatible with PHP 8.0
* Added: New feature: Allow adding any columns on the contact listing page and sorting options. (#1083)
* Added: New Event: 'User role updated'. (#1078)
* Added: 'creation date' column is added on all the listing pages. (#1178)
* Added: Unschedule a broadcast, quick action added. (#1193)
* Fixed: 'Delete Coupon' action code improved to handle coupons with dynamic tags. (#1182)
* Improved: Showing decoded value in the subject on the Contact > Email page. (#1184)
* Improved: Automation triggering code optimized during 'Bulk Action'. (#1188)
* Improved: 3rd party compatibilities related to merge tags, code improved. (#1195, #1205)
* Improved: Hardened email auto open & click actions. Default time set to 5 secs. (#1213)
* Improved: Automation: Events & Actions default value is set where it was missing. (#1215, #1296)
* Improved: Contact Exports: Code improved. (#1234)
* Improved: WC Subscription related events: Email is set at the top level to help further automation flow. (#1242)
* Improved: Automation 'Debug' action, doing force logging. (#1246)
* Improved: Automation > Contacts. Bulk actions code improved. (#1248)
* Improved: Delete contact code improved, done checking for active integration related tables. (#1255)
* Improved: WC 'Before card expiry' event code is improved. (#1268)
* Improved: Added handling in forms submit related events rules, where field value contains a comma. (#1270)
* Improved: Automation webhook received event: Code optimized when nested data is passed in the webhook. (#1318)
* Fixed: Contacts export - Code added for 'Last order days' and 'AOV' columns. (#1200)
* Fixed: 'Subscription status change' event - Validation code added for the event. (#1207)
* Fixed: UTM parameters case sensitive issue fixed. (#1211)
* Fixed: Shortcodes are not executable in automation emails. Fixed. (#1218)
* Fixed: Order items table merge tag: Download URL was not coming, fixed. (#1235)
* Fixed: Contact: Bulk action filters query improved. (#1275)
* Fixed: Legacy v1 Automation: Contact tags rule code optimized. (#1279)
* Fixed: Thrive Form submit event: All forms are not coming for selection, code improved. (#1305)
* Fixed: Contact fields dynamic tags are not decoding if present inside a tag, fixed. (#1308)
* Fixed: Divi form submit event: Was not working for global forms, fixed. (#1313)
* Dev: Filter hook added before redirecting a link trigger. (#1261)

= 2.1.3 (Jul 15, 2022) =
* Added: Contact filters and automation rules, new advanced operators added like 'is blank', 'is not blank', 'starts with' etc. (#1126)
* Improved: Contacts export: when a server has a file permissions issue, displaying the error in the app and other code improvements. (->#1666, #1144)
* Fixed: Date type fields updating current date if the passed value is blank, fixed. (#1159)
* Fixed: 'From Name' & 'From Email' overriding feature wasn't working for test emails, fixed. (#1167)
* Fixed: Automation Next-gen: 'Custom winback' event settings were not passing to the event hence using the default settings, fixed. (#1172)
* Fixed: Automation Next-gen: Elementor form submits event wasn't considering global widgets, sections & posts, fixed. (#1170)
* Fixed: Link trigger wasn't saving for a particular action, fixed. (->#1680)
* Fixed: Automation: Gravity form 'Form field' rule code improved. (#1141)
* Fixed: Automation: Send Test SMS was not working, fixed. (->#1641)
* Fixed: Broadcast: Edit button in quick actions wasn't working for draft broadcasts, fixed. (->#1654)

= 2.1.2 (Jul 04, 2022) =
* Improved: Bulk actions file logging code handling in case file writing permissions are not there. (#1122)
* Improved: Engagement table column missing sometimes, more handling done. (#1124)
* Fixed: Subscription item merge tag format - `product name with quantity` wasn't working, fixed. (#1120)

= 2.1.1 (Jun 30, 2022) =
* Improved: Couple of performance enhancements optimised few duplicate queries. (#1110)
* Improved: Bulk Actions execution logic improved. (#1099)
* Fixed: Audience rule was not working for older automation, fixed. (#1101)
* Fixed: Some custom fields are not coming in contact field rules, fixed. (#1108)

= 2.1.0 (Jun 27, 2022) =
* New: Compatible with Autonami next-gen automation builder. (Autonami v2.1.0 or above)
* New: Create automation easily from built-in 32 recipes.
* New: 6 Step types: Action, Delay, Condition, Goal, Jump & Exit.
* New: Contact journey: View contact visually in the automation.
* New: In-line analytics for Email and SMS action steps.
* New: Bulk Actions a new feature introduced. Now filter contacts and perform from 9 available actions in bulk on contacts.
* Improved: Tons of performance improvements.


= 2.0.10 (May 26, 2022) =
* Added: Import contacts via CSV: Added 'creation date' as a column to create contacts with a given date. (#1039)
* Improved: Import contacts via CSV: Added more data in the error log file for better understanding. (#1033)
* Improved: Showing Error message on Broadcast Engagement Timeline (->#1535)
* Fixed: Automation rule: 'Is WordPress user' has some issues, fixed. (#1013)
* Fixed: During multiple lists/ tags assigned or unassigned, automation was not running multiple times, fixed. (#1019)
* Fixed: Forms: Elementor popup form via global widget wasn't working correctly, fixed. (#1027)
* Fixed: Forms: Auto-confirm contact setting wasn't working when contact timezone is different than store local timezone, fixed. (#1030)

= 2.0.9 (Apr 23, 2022) =
* Critical: On some servers, WordFence flag the save email body request, fixed. (#1002)
* Added: Create contact action, phone optional field added. Status field code optimized. (#982)
* Improved: Drag and Drop editor, image CSS improved. Earlier high width images overlapped. (#1007)
* Improved: Forms: Thrive form, added handling to fetch entry details from a custom field. (#1004)
* Improved: Forms: Fluent form, showing attribute name first then label then admin label of fields inside admin. (#1009)
* Fixed: Broadcast: Send test email was not working, fixed. (-> #1511)
* Fixed: Allowed mailto links in the email. (#978)
* Fixed: Forms: Gravity form checkbox field mapping has issues, resolved. (#980)
* Fixed: Forms: Add tags on confirmation field value wasn't saving, fixed. (#995)
* Fixed: Displaying errors messages during contact CSV import. (#984)

= 2.0.8 (Apr 10, 2022) =
* This release lays out foundation for upcoming Autonami Next Generation Automation Builder.
* Added: Conditions: Added 'contains', 'does not contains', 'starts with' & 'ends with' operators in all form related events, form field rule and contact related rules. (#917)
* Added: Condition: Advanced shipping rate rule added in order related events. (#939)
* Added: UTM Lead Tracker data merge tag added in order related events. (#931)
* Added: Multi currency handling done during creating conversions. (#865)
* Improved: Engaged and Unengaged filter query improved. (#943, #947)
* Improved: Condition: WooCommerce total order count rule wasn't working when no order is purchased. (#933)
* Improved: Saving email template sometimes caused 404 error on few occasions of a server, fixed. (-> #1448, -> #1490)
* Improved: WP is user rule code improved. (#925)
* Improved: Export file names more dynamic now. (#920)
* Improved: Updating contact data via API throwing email already exists error, handling done for WP Fusion plugin. (#891)
* Improved: PHP 8.1 related improvements. (#882)
* Improved: Contacts importer UI improvements. (-> #1370)
* Fixed: Total revenue not displaying in the broadcast analytics when A/B mode active. (#937)
* Fixed: Send Test SMS not decoding the merge tags, fixed. (-> #1249)
* Fixed: Contact DOB merge tag code improved. (#919)
* Dev: Added filter hook 'bwfan_skip_broadcast_tracking_url' to disable open click tracking in broadcast. (#896)
* Dev: Added filter hook 'bwfan_event_wcs_before_end_statuses' to allow any WooCommerce status on 'Subscription before end' event. (#874)

= 2.0.7 (Nov 02, 2021) =
* Added: Deep integration done with Wishlist Member plugin. Filters, Import/ Export Contacts/ Events, Actions. (#392)
* Added: New Action: Change Contact Status added. (#704)
* Added: Order related Events: Added Handl UTM Grabber plugin merge tag. (#695)
* Improved: Event: Thrive form submission: New handle found for conversion forms, added. (#720)
* Improved: Forms: Allows hidden fields for selection in Fluent Form. (#721)
* Improved: Link Trigger: Creating new hash encrypted key on cloning. (#710)
* Improved: Templates listing and Applying template code optimized. (#698, #723)
* Fixed: Event: Thrive form submission: Blank fields are showing in some cases, scenario handled. (#701)
* Fixed: Filters: User role filter wasn't working, fixed. (#729)


= 2.0.6 (Oct 07, 2021) =
* Fixed: One query was taking higher time, optimized. (#690)


= 2.0.5 (Oct 06, 2021) =
* Compatible upto Autonami 2.0.7
* Added: Link Triggers, new feature added.
* Added: Forms: Thrive Leads integration added. (#636)
* Added: New Event: Contact Unsubscribes added. (#652 -> #1036)
* Added: Filters: Engaged and Un-engaged filters added. (#675)
* Added: Automations Rule: Check if contact is in the audience, added. (#595, #610)
* Added: Automation Merge Tag: Contact total spent and contact order count merge tags added under contact profile in all events. (#641)
* Added: Automation Merge Tag: {{new_user_password}} one-time use only merge tag added that saved the user password and allows to send once. (#633)
* Added: Contacts listing screen: allow sorting by the first name. (#989)
* Added: Compatibility added with 'Advance shipment tracking pro' plugin by Zorem. (#571)
* Improved: Forms: File upload field value wasn't supported with WP Forms integration, supported now. (#580)
* Improved: Delete the conversion on WC order deletion. (#602)
* Improved: Automation Event: Webhook received code and UI improvements. (#615)
* Improved: Automation Event: Outgoing Webhook, HTTP Request: UI improved, allow adding contact basic details quickly. (#625)
* Improved: Filters: New operators 'contains', 'does not contains', 'start with' and 'end with' added in contact field filter. (#635)
* Improved: Contacts Import: Added failed entry logs, available for download after import. (#654)
* Improved: Some improvements in tables and code to speed up the performance. (#655)
* Improved: Automation Rules: Textual improvement in rules for better understanding. (#677)
* Improved: Improvement in Analytics screens when viewing on mobile devices. (#1010)
* Fixed: Purge contact reference data when contact is deleted. (#573)
* Fixed: 'Broadcast Click' filter wasn't working, fixed. (#574)
* Fixed: Compatibility updated with 'WooCommerce membership' oldest version, PHP error was coming, resolved. (#590)
* Fixed: Tracking links and conversion recording issues with SMS and Whatsapp messages, fixed. (#598)
* Fixed: Automation Event: Contact subscribes event wasn't running, fixed. (#606 -> #980)
* Fixed: Automation Event: Tag Assigned and List Assigned aren't working properly in case multiple tags/ lists are assigned. (#628)


= 2.0.4 (Aug 23, 2021) =
* Added: Sendinblue Bounce option added. (#542)
* Added: Users and Broadcast Engagement filters added. (Is user, User Role, Broadcast Send, Open and Click). Now segment contacts using broadcast enhanced filters. (#553)
* Improved: Contact update field API call improvement.
* Improved: Create user & Update fields action UI improved. (#555)
* Fixed: Contacts listing: Datetime error in a rare case, handling done.


= 2.0.3 (Aug 18, 2021) =
* Compatible upto Autonami 2.0.5
* Added: Contact filters: New filter 'Contact User Role' added. (#503)
* Added: A feature to send user password (one time) from the `create user` action to the user. (#514)
* Added: Action - Create contact, status dropdown field added. (#457)
* Added: Support for polylang for forms, now verifying the language. (#520)
* Added: Autonami Contact rules and merge tags in all the events. (#406)
* Improved: Email links as text, UTM arguments appending on the the hyper link only. (#420)
* Improved: Contacts - WC orders import, disallow importing of child orders, supported by some plugins. (#431)
* Improved: Forms now support Radio/ Checkboxes/ Dropdown fields while syncing with Autonami fields. (#442)
* Improved: Autonami contacts, code is improved, execution speed increased from an earlier time. (#450)
* Improved: Email tracking code improved. (#506)
* Improved: Contact import process improved. ($523)
* Improved: Contact export code improved. An issue was found on some servers. (#522)
* Improved: Form submission events - Fields checking code improved. (#531)
* Improved: Broadcasts scheduling now showing the time as per the store set time.
* Dev: Improved: Autonami incoming webhooks now supports nested array object data on a single key. (#425)
* Fixed: Issue occurred while adding multiple exports. (#408)
* Fixed: Forms - Funnel Builder Optin form, phone value is not coming with the country code when available, fixed. (#413)
* Fixed: Single contact - WC paid orders listing is failing in case order was deleted, fixed. (#466)
* Fixed: Event - Subscription card expiry event was running on the same contact again, another day, fixed. (#444)
* Fixed: Emails - Links with query arguments are breaking for open and click tracking, fixed. (#446)
* Fixed: Added handling in case undefined is the target link. (#500)
* Fixed: Forms - Thrive integration fetching of form fields causing issues with the latest version, fixed. (#528)


= 2.0.2 (Jul 05, 2021) =
* Added: WooCommerce Wishlist integration added. 3 events are added. (#335)
* Added: Weglot integration added. Allowing sending emails based on the buyers language. (#362)
* Added: WooCommerce Subscription: Payment count rule added. (#330)
* Added: Templates cloning feature added. (#389)
* Improved: Allowing WC Membership actions to execute on Autonami CRM events, like on Add a Tag or List. (#340)
* Improved: Auto-sync WP user profile known fields with Autonami Contact. (#341)
* Improved: Contacts import via CSV. Code is improved to parse the country by name as well. (#361)
* Improved: Allow saving blank values for contact custom fields. (#363)
* Improved: Tags and Lists fetching calls improved. (#347)
* Improved: WC Subscription failed event: validating the subscription status before executing the tasks. (#377)
* Improved: Email pre-header text code handling, hide on all email clients. (#396)
* Improved: Reports: Email: Some mysql calls improvements. (#359)
* Fixed: Forms: Email notification: Open & Click tracking wasn't working, fixed. (#384)
* Fixed: Contact custom field rule wasn't working, fixed. (#401)
* Fixed: HTTP Request action: In each scenario sending the request via GET method, fixed. (#332)
* Fixed: Fluent Form: An issue found, unable to fetch form fields in a scenario when multiple columns in a form. (#345)
* Fixed: Postmark bounce feature, found an issue, resolved. (#349)
* Dev: Added a filter hook to disable the click tracking in Automation. (#394)


= 2.0.1 (Jun 11, 2021) =
* Fixed: Some tables were not creating on some server enviroments, fixed. (fix/325)


= 2.0.0 (Jun 10, 2021) =
* Compatible with Autonami 2.0:
- > Rich contact profiles
- > Advanced import and export of contacts
- > Deep Integration with WooCommerce
- > Advanced segmenting to send targeted messages
- > Broadcast campaigns with A/B testing and smart sending
- > SMS Broadcasts via Twilio/ Bulkgate
- > Smart Automations
- > Drag and Drop email builder
- > Smart Analytics that uncover Email tracking, Engagement Metrics, ROI Analysis per campaign
- > Capture leads from your favourite form builder
- > Create WorkFlows and let different plugins interact with each other
- > Connect with your favourite services like Twilio, Slack and other services
* Compatible with PHP 8.0
* Fixed: Elementor and Fluent Form submission events some improvements.


= 1.3.0 (2021-01-12) =

* Added: New Rule: Customer Marketing status on order related events. (#224)
* Added: New Event: WooFunnels Optin form submission. (#238)
* Added: New Event: Learndash - User removed from a group. (#252)
* Added: New Event: WC Subscription note added. (#275)
* Added: New Merge tag: Subscription billing company. (#275)
* Improved: Thrive Leads: Form submit event, now includes lead groups. (#257)
* Fixed: Winback event: Validating user last purchase at the time of executing actions. (#251)
* Fixed: Elementor form submit event: A PHP notice was occurring, resolved. (#259)
* Fixed: HTTP Post action: Send test data not decoding the cart items merge tag, fixed. (#263)
* Fixed: Winback event: When a contact list is huge, sometimes based on the server won't be able to execute all the actions. Fixed. (#272)
* Fixed: Update user role action was not updating the user role, found issues with 3rd party plugin, fixed. (#281)


= 1.2.2 (2020-09-25) =

* Added: New Merge tag '{{bwf_contact_id}}' added. Will return the unique contact id of every user. Usable in case of creating coupon with dynamic value. (#241)
* Improved: Update User Role: Action now supports role assignment as well. (#243)
* Improved: Learndash: Lesson selection rule, now showing course name aside of lesson name for better understanding. (#234)
* Fixed: Fluent Forms: After form submission, it is not redirecting to the correct page, fixed. (#230)


= 1.2.1 (2020-08-26) =

* Fixed: PHP error in case WooCommerce is not active. (#220)
* Fixed: Contact has 'Active Subscription' rule, wasn't working with 'Win-back campaign' event, fixed. (#225)


= 1.2.0 (2020-08-23) =

* Compatible with WordPress 5.5
* Compatible with WooCommerce 4.3 & 4.4
* Added: Learndash integration added. Events like a user is enrolled, user completed a course or lesson or topic. Actions like enroll a user in a course, add a user to a group etc. (#153)
* Added: New event: Webhook received. Receive any data via HTTP Post and perform actions in your site. (#141)
* Added: New Action: End Automation. Stop the automation execution i.e. deletes the schedule tasks of particular automation based on contact from any automation. (#117)
* Added: Ninja Form integration added. Now execute actions after a Ninja form is submitted. (#153)
* Added: Fluent Form integration added. Now execute actions after a Fluent form is submitted. (#172)
* Added: Caldera Form integration added. Now execute actions after a Caldera form is submitted. (#179)
* Added: New merge tag: Order again URL. Ability to add all order items to the cart with a single URL. (#164)
* Added: New Rule: Subscription Failed Attempt. (#168)
* Added: New Rule: Customer Purchased Products Category added. (#150)
* Added: New rule: BWF Contact added on Gravity form, Ninja Form, Elementor Form & Thrive Leads form submission events. (#148)
* Added: New event: Order Status Pending. Run, on orders which are left in pending state and are 10 mins older. (#146)
* Added: Compatibility with 'WooCommerce Sequential Order Numbers' plugin. Merge tag {{wc_sequential_order_number}} with output (Order Number & Order number Formatted) on order related event. (#138)
* Added: Compatibility with 'WooCommerce Advanced Shipment Tracking' plugin. Merge tag {{wc_advanced_shipment_tracking}} with output (tracking_number, tracking_provider, tracking_link & date_shipped) on order related event. (#186)
* Added: Compatibility with 'Handl UTM Grabber' plugin. Merge tag {{hand_utm_grabber_data}} with multiple outputs (like utm_campaign, utm_source etc) on cart abandonment event. (#211)
* Improved: Elementor forms have multiple cases like popup form, widget form etc. All are handled. (#188, #195)
* Improved: 'Send data to Zapier' & 'HTTP Post' actions, UI improved. (#199)
* Fixed: 'Send data to Zapier' action, sometimes data contain extra slashes, fixed. (#137)
* Fixed: UpStroke offer accepted event: item id and name merge tags issue fixed. Item SKU, new merge tag added. (#184)


= 1.1.0 (2020-03-25) =

* Added: ThriveLeads integration added. Now execute actions after a thrive leads form submission. (#87)
* Added: AffiliateWP integration: New Event: Affiliate status change added. (#82)
* Added: AffiliateWP integration: New Rule: Affiliate rate added. (#82)
* Added: AffiliateWP integration: New Merge Tags: {{affwp_affiliate_rate}} and {{affwp_affiliate_status}} added. (#82)
* Added: New action: Update WordPress user role. (#92)
* Added: Compatibility with 'WooCommerce Shipment Tracking' plugin. Merge tag {{wc_shipment_tracking}} with output (tracking_number, formatted_tracking_provider, formatted_tracking_link & date_shipped) on order related event. (#95)
* Added: Compatibility with 'Jetpack' plugin shipment feature. Merge tag {{wc_jetpack_shipment}} with output (carrier_name_full, package_name, tracking_number & tracking_link) on order related event. (#105)
* Added: New action: Cancel WC order associated subscription for order status change event only. (#127)
* Added: Autonami notice to install a plugin if Autonami is not installed or active. (#133)
* Improved: HTTP Post action, showing correct response code after execution. (#104)
* Improved: Create user action, now have the first name and last name optional fields as well. (#111)
* Improved: WC Add order note action now have the option to choose between customer note and private note. (#107)
* Fixed: Compatibility to run without WooCommerce. (#80)


= 1.0.2 (2020-01-07) =

* No change


= 1.0.1 (2020-01-07) =

* Added: Affiliate first name merge tag added.
* Added: Zapier 'Send data' action: new option 'send test data' coded.
* Added: Customer winback campaign, new settings added; UI & logic improved.
* Added: New rules 'Order is a renewal for WC subscription' added.
* Added: Batch Processes: Delete option added for completed processes.
* Improved: Time sync events like 'customer winback', 'affiliate digest' etc. are now showing 'last run' date on the event UI so that store owner can see when it last ran.
* Improved: Action UI spacing, descriptions, overall UX improved.
* Improved: Custom callback action code improved.
* Improved: Delete scheduled tasks of winback campaign automation of an user after a new order is placed.
* Improved: WooCommerce subscription renewal event auto validating subscription status before executing tasks.
* Fixed: AeroCheckout page id rule wasn't working, fixed.


= 1.0.0 (2019-11-25) =

* Public Release