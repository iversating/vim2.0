<?php


class BWFAN_Model_Contact_Note extends BWFAN_Model {

	/**
	 * @param $contact_id
	 * @param int $offset
	 * @param int $limit
	 *
	 * @return array
	 */
	public static function get_contact_notes( $contact_id, $offset = 0, $limit = 0 ) {

		if ( empty( $offset ) && empty( $limit ) ) {
			$query = "Select * from {table_name} where cid='" . $contact_id . "'";
		} else {
			$query = "Select * from {table_name} where cid='" . $contact_id . "' LIMIT $offset,$limit";
		}

		$query_results = self::get_results( $query );

		return $query_results;
	}

	/**
	 * @param $contact_id
	 * @param $note
	 * @param $note_id
	 */
	public static function update_contact_note( $contact_id, $notes, $note_id ) {

		$data = $notes;

		$where = array(
			'id'  => $note_id,
			'cid' => $contact_id,
		);

		$update_notes = self::update( $data, $where );

		return $update_notes;

	}
}