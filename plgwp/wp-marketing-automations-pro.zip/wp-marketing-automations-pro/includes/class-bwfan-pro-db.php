<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Class BWFAN_Pro_DB
 *
 * @package Autonami
 */
class BWFAN_Pro_DB {
	private static $ins = null;
	protected $tables_created = false;
	protected $method_run = [];

	/**
	 * BWFAN_Pro_DB constructor.
	 */
	public function __construct() {
		global $wpdb;
		$wpdb->bwfan_broadcast               = $wpdb->prefix . 'bwfan_broadcast';
		$wpdb->bwfan_bulk_action             = $wpdb->prefix . 'bwfan_bulk_action';
		$wpdb->bwfan_contact_note            = $wpdb->prefix . 'bwfan_contact_note';
		$wpdb->bwfan_conversions             = $wpdb->prefix . 'bwfan_conversions';
		$wpdb->bwfan_engagement_tracking     = $wpdb->prefix . 'bwfan_engagement_tracking';
		$wpdb->bwfan_engagement_trackingmeta = $wpdb->prefix . 'bwfan_engagement_trackingmeta';
		$wpdb->bwfan_fields                  = $wpdb->prefix . 'bwfan_fields';
		$wpdb->bwfan_field_groups            = $wpdb->prefix . 'bwfan_field_groups';
		$wpdb->bwfan_form_feeds              = $wpdb->prefix . 'bwfan_form_feeds';
		$wpdb->bwfan_import_export           = $wpdb->prefix . 'bwfan_import_export';
		$wpdb->bwfan_link_triggers           = $wpdb->prefix . 'bwfan_link_triggers';
		$wpdb->bwfan_message                 = $wpdb->prefix . 'bwfan_message';
		$wpdb->bwfan_templates               = $wpdb->prefix . 'bwfan_templates';
		$wpdb->bwfan_terms                   = $wpdb->prefix . 'bwfan_terms';
		$wpdb->bwf_contact_fields            = $wpdb->prefix . 'bwf_contact_fields';
		$wpdb->bwf_contact_lms_fields        = $wpdb->prefix . 'bwf_contact_lms_fields';
		$wpdb->bwf_contact_wlm_fields        = $wpdb->prefix . 'bwf_contact_wlm_fields';

		add_action( 'plugins_loaded', array( $this, 'load_db_classes' ), 8 );
		add_action( 'admin_init', array( $this, 'db_update' ), 10 );
	}

	/**
	 * Get tables
	 *
	 * @return string[]
	 */
	public static function get_tables_name() {
		return [
			'bwfan_broadcast',
			'bwfan_bulk_action',
			'bwfan_contact_note',
			'bwfan_conversions',
			'bwfan_engagement_tracking',
			'bwfan_engagement_trackingmeta',
			'bwfan_fields',
			'bwfan_field_groups',
			'bwfan_form_feeds',
			'bwfan_import_export',
			'bwfan_link_triggers',
			'bwfan_message',
			'bwfan_templates',
			'bwfan_terms',
			'bwf_contact_fields'
		];
	}

	/**
	 * Return the object of current class
	 *
	 * @return null|BWFAN_Pro_DB
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	/**
	 * Include all the DB Table files
	 */
	public static function load_db_classes() {
		$integration_dir = __DIR__ . '/db';
		foreach ( glob( $integration_dir . '/class-*.php' ) as $_field_filename ) {
			require_once $_field_filename;
		}
	}

	/**
	 * Creating tables for v 1.0
	 */
	public function db_update() {
		$db_changes       = array(
			'1.9.4'  => '1_9_4',
			'1.9.5'  => '1_9_5',
			'1.9.6'  => '1_9_6',
			'2.0.2'  => '2_0_2',
			'2.0.4'  => '2_0_4',
			'2.0.5'  => '2_0_5',
			'2.0.6'  => '2_0_6',
			'2.0.7'  => '2_0_7',
			'2.0.8'  => '2_0_8',
			'2.0.9'  => '2_0_9',
			'2.0.11' => '2_0_11',
			'2.1.2'  => '2_1_2',
		);
		$saved_db_version = get_option( 'bwfan_pro_db', '1.2.2' );

		foreach ( $db_changes as $version_key => $version_value ) {
			if ( version_compare( $saved_db_version, $version_key, '<' ) ) {
				$function_name = 'db_update_' . $version_value;
				$this->$function_name( $version_key );
			}
		}
	}

	/**
	 * Create tables
	 *
	 * @param $version_key
	 *
	 * @throws Exception
	 */
	public function db_update_1_9_4( $version_key ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		global $wpdb;
		$collate = '';

		if ( $wpdb->has_cap( 'collation' ) ) {
			$collate = $wpdb->get_charset_collate();
		}

		$max_index_length = 191;
		$db_errors        = [];

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_engagement_tracking (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`cid` bigint(20) unsigned NOT NULL default 0,
			`hash_code` varchar(60) NOT NULL,
			`created_at` datetime NOT NULL default '0000-00-00 00:00:00',
			`updated_at` datetime default NULL,
			`mode` tinyint(1) unsigned not null default 1 COMMENT '1 - Email 2 - SMS',
			`send_to` varchar(255) NOT NULL,
			`type` tinyint(2) unsigned not null default 1 COMMENT '1 - Automation 2 - Broadcast 3 - Note 4 - Email 5 - SMS',
			`open` smallint(3) unsigned NOT NULL default 0,
			`click` smallint(3) unsigned NOT NULL default 0,
			`oid` bigint(20) unsigned NOT NULL,
			`sid` bigint(20) unsigned NOT NULL default 0 COMMENT 'Step ID',
			`author_id` bigint(10) unsigned NOT NULL default 1,
			`tid` int(20) unsigned NOT NULL default 0 COMMENT 'Template ID',
			`o_interaction` varchar(255),
			`f_open` datetime default NULL,
			`c_interaction` varchar(255),
			`f_click` datetime default NULL,
			`c_status` tinyint(2) unsigned default 1 COMMENT '1 - Draft 2 - Send 3 - Error 4 - Bounced',
			`day` tinyint(1) unsigned default NUll,
			`hour` tinyint(2) unsigned default NUll,
			PRIMARY KEY (`ID`),			
			KEY `cid` (`cid`),
			KEY `hash_code` (`hash_code`),
			KEY `created_at` (`created_at`),
			KEY `mode` (`mode`),
			KEY `type` (`type`),
			KEY `oid` (`oid`),
			KEY `sid` (`sid`),
			KEY `c_status` (`c_status`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_engagement_tracking - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_engagement_trackingmeta (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`eid` bigint(20) unsigned NOT NULL,
			`meta_key` varchar(255) default NULL,
		  	`meta_value` longtext,
			PRIMARY KEY (`ID`),		
			KEY `eid` (`eid`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_engagement_trackingmeta - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_templates (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`subject` varchar(255) default NULL,
			`template` longtext,
			`type` tinyint(1) unsigned not null default 1 COMMENT '1 - Email 2 - SMS',
			`title` varchar(255) default NULL,
			`mode` tinyint(1) NOT NULL default 1 COMMENT '1 - text only 2 - wc 3 - raw html 4 - drag and drop',
			`data` longtext,
			`canned` tinyint(1) default 0,
			`created_at` datetime NOT NULL default '0000-00-00 00:00:00',
			`updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
			PRIMARY KEY (`ID`),
			KEY `type` (`type`),
			KEY `mode` (`mode`),
			KEY `canned` (`canned`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_templates - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_conversions (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`wcid` bigint(20) unsigned NOT NULL,
			`cid` bigint(20) unsigned NOT NULL,
			`trackid` bigint(20) unsigned NOT NULL,
			`oid` bigint(20) unsigned NOT NULL,
			`otype` tinyint(2) unsigned not null COMMENT '1 - Automation 2 - Campaign 3 - Note 4 - Email 5 - SMS',
			`wctotal` varchar(32),
			`date` datetime NOT NULL default '0000-00-00 00:00:00',
			PRIMARY KEY (`ID`),
			KEY `cid` (`cid`),
			KEY `oid` (`oid`),
			KEY `otype` (`otype`),
			KEY `date` (`date`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_conversions - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_terms (
 		  `ID` bigint(20) unsigned NOT NULL auto_increment,
 		  `name` varchar(255) NOT NULL,
 		  `type` tinyint(2) unsigned NOT NULL,
 		  `data` longtext, 
 		  `created_at` datetime,
 		  `updated_at` datetime,
		  PRIMARY KEY (`ID`),
		  KEY `type` (`type`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_terms - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_fields (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`name` varchar(255) NOT NULL,
			`slug` varchar(255) NOT NULL,
			`type` tinyint(2) unsigned NOT NULL,
			`gid` bigint(20) unsigned NOT NULL,
			`meta` text NOT NULL,
			`mode` tinyint(2) unsigned NOT NULL default 1 COMMENT '1 - Editable 2 - Non-editable',
			`vmode` tinyint(2) unsigned NOT NULL default 1 COMMENT '1 - Editable 2 - Non-editable',
			`search` tinyint(1) unsigned NOT NULL default 2 COMMENT '1 - Searchable 2 - Non-searchable',
			`view` tinyint(1) unsigned NOT NULL default 1 COMMENT '1 - Viwable 2 - Non-Viwable',
			`created_at` datetime,
			PRIMARY KEY (`ID`),
			KEY `slug` (`slug`($max_index_length)),
			KEY `gid` (`gid`),
			KEY `mode` (`mode`),
			KEY `vmode` (`vmode`),
			KEY `search` (`search`),
			KEY `view` (`view`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_fields - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_field_groups (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`name` varchar(255) NOT NULL,
			`created_at` datetime,
			PRIMARY KEY (`ID`)
		  ) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_field_groups - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_contact_note (
		  `id` bigint(20) unsigned NOT NULL auto_increment,
		  `cid` bigint(20) unsigned NOT NULL,
		  `type` varchar(255) NOT NULL,
		  `created_by` bigint(20),
		  `created_date` datetime,
		  `private` tinyint(1) unsigned not null default 0,
		  `title` varchar(255),
		  `body` longtext,
		  `modified_by` bigint(20) default null,
		  `modified_date` datetime default null,
		  `date_time` datetime default null,
		  PRIMARY KEY (`id`),
		  KEY `cid` (`cid`)
		  ) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_contact_note - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_import_export (
		  `id` bigint(20) unsigned NOT NULL auto_increment,
		  `offset` bigint(20) unsigned NOT NULL,
		  `processed` bigint(20) unsigned NOT NULL,
		  `count` bigint(20) unsigned NOT NULL,
		  `type` tinyint(1) unsigned not null default 1,
		  `status` tinyint(1) unsigned not null default 1,
		  `meta` text NOT NULL,
		  `last_modified` datetime default null,
		  `created_date` datetime,
		  PRIMARY KEY (`id`),
		  KEY `type` (`type`),
		  KEY `status` (`status`)
		  ) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_import_export - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_broadcast (
		  `id` bigint(20) UNSIGNED NOT NULL auto_increment,
		  `title` varchar(255) NOT NULL,
		  `description` longtext,
		  `type` tinyint(1) unsigned NOT NULL DEFAULT 1,
		  `status` tinyint(1) unsigned NOT NULL DEFAULT 1,
		  `count` bigint(10) unsigned NOT NULL,
		  `processed` bigint(10) unsigned NOT NULL,
		  `created_by` bigint(20) unsigned NOT NULL,
		  `offset` bigint(10) unsigned NOT NULL,
		  `modified_by` bigint(20) NOT NULL,
		  `execution_time` datetime DEFAULT NULL,
		  `created_at` datetime DEFAULT NULL,
		  `last_modified` datetime DEFAULT NULL,
		  `data` longtext,
		  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
		  PRIMARY KEY (`id`),
		  KEY `type` (`type`),
		  KEY `status` (`status`)
		  ) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_broadcast - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_form_feeds (
		  `ID` bigint(20) unsigned NOT NULL auto_increment,
		  `title` varchar(255) NOT NULL,
		  `status` tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '1 - Draft 2 - Active 3 - InActive',
		  `source` varchar(255) NOT NULL,
		  `contacts` bigint(20) NOT NULL DEFAULT 0,
		  `created_at` datetime DEFAULT NULL,
		  `updated_at` datetime DEFAULT NULL,
		  `data` longtext,
		  PRIMARY KEY (`ID`),
		  KEY `source` (`source`($max_index_length)),
		  KEY `status` (`status`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_form_feeds - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_message (
		  `ID` bigint(20) unsigned NOT NULL auto_increment,
		  `track_id` bigint(20) unsigned NOT NULL,
		  `sub` varchar(255) NOT NULL,
		  `body` longtext,
		  `date` datetime DEFAULT NULL,
		  PRIMARY KEY (`ID`),
		  KEY `track_id` (`track_id`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_message - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwf_contact_fields (
		  `ID` bigint(20) unsigned NOT NULL auto_increment,
		  `cid` bigint(20) unsigned NOT NULL,
		  PRIMARY KEY (`ID`),
		  KEY `cid` (`cid`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwf_contact_fields - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_link_triggers (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`hash` varchar(40) NOT NULL,
			`title` varchar(255) default NULL,
			`status` tinyint(1) unsigned not null default 1 COMMENT '0 - Draft 1 - Inactive 2 - Active',
			`total_clicked` bigint(10) unsigned default 0,
			`data` longtext,
			`created_by` bigint(10) unsigned default 0,
			`created_at` datetime NOT NULL default '0000-00-00 00:00:00',
			`updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
			PRIMARY KEY (`ID`),
			KEY `hash` (`hash`),
			KEY `title` (`title`),
			KEY `status` (`status`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_link_triggers - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_bulk_action (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`offset` bigint(20) unsigned NOT NULL,
			`processed` bigint(20) unsigned NOT NULL,
			`count` bigint(20) unsigned NOT NULL,
			`title` varchar(255) default NULL,
			`status` tinyint(1) unsigned not null default 0 COMMENT '0 - Draft 1 - Ongoing 2 - Completed 3 - Paused',
			`actions` longtext NOT NULL,
			`meta` longtext NOT NULL,
			`created_by` bigint(10) unsigned default 0,
			`created_at` datetime NOT NULL default '0000-00-00 00:00:00',
			`updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
			PRIMARY KEY (`ID`),
			KEY `title` (`title`),
			KEY `status` (`status`)
	    ) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_bulk_action - ' . $wpdb->last_error;
		}

		$this->tables_created = true;

		$this->method_run[] = $version_key;

		/** Updating version key */
		update_option( 'bwfan_pro_db', $version_key, true );

		/** Log if any mysql errors */
		if ( ! empty( $db_errors ) ) {
			BWFAN_PRO_Common::log_test_data( array_merge( [ __FUNCTION__ ], $db_errors ), 'db-creation-errors' );
		}
	}

	/**
	 * Create fields
	 *
	 * @param $version_key
	 */
	public function db_update_1_9_5( $version_key ) {
		global $wpdb;

		/** Set View = 2 (Hide) for System Fields for existing fields */
		$query   = "SELECT `ID` FROM `{$wpdb->prefix}bwfan_fields` WHERE `slug` IN ('form-feed-id', 'last-click', 'last-open', 'last-login', 'address-1', 'address-2', 'city', 'postcode', 'company', 'gender', 'dob')"; // WPCS: unprepared SQL OK
		$results = $wpdb->get_results( $query, ARRAY_A );

		if ( is_array( $results ) && count( $results ) > 0 ) {
			$ids   = array_column( $results, 'ID' );
			$query = "UPDATE `{$wpdb->prefix}bwfan_fields` SET `view`= 2 WHERE `ID` IN (" . implode( ',', $ids ) . ")"; // WPCS: unprepared SQL OK

			$wpdb->query( $query );
		}

		/** Creating default contact fields */
		BWFAN_PRO_Common::insert_default_crm_fields();

		BWFCRM_Fields::add_field( 'Last Login', BWFCRM_Fields::$TYPE_DATE, array(), '', 2, 2, 1, 0, 2 );
		BWFCRM_Fields::add_field( 'Last Open', BWFCRM_Fields::$TYPE_DATE, array(), '', 2, 2, 1, 0, 2 );
		BWFCRM_Fields::add_field( 'Last Click', BWFCRM_Fields::$TYPE_DATE, array(), '', 2, 2, 1, 0, 2 );
		BWFCRM_Fields::add_field( 'Form Feed ID', 2, array(), 'System Field', 2, 2, 1, 0, 2 );

		/** Type Checkbox will enable the JSON Array searching capabilities */
		BWFCRM_Fields::add_field( 'Unsubscribed Lists', BWFCRM_Fields::$TYPE_CHECKBOX, array(), 'System Field', 2, 2, 1, 0, 2 );

		$this->method_run[] = $version_key;

		/** Updating version key */
		update_option( 'bwfan_pro_db', $version_key, true );
	}

	/**
	 * Schedule cron' and extra savings
	 *
	 * @param $version_key
	 *
	 * @throws Exception
	 */
	public function db_update_1_9_6( $version_key ) {
		global $wpdb;

		/** Scheduling Broadcast action */
		if ( ! bwf_has_action_scheduled( 'bwfcrm_broadcast_run_queue' ) ) {
			bwf_schedule_recurring_action( time(), 10, 'bwfcrm_broadcast_run_queue', array(), 'bwfcrm' );
		}

		/** Schedule midnight cron and 5-min worker */
		BWFAN_PRO_Common::schedule_cron();

		/** Save last created contact id */
		$saved_val = get_option( 'bwfan_show_contacts_from', 0 );
		if ( empty( $saved_val ) ) {
			$last_contact_id = BWFCRM_Model_Contact::get_last_contact_id();
			if ( absint( $last_contact_id ) > 0 ) {
				update_option( 'bwfan_show_contacts_from', $last_contact_id, true );
			}
		}

		/** Delete unpaid or invalid conversions */
		$last_conversion_id = BWFAN_Model_Conversions::get_last_conversion_id();
		if ( absint( $last_conversion_id ) > 0 ) {
			$hook  = 'bwfan_check_conversion_validity';
			$group = 'autonami';
			$args  = array();

			if ( ! bwf_has_action_scheduled( $hook, $args, $group ) ) {
				update_option( 'bwfan_db_1_3_3_options', array( 'last_conversion_id' => $last_conversion_id ), false );
				bwf_schedule_recurring_action( time(), MINUTE_IN_SECONDS * 10, $hook, $args, $group );
			}
		}

		/** Delete Unwanted last login field */
		$wpdb->query( "DELETE FROM {$wpdb->prefix}bwfan_fields WHERE slug = 'lastlogin'" ); // WPCS: unprepared SQL OK

		$this->method_run[] = $version_key;

		/** Updating version key */
		update_option( 'bwfan_pro_db', $version_key, true );
	}

	/**
	 * Correct the default values and make the missing tables
	 *
	 * @param $version_key
	 *
	 * @throws Exception
	 */
	public function db_update_2_0_2( $version_key ) {
		if ( true === $this->tables_created ) {
			update_option( 'bwfan_pro_db', $version_key, true );

			return;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		global $wpdb;
		$collate   = '';
		$db_errors = [];

		if ( $wpdb->has_cap( 'collation' ) ) {
			$collate = $wpdb->get_charset_collate();
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_engagement_tracking (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`cid` bigint(20) unsigned NOT NULL default 0,
			`hash_code` varchar(60) NOT NULL,
			`created_at` datetime NOT NULL default '0000-00-00 00:00:00',
			`updated_at` datetime default NULL,
			`mode` tinyint(1) unsigned not null default 1 COMMENT '1 - Email 2 - SMS',
			`send_to` varchar(255) NOT NULL,
			`type` tinyint(2) unsigned not null default 1 COMMENT '1 - Automation 2 - Broadcast 3 - Note 4 - Email 5 - SMS',
			`open` smallint(3) unsigned NOT NULL default 0,
			`click` smallint(3) unsigned NOT NULL default 0,
			`oid` bigint(20) unsigned NOT NULL,
			`sid` bigint(20) unsigned NOT NULL default 0 COMMENT 'Step ID',
			`author_id` bigint(10) unsigned NOT NULL default 1,
			`tid` int(20) unsigned NOT NULL default 0 COMMENT 'Template ID',
			`o_interaction` varchar(255),
			`f_open` datetime default NULL,
			`c_interaction` varchar(255),
			`f_click` datetime default NULL,
			`c_status` tinyint(2) unsigned default 1 COMMENT '1 - Draft 2 - Send 3 - Error 4 - Bounced',
			`day` tinyint(1) unsigned default NUll,
			`hour` tinyint(2) unsigned default NUll,
			PRIMARY KEY (`ID`),			
			KEY `cid` (`cid`),
			KEY `hash_code` (`hash_code`),
			KEY `created_at` (`created_at`),
			KEY `mode` (`mode`),
			KEY `type` (`type`),
			KEY `oid` (`oid`),
			KEY `sid` (`sid`),
			KEY `c_status` (`c_status`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_engagement_tracking - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_templates (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`subject` varchar(255) default NULL,
			`template` longtext,
			`type` tinyint(1) unsigned not null default 1 COMMENT '1 - Email 2 - SMS',
			`title` varchar(255) default NULL,
			`mode` tinyint(1) NOT NULL default 1 COMMENT '1 - text only 2 - wc 3 - raw html 4 - drag and drop',
			`data` longtext,
			`canned` tinyint(1) default 0,
			`created_at` datetime NOT NULL default '0000-00-00 00:00:00',
			`updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
			PRIMARY KEY (`ID`),
			KEY `type` (`type`),
			KEY `mode` (`mode`),
			KEY `canned` (`canned`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_templates - ' . $wpdb->last_error;
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_conversions (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`wcid` bigint(20) unsigned NOT NULL,
			`cid` bigint(20) unsigned NOT NULL,
			`trackid` bigint(20) unsigned NOT NULL,
			`oid` bigint(20) unsigned NOT NULL,
			`otype` tinyint(2) unsigned not null COMMENT '1 - Automation 2 - Campaign 3 - Note 4 - Email 5 - SMS',
			`wctotal` varchar(32),
			`date` datetime NOT NULL default '0000-00-00 00:00:00',
			PRIMARY KEY (`ID`),
			KEY `cid` (`cid`),
			KEY `oid` (`oid`),
			KEY `otype` (`otype`),
			KEY `date` (`date`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_conversions - ' . $wpdb->last_error;
		}

		$this->method_run[] = $version_key;

		update_option( 'bwfan_pro_db', $version_key, true );

		/** Log if any mysql errors */
		if ( ! empty( $db_errors ) ) {
			BWFAN_PRO_Common::log_test_data( array_merge( [ __FUNCTION__ ], $db_errors ), 'db-creation-errors' );
		}
	}

	/**
	 * Make new table for link triggers
	 * Add Indexes for Hash Code and CStatus columns
	 *
	 * @param $version_key
	 *
	 * @throws Exception
	 */
	public function db_update_2_0_4( $version_key ) {
		/** Create fields */
		BWFCRM_Fields::add_field( 'Link Trigger Click', BWFCRM_Fields::$TYPE_TEXTAREA, array(), '', 2, 2, 1, 0, 2 );
		BWFCRM_Fields::add_field( 'Auth', BWFCRM_Fields::$TYPE_TEXT, array(), '', 2, 2, 1, 0, 2 );
		BWFCRM_Fields::add_field( 'Last Sent', BWFCRM_Fields::$TYPE_DATE, array(), '', 2, 2, 1, 0, 2 );

		if ( true === $this->tables_created ) {
			update_option( 'bwfan_pro_db', $version_key, true );

			return;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		global $wpdb;
		$collate   = '';
		$db_errors = [];

		if ( $wpdb->has_cap( 'collation' ) ) {
			$collate = $wpdb->get_charset_collate();
		}

		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_link_triggers (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`hash` varchar(40) NOT NULL,
			`title` varchar(255) default NULL,
			`status` tinyint(1) unsigned not null default 1 COMMENT '0 - Draft 1 - Inactive 2 - Active',
			`total_clicked` bigint(10) unsigned default 0,
			`data` longtext,
			`created_by` bigint(10) unsigned default 0,
			`created_at` datetime NOT NULL default '0000-00-00 00:00:00',
			`updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
			PRIMARY KEY (`ID`),
			KEY `hash` (`hash`),
			KEY `title` (`title`),
			KEY `status` (`status`)
		) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_link_triggers - ' . $wpdb->last_error;
		}

		/** Add Indexes for Hash Code and C_Status keys */
		$wpdb->query( "ALTER TABLE `{$wpdb->prefix}bwfan_engagement_tracking` MODIFY COLUMN `hash_code` varchar(60), ADD KEY `hash_code`(`hash_code`), ADD KEY `c_status`(`c_status`)" );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_engagement_tracking indexes - ' . $wpdb->last_error;
		}

		$this->method_run[] = $version_key;

		update_option( 'bwfan_pro_db', $version_key, true );

		/** Log if any mysql errors */
		if ( ! empty( $db_errors ) ) {
			BWFAN_PRO_Common::log_test_data( array_merge( [ __FUNCTION__ ], $db_errors ), 'db-creation-errors' );
		}
	}

	/**
	 * Add new column in table
	 *
	 * @param $version_key
	 *
	 * @throws Exception
	 */
	public function db_update_2_0_5( $version_key ) {
		if ( true === $this->tables_created ) {
			update_option( 'bwfan_pro_db', $version_key, true );

			return;
		}
		global $wpdb;
		$db_errors = [];

		/** Add Step Id (sid) column */
		$wpdb->query( "ALTER TABLE `{$wpdb->prefix}bwfan_engagement_tracking` ADD `sid` bigint(20) unsigned NOT NULL default 0 COMMENT 'Step ID', ADD KEY `sid` (`sid`)" );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_engagement_tracking new column - ' . $wpdb->last_error;
		}

		$this->method_run[] = $version_key;

		update_option( 'bwfan_pro_db', $version_key, true );

		/** Log if any mysql errors */
		if ( ! empty( $db_errors ) ) {
			BWFAN_PRO_Common::log_test_data( array_merge( [ __FUNCTION__ ], $db_errors ), 'db-creation-errors' );
		}
	}

	/**
	 * Add indexes
	 *
	 * @param $version_key
	 *
	 * @throws Exception
	 */
	public function db_update_2_0_6( $version_key ) {
		if ( true === $this->tables_created ) {
			update_option( 'bwfan_pro_db', $version_key, true );

			return;
		}
		global $wpdb;
		$db_errors = [];

		/** Add Indexes for Hash Code and C_Status keys */
		$wpdb->query( "ALTER TABLE `{$wpdb->prefix}bwfan_engagement_tracking` ADD KEY `created_at`(`created_at`)" );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_engagement_tracking indexes - ' . $wpdb->last_error;
		}

		$this->method_run[] = $version_key;

		update_option( 'bwfan_pro_db', $version_key, true );

		/** Log if any mysql errors */
		if ( ! empty( $db_errors ) ) {
			BWFAN_PRO_Common::log_test_data( array_merge( [ __FUNCTION__ ], $db_errors ), 'db-creation-errors' );
		}
	}

	public function db_update_2_0_7( $version_key ) {
		/** Create automation fields */
		BWFCRM_Fields::add_field( 'Automation Entered', BWFCRM_Fields::$TYPE_TEXTAREA, array(), '', 2, 2, 1, 0, 2 );
		BWFCRM_Fields::add_field( 'Automation Active', BWFCRM_Fields::$TYPE_TEXTAREA, array(), '', 2, 2, 1, 0, 2 );
		BWFCRM_Fields::add_field( 'Automation Completed', BWFCRM_Fields::$TYPE_TEXTAREA, array(), '', 2, 2, 1, 0, 2 );

		$this->method_run[] = $version_key;

		/** Updating version key */
		update_option( 'bwfan_pro_db', $version_key, true );

	}

	public function db_update_2_0_8( $version_key ) {
		if ( true === $this->tables_created ) {
			update_option( 'bwfan_pro_db', $version_key, true );

			return;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		global $wpdb;
		$collate   = '';
		$db_errors = [];

		if ( $wpdb->has_cap( 'collation' ) ) {
			$collate = $wpdb->get_charset_collate();
		}

		/** Add Bulk Action table */
		$creationSQL = "CREATE TABLE {$wpdb->prefix}bwfan_bulk_action (
			`ID` bigint(20) unsigned NOT NULL auto_increment,
			`offset` bigint(20) unsigned NOT NULL,
			`processed` bigint(20) unsigned NOT NULL,
			`count` bigint(20) unsigned NOT NULL,
			`title` varchar(255) default NULL,
			`status` tinyint(1) unsigned not null default 0 COMMENT '0 - Draft 1 - Ongoing 2 - Completed 3 - Paused',
			`actions` longtext NOT NULL,
			`meta` longtext NOT NULL,
			`created_by` bigint(10) unsigned default 0,
			`created_at` datetime NOT NULL default '0000-00-00 00:00:00',
			`updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
			PRIMARY KEY (`ID`),
			KEY `title` (`title`),
			KEY `status` (`status`)
	    ) $collate;";
		dbDelta( $creationSQL );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_bulk_action - ' . $wpdb->last_error;
		}

		$this->method_run[] = $version_key;

		update_option( 'bwfan_pro_db', $version_key, true );

		/** Log if any mysql errors */
		if ( ! empty( $db_errors ) ) {
			BWFAN_PRO_Common::log_test_data( array_merge( [ __FUNCTION__ ], $db_errors ), 'db-creation-errors' );
		}
	}

	/**
	 * Temporary done for beta users
	 *
	 * @param $version_key
	 *
	 * @return void
	 */
	public function db_update_2_0_9( $version_key ) {
		global $wpdb;
		$events_slugs = [
			'elementor_form_submit',
			'elementor_popup_form_submit',
			'caldera_form_submit',
			'divi_form_Submit',
			'fluent_form_submit',
			'gf_form_submit',
			'formidable_form_Submit',
			'ninja_form_submit',
			'funnel_optin_form_submit',
			'tve_lead_form_submit',
			'wpforms_form_submit'
		];

		$automations = $this->get_automations_by_slugs( $events_slugs );
		if ( empty( $automations ) ) {
			$this->method_run[] = $version_key;
			update_option( 'bwfan_pro_db', $version_key, true );
		}

		$aids       = array_column( $automations, 'ID' );
		$event_meta = BWFAN_Model_Automationmeta::get_automations_meta( $aids, 'event_meta' );
		foreach ( $event_meta as $aid => $data ) {
			if ( ! isset( $data['event_meta'] ) || isset( $data['event_meta']['bwfan-form-field-map'] ) ) {
				continue;
			}

			$map_fields = $this->format_form_submit_data( $data['event_meta'] );
			$table_name = "{$wpdb->prefix}bwfan_automationmeta";
			$wpdb->update( $table_name, [
				'meta_value' => maybe_serialize( $map_fields )
			], [
				'bwfan_automation_id' => intval( $aid ),
				'meta_key'            => 'event_meta'
			] );
		}

		$this->method_run[] = $version_key;

		/** Updating version key */
		update_option( 'bwfan_pro_db', $version_key, true );
	}

	/**
	 * Get v2 automations ids by event slug
	 *
	 * @param $event_slugs
	 *
	 * @return array|object|stdClass[]|null
	 */
	protected function get_automations_by_slugs( $event_slugs ) {
		global $wpdb;
		$args        = $event_slugs;
		$args[]      = 2;
		$placeholder = array_fill( 0, count( $event_slugs ), '%s' );
		$placeholder = implode( ', ', $placeholder );

		return $wpdb->get_results( $wpdb->prepare( "SELECT `ID` FROM {$wpdb->prefix}bwfan_automations WHERE `event` IN ($placeholder) AND `v` = %d", $args ), ARRAY_A );
	}

	protected function format_form_submit_data( $event_meta ) {
		if ( ! is_array( $event_meta ) || empty( $event_meta ) ) {
			return [];
		}
		$data = [];
		foreach ( $event_meta as $key => $value ) {
			if ( false === strpos( $key, 'email' ) && false === strpos( $key, 'first_name' ) && false === strpos( $key, 'last_name' ) && false === strpos( $key, 'phone' ) ) {
				continue;
			}

			switch ( $key ) {
				case( false !== strpos( $key, 'email' ) ) :
					$data['bwfan_email_field_map'] = $value;
					break;
				case( false !== strpos( $key, 'first_name' ) ) :
					$data['bwfan_first_name_field_map'] = $value;
					break;
				case( false !== strpos( $key, 'last_name' ) ) :
					$data['bwfan_last_name_field_map'] = $value;
					break;
				case( false !== strpos( $key, 'phone' ) ) :
					$data['bwfan_phone_field_map'] = $value;
					break;
			}

			unset( $event_meta[ $key ] );
		}
		$event_meta['bwfan-form-field-map'] = $data;

		return $event_meta;

	}

	/**
	 * Temporary done for beta users
	 *
	 * @param $version_key
	 *
	 * @return void
	 */
	public function db_update_2_0_11( $version_key ) {
		global $wpdb;
		$table_name      = "{$wpdb->prefix}bwfan_automation_step";
		$query           = "SELECT `ID`,`data` FROM $table_name WHERE `type` = 4 AND `data` LIKE '%customer_custom_field%'"; // WPCS: unprepared SQL OK
		$condition_steps = $wpdb->get_results( $query, ARRAY_A );

		/** If empty then don't proceed */
		if ( empty( $condition_steps ) ) {
			$this->method_run[] = $version_key;
			update_option( 'bwfan_pro_db', $version_key, true );

			return;
		}

		foreach ( $condition_steps as $step ) {
			if ( ! isset( $step['data'] ) && empty( $step['data'] ) ) {
				continue;
			}

			$db_data = json_decode( $step['data'], true );
			foreach ( $db_data['sidebarData'] as $key => $data ) {
				if ( ! is_array( $data ) || 0 === count( $data ) ) {
					continue;
				}
				/** $key holds a group of fields with AND operator */
				$db_data['sidebarData'][ $key ] = $this->modify_custom_field_filters( $data );
			}

			$wpdb->update( $table_name, [
				'data'       => wp_json_encode( $db_data ),
				'updated_at' => current_time( 'mysql', 1 )
			], [
				'ID' => intval( $step['ID'] )
			] );
		}
		$this->method_run[] = $version_key;

		/** Updating version key */
		update_option( 'bwfan_pro_db', $version_key, true );
	}

	protected function modify_custom_field_filters( $sidebar_data ) {
		$sidebar_data = array_map( function ( $data ) {
			/** If not "customer_custom_field" filter */
			if ( ! isset( $data['filter'] ) || 'customer_custom_field' !== $data['filter'] ) {
				return $data;
			}

			$field_slug      = $data['data'][0];
			$contact_columns = [ 'f_name', 'l_name', 'email', 'contact_no', 'status', 'country', 'state' ];
			if ( in_array( $field_slug, $contact_columns, false ) ) {
				/** These are contact columns so filtered under contact details and geography group */
				return $this->modify_contact_table_filters( $data );
			}

			/** Below all are contact fields */

			$field = BWFAN_Model_Fields::get_field_by_slug( $field_slug );
			if ( ! isset( $field['ID'] ) ) {
				return $data;
			}

			/** Field type is date (6) */
			if ( 6 === absint( $field['type'] ) ) {
				$data['data'] = [
					[
						'key'   => $data['data'][1],
						'label' => $data['data'][1]
					]
				];

				$rule         = 'is' === $data['rule'] ? 'has' : '';
				$rule         = ( 'is_not' === $data['rule'] || 'isnot' === $data['rule'] ) ? 'hasnot' : $rule;
				$data['rule'] = empty( $rule ) ? 'any' : $rule;
			} else {
				$data['data'] = $data['data'][1];
			}

			$data['filter'] = 'bwf_contact_field_f' . $field['ID'];

			/** Check for Geography fields */
			if ( in_array( $field_slug, [ 'address-1', 'address-2', 'city', 'postcode' ] ) ) {
				switch ( $field_slug ) {
					case 'address-1':
						$data['filter'] = 'contact_address_1';
						break;
					case 'address-2':
						$data['filter'] = 'contact_address_2';
						break;
					case 'city':
						$data['filter'] = 'contact_city';
						break;
					case 'postcode':
						$data['filter'] = 'contact_post_code';
						break;
				}
			}

			/** If company, gender & dob */
			if ( in_array( $field_slug, [ 'company', 'gender', 'dob' ] ) ) {
				switch ( $field_slug ) {
					case 'company':
						$data['filter'] = 'contact_company';
						break;
					case 'gender':
						$data['filter'] = 'contact_gender';
						break;
					case 'dob':
						$data['filter'] = 'contact_dob';
						break;
				}
			}

			return $data;
		}, $sidebar_data );

		return $sidebar_data;
	}

	protected function modify_contact_table_filters( $data ) {
		$key   = $data['data'][0];
		$value = $data['data'][1];
		$rule  = $data['rule'];

		if ( 'f_name' === $key ) {
			return [
				'filter' => 'contact_first_name',
				'rule'   => $rule,
				'data'   => $value,
			];
		}
		if ( 'l_name' === $key ) {
			return [
				'filter' => 'contact_last_name',
				'rule'   => $rule,
				'data'   => $value,
			];
		}
		if ( 'email' === $key ) {
			return [
				'filter' => 'contact_email',
				'rule'   => $rule,
				'data'   => $value,
			];
		}
		if ( 'contact_no' === $key ) {
			return [
				'filter' => 'contact_phone',
				'rule'   => $rule,
				'data'   => $value,
			];
		}
		if ( 'state' === $key ) {
			return [
				'filter' => 'contact_state',
				'rule'   => $rule,
				'data'   => $value,
			];
		}
		if ( 'status' === $key ) {
			return [
				'filter' => 'customer_marketing_status',
				'rule'   => '',
				'data'   => $value,
			];
		}
		if ( 'country' === $key ) {
			$arr           = [
				'filter' => 'contact_country',
				'rule'   => ( 'is_not' === $rule ) ? 'none' : 'any',
				'data'   => [
					[
						'key'   => '',
						'label' => ''
					]
				],
			];
			$all_countries = bwf_get_countries_data();
			if ( isset( $all_countries[ $value ] ) || isset( $all_countries[ strtoupper( $value ) ] ) ) {
				$arr['data'][0]['key']   = strtoupper( $value );
				$arr['data'][0]['label'] = $all_countries[ strtoupper( $value ) ];
			}

			return $arr;
		}

		return $data;
	}

	/**
	 * Add sid column in engagement table if not available
	 *
	 * @param $version_key
	 *
	 * @throws Exception
	 */
	public function db_update_2_1_2( $version_key ) {
		if ( true === $this->tables_created || ( is_array( $this->method_run ) && in_array( '2.0.5', $this->method_run, true ) ) ) {
			update_option( 'bwfan_pro_db', $version_key, true );
			$this->method_run[] = $version_key;

			return;
		}

		global $wpdb;

		/** Check `sid` column if exists */
		$query      = "SHOW COLUMNS FROM `{$wpdb->prefix}bwfan_engagement_tracking` LIKE 'sid'";
		$sid_exists = $wpdb->get_var( $query );
		if ( ! empty( $sid_exists ) ) {
			update_option( 'bwfan_pro_db', $version_key, true );

			return;
		}

		$db_errors = [];

		/** Add Step Id (sid) column */
		$wpdb->query( "ALTER TABLE `{$wpdb->prefix}bwfan_engagement_tracking` ADD `sid` bigint(20) unsigned NOT NULL default 0 COMMENT 'Step ID', ADD KEY `sid` (`sid`)" );
		if ( ! empty( $wpdb->last_error ) ) {
			$db_errors[] = 'bwfan_engagement_tracking new column in 2.1.2- ' . $wpdb->last_error;
		}

		$this->method_run[] = $version_key;

		update_option( 'bwfan_pro_db', $version_key, true );

		/** Log if any mysql errors */
		if ( ! empty( $db_errors ) ) {
			BWFAN_PRO_Common::log_test_data( array_merge( [ __FUNCTION__ ], $db_errors ), 'db-creation-errors' );
		}
	}
}

BWFAN_Pro_DB::get_instance();
