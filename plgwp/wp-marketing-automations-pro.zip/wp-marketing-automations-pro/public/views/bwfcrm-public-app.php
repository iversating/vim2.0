<p>I was trying to boot my computer, but I got this hilarious message:</p>

<p><samp>Keyboard not found <br>Press F1 to continue</samp></p>
<div id="bwfcrm-public"></div>
<?php

do_action( 'wp_print_footer_scripts' );