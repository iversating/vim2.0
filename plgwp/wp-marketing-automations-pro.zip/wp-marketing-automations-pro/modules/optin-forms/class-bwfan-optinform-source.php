<?php

class BWFAN_OptinForm_Source extends BWFAN_Source {
	private static $instance = null;

	public function __construct() {
		$this->event_dir  = __DIR__;
		$this->nice_name  = __( 'WooFunnels', 'autonami-automations-pro' );
		$this->group_name = __( 'WooFunnels', 'autonami-automations-pro' );
		$this->group_slug = 'woofunnels';
		$this->priority   = 100;
	}

	/**
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @return BWFAN_CalderaForm_Source|null
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

}

/**
 * Register this as a source.
 */
if ( function_exists( 'bwfan_is_optin_forms_active' ) && bwfan_is_optin_forms_active() ) {
	BWFAN_Load_Sources::register( 'BWFAN_OptinForm_Source' );
}
