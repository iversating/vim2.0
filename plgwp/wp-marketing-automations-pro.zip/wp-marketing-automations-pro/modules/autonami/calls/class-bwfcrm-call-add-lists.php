<?php

namespace BWFCRM\Calls\Autonami;

use BWFCRM\Calls\Base;

/**
 * Add lists call class
 */
class Add_To_Lists extends Base {

	/**
	 * Add list to contact
	 *
	 * @param \BWFCRM_Contact $contact
	 * @param $data
	 */
	public function process_call( $contact, $data ) {
		return $contact->add_lists( $data, false, false, true );
	}
}

/**
 * Register call
 */
BWFCRM_Core()->calls->register_call( 'add_to_lists', 'BWFCRM\Calls\Autonami\Add_To_Lists' );
