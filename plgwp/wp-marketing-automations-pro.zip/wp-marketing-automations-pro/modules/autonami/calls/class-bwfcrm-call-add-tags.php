<?php

namespace BWFCRM\Calls\Autonami;

use BWFCRM\Calls\Base;

/**
 * Add tags call class
 */
class Add_Tags extends Base {

	/**
	 * Add tags to contact
	 *
	 * @param \BWFCRM_Contact $contact
	 * @param $data
	 *
	 * @return mixed
	 */
	public function process_call( $contact, $data ) {
		return $contact->add_tags( $data, false, false, true );
	}
}

/**
 * Register call
 */
BWFCRM_Core()->calls->register_call( 'add_tags', 'BWFCRM\Calls\Autonami\Add_Tags' );
