<?php

class BWFAN_Wordpress_Adv_New_User_Role extends BWFAN_Merge_Tag {

	private static $instance = null;

	public function __construct() {
		$this->tag_name        = 'contact_user_new_role';
		$this->tag_description = __( 'Contact User New Role', 'autonami-automations-pro' );
		add_shortcode( 'bwfan_new_user_role', array( $this, 'parse_shortcode' ) ); // legacy
		add_shortcode( 'bwfan_contact_user_new_role', array( $this, 'parse_shortcode' ) );
		$this->priority = 15;
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Parse the merge tag and return its value.
	 *
	 * @param $attr
	 *
	 * @return mixed|string|void
	 */
	public function parse_shortcode( $attr ) {
		$get_data = BWFAN_Merge_Tag_Loader::get_data();
		if ( true === $get_data['is_preview'] ) {
			return $this->get_dummy_preview();
		}

		$new_role = isset( $get_data['new_role'] ) ? $get_data['new_role'] : '';
		$new_role = is_array( $new_role ) ? implode( ', ', $new_role ) : $new_role;

		return $this->parse_shortcode_output( $new_role, $attr );
	}

	/**
	 * Show dummy value of the current merge tag.
	 *
	 * @return string
	 */
	public function get_dummy_preview() {
		if ( ! method_exists( BWFAN_Merge_Tag::class, 'get_contact_data' ) ) {
			return '-';
		}

		$contact = $this->get_contact_data();

		/** checking contact instance and id */
		if ( ! $contact instanceof WooFunnels_Contact || 0 === absint( $contact->get_id() ) ) {
			return '-';
		}

		$user_id = $contact->get_wpid() ? $contact->get_wpid() : 0;
		if ( empty( $user_id ) ) {
			return '-';
		}

		$user_meta  = get_userdata( $user_id );
		$user_roles = $user_meta->roles;

		return is_array( $user_roles ) ? implode( ',', $user_roles ) : $user_roles;
	}
}

/**
 * Register this merge tag to a group.
 */
BWFAN_Merge_Tag_Loader::register( 'bwf_contact', 'BWFAN_Wordpress_Adv_New_User_Role', null, 'Contact' );
