<?php

 add_theme_support( 'post-thumbnails' );

/**
 * Server-side rendering of the `zeguten/posts-block` block.
 *
 *  @package ZeGuten Post Layouts for Gutenberg
 */

add_action('init', 'register_zeguten_post_block');

function render_latest_post_block( $attributes ) {
	
	$args = array(
		'posts_per_page'   => $attributes['postsToShow'],
		'post_status'      => 'publish',
		'order'            => $attributes['order'],
		'orderby'          => $attributes['orderBy'],
		'suppress_filters' => false,
		'post_type'        => 'post',
	); 

	if ( isset( $attributes['offset'] ) && $attributes['offset'] != '' ) {
		$args['offset'] = $attributes['offset'];
	}


	if ( isset( $attributes['categories'] ) ) {
		$args['category__in'] = array_column( $attributes['categories'], 'id' );
	}

	if ( isset( $attributes['selectedAuthor'] ) ) {
		$args['author'] = $attributes['selectedAuthor'];
	}

	//Filter by IDs
    if (isset($attributes['filterById']) && $attributes['filterById'] != ''){

        $ids_arr = explode(',', $attributes['filterById']);
        $args['post__in'] = $ids_arr;
    }

	$latest_posts = wp_get_recent_posts( $args );

	if (empty($latest_posts) ) {
		return '<p>No Posts</p>';
	}

	$imgclass = '';
	$post_thumbnail = '';


	
	if ( isset( $attributes['imgPosition'] ) && $attributes['imgPosition']  && true === $attributes['displayPostImage'] && 'list' === $attributes['postLayout'] ) {
		$imgclass .= $attributes['imgPosition'];
	}
	
	$posts_output = '';

	foreach ($latest_posts as $post ) {

		$post_id = $post['ID'];

		$attributes['imgOrder'] = ( isset( $attributes['postLayout'] ) && 'grid' === $attributes['postLayout'] ) ?  $attributes['imgOrder'] : 0;

		$categories_list = get_the_category_list("," , "", $post_id);
		$tags_list = get_the_tag_list("", ", ", "", $post_id);

		//Custom Icon
		$icon_tag = zeguten_get_icon( $attributes['tags_icon'] );
		$icon_admin = zeguten_get_icon( $attributes['admin_icon']  );
		$icon_comment = zeguten_get_icon( $attributes['comment_icon']  );
		$icon_date = zeguten_get_icon( $attributes['date_icon']   );
		$icon_button = zeguten_get_icon( $attributes['button_icon']   );

		if (isset($attributes['displayPostImage']) && $attributes['displayPostImage'] ) {

			$post_thumbnail = has_post_thumbnail($post_id);

			if( $post_thumbnail ) {

				$post_thumbnail = esc_html__('has-post-thumbnail', 'zeguten');
			}
			else {
				$post_thumbnail = esc_html__('', 'zeguten');
			}
		}


		// Get the post title
		$title = get_the_title($post_id);

		if (!$title) {
			$title = esc_html__('Untitled', 'zeguten');
		}

		$comment = get_comments_number( $post_id );

		if ( $comment == 0 ) {
				$comments = esc_html__('No Comments', 'zeguten');
			} elseif ( $comment > 1 ) {
				$comments = $comment . esc_html__(' Comments', 'zeguten');
			} else {
				$comments = esc_html__('1 Comment', 'zeguten');
		}
		
		$write_comments = '<a href="' . get_comments_link($post_id) .'">'. $comments.'</a>';


		$posts_output .= sprintf('<div class = "zeguten-post-item-wrapper">');

		$posts_output .= sprintf('<div class = "zeguten-post-item %1$s %2$s">', $post_thumbnail, $imgclass);

		
		if (isset($attributes['displayPostImage']) && $attributes['displayPostImage']) {
			if ( $attributes['imgOrder'] == '') {
				$posts_output .= zeguten_get_featured_image($post_id, $attributes);
			}
		}


		$posts_output .= sprintf('<div class = "zeguten-post-item-content">') ;

		if (isset($attributes['displayPostImage']) && $attributes['displayPostImage']){
			if ( $attributes['imgOrder'] != '' ) {
				$posts_output .= zeguten_get_featured_image( $post_id, $attributes );
			}
		}


        // Wrap the category contentecho 
		if (isset($attributes['displayPostCategory']) && $attributes['displayPostCategory']) {
			if ($attributes['categoryView'] == '') {
				$posts_output .= sprintf('<div class="ze-block-post-cat">%s</div>', $categories_list);
			}
		}


		//Get title tag
		if (isset($attributes['titleTag'])) {
			$post_title_tag = $attributes['titleTag'];
		} else {
			$post_title_tag = 'h2';
		}

		$posts_output .= sprintf('<%3$s class="ze-block-title"><a href="%1$s" rel="bookmark">%2$s</a></%3$s>', esc_url(get_permalink($post_id)), esc_html($title), esc_html($post_title_tag));

		$posts_output .= sprintf('<div class = "zeguten-meta-box">');

		$author_id = get_post_field ('post_author', $post_id);

		$write_author_link = '<a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID', $author_id ) ) ) .'">'. esc_html( get_the_author_meta('display_name', $author_id ) ) .'</a>';

		// Wrap the byline content
		if (isset($attributes['displayPostAuthor']) && $attributes['displayPostAuthor']) {
			$posts_output .= sprintf('<div class="ze-block-post-autor"><span>%2$s</span> %3$s %1$s</div>',
				$write_author_link,
				esc_html__('by', 'zeguten'),
				$icon_admin
			);
		}
		// Wrap the post date
		if ( isset( $attributes['displayPostDate'] ) && $attributes['displayPostDate'] ) {
			$posts_output .= sprintf(
				'<time datetime="%1$s" class="ze-block-post-date"><span>%3$s</span>%4$s%2$s</time>',
				esc_attr( get_the_date( 'F, Y', $post_id ) ),
				esc_html( get_the_date( '', $post_id ) ),
				esc_html__('on ', 'zeguten'),
				$icon_date
			);
		}

		if (isset($attributes['displayPostCategory']) && $attributes['displayPostCategory']) {
			
			if ($attributes['categoryView'] == 'MetaBox') {
				$posts_output .= sprintf('<span class="ze-block-post-cat"><span>%1$s</span>%2$s</span>', esc_html__('in ', 'zeguten'), $categories_list);
			}
		}

		$posts_output .=sprintf('</div>');

	    // Wrap the excerpt content
		if (isset($attributes['wordsExcerpt']) && $attributes['wordsExcerpt'] && isset( $attributes['displayPostExcerpt'] ) && $attributes['displayPostExcerpt']) {

			$link = '';

			if (isset($attributes['displayPostLink']) && $attributes['displayPostLink'] && $attributes['readmoreView'] === 'text-only'){

				$link = sprintf( '<a class="ze-button ze-link" href="%1$s" rel="bookmark">%2$s%3$s</a>', esc_url(get_permalink($post_id)), esc_html($attributes['readMoreText'] ),$icon_button );
			}
			
			$posts_output .= sprintf(
				'<p class="ze-block-post-excerpt">%1$s%2$s</p>', esc_html(wp_trim_words(get_the_excerpt($post_id, $attributes), $attributes['wordsExcerpt'])), $link);
		}

	    //Display Readmore  
		if (isset($attributes['displayPostLink']) && $attributes['displayPostLink']) {
			if ($attributes['readmoreView'] == 'ze-button') {
				$posts_output .= sprintf('<div class = "ze-block-post-btn" ><a class="ze-button ze-link" href="%1$s" rel="bookmark">%2$s%3$s</a></div>', esc_url(get_permalink($post_id)), esc_html($attributes['readMoreText']),$icon_button);
			}
		}

		//Get comments
		if (isset($attributes['displayPostComment']) && $attributes['displayPostComment']) {
			$posts_output .= sprintf('<div class="ze-block-post-comment">%2$s%1$s</div>', 
			$write_comments,$icon_comment);

		}


		// Wrap the tags content
		if (isset($attributes['displayPostTag']) && $attributes['displayPostTag'] && isset($tags_list) && $tags_list != '' ) {
			$posts_output .= sprintf('<div class="ze-block-post-tag">%3$s%1$s%2$s</div>', esc_html($attributes['prefixTags'] ), 
			$tags_list, $icon_tag);
		}

		$posts_output .= '</div>';

		$posts_output .= '</div>';

		$posts_output .= '</div>';

	}
		

	$class = "zeguten-latest-posts align-{$attributes['align']}";

	$baseClass = "zeguten-posts-block zeguten_block";

	$block_id = 'zeguten-posts-' . $attributes['block_id'];

	$default_class = 'zeguten-block-container';


	if ( isset( $attributes['entranceAnimation'] ) && $attributes['entranceAnimation'] ) {
		$blockAnimation = 'animated ' . esc_attr($attributes['entranceAnimation']);
	}

	if ( isset( $attributes['postLayout'] ) && 'grid' === $attributes['postLayout'] ) {
		$class .= ' is-grid';
	}
	if ( isset( $attributes['postLayout'] ) && 'uneven' === $attributes['postLayout'] ) {
		$class .= ' is-uneven';
	}
	if ( isset( $attributes['postLayout'] ) && 'masonry' === $attributes['postLayout'] ) {
		$class .= ' is-masonry';
	}
	
	if ( isset( $attributes['postLayout'] ) && 'list' === $attributes['postLayout'] ) {
		$class .= ' is-list';
	}

	if ( isset( $attributes['columns'] ) && 'grid' === $attributes['postLayout'] ) {
		$class .= ' col-desktop-' . $attributes['columns'];
	}

	if ( isset( $attributes['columnsTablet'] ) && 'grid' === $attributes['postLayout'] ) {
		$class .= ' col-tablet-' . $attributes['columnsTablet'];
	}

	if ( isset( $attributes['columnsMobile'] ) && 'grid' === $attributes['postLayout'] ) {
		$class .= ' col-mobile-' . $attributes['columnsMobile'];
	}

	if ( isset( $attributes['columnsList'] ) && 'list' === $attributes['postLayout'] ) {
		$class .= ' col-desktop-' . $attributes['columnsList'];
	}

	if ( isset( $attributes['columnsMasonry'] ) && 'masonry' === $attributes['postLayout'] ) {
		$class .= ' col-desktop-' . $attributes['columnsMasonry'];
	}
	if ( isset( $attributes['columnsTabletMasonry'] ) && 'masonry' === $attributes['postLayout'] ) {
		$class .= ' col-tablet-' . $attributes['columnsTabletMasonry'];
	}
	if ( isset( $attributes['columnsMobileMasonry'] ) && 'masonry' === $attributes['postLayout'] ) {
		$class .= ' col-mobile-' . $attributes['columnsMobileMasonry'];
	}

	if ( isset( $attributes['reverseColumns'] ) && $attributes['reverseColumns']  && 'uneven' === $attributes['postLayout'] ) {
		$class .= ' reverse-columns';
	}

	if ( isset( $attributes['className'] ) ) {
		$class .= '' . $attributes['className'];
	}


	$ZeGutenSlider = array(
		'slidesToScroll' => $attributes['slidesToScroll'],
		'arrows'          => $attributes['arrow'],
		'dots'           => $attributes['dots'],
		'slidesToShow'   => $attributes['columns'],
		'infinite'       => $attributes['infinite'],
		'adaptiveHeight' => $attributes['adaptiveHeight'],
		'draggable'      => true,
		'autoplay'		 => $attributes['autoplay'],
		'autoplaySpeed'  => $attributes['autoplaySpeed'],
		'pauseOnHover' 	 => $attributes['pauseOnHover'],
		'responsive'     => [
			[
				'breakpoint' => 1024,
				'settings'   => [
				'slidesToShow'   => $attributes['columns'],
				],
			],
			[
				'breakpoint' => zeguten_breakpoints_tablet,
				'settings'   => [
				'slidesToShow'   => $attributes['columnsTablet'],
				
				],
			],
			[
				'breakpoint' => zeguten_breakpoints_mobile,
				'settings'   => [
				'slidesToShow'   => $attributes['columnsMobile'],
				],
			],
		],
	);

	$slider_options = json_encode( $ZeGutenSlider );
	$attr = '';
	$blockAnimation = '';
	$attr_responsive = '';
	$attr_wow = '';

   	ob_start();

   	if ( isset( $attributes['postLayout'] ) && 'carousel' === $attributes['postLayout'] ) {
		$class .= ' zeguten-slick';
		$attr .= ' data-slick=' .  $slider_options .  '';
	}

	$wowDurationData  = $attributes['entranceAnimationDuration']  !== '' ? $attributes['entranceAnimationDuration'] : '2000ms';
    $wowDelayData  = $attributes['entranceAnimationDelay']     !== '' ? $attributes['entranceAnimationDelay']    : '500ms';

	if ( isset( $attributes['entranceAnimation'] ) && ( $attributes['entranceAnimation'] )) {
		$attr_wow .= ' data-wow-duration=' .  esc_attr($wowDurationData) .  '';
		$attr_wow .= ' data-wow-delay=' .  esc_attr($wowDelayData) .  '';
	}

	
	$responsiveDesktop = $attributes['responsiveDesktop']  !== true ? $attributes['responsiveDesktop'] : 'hidden';
	$responsiveTablet  = $attributes['responsiveTablet']   !== true ? $attributes['responsiveTablet']  : 'hidden';
	$responsiveMobile  = $attributes['responsiveMobile']   !== true ? $attributes['responsiveMobile']  : 'hidden';


	if (isset( $attributes['responsiveDesktop'] ) && ( $attributes['responsiveDesktop'] )) {
		$attr_responsive .= ' data-device-desktop=' .  esc_attr($responsiveDesktop) .  '';
	}

	if  (isset( $attributes['responsiveTablet'] ) && ( $attributes['responsiveTablet'] )){
		$attr_responsive .= ' data-device-tablet='  .  esc_attr($responsiveTablet)  .  '';
	}

	if  (isset( $attributes['responsiveMobile'] ) && ( $attributes['responsiveMobile'] )){
		$attr_responsive .= ' data-device-mobile='  .  esc_attr($responsiveMobile)  .  '';
	}

	return sprintf(
		'<div id="%1$s" class="%9$s"%6$s %7$s> <div class="%8$s %2$s %5$s" %4$s > %3$s </div> </div>',
		esc_attr($block_id),
		esc_attr($class),
		$posts_output,
		$attr,
		$blockAnimation,
		$attr_responsive,
		$attr_wow,
		$default_class,
		$baseClass
	);

	wp_reset_postdata();
}




/**
 * Create API fields for additional info
 *
 * @since 0.0.1
 */
function zeguten_blocks_register_rest_fields() {
	$post_type = ZeGuten_Helper::get_zeguten_post_types();

	foreach ( $post_type as $key => $value ) {
		// Add featured image source.
		register_rest_field(
			$value['value'],
			'zeguten_blocks_get_image_src',
			array(
				'get_callback'    => 'zeguten_blocks_get_image_src',
				'update_callback' => null,
				'schema'          => null,
			)
		);

		// Add author info
		register_rest_field(
			$value['value'],
			'zeguten_author_info',
			array(
				'get_callback'    => 'zeguten_blocks_get_author_info',
				'update_callback' => null,
				'schema'          => null,
			)
		);

		// Add category info
	    register_rest_field(
	        'post', 'category_info', array(
	        'get_callback' => 'zeguten_block_get_category_info',
	        'update_callback' => null,
	        'schema' => null,
	        )
	    );

	    // Add tags info
	    register_rest_field(
	        'post', 'tags_info', array(
	        'get_callback' => 'zeguten_block_get_tags_info',
	        'update_callback' => null,
	        'schema' => null,
	        )
	    );

		// Add comment info.
		register_rest_field(
			$value['value'],
			'zeguten_comment_info',
			array(
				'get_callback'    => 'zeguten_blocks_get_comment_info',
				'update_callback' => null,
				'schema'          => null,
			)
		);

		// Add excerpt info.
		register_rest_field(
			$value['value'],
			'zeguten_excerpt',
			array(
				'get_callback'    => 'zeguten_blocks_get_excerpt',
				'update_callback' => null,
				'schema'          => null,
			)
		);


	}
}

add_action( 'rest_api_init', 'zeguten_blocks_register_rest_fields' );

/**
 * Get featured image source for the rest field as per size
 *
 * @param object $object Post Object.
 * @param string $field_name Field name.
 * @param object $request Request Object.
 * @since 0.0.1
 */
function zeguten_blocks_get_image_src( $object, $field_name, $request ) {
	
	$image_sizes = ZeGuten_Helper::get_zeguten_image_sizes();

	$featured_images = array();

	if ( ! isset( $object['featured_media'] ) ) {
		return $featured_images;
	}

	foreach ( $image_sizes as $key => $value ) {
		$size = $value['value'];

		$featured_images[ $size ] = wp_get_attachment_image_src(
			$object['featured_media'],
			$size,
			false
		);
	}

	return $featured_images;
}

/**
 * Get author info for the rest field
 *
 * @param object $object Post Object.
 * @param string $field_name Field name.
 * @param object $request Request Object.
 * @since 0.0.1
 */
function zeguten_blocks_get_author_info( $object, $field_name, $request ) {

	$author = ( isset( $object['author'] ) ) ? $object['author'] : '';

	// Get the author name.
	$author_data['display_name'] = get_the_author_meta( 'display_name', $author );

	// Get the author link.
	$author_data['author_link'] = get_author_posts_url( $author );

	// Return the author data.
	return $author_data;
}

/**
 * Get category info for the rest field
 */
function zeguten_block_get_category_info($object, $field_name, $request) {
    $object['ID'] = '';
    $categories_list = get_the_category_list(",", "", $object['ID']);
    $cat_class = '';

    $category_info = sprintf('%1$s', $categories_list);
    // Return the category data
    return $category_info;
}

/**
 * Get tags info for the rest field
 */
function zeguten_block_get_tags_info($object, $field_name, $request) {
    // Get the author name
    $object['ID'] = '';

    $tags_list = get_the_tag_list("", ", ", "", $object['ID']);

    $tags_info = sprintf('%1$s', $tags_list);

    // Return the tag data
    return $tags_info;
}

/**
 * Get comment info for the rest field
 *
 * @param object $object Post Object.
 * @param string $field_name Field name.
 * @param object $request Request Object.
 * @since 0.0.1
 */
function zeguten_blocks_get_comment_info( $object, $field_name, $request ) {
	$object['ID'] = '';

	// Get the author link.
	$comments_data['comments_number'] = get_comments_number( $object['ID'] );

	$comments_data['comments_link'] =  get_comments_link( $object['ID'] );

	return $comments_data;
}

/**
 * Get excerpt for the rest field
 *
 * @param object $object Post Object.
 * @param string $field_name Field name.
 * @param object $request Request Object.
 * @since 0.0.1
 */
function zeguten_blocks_get_excerpt( $object, $field_name, $request ) {
	$excerpt = wp_trim_words( get_the_excerpt( $object['id'] ) );
	if ( ! $excerpt ) {
		$excerpt = null;
	}
	return $excerpt;
}




/**
 * Function Name: zeguten_get_icon.
 *
 * @param  array $attributes attribute array.
 * @return string             [description].
 */
function zeguten_get_icon( $attributes ) {
	if( $icon = $attributes){
		$htm  = ZeGuten_Helper::render_svg_html( $icon);
		$icon_class = 'zeguten__marker';
		$output     = '';
		$output    .= sprintf( '<span class = "%1$s" >', esc_attr( $icon_class ) );
		$output    .= $htm;
		$output    .= sprintf( '</span>' ); // End of icon span.

		return $output;
	}
}

/*
 *  Get the featured image
 */

function zeguten_get_featured_image($post_id, $attributes) {

    // Get the post thumbnail
    $zeguten_fetured_image = '';
    $post_thumb_id = get_post_thumbnail_id($post_id);
    if (isset($attributes['displayPostImage']) && $attributes['displayPostImage'] && $post_thumb_id) {

        $zeguten_fetured_image = sprintf('<figure class = "zeguten-post-item-image"><div class="ze-block-post-image"><a href="%1$s" rel="bookmark">%2$s</a></div></figure>', esc_url(get_permalink($post_id)), wp_get_attachment_image($post_thumb_id, $attributes['imgSize']));
    }
    return $zeguten_fetured_image;
}

/**
 * Registers the `zeguten/posts-block` block on server.
 */

function register_zeguten_post_block() {
// Check if the register function exists
	if (!function_exists('register_block_type')) {
		return;
	}
	register_block_type( 'zeguten/posts',
		array(
			'attributes' => array(
				'displayPostDate' => array(
					'type'    => 'boolean',
					'default' => true,
				),
				'slidesToScroll'            => array(
					'type'    => 'number',
					'default' => 1,
				),
				'pauseOnHover'            => array(
					'type'    => 'boolean',
					'default' => true,
				),
				'displayPostDivider' => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'block_id' => array(
					'type' => 'string',
					'default' => 'not_set',
				),
				'block_css' => array(
					'type' => 'string'
				),
				'postsToShow'  => array(
					'type'     => 'number',
					'default'  => 6,
				),
				'dots'  => array(
					'type'    => 'boolean',
					'default' => true,
				),
				'arrow'  => array(
					'type'    => 'boolean',
					'default' => true,
				),
				'infinite'  => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'adaptiveHeight'  => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'autoplay'  => array(
					'type'    => 'boolean',
					'default' => true,
				),
				'autoplaySpeed'  => array(
					'type'    => 'number',
					'default' =>  800,
				),
				'order'        => array(
					'type'     => 'string',
					'default'  => 'desc',
				),
				'tags_icon'   => array(
					'type'    => 'string',
					'default' => '',
				),
				'admin_icon'   => array(
					'type'    => 'string',
					'default' => '',
				),
				'comment_icon'   => array(
					'type'    => 'string',
					'default' => '',
				),
				'date_icon'   => array(
					'type'    => 'string',
					'default' => '',
				),
				'button_icon'   => array(
					'type'    => 'string',
					'default' => '',
				),
				'align' => array(
	                'type' => 'string',
	                'default' => 'left',
            	),
				'iconSizeButton'        => array(
					'type'    => 'number',
					'default'  => 16,
				),
				'iconSizeTags'        => array(
					'type'    => 'number',
					'default'  => 16,
				),
				'iconSizeAdmin'        => array(
					'type'    => 'number',
					'default'  => 16,
				),
				'iconSizeComment'        => array(
					'type'    => 'number',
					'default'  => 16,
				),
				'iconSizeDate' => array(
					'type'    => 'number',
					'default'  => 16,
				),
				'orderBy'      => array(
					'type'     => 'string',
					'default'  => 'date',
				),
				'categories'  => array(
					'type'    => 'array',
					'items' => array(
						'type'    => 'object',
					),
				),
				'displayPostTag' => array(
					'type' => 'boolean',
					'default' => true,
				),
				'displayPostExcerpt'   => array(
					'type'     		   => 'boolean',
					'default'		   =>  true,
				),
				'displayPostAuthor'    => array(
					'type'     		   => 'boolean',
					'default'		   =>  true,
				),
				'displayPostLink'      => array(
					'type'     		   => 'boolean',
					'default'		   =>  true,
				),
				'readmoreView' 		   => array(
					'type' 			   => 'string',
					'default'          => 'ze-button',
				),
				'categoryView'		   => array(
					'type' 			   => 'string',
					'default'          => '',
				),
				'readmoreWidth' 	   => array(
					'type' 			   => 'string',
					'default'          => 'inline-block',
				),
				'readMoreText'         => array(
					'type'             => 'string',
					'default'          => 'Read More',
				),
				'prefixTags' 		   => array(
					'type'             => 'string',
					'default'          => 'Tags:',
				),
				'postContentAlign'  => array(
					'type'    => 'string',
					'default' => 'left',
				),
				'postLayout'  => array(
					'type'    => 'string',
					'default' => 'grid',
				),
				'imgPosition'  => array(
					'type'    => 'string',
					'default' => '',
				),
				'columnsList'   => array(
					'type'    => 'number',
					'default' => 1,
				),
				'offset' => array(
					'type'    => 'number',
				),
				'columnsMasonry'   => array(
					'type'    => 'number',
					'default' => 2,
				),
				'columnsTabletMasonry'   => array(
					'type'    => 'number',
					'default' => 2,
				),
				'columnsMobileMasonry'   => array(
					'type'    => 'number',
					'default' => 1,
				),
				'columns'   => array(
					'type'    => 'number',
					'default' => 2,
				),
				'columnsTablet'   => array(
					'type'    => 'number',
					'default' => 2,
				),
				'columnsMobile'   => array(
					'type'    => 'number',
					'default' => 1,
				),
				'className'  => array(
					'type' => 'string',
				),
				'wordsExcerpt' => array(
					'type' => 'number',
					'default' => 5,
				),
				'displayPostCategory' => array(
					'type' => 'boolean',
					'default' => true,
				),
				'displayPostImage' => array(
					'type' => 'boolean',
					'default' => true,
				),
				'reverseColumns' => array(
					'type' => 'boolean',
					'default' =>  false,
				),
				'titleTag'  => array(
					'type' => 'string',
					'default' => 'h2',
				),
				'titleFontSize' => array(
					'type'      => 'number',
				),
				'titleFontSizeType' => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'titleFontSizeMobile'  => array(
					'type' => 'number',
				),
				'titleFontSizeTablet'  => array(
					'type' => 'number',
				),
				'titleFontFamily'         => array(
					'type'    => 'string',
					'default' => '',
				),
				'titleFontWeight'         => array(
					'type' => 'string',
				),
				'titleFontSubset'         => array(
					'type' => 'string',
				),
				'titleLineHeightType'     => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'titleLineHeight'         => array(
					'type'    => 'number',
				),
				'titleLineHeightTablet'   => array(
					'type'    => 'number',
				),
				'titleLineHeightMobile'   => array(
					'type'    => 'number',
				),
				'titleLoadGoogleFonts'    => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'titleLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'em',
				),

				'columnMarginType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),

				'rowMarginType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'titleLetterSpacing' => array(
					'type'  => 'number',
				),
				'titleLetterSpacingTablet' => array(
					'type'  => 'number',
				),
				'titleLetterSpacingMobile' => array(
					'type'  => 'number',
				),
				'categoriesLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'categoriesLetterSpacing' => array(
					'type'    => 'number',
				),
				'categoriesLetterSpacingTablet' => array(
					'type'  => 'number',
				),
				'categoriesLetterSpacingMobile' => array(
					'type'  => 'number',
				),
				'dateLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'dateLetterSpacing' => array(
					'type'    => 'number',
				),
				'dateLetterSpacingTablet' => array(
					'type'  => 'number',
				),
				'dateLetterSpacingMobile' => array(
					'type'  => 'number',
				),
				'dateLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'em',
				),
				
				'categoriesFontFamily' => array(
					'type' => 'string',
					'default' => '',
				),
				'categoriesFontWeight' => array(
					'type' => 'string',
					'default' => '',
				),
				'categoriesFontSubset' => array(
					'type' => 'string',
					'default' => '',
				),
				'categoriesFontSize' => array(
					'type'  => 'number',
				),
				'categoriesFontSizeTablet' => array(
					'type'   => 'number',
				),
				'categoriesFontSizeMobile' => array(
					'type'  => 'number',
				),
				'categoriesLineHeight' => array(
					'type'  => 'number',
				),
				'categoriesLineHeightTablet' => array(
					'type'  => 'number',
				),
				'categoriesLineHeightMobile' => array(
					'type'  => 'number',
				),
				'categoriesFontSizeType' => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'categoriesLineHeightType' => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'dateFontFamily' => array(
					'type' => 'string',
					'default' => '',
				),
				'dateFontWeight' => array(
					'type' => 'string',
					'default' => '',
				),
				'dateFontSubset' => array(
					'type' => 'string',
					'default' => '',
				),
				'dateFontSize' => array(
					'type'  => 'number',
				),
				'dateFontSizeTablet' => array(
					'type'  => 'number',
				),
				'dateFontSizeMobile' => array(
					'type'  => 'number',
				),
				'dateLineHeight' => array(
					'type'  => 'number',
				),
				'dateLineHeightTablet' => array(
					'type'  => 'number',
				),
				'dateLineHeightMobile' => array(
					'type'  => 'number',
				),
				'dateFontSizeType' => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'dateLineHeightType' => array(
					'type'    => 'string',
					'default' => 'em',
				),

				'authorLoadGoogleFonts'    => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'authorFontFamily' => array(
					'type' => 'string',
					'default' => '',
				),
				'authorFontWeight' => array(
					'type' => 'string',
					'default' => '',
				),
				'authorFontSubset' => array(
					'type' => 'string',
					'default' => '',
				),
				'authorFontSize' => array(
					"type"  => "number",
				),
				'authorFontSizeTablet' => array(
					"type"  => "number",
				),
				'authorFontSizeMobile' => array(
					'type'  => "number",
				),
				'authorLineHeight' => array(
					'type'  => "number",
				),
				'authorLineHeightTablet' => array(
					'type'  => "number",
				),
				'authorLineHeightMobile' => array(
					"type" => "number",
				),
				'authorFontSizeType' => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'authorLineHeightType' => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'authorTextTransform'     => array(
					'type'    => 'string',
				),
				'authorFontStyle'     => array(
					'type'    => 'string',
				),
				'authorTextDecoration'     => array(
					'type'    => 'string',
				),
				'authorLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'authorLetterSpacing' => array(
					'type'  => "number",
				),
				'authorLetterSpacingTablet' => array(
					'type'  => "number",
				),
				'authorLetterSpacingMobile' => array(
					'type'  => "number",
				),

				'categoriesLoadGoogleFonts'    => array(
					'type'    => 'boolean',
					'default' => false,
				),

				'dateLoadGoogleFonts'    => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'desktopMarginType'    => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'innerMarginType'    => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'titlemarginBottomMobile'    => array(
					'type'    => 'number',
				),
				'titlemarginBottomTablet'    => array(
					'type'    => 'number',
				),
				'titlemarginBottom'    => array(
					'type'    => 'number',
				),
				'categoriesmarginBottom'    => array(
					'type'    => 'number',
				),
				'categoriesmarginBottomMobile'    => array(
					'type'    => 'number',
				),
				'categoriesmarginBottomTablet'    => array(
					'type'    => 'number',
				),
				'columnGap'    => array(
					'type'    => 'number',
					'default'  => 20,
 				),
				'columnGapMobile'    => array(
					'type'    => 'number',
				),
				'columnGapTablet'    => array(
					'type'    => 'number',
				),
				'innerGap'    => array(
					'type'    => 'number',
				),
				'innerGapMobile'    => array(
					'type'    => 'number',
				),
				'innerGapTablet'    => array(
					'type'    => 'number',
				),
				'rowGap'    => array(
					'type'    => 'number',
				),
				'rowGapMobile'    => array(
					'type'    => 'number',
				),
				'rowGapTablet'    => array(
					'type'    => 'number',
				),
				'imgSize'     => array(
					'type'    => 'string',
					'default' => 'zeguten-blog-image',
				),
				'titleTextTransform'     => array(
					'type'    => 'string',
				),
				'titleFontStyle'     => array(
					'type'    => 'string',
				),
				'titleTextDecoration'     => array(
					'type'    => 'string',
				),
				
				'categoriesTextTransform'     => array(
					'type'    => 'string',
				),
				'categoriesFontStyle'     => array(
					'type'    => 'string',
				),
				'categoriesTextDecoration'     => array(
					'type'    => 'string',
				),
				'dateTextTransform'     => array(
					'type'    => 'string',
				),
				'dateFontStyle'     => array(
					'type'    => 'string',
				),
				'dateTextDecoration'     => array(
					'type'    => 'string',
				),
				'excerptLoadGoogleFonts'    => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'excerptFontFamily' => array(
					'type' => 'string',
					'default' => '',
				),
				'excerptFontWeight' => array(
					'type' => 'string',
					'default' => '',
				),
				'excerptFontSubset' => array(
					'type' => 'string',
					'default' => '',
				),
				'excerptFontSize' => array(
					'type'  => 'number',
				),
				'excerptFontSizeTablet' => array(
					'type'  => 'number',
				),
				'excerptFontSizeMobile' => array(
					'type'  => 'number',
				),
				'excerptLineHeight' => array(
					'type'  => 'number',
				),
				'excerptLineHeightTablet' => array(
					'type'  => 'number',
				),
				'excerptLineHeightMobile' => array(
					'type'  => 'number',
				),
				'excerptFontSizeType' => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'excerptLineHeightType' => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'excerptLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'excerptLetterSpacing' => array(
					'type'    => 'number',
				),
				'excerptLetterSpacingTablet' => array(
					'type'  => 'number',
				),
				'excerptLetterSpacingMobile' => array(
					'type'  => 'number',
				),
				'excerptLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'excerptTextTransform'     => array(
					'type'    => 'string',
				),
				'excerptFontStyle'     => array(
					'type'    => 'string',
				),
				'excerptTextDecoration'     => array(
					'type'    => 'string',
				),
				'tagsLoadGoogleFonts'    => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'tagsFontFamily' => array(
					'type' => 'string',
					'default' => '',
				),
				'tagsFontWeight' => array(
					'type' => 'string',
					'default' => '',
				),
				'tagsFontSubset' => array(
					'type' => 'string',
					'default' => '',
				),
				'tagsFontSize' => array(
					'type'  => 'number',
				),
				'tagsFontSizeTablet' => array(
					'type'  => 'number',
				),
				'tagsFontSizeMobile' => array(
					'type'  => 'number',
				),
				'tagsLineHeight' => array(
					'type'  => 'number',
				),
				'tagsLineHeightTablet' => array(
					'type'  => 'number',
				),
				'tagsLineHeightMobile' => array(
					'type'  => 'number',
				),
				'tagsFontSizeType' => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'tagsLineHeightType' => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'tagsLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'tagsLetterSpacing' => array(
					'type'    => 'number',
				),
				'tagsLetterSpacingTablet' => array(
					'type'  => 'number',
				),
				'tagsLetterSpacingMobile' => array(
					'type'  => 'number',
				),
				'tagsLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'tagsTextTransform'     => array(
					'type'    => 'string',
				),
				'tagsFontStyle'     => array(
					'type'    => 'string',
				),
				'tagsTextDecoration'     => array(
					'type'    => 'string',
				),
				'bgColor'  => array(
					'type'    => 'string',
				),
				'titleColor'  => array(
					'type'    => 'string',
				),
				'titleHoverColor'  => array(
					'type'    => 'string',
				),

				'borderStyle'  => array(
					'type'    => 'string',
				),

				'borderWidthTop'  => array(
					'type'    => 'string',
				),
				'borderWidthRight'  => array(
					'type'    => 'string',
				),
				'borderWidthBottom'  => array(
					'type'    => 'string',
				),
				'borderWidthLeft'  => array(
					'type'    => 'string',
				),

				'borderWidthTopTablet'  => array(
					'type'    => 'string',
				),
				'borderWidthRightTablet'  => array(
					'type'    => 'string',
				),
				'borderWidthBottomTablet'  => array(
					'type'    => 'string',
				),
				'borderWidthLeftTablet'  => array(
					'type'    => 'string',
				),

				'borderWidthTopMobile'  => array(
					'type'    => 'string',
				),
				'borderWidthRightMobile'  => array(
					'type'    => 'string',
				),
				'borderWidthBottomMobile'  => array(
					'type'    => 'string',
				),
				'borderWidthLeftMobile'  => array(
					'type'    => 'string',
				),

				'borderRadiusTop'  => array(
					'type'    => 'string',
				),
				'borderRadiusLeft'  => array(
					'type'    => 'string',
				),
				'borderRadiusRight'  => array(
					'type'    => 'string',
				),
				'borderRadiusBottom'  => array(
					'type'    => 'string',
				),

				'borderRadiusTopTablet'  => array(
					'type'    => 'string',
				),
				'borderRadiusLeftTablet'  => array(
					'type'    => 'string',
				),
				'borderRadiusRightTablet'  => array(
					'type'    => 'string',
				),
				'borderRadiusBottomTablet'  => array(
					'type'    => 'string',
				),

				'borderRadiusTopMobile'  => array(
					'type'    => 'string',
				),
				'borderRadiusLeftMobile'  => array(
					'type'    => 'string',
				),
				'borderRadiusRightMobile'  => array(
					'type'    => 'string',
				),
				'borderRadiusBottomMobile'  => array(
					'type'    => 'string',
				),

				'borderColor'  => array(
					'type'    => 'string',
				),
				'borderSizeType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'borderWidthType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'dateColor'  => array(
					'type'    => 'string',
				),
				'tagsColor'  => array(
					'type'    => 'string',
				),
				'categoriesColor'  => array(
					'type'    => 'string',
				),
				'excerptColor'  => array(
					'type'    => 'string',
				),
				'authorColor'  => array(
					'type'    => 'string',
				),
				'authorHoverColor'  => array(
					'type'    => 'string',
				),
				'tagsHoverColor'  => array(
					'type'    => 'string',
				),
				'categoriesHoverColor'  => array(
					'type'    => 'string',
				),
				'contentPaddingTop'  => array(
					'type'    => 'string',
				),
				'contentPaddingRight'  => array(
					'type'    => 'string',
				),
				'contentPaddingBottom'  => array(
					'type'    => 'string',
				),
				'contentPaddingLeft'  => array(
					'type'    => 'string',
				),
				'itemPaddingType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'contentPaddingType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'contentPaddingTopTablet'  => array(
					'type'    => 'string',
				),
				'contentPaddingRightTablet'  => array(
					'type'    => 'string',
				),
				'contentPaddingBottomTablet'  => array(
					'type'    => 'string',
				),
				'contentPaddingLeftTablet'  => array(
					'type'    => 'string',
				),
				'contentPaddingTopMobile'  => array(
					'type'    => 'string',
				),
				'contentPaddingRightMobile'  => array(
					'type'    => 'string',
				),
				'contentPaddingBottomMobile'  => array(
					'type'    => 'string',
				),
				'contentPaddingLeftMobile'  => array(
					'type'    => 'string',
				),

				'displayPostComment'      => array(
					'type'    => 'boolean',
					'default' => true,
				),
				'buttonLoadGoogleFonts'    => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'buttonFontFamily' => array(
					'type' => 'string',
					'default' => '',
				),
				'buttonFontWeight' => array(
					'type' => 'string',
					'default' => '',
				),
				'buttonFontSubset' => array(
					'type' => 'string',
					'default' => '',
				),
				'buttonFontSize' => array(
					'type'  => 'number',
				),
				'buttonFontSizeTablet' => array(
					'type'  => 'number',
				),
				'buttonFontSizeMobile' => array(
					'type'  => 'number',
				),
				'buttonLineHeight' => array(
					'type'  => 'number',
				),
				'buttonLineHeightTablet' => array(
					'type'  => 'number',
				),
				'buttonLineHeightMobile' => array(
					'type'  => 'number',
				),
				'buttonFontSizeType' => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'buttonLineHeightType' => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'buttonLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'buttonLetterSpacing' => array(
					'type'    => 'number',
				),
				'buttonLetterSpacingTablet' => array(
					'type'  => 'number',
				),
				'buttonLetterSpacingMobile' => array(
					'type'  => 'number',
				),
				'buttonLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'buttonTextTransform'     => array(
					'type'    => 'string',
				),
				'buttonFontStyle'     => array(
					'type'    => 'string',
				),
				'buttonTextDecoration'     => array(
					'type'    => 'string',
				),
				'buttonPaddingTop'  => array(
					'type'    => 'string',
				),
				'buttonPaddingRight'  => array(
					'type'    => 'string',
				),
				'buttonPaddingBottom'  => array(
					'type'    => 'string',
				),
				'buttonPaddingLeft'  => array(
					'type'    => 'string',
				),
				'buttonPaddingTopTablet'  => array(
					'type'    => 'string',
				),
				'buttonPaddingRightTablet'  => array(
					'type'    => 'string',
				),
				'buttonPaddingBottomTablet'  => array(
					'type'    => 'string',
				),
				'buttonPaddingLeftTablet'  => array(
					'type'    => 'string',
				),
				'buttonPaddingTopMobile'  => array(
					'type'    => 'string',
				),
				'buttonPaddingRightMobile'  => array(
					'type'    => 'string',
				),
				'buttonPaddingBottomMobile'  => array(
					'type'    => 'string',
				),
				'buttonPaddingLeftMobile'  => array(
					'type'    => 'string',
				),
				'buttonPaddingType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'borderStyleButton'  => array(
					'type'    => 'string',
				),
				'buttonBorderColor'  => array(
					'type'    => 'string',
				),
				'buttonBorderWidthTop'  => array(
					'type'    => 'string',
				),
				'buttonBorderWidthRight'  => array(
					'type'    => 'string',
				),
				'buttonBorderWidthBottom'  => array(
					'type'    => 'string',
				),
				'buttonBorderWidthLeft'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusTop'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusLeft'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusRight'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusBottom'  => array(
					'type'    => 'string',
				),

				'buttonBorderWidthTopTablet'  => array(
					'type'    => 'string',
				),
				'buttonBorderWidthRightTablet'  => array(
					'type'    => 'string',
				),
				'buttonBorderWidthBottomTablet'  => array(
					'type'    => 'string',
				),
				'buttonBorderWidthLeftTablet'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusTopTablet'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusLeftTablet'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusRightTablet'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusBottomTablet'  => array(
					'type'    => 'string',
				),

				'buttonBorderWidthTopMobile'  => array(
					'type'    => 'string',
				),
				'buttonBorderWidthRightMobile'  => array(
					'type'    => 'string',
				),
				'buttonBorderWidthBottomMobile'  => array(
					'type'    => 'string',
				),
				'buttonBorderWidthLeftMobile'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusTopMobile'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusLeftMobile'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusRightMobile'  => array(
					'type'    => 'string',
				),
				'buttonBorderRadiusBottomMobile'  => array(
					'type'    => 'string',
				),
				'buttonBorderColor'  => array(
					'type'    => 'string',
				),
				'buttonBorderWidthType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'buttonBorderSizeType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'buttonMarginTop'  => array(
					'type'    => 'string',
				),
				'buttonMarginRight'  => array(
					'type'    => 'string',
				),
				'buttonMarginBottom'  => array(
					'type'    => 'string',
				),
				'buttonMarginLeft'  => array(
					'type'    => 'string',
				),
				'buttonMarginTopTablet'  => array(
					'type'    => 'string',
				),
				'buttonMarginRightTablet'  => array(
					'type'    => 'string',
				),
				'buttonMarginBottomTablet'  => array(
					'type'    => 'string',
				),
				'buttonMarginLeftTablet'  => array(
					'type'    => 'string',
				),
				'buttonMarginTopMobile'  => array(
					'type'    => 'string',
				),
				'buttonMarginRightMobile'  => array(
					'type'    => 'string',
				),
				'buttonMarginBottomMobile'  => array(
					'type'    => 'string',
				),
				'buttonMarginLeftMobile'  => array(
					'type'    => 'string',
				),				
				'buttonMarginType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'readmoreColor'  => array(
					'type'    => 'string',
				),
				'readmoreBgColor'  => array(
					'type'    => 'string',
				),
				'readmoreHoverColor'  => array(
					'type'    => 'string',
				),
				'readmoreBgColorHover'  => array(
					'type'    => 'string',
				),
				'readmoreBorderColorHover'  => array(
					'type'    => 'string',
				),
				'commentFontSize'           => array(
					'type'    => 'number',
				),
				'commentFontStyle'           => array(
					'type'    => 'string',
					'default'  => '',
				),
				'commentFontSizeType'       => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'commentFontSizeMobile'     => array(
					'type'    => 'number',
				),
				'commentFontSizeTablet'     => array(
					'type'    => 'number',
				),
				'commentFontFamily'         => array(
					'type'    => 'string',
					'default' => '',
				),
				'commentFontWeight'         => array(
					'type' => 'string',
				),
				'commentFontSubset'         => array(
					'type' => 'string',
				),
				'commentLineHeightType'     => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'commentLineHeight'         => array(
					'type'    => 'number',
				),
				'commentLineHeightTablet'   => array(
					'type'    => 'number',
				),
				'commentLineHeightMobile'   => array(
					'type'    => 'number',
				),
				'commentLoadGoogleFonts'    => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'commentLetterSpacingType'  => array(
					'type'    => 'string',
					'default' => 'em',
				),
				'commentLetterSpacing' => array(
					'type'    => 'number',
				),
				'commentLetterSpacingTablet' => array(
					'type'  => 'number',
				),
				'commentLetterSpacingMobile' => array(
					'type'  => 'number',
				),
				'commentTextTransform'     => array(
					'type'    => 'string',
				),
				'commentFontStyle'     => array(
					'type'    => 'string',
				),
				'commentTextDecoration'     => array(
					'type'    => 'string',
				),
				'commentColor'  => array(
					'type'    => 'string',
				),
				'commentColorHover'  => array(
					'type'    => 'string',
				),
				'imagePaddingTop'  => array(
					'type'    => 'string',
				),
				'imagePaddingRight'  => array(
					'type'    => 'string',
				),
				'imagePaddingBottom'  => array(
					'type'    => 'string',
				),
				'imagePaddingLeft'  => array(
					'type'    => 'string',
				),
				'imagePaddingTopTablet'  => array(
					'type'    => 'string',
				),
				'imagePaddingRightTablet'  => array(
					'type'    => 'string',
				),
				'imagePaddingBottomTablet'  => array(
					'type'    => 'string',
				),
				'imagePaddingLeftTablet'  => array(
					'type'    => 'string',
				),
				'imagePaddingTopMobile'  => array(
					'type'    => 'string',
				),
				'imagePaddingRightMobile'  => array(
					'type'    => 'string',
				),
				'imagePaddingBottomMobile'  => array(
					'type'    => 'string',
				),
				'imagePaddingLeftMobile'  => array(					
					'type'    => 'string',
				),	
				'imagePaddingType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'imageMarginTopMobile'  => array(
					'type'    => 'string',
				),
				'imageMarginRightMobile'  => array(
					'type'    => 'string',
				),
				'imageMarginBottomMobile'  => array(
					'type'    => 'string',
				),
				'imageMarginLeftMobile'  => array(
					'type'    => 'string',
				),
				'imageMarginTopTablet'  => array(
					'type'    => 'string',
				),
				'imageMarginRightTablet'  => array(
					'type'    => 'string',
				),
				'imageMarginBottomTablet'  => array(
					'type'    => 'string',
				),
				'imageMarginLeftTablet'  => array(
					'type'    => 'string',
				),
				'borderStyleImage'  => array(
					'type'    => 'string',
				),
				'imageBorderWidthTop'  => array(
					'type'    => 'string',
				),
				'imageBorderWidthRight'  => array(
					'type'    => 'string',
				),
				'imageBorderWidthBottom'  => array(
					'type'    => 'string',
				),
				'imageBorderWidthLeft'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusTop'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusLeft'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusRight'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusBottom'  => array(
					'type'    => 'string',
				),

				'imageBorderWidthTopTablet'  => array(
					'type'    => 'string',
				),
				'imageBorderWidthRightTablet'  => array(
					'type'    => 'string',
				),
				'imageBorderWidthBottomTablet'  => array(
					'type'    => 'string',
				),
				'imageBorderWidthLeftTablet'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusTopTablet'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusLeftTablet'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusRightTablet'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusBottomTablet'  => array(
					'type'    => 'string',
				),	


				'imageBorderWidthTopMobile'  => array(
					'type'    => 'string',
				),
				'imageBorderWidthRightMobile'  => array(
					'type'    => 'string',
				),
				'imageBorderWidthBottomMobile'  => array(
					'type'    => 'string',
				),
				'imageBorderWidthLeftMobile'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusTopMobile'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusLeftMobile'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusRightMobile'  => array(
					'type'    => 'string',
				),
				'imageBorderRadiusBottomMobile'  => array(
					'type'    => 'string',

				),
				'imageBorderColor'  => array(
					'type'    => 'string',
				),

				'imageBorderStyle'  => array(
					'type'    => 'string',
				),

				'imageBorderSizeType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'imageBorderWidthType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'imageBgColor'  => array(
					'type'    => 'string',
				),
				'metaBoxMarginBottomMobile'    => array(
					'type'    => 'string',
				),
				'metaBoxMarginBottomTablet'    => array(
					'type'    => 'number',
				),
				'metaBoxMarginBottom'    => array(
					'type'    => 'number',
				),
				'excerptMarginBottom'    => array(
					'type'    => 'number',
				),
				'excerptMarginBottomMobile'    => array(
					'type'    => 'number',
				),
				'excerptMarginBottomTablet'    => array(
					'type'    => 'number',
				),
				'commentsMarginBottom'    => array(
					'type'    => 'number',
				),
				'commentsMarginBottomTablet'    => array(
					'type'    => 'number',
				),
				'commentsMarginBottomMobile'    => array(
					'type'    => 'number',
				),
				'tagsMarginBottom'    => array(
					'type'    => 'number',
				),
				'tagsMarginBottomMobile'    => array(
					'type'    => 'number',
				),
				'tagsMarginBottomTablet'    => array(
					'type'    => 'number',
				),
				'contentAlign' => array(
					'type'    => 'string',
					'default'    => '',
				),
				'contentListAlign' => array(
					'type'    => 'string',
				),
				'tagsOrder'    => array(
					'type'    => 'string',
				),
				'titleOrder'    => array(
					'type'    => 'string',
				),
				'metaBoxOrder'    => array(
					'type'    => 'string',
				),
				'excerptOrder'    => array(
					'type'    => 'string',
				),
				'categoriesOrder'   => array(
					'type'    => 'string',
				),
				'commentsOrder'    => array(
					'type'    => 'string',
				),
				'buttonOrder' => array(
					'type'    => 'string',
				),
				'imgOrder' => array(
					'type'    => 'string',
					'default'    => '',
				),
				'dividerColor' => array(
					'type'    => 'string',
				),
				'filterById' => array(
					'type'    => 'string',
				),
				'imageMarginTop'  => array(
					'type'    => 'number',
				),
				'imageMarginRight'  => array(
					'type'    => 'number',
				),
				'imageMarginBottom'  => array(
					'type'    => 'number',
				),
				'imageMarginLeft'  => array(
					'type'    => 'number',
				),
				'imageMarginType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'itemPaddingTopTablet'  => array(
					'type'    => 'string',
				),
				'itemPaddingRightTablet'  => array(
					'type'    => 'string',
				),
				'itemPaddingBottomTablet'  => array(
					'type'    => 'string',
				),
				'itemPaddingLeftTablet'  => array(
					'type'    => 'string',
				),
				'itemPaddingTop'  => array(
					'type'    => 'string',
				),
				'itemPaddingRight'  => array(
					'type'    => 'string',
				),
				'itemPaddingBottom'  => array(
					'type'    => 'string',
				),
				'itemPaddingLeft'  => array(
					'type'    => 'string',
				),
				'itemPaddingTopMobile'  => array(
					'type'    => 'string',
				),
				'itemPaddingRightMobile'  => array(
					'type'    => 'string',
				),
				'itemPaddingBottomMobile'  => array(
					'type'    => 'string',
				),
				'itemPaddingLeftMobile'  => array(
					'type'    => 'string',
				),

				'verticalPositionArrow' => array(
					'type'    => 'string',
				),
				'topIndentArrow'  => array(
					'type'    => 'number',
				),
				'bottomIndentArrow'  => array(
					'type'    => 'number',
				),

				'horizontalPositionArrow' => array(
					'type'    => 'string',
				),
				'leftIndentArrow'  => array(
					'type'    => 'number',
				),
				'rightIndentArrow'  => array(
					'type'    => 'number',
				),

				
				'verticalPositionArrowNext' => array(
					'type'    => 'string',
				),
				'topIndentArrowNext'  => array(
					'type'    => 'number',
				),
				'bottomIndentArrowNext'  => array(
					'type'    => 'number',
				),

				'horizontalPositionArrowNext' => array(
					'type'    => 'string',
				),
				'leftIndentArrowNext'  => array(
					'type'    => 'number',
				),
				'rightIndentArrowNext'  => array(
					'type'    => 'number',
				),

				//	Carousel Dots
				'carouselDotsStyle' => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'carouselDotsWidth' => array(
					'type'    => 'number',
				),
				'carouselDotsWidthHover' => array(
					'type'    => 'number',
				),
				'carouselDotsWidthActive' => array(
					'type'    => 'number',
				),
				'carouselDotsHeight' => array(
					'type'    => 'number',
				),
				'carouselDotsHeightHover' => array(
					'type'    => 'number',
				),
				'carouselDotsHeightActive' => array(
					'type'    => 'number',
				),
				'carouselDotsTopIndent' => array(
					'type'    => 'number',
				),
				'carouselDotsIndent' => array(
					'type'    => 'number',
				),
				'carouselDotsAlign' => array(
					'type'    => 'string',
					'default' => 'center',
				),

		 		'carouselDotsBgColor' => array(
					'type'    => 'string',
				),
				'carouselDotsBorderStyle' => array(
					'type'    => 'string',
				),
				'carouselDotsBorderWidthType' => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'carouselDotsBorderWidthTop' => array(
					'type' => 'string'
				),
				'carouselDotsBorderWidthTopMobile' => array(
					'type' => 'string'
				),
				'carouselDotsBorderWidthTopTablet' => array(
					'type' => 'string'
				),
				'carouselDotsBorderWidthLeft' => array(
					'type' => 'string'
				),
				'carouselDotsBorderWidthLeftMobile' => array(
					'type' => 'string'
				),
				'carouselDotsBorderWidthLeftTablet' => array(
					'type' => 'string'
				),
				'carouselDotsBorderWidthBottom' => array(
					'type' => 'string'
				),
				'carouselDotsBorderWidthBottomMobile' => array(
					'type' => 'string'
				),
				'carouselDotsBorderWidthBottomTablet' => array(
					'type' => 'string'
				),
				'carouselDotsBorderWidthRight' => array(
					'type' => 'string'
				),
				'carouselDotsBorderWidthRightMobile' => array(
					'type' => 'string'
				),
				'carouselDotsBorderWidthRightTablet' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusType' => array(
					'type'    => 'string',
					'default' => 'px'
				),
				'carouselDotsBorderRadiusTop' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusTopMobile' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusTopTablet' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusLeft' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusLeftMobile' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusLeftTablet' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusBottom' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusBottomMobile' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusBottomTablet' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusRight' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusRightMobile' => array(
					'type' => 'string'
				),
				'carouselDotsBorderRadiusRightTablet' => array(
					'type' => 'string'
				),
				'carouselDotsBorderColor' => array(
					'type'    => 'string',
				),
				'carouselDotsShadowHorizontal' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowVertical' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowBlur' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowSpread' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowColor' => array(
					'type'    => 'string',
				),
				'carouselDotsShadowPosition' => array(
					'type'    => 'string',
				),

				'blockShadowHorizontal' => array(
					'type'    => 'number',
				),
				'blockShadowVertical' => array(
					'type'    => 'number',
				),
				'blockShadowBlur' => array(
					'type'    => 'number',
				),
				'blockShadowSpread' => array(
					'type'    => 'number',
				),
				'blockShadowColor' => array(
					'type'    => 'string',
				),
				'blockShadowPosition' => array(
					'type'    => 'string',
				),

				'carouselDotsBgColorHover' => array(
					'type'    => 'string',
				),
				'carouselDotsBorderColorHover' => array(
					'type'    => 'string',
				),
				'carouselDotsShadowHorizontalHover' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowVerticalHover' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowBlurHover' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowSpreadHover' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowColorHover' => array(
					'type'    => 'string',
				),
				'carouselDotsShadowPositionHover' => array(
					'type'    => 'string',
				),

				'carouselDotsBgColorActive' => array(
					'type'    => 'string',
				),
				'carouselDotsBorderColorActive' => array(
					'type'    => 'string',
				),
				'carouselDotsShadowHorizontalActive' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowVerticalActive' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowBlurActive' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowSpreadActive' => array(
					'type'    => 'number',
				),
				'carouselDotsShadowColorActive' => array(
					'type'    => 'string',
				),
				'carouselDotsShadowPositionActive' => array(
					'type'    => 'string',
				),
				//	Carousel Arrows
				'carouselArrowsPaddingType' => array(
					'type' => 'string',
					'default' => 'px'
				),
				'carouselArrowsPaddingTop' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingTopMobile' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingTopTablet' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingLeft' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingLeftMobile' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingLeftTablet' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingBottom' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingBottomMobile' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingBottomTablet' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingRight' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingRightMobile' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingRightTablet' => array(
					'type' => 'string'
				),

				'carouselArrowsPaddingTypeHover' => array(
					'type' => 'string',
					'default' => 'px'
				),
				'carouselArrowsPaddingTopHover' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingTopMobileHover' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingTopTabletHover' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingLeftHover' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingLeftMobileHover' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingLeftTabletHover' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingBottomHover' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingBottomMobileHover' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingBottomTabletHover' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingRightHover' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingRightMobileHover' => array(
					'type' => 'string'
				),
				'carouselArrowsPaddingRightTabletHover' => array(
					'type' => 'string'
				),

				'carouselArrowsBGColor' => array(
					'type'    => 'string',
				),
				'carouselArrowsBGColorHover' => array(
					'type'    => 'string',
				),
				'carouselArrowsColor' => array(
					'type'    => 'string',
				),
				'carouselArrowsColorHover' => array(
					'type'    => 'string',
				),

				'horizontalIndentArrowType' => array(
					'type'    => 'string',
					'default' => 'px',
				),

				'verticalIndentArrowType' => array(
					'type'    => 'string',
					'default' => 'px',
				),

				'verticalPositionArrow' => array(
					'type'    => 'string',
					'default' => '',
				),
				'topIndentArrow'  => array(
					'type'    => 'number',
				),
				'bottomIndentArrow'  => array(
					'type'    => 'number',
				),

				'topIndentArrowTablet'  => array(
					'type'    => 'number',
				),
				'bottomIndentArrowTablet'  => array(
					'type'    => 'number',
				),

				'topIndentArrowMobile'  => array(
					'type'    => 'number',
				),
				'bottomIndentArrowMobile'  => array(
					'type'    => 'number',
				),

				'horizontalPositionArrow' => array(
					'type'    => 'string',
					'default' => '',
				),
				'leftIndentArrow'  => array(
					'type'    => 'number',
				),
				'rightIndentArrow'  => array(
					'type'    => 'number',
				),

				'leftIndentArrowTablet'  => array(
					'type'    => 'number',
				),
				'rightIndentArrowTablet'  => array(
					'type'    => 'number',
				),

				'leftIndentArrowMobile'  => array(
					'type'    => 'number',
				),
				'rightIndentArrowMobile'  => array(
					'type'    => 'number',
				),

				
				'verticalPositionArrowNext' => array(
					'type'    => 'string',
					'default' => '',
				),
				'topIndentNextArrow'  => array(
					'type'    => 'number',
				),
				'bottomIndentNextArrow'  => array(
					'type'    => 'number',
				),

				'topIndentArrowNextTablet'  => array(
					'type'    => 'number',
				),
				'bottomIndentArrowNextTablet'  => array(
					'type'    => 'number',
				),

				'topIndentArrowNextMobile'  => array(
					'type'    => 'number',
				),
				'bottomIndentArrowNextMobile'  => array(
					'type'    => 'number',
				),

				'horizontalPositionArrowNext' => array(
					'type'    => 'string',
					'default' => '',
				),
				'leftIndentArrowNext'  => array(
					'type'    => 'number',
				),
				'rightIndentArrowNext'  => array(
					'type'    => 'number',
				),
				'leftIndentArrowNextTablet'  => array(
					'type'    => 'number',
				),
				'rightIndentArrowNextTablet'  => array(
					'type'    => 'number',
				),
				'leftIndentArrowNextMobile'  => array(
					'type'    => 'number',
				),
				'rightIndentArrowNextMobile'  => array(
					'type'    => 'number',
				),

				'verticalIndentArrowNextType' => array(
					'type'    => 'string',
					'default' => 'px',
				),

				'horizontalIndentArrowNextType' => array(
					'type'    => 'string',
					'default' => 'px',
				),

				// Border Carousel Arrow Hover
				'borderStyleArrowHover'  => array(
					'type'    => 'string',
				),
				'borderWidthArrowHoverType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'borderWidthArrowHoverTop'  => array(
					'type'    => 'string',
				),
				'borderWidthArrowHoverTopTablet'  => array(
					'type'    => 'string',
				),
				'borderWidthArrowHoverTopMobile'  => array(
					'type'    => 'string',
				),
				'borderWidthArrowHoverLeft'  => array(
					'type'    => 'string',
				),
				'borderWidthArrowHoverLeftMobile'  => array(
					'type'    => 'string',
				),
				'borderWidthArrowHoverLeftTablet'  => array(
					'type'    => 'string',
				),

				'borderWidthArrowHoverBottom'  => array(
					'type'    => 'string',
				),
				'borderWidthArrowHoverBottomMobile'  => array(
					'type'    => 'string',
				),
				'borderWidthArrowHoverBottomTablet'  => array(
					'type'    => 'string',
				),

				'borderWidthArrowHoverRight'  => array(
					'type'    => 'string',
				),
				'borderWidthArrowHoverRightMobile'  => array(
					'type'    => 'string',
				),
				'borderWidthArrowHoverRightTablet'  => array(
					'type'    => 'string',
				),

				'borderSizeArrowHoverType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'borderRadiusArrowHoverTop'  => array(
					'type'    => 'string',
				),
				'borderRadiusArrowHoverTopMobile'  => array(
					'type'    => 'string',
				),
				'borderRadiusArrowHoverTopTablet'  => array(
					'type'    => 'string',
				),

				'borderRadiusArrowHoverLeft'  => array(
					'type'    => 'string',
				),
				'borderRadiusArrowHoverLeftMobile'  => array(
					'type'    => 'string',
				),
				'borderRadiusArrowHoverLeftTablet'  => array(
					'type'    => 'string',
				),

				'borderRadiusArrowHoverRight'  => array(
					'type'    => 'string',
				),
				'borderRadiusArrowHoverRightMobile'  => array(
					'type'    => 'string',
				),
				'borderRadiusArrowHoverRightTablet'  => array(
					'type'    => 'string',
				),

				'borderRadiusArrowHoverBottom'  => array(
					'type'    => 'string',
				),
				'borderRadiusArrowHoverBottomMobile'  => array(
					'type'    => 'string',
				),
				'borderRadiusArrowHoverBottomTablet'  => array(
					'type'    => 'string',
				),

				'borderColorArrowHover'  => array(
					'type'    => 'string',
				),

				// Border Carousel Arrow 

				'borderStyleArrow'  => array(
					'type'    => 'string',
				),
				'borderWidthArrowType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'borderWidthArrowTop'  => array(
					'type' => 'string'
				),
				'borderWidthArrowTopTablet'  => array(
					'type' => 'string'
				),
				'borderWidthArrowTopMobile'  => array(
					'type' => 'string'
				),
				'borderWidthArrowLeft'  => array(
					'type' => 'string'
				),
				'borderWidthArrowLeftMobile'  => array(
					'type' => 'string'
				),
				'borderWidthArrowLeftTablet'  => array(
					'type' => 'string'
				),

				'borderWidthArrowBottom'  => array(
					'type' => 'string'
				),
				'borderWidthArrowBottomMobile'  => array(
					'type' => 'string'
				),
				'borderWidthArrowBottomTablet'  => array(
					'type' => 'string'
				),

				'borderWidthArrowRight'  => array(
					'type' => 'string'
				),
				'borderWidthArrowRightMobile'  => array(
					'type' => 'string'
				),
				'borderWidthArrowRightTablet'  => array(
					'type' => 'string'
				),

				'borderRadiusArrowBottom'  => array(
					'type' => 'string'
				),
				'borderRadiusArrowBottomMobile'  => array(
					'type' => 'string'
				),
				'borderRadiusArrowBottomTablet'  => array(
					'type' => 'string'
				),

				'borderSizeArrowType'  => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'borderRadiusArrowTop'  => array(
					'type' => 'string'
				),
				'borderRadiusArrowTopMobile'  => array(
					'type' => 'string'
				),
				'borderRadiusArrowTopTablet'  => array(
					'type' => 'string'
				),

				'borderRadiusArrowLeft'  => array(
					'type' => 'string'
				),
				'borderRadiusArrowLeftMobile'  => array(
					'type' => 'string'
				),
				'borderRadiusArrowLeftTablet'  => array(
					'type' => 'string'
				),

				'borderRadiusArrowRight'  => array(
					'type' => 'string'
				),
				'borderRadiusArrowRightMobile'  => array(
					'type' => 'string'
				),
				'borderRadiusArrowRightTablet'  => array(
					'type' => 'string'
				),

				'borderColorArrow'  => array(
					'type'    => 'string',
				),
				'styleCarousel' => array(
					'type'    => 'string',
					'default' => 'style1'
				),
				'selectedAuthor' => array(
					'type'    => 'number',
				),
				'titleMarginType' => array(
					'type'    => 'string',
					'default' => 'px'
				),
				'categoriesMarginType'=> array(
					'type'    => 'string',
					'default' => 'px'
				),
				'tagsMarginType' => array(
					'type'    => 'string',
					'default' => 'px'
				),
				'excerptMarginType' => array(
					'type'    => 'string',
					'default' => 'px'
				),
				'commentsMarginType' => array(
					'type'    => 'string',
					'default' => 'px'
				),

				'blockBorderSizeType'   => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'blockBorderRadiusTop'   => array(
					'type'    => 'string',
				),
				'blockBorderRadiusTopMobile'   => array(
					'type'    => 'string',
				),
				'blockBorderRadiusTopTablet'   => array(
					'type'    => 'string',
				),
				'blockBorderRadiusLeft'   => array(
					'type'    => 'string',
				),
				'blockBorderRadiusLeftMobile'   => array(
					'type'    => 'string',
				),
				'blockBorderRadiusLeftTablet'   => array(
					'type'    => 'string',
				),
				'blockBorderRadiusBottom'   => array(
					'type'    => 'string',
				),
				'blockBorderRadiusBottomMobile'   => array(
					'type'    => 'string',
				),
				'blockBorderRadiusBottomTablet'   => array(
					'type'    => 'string',
				),
				'blockBorderRadiusRight'   => array(
					'type'    => 'string',
				),
				'blockBorderRadiusRightMobile'   => array(
					'type'    => 'string',
				),
				'blockBorderRadiusRightTablet'   => array(
					'type'    => 'string',
				),

				'PaddingType'   => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'paddingTop' => array(
					'type' => 'string'
				),
				'paddingTopMobile' => array(
					'type' => 'string'
				),
				'paddingTopTablet' => array(
					'type' => 'string'
				),
				'paddingLeft' => array(
					'type' => 'string'
				),
				'paddingLeftMobile' => array(
					'type' => 'string'
				),
				'paddingLeftTablet' => array(
					'type' => 'string'
				),
				'paddingBottom' => array(
					'type' => 'string'
				),
				'paddingBottomMobile' => array(
					'type' => 'string'
				),
				'paddingBottomTablet' => array(
					'type' => 'string'
				),
				'paddingRight' => array(
					'type' => 'string'
				),
				'paddingRightMobile' => array(
					'type' => 'string'
				),
				'paddingRightTablet' => array(
					'type' => 'string'
				),

				'MarginType'   => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'marginTop' => array(
					'type' => 'string'
				),
				'marginTopMobile' => array(
					'type' => 'string'
				),
				'marginTopTablet' => array(
					'type' => 'string'
				),
				'marginLeft' => array(
					'type' => 'string'
				),
				'marginLeftMobile' => array(
					'type' => 'string'
				),
				'marginLeftTablet' => array(
					'type' => 'string'
				),
				'marginBottom' => array(
					'type' => 'string'
				),
				'marginBottomMobile' => array(
					'type' => 'string'
				),
				'marginBottomTablet' => array(
					'type' => 'string'
				),
				'marginRight' => array(
					'type' => 'string'
				),
				'marginRightMobile' => array(
					'type' => 'string'
				),
				'marginRightTablet' => array(
					'type' => 'string'
				),
				'blockBGColor'   => array(
					'type'    => 'string',
				),
				'blockBorderStyle'   => array(
					'type'    => 'string',
					'default' => '',
				),
				'blockBorderWidthType'   => array(
					'type'    => 'string',
					'default' => 'px',
				),
				'blockBorderWidthTop'   => array(
					'type'    => 'string',
				),
				'blockBorderWidthTopMobile'   => array(
					'type'    => 'string',
				),
				'blockBorderWidthTopTablet'   => array(
					'type'    => 'string',
				),
				'blockBorderWidthLeft'   => array(
					'type'    => 'string',
				),
				'blockBorderWidthLeftMobile'   => array(
					'type'    => 'string',
				),
				'blockBorderWidthLeftTablet'   => array(
					'type'    => 'string',
				),
				'blockBorderWidthBottom'   => array(
					'type'    => 'string',
				),
				'blockBorderWidthBottomMobile'   => array(
					'type'    => 'string',
				),
				'blockBorderWidthBottomTablet'   => array(
					'type'    => 'string',
				),
				'blockBorderWidthRight'   => array(
					'type'    => 'string',
				),
				'blockBorderWidthRightMobile'   => array(
					'type'    => 'string',
				),
				'blockBorderWidthRightTablet'   => array(
					'type'    => 'string',
				),
				'z_index'=> array(
					'type'    => 'string',
				),
				'responsiveDesktop'=> array(
					'type'    => 'boolean',
					'default' => false,
				),
				'responsiveTablet'=> array(
					'type'    => 'boolean',
					'default' => false,
				),
				'responsiveMobile'=> array(
					'type'    => 'boolean',
					'default' => false,
				),
				'entranceAnimation' => array(
					'type'    => 'string',
				),
				'entranceAnimationDuration' => array(
					'type'    => 'string',
					'default' => '1500ms',
				),
				'entranceAnimationDelay' => array(
					'type'    => 'string',
					'default' => '200ms',
				),

			),
			'render_callback' => 'render_latest_post_block',
			'editor_script'   => 'zeguten-slick-initializer',
		)
	);
}




