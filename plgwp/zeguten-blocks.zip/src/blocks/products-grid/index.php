<?php
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

if ( is_plugin_active( 'woocommerce/woocommerce.php') ) {

    /**
     * Server-side rendering of the `zeguten/products-grid` block.
     *
     * @package ZeGuten Products Grid Layouts for Gutenberg
     */

    add_action('init', 'register_zeguten_products_grid_block');

    function render_products_grid_block($attributes) {

        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => $attributes['postsToShow'],
            'order' => $attributes['order'],
        );

        //Filter by IDs
        if (isset($attributes['filterById']) && $attributes['filterById']) {
            $args['include'] = explode(',', $attributes['filterById']);
        }

        switch ($attributes['orderBy']) {
            case 'price':
                $args['meta_key'] = '_price';
                $args['orderby'] = 'meta_value_num';
                break;
            default:
                $args['orderby'] = $attributes['orderBy'];
        }

        if ($attributes['onlyOutofstock']) {
            $args['stock_status'] = 'outofstock';
        }

        if ($attributes['onlyFeatured']) {
            $args['featured'] = $attributes['onlyFeatured'];
        }

        if ($attributes['onlyNew']) {
            $args['date_query'] = array(
                array(
                    'after' => date("Y-m-d H:i:s", strtotime("-1 month")),
                    'inclusive' => true
                )
            );
        }

        if ($attributes['onlyOnSale']) {
            $args['include'] = array_merge( array( 0 ), wc_get_product_ids_on_sale() );
        }

        if (isset($attributes['categories']) && !empty($attributes['categories'])) {
            $categoriesIds = explode(',', $attributes['categories']);
            if (count($categoriesIds) > 0) {
                $categoriesSlugs = [];
                foreach ($categoriesIds as $categoryId) {
                    $category = get_term_by('id', $categoryId, 'product_cat');
                    if (isset($category) && isset($category->slug)) {
                        $categoriesSlugs[] = $category->slug;
                    }
                }

                $args['category'] = $categoriesSlugs;
            }

        }



        if (isset($attributes['tags']) && !empty($attributes['tags'])) {
            $tagsIds = explode(',', $attributes['tags']);
            if (count($tagsIds) > 0) {
                $tagsSlugs = [];
                foreach ($tagsIds as $tagId) {
                    $tag = get_term_by('id', $tagId, 'product_tag');
                    if (isset($tag) && isset($tag->slug)) {
                        $tagsSlugs[] = $tag->slug;
                    }
                }
                $args['tag'] = $tagsSlugs;
            }
        }

        // An array of all published WC_Product Objects
        $products = wc_get_products($args);

        $attr = "";


        $priceArgs = array(
            'currency_symbol' => get_woocommerce_currency_symbol(),
            'decimal_separator' => wc_get_price_decimal_separator(),
            'thousand_separator' => wc_get_price_thousand_separator(),
            'decimals' => wc_get_price_decimals(),
            'price_format' => get_woocommerce_price_format(),
        );


        if (empty($products)) {
            return '<p>No Products</p>';
        }

        $imgclass = '';


        if (isset($attributes['imgPosition']) && $attributes['imgPosition'] && true === $attributes['displayPostImage'] && 'list' === $attributes['postLayout']) {
            $imgclass .= $attributes['imgPosition'];
        }

        $itemClass = '';
        if (isset($attributes['columns'])) {
            $itemClass .= ' col-desktop-' . $attributes['columns'];
        }
        if (isset($attributes['columnsTablet'])) {
            $itemClass .= ' col-tablet-' . $attributes['columnsTablet'];
        }
        if (isset($attributes['columnsMobile'])) {
            $itemClass .= ' col-mobile-' . $attributes['columnsMobile'];
        }


        $productsOutput = '<div class="zeguten-products-grid__wrap' . $itemClass . '">';

        
        foreach ($products as $product) {

           
            $id = $product->get_id();
            $title = $product->get_name();
            $description = $product->get_short_description();
            $stockStatus = $product->get_stock_status();
            $productType = $product->get_type();
            $averageRating = (int)$product->get_average_rating();
            $isFeatured = $product->is_featured();

            $prices = [];
            $hasDiscount = false;

            if ($productType === 'variable') {
                $minRegularPrice = (float)$product->get_variation_regular_price('min');
                $maxRegularPrice = (float)$product->get_variation_regular_price('max');
                $minPrice = (float)$product->get_variation_price('min');
                $maxPrice = (float)$product->get_variation_price('max');
                $hasDiscount = $minRegularPrice > $minPrice ||
                $maxRegularPrice > $maxPrice ? true : false;

                $prices["regular"] = [$minRegularPrice, $maxRegularPrice];
                $prices["sale"] = [$minPrice, $maxPrice];

            } else {
                $regularPrice = (float)$product->get_regular_price();
                $price = (float)$product->get_price();

                $hasDiscount = $regularPrice > $price ? true : false;
                $prices["regular"] = [$regularPrice];
                $prices["sale"] = [$price];
            }


            $buyBtn = [];

            if ($product->is_purchasable() && $productType !== 'simple') {
                $buyBtn["label"] = __('Select options', 'woocommerce');
                $buyBtn["link"] = get_permalink($id);
            
            } 
            elseif ($stockStatus !== 'outofstock') {
                $buyBtn["label"] = __('Add to cart', 'woocommerce');
                $buyBtn["link"] = esc_url(add_query_arg('add-to-cart', $id, ''));

            } else {
                $buyBtn["label"] = __('Read more', 'woocommerce');
                $buyBtn["link"] = get_permalink($id);
            }



            $tagsList = wc_get_product_tag_list($id, ", ", "");
            $categoriesList = wc_get_product_category_list($id, ",", "");

            $dateCreated = strtotime($product->get_date_created());
            $link = get_permalink($id);

            $priceOutput = "";


            // Get the post title


            if (!$title) {
                $title = esc_html__('Untitled', 'zeguten');
            }


            if ($productType === 'variable') {
                $minPrice = min($prices["sale"]);
                $minPrice = apply_filters('formatted_woocommerce_price', number_format($minPrice, $priceArgs['decimals'], $priceArgs['decimal_separator'], $priceArgs['thousand_separator']), $minPrice, $priceArgs['decimals'], $priceArgs['decimal_separator'], $priceArgs['thousand_separator']);

                $maxPrice = max($prices["sale"]);
                $maxPrice = apply_filters('formatted_woocommerce_price', number_format($maxPrice, $priceArgs['decimals'], $priceArgs['decimal_separator'], $priceArgs['thousand_separator']), $maxPrice, $priceArgs['decimals'], $priceArgs['decimal_separator'], $priceArgs['thousand_separator']);

                $priceOutput = '<div class="current_price">
                                <div class="price">
                                        <span class = "currency_symbol">' . $priceArgs["currency_symbol"] . '</span>
                                        <span class="price_number">' . $minPrice . '</span>
                                    </div>
                                    <div class="price_separator">
                                        -
                                    </div>
                                    <div class="price">
                                        <span class = "currency_symbol">' . $priceArgs["currency_symbol"] . '</span>
                                        <span class="price_number">' . $maxPrice . '</span>
                                    </div>
                            </div>';
            } else {
                $regularPrice = $prices["regular"][0];
                $regularPrice = apply_filters('formatted_woocommerce_price', number_format($regularPrice, $priceArgs['decimals'], $priceArgs['decimal_separator'], $priceArgs['thousand_separator']), $regularPrice, $priceArgs['decimals'], $priceArgs['decimal_separator'], $priceArgs['thousand_separator']);

                $price = $prices["sale"][0];
                $price = apply_filters('formatted_woocommerce_price', number_format($price, $priceArgs['decimals'], $priceArgs['decimal_separator'], $priceArgs['thousand_separator']), $price, $priceArgs['decimals'], $priceArgs['decimal_separator'], $priceArgs['thousand_separator']);

                $regularPriceOutput = $hasDiscount ? '<div class="old_price">
                                    <div class="price">
                                        <span class = "currency_symbol">' . $priceArgs["currency_symbol"] . '</span>
                                        <span class="price_number">' . $regularPrice . '</span>
                                    </div>
                                </div>' : '';
                $priceOutput = $regularPriceOutput . '<div class="current_price">
                                <div class="price">
                                    <span class="currency_symbol">' . $priceArgs["currency_symbol"] . '</span>
                                    <span class="price_number">' . $price . '</span>
                                </div>
                            </div>';
            }


            $btnOutput = '<div class="zeguten-products-grid__item__btn__wrapper"><a href="' . $buyBtn["link"] . '" rel="nofollow"
                           class="zeguten-products-grid__item__btn"
                           aria-label="' . $buyBtn["label"] . '">';

            if ($attributes['productsGridLayout'] === 'zeguten-products-grid-2' ||
                isset($attributes['buttonContent']) &&
                ($attributes['buttonContent'] === 'iconText' || $attributes['buttonContent'] === 'icon')
            ) {
                $btnOutput .= '<svg xmlns="http://www.w3.org/2000/svg" width="19" height="20" viewBox="0 0 19 20" fill="none">
            <path xmlns="http://www.w3.org/2000/svg" d="M3 1.97588L6.16859 13.9316V14H16.8315L19 5H6.5L5 0H0V1.97588H3Z"/>
            <path fill-rule="evenodd" clip-rule="evenodd" d="M3 1.97588L6.16859 13.9316V14H16.8315L19 5H6.5L5 0H0V1.97588H3ZM15.8854 6.00475L15.894 6L16.3112 6.74538C16.1594 6.84771 16.0105 6.95274 15.8646 7.06046C15.2188 7.54234 14.6215 8.0591 14.0729 8.61073C13.5312 9.16236 13.0347 9.73936 12.5833 10.3417C12.1319 10.9441 11.7153 11.5528 11.3333 12.1678L8 8.81997L9 7.90693L11.3333 9.42867C11.75 9.01653 12.2014 8.60756 12.6875 8.20176C13.1736 7.79597 13.684 7.40919 14.2188 7.04144C14.7535 6.66734 15.309 6.32178 15.8854 6.00475Z"/>
            <path d="M9 18C9 19.1046 8.10457 20 7 20C5.89543 20 5 19.1046 5 18C5 16.8954 5.89543 16 7 16C8.10457 16 9 16.8954 9 18Z"/>
            <path d="M18 18C18 19.1046 17.1046 20 16 20C14.8954 20 14 19.1046 14 18C14 16.8954 14.8954 16 16 16C17.1046 16 18 16.8954 18 18Z"/>
        </svg>';
            }

            if ($attributes['productsGridLayout'] !== 'zeguten-products-grid-2'
                && isset($attributes['buttonContent'])
                && ($attributes['buttonContent'] === 'iconText' || $attributes['buttonContent'] === 'text')) {
                $btnOutput .= '<span class="zeguten-products-grid__item__btn__text">
                           ' . $buyBtn["label"] . '</span>';
            }

            $btnOutput .= '</a></div>';


            $productsOutput .= '<div class="zeguten-products-grid__item__wrap" >';

            $productsOutput .= '<div class="zeguten-products-grid__item products-' . $id . '">';

            $hasDiscountClass = $hasDiscount ? 'has_discount' : '';


            $productsOutput .= '<div class="zeguten-products-grid__item__img_elements">';

            $productsOutput .= '<div class="zeguten-products-grid__item__img__wrapper">
                        <a href="' . $link . '" rel ="noopener noreferrer">
                            ' . $product->get_image($attributes['imgSize'] ? $attributes['imgSize'] : 'full', ["class" => 'zeguten-products-grid__item__img'], true) . '
                        </a>
                    </div>';


            $productsOutput .= '<div class="zeguten-products-grid__item__badge__wrapper">';

            if ($attributes['badgeOutStockDisplay'] && $stockStatus === 'outofstock') {
                $productsOutput .= '<div class="zeguten-products-grid__item__badge zeguten-products-grid__item__badge_outofstock">' .
                    __("Out Stock", 'zeguten') .
                    '</div>';
            }

            if ($attributes['badgeNewDisplay'] && time() < $dateCreated + 2592000) {
                $productsOutput .= '<div class="zeguten-products-grid__item__badge zeguten-products-grid__item__badge_new">' .
                    __("New", 'zeguten') .
                    '</div>';
            }

            if ($attributes['badgeSaleDisplay'] && $hasDiscount) {
                $productsOutput .= '<div class="zeguten-products-grid__item__badge zeguten-products-grid__item__badge_sale">' .
                    __("Sale", 'zeguten') .
                    '</div>';
            }

            if ($attributes['badgeFeaturedDisplay'] && $isFeatured) {
                $productsOutput .= '<div class="zeguten-products-grid__item__badge zeguten-products-grid__item__badge_featured">' .
                    __("Featured", 'zeguten') .
                    '</div>';

            }

            $productsOutput .= '</div>';

            if ($attributes['buttonDisplay'] && $attributes['productsGridLayout'] === 'zeguten-products-grid-2') {
                $productsOutput .= $btnOutput;
            }

            $productsOutput .= '</div>';

            if ($attributes['productsGridLayout'] === 'zeguten-products-grid-4') {
                $productsOutput .= '<div class="zeguten-products-grid__item__info">';
            }

            if ($attributes['categoriesDisplay'] && isset($categoriesList) && $categoriesList) {
                $categories = explode(',', $categoriesList);
                $categories = isset($attributes['categoriesNumber']) && $attributes['categoriesNumber'] >=0 ? array_slice($categories,0,$attributes['categoriesNumber']):$categories;
                if(count($categories) > 0) {
                    $productsOutput .= '<div class="zeguten-products-grid__item__categories">
                            <div class="zeguten-products-grid__item__categories__list">' . implode(', ',$categories) . '</div>
                        </div>';
                }
            }

            

            if($attributes['titleDisplay']) {
                $productsOutput .= '<div class="zeguten-products-grid__item__title">
                    <a href="' . $link . '" rel="noopener noreferrer">' . $title . '</a></div>';
            }

            if($attributes['priceDisplay']) {
                $productsOutput .= '<div class="zeguten-products-grid__item__price ' . $hasDiscountClass . '">' .
                    $priceOutput .
                    '</div>';

            }

            if ($attributes['buttonDisplay'] && $attributes['productsGridLayout'] !== 'zeguten-products-grid-2') {
                $productsOutput .= $btnOutput;
            }


            if ($attributes['descriptionDisplay'] && $description !== "") {
                $productsOutput .= '<div class="zeguten-products-grid__item__description">' .
                    strip_tags($description) .
                    '</div>';
            }


            if($attributes['starsDisplay'] && $averageRating ) {

                $productsOutput .= '<div class="zeguten-products-grid__item__stars">';

                for ($i = 0; $i < 5; $i++) {
                    
                    $activeClass = $i < $averageRating ? 'active' : '';
                    
                    $productsOutput .= '<span class="star ' . $activeClass . '">
                       
                       <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 19" fill="none">
                        <path d="M10 0L12.3607 7.25735H20L13.8197 11.7426L16.1803 19L10 14.5147L3.81966 19L6.18034 11.7426L0 7.25735H7.63932L10 0Z" />
                       </svg>

                    </span>';
                }

                $productsOutput .= '</div>';
            }

            if ($attributes['tagsDisplay'] && isset($tagsList) && $tagsList) {
                $tags = explode(',', $tagsList);
                $tags = isset($attributes['tagsNumber']) && $attributes['tagsNumber']>=0? array_slice($tags,0,$attributes['tagsNumber']):$tags;
                if(count($tags)>0) {
                    $productsOutput .= '<div class="zeguten-products-grid__item__tags">
                            <div class="zeguten-products-grid__item__tags__title">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                    <path d="M0 252.118V48C0 21.49 21.49 0 48 0h204.118a48 48 0 0 1 33.941 14.059l211.882 211.882c18.745 18.745 18.745 49.137 0 67.882L293.823 497.941c-18.745 18.745-49.137 18.745-67.882 0L14.059 286.059A48 48 0 0 1 0 252.118zM112 64c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48z"></path>
                                </svg>' .
                        __("Tags:", 'zeguten')
                        . '</div>
                            <div class="zeguten-products-grid__item__tags__list">' . implode(', ',$tags) . '</div>
                        </div>';
                }

            }

            if ($attributes['productsGridLayout'] === 'zeguten-products-grid-4') {
                $productsOutput .= '</div>';
            }


            $productsOutput .= '</div>';

            $productsOutput .= '</div>';

        }

        wp_reset_query();
        wp_reset_postdata(); 

        $productsOutput .= '</div>';
            
        $block_id = 'zeguten-products-grid-' . $attributes['block_id'];

        $class = "zeguten-products-grid " . $attributes['productsGridLayout'];

        $baseClass = "zeguten_block";

        $default_class = 'zeguten-block-container';

        $blockAnimation = '';
        $attr_responsive = '';
        $attr_wow = '';

        if ( isset( $attributes['entranceAnimation'] ) && $attributes['entranceAnimation'] ) {
            $blockAnimation = 'animated ' . esc_attr($attributes['entranceAnimation']);
        }

        $wowDurationData  = $attributes['entranceAnimationDuration']  !== '' ? $attributes['entranceAnimationDuration'] : '2000ms';
        $wowDelayData  = $attributes['entranceAnimationDelay']     !== '' ? $attributes['entranceAnimationDelay']    : '500ms';

        if ( isset( $attributes['entranceAnimation'] ) && ( $attributes['entranceAnimation'] )) {
            $attr_wow .= ' data-wow-duration=' .  esc_attr($wowDurationData) .  '';
            $attr_wow .= ' data-wow-delay=' .  esc_attr($wowDelayData) .  '';
        }

        
        $responsiveDesktop = $attributes['responsiveDesktop']  !== true ? $attributes['responsiveDesktop'] : 'hidden';
        $responsiveTablet  = $attributes['responsiveTablet']   !== true ? $attributes['responsiveTablet']  : 'hidden';
        $responsiveMobile  = $attributes['responsiveMobile']   !== true ? $attributes['responsiveMobile']  : 'hidden';


        if (isset( $attributes['responsiveDesktop'] ) && ( $attributes['responsiveDesktop'] )) {
            $attr_responsive .= ' data-device-desktop=' .  esc_attr($responsiveDesktop) .  '';
        }

        if  (isset( $attributes['responsiveTablet'] ) && ( $attributes['responsiveTablet'] )){
            $attr_responsive .= ' data-device-tablet='  .  esc_attr($responsiveTablet)  .  '';
        }

        if  (isset( $attributes['responsiveMobile'] ) && ( $attributes['responsiveMobile'] )){
            $attr_responsive .= ' data-device-mobile='  .  esc_attr($responsiveMobile)  .  '';
        }


        if (isset($attributes['className'])) {
            $class .= '' . $attributes['className'];
        }


        return sprintf(
            '<div id="%1$s" class="%2$s %3$s %4$s" %5$s %6$s %7$s> <div class="%8$s">%9$s</div></div>',
            esc_attr($block_id),
            esc_attr($class),
            $blockAnimation,
            $baseClass,
            $attr_responsive,
            $attr_wow,
            $attr,
            $default_class,
            $productsOutput
        );

    }




    /**
     * Registers the `zeguten/products-grid` block on server.
     */

    function register_zeguten_products_grid_block()
    {
// Check if the register function exists
        if (!function_exists('register_block_type')) {
            return;
        }
        register_block_type('zeguten/products-grid',
            array(
                'attributes' => array(
                    'block_id' => array(
                        'type' => 'string',
                        'default' => 'not_set',
                    ),

                    'block_css' => array(
                        'type' => 'string',
                    ),

                    'imgSize'=> array(
                        'type'    => 'string',
                        'default' => 'zeguten-blog-image',
                    ),

                    'columns' => array(
                        'type' => 'number',
                        'default' => 3,
                    ),
                    'columnsTablet' => array(
                        'type' => 'number',
                        'default' => 2,
                    ),
                    'columnsMobile' => array(
                        'type' => 'number',
                        'default' => 1,
                    ),

                    'innerType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'columnType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),

                    'buttonWidth' => array(
                        'type' => 'string',
                        'default' => '100%'
                    ),
                    'innerGap' => array(
                        'type' => 'number',
                        'default' => 20,
                    ),
                    'columnGap' => array(
                        'type' => 'number',
                        'default' => 20,
                    ),
                    'innerGapTablet' => array(
                        'type' => 'number',
                    ),
                    'columnGapTablet' => array(
                        'type' => 'number',
                    ),
                    'innerGapMobile' => array(
                        'type' => 'number',
                    ),
                    'columnGapMobile' => array(
                        'type' => 'number',
                    ),

                    'imageBgColor' => array(
                        'type' => 'string'
                    ),

                    'blockBGColor' => array(
                        'type' => 'string'
                    ),
                    'blockBGColorHover' => array(
                        'type' => 'string'
                    ),
                    'blockBorderStyle' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'blockBorderWidthTop' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthTopMobile' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthTopTablet' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthLeft' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthBottom' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthRight' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthRightMobile' => array(
                        'type' => 'string'
                    ),
                    'blockBorderWidthRightTablet' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'blockBorderRadiusTop' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusTopMobile' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusTopTablet' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusLeft' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusBottom' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusRight' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusRightMobile' => array(
                        'type' => 'string'
                    ),
                    'blockBorderRadiusRightTablet' => array(
                        'type' => 'string'
                    ),
                    'blockBorderColor' => array(
                        'type' => 'string'
                    ),
                    'blockShadowHorizontal' => array(
                        'type' => 'number'
                    ),
                    'blockShadowVertical' => array(
                        'type' => 'number'
                    ),
                    'blockShadowBlur' => array(
                        'type' => 'number'
                    ),
                    'blockShadowSpread' => array(
                        'type' => 'number'
                    ),
                    'blockShadowColor' => array(
                        'type' => 'string'
                    ),
                    'blockShadowPosition' => array(
                        'type' => 'string'
                    ),

                    'blockPaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'blockPaddingTop' => array(
                        'type' => 'string'
                    ),
                    'blockPaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'blockPaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'blockPaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'blockPaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'blockPaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'blockPaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'blockPaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'blockPaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'blockPaddingRight' => array(
                        'type' => 'string'
                    ),
                    'blockPaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'blockPaddingRightTablet' => array(
                        'type' => 'string'
                    ),

                    'titleDisplay' => array(
                        'type' => 'boolean',
                        'default' => true
                    ),
                    'titleLinesNumber' => array(
                        'type' => "string",
                        'default'    => '1',
                    ),
                    'titleOrder' => array(
                        'type' => "number"
                    ),
                    'titleColor' => array(
                        'type' => "string",
                    ),

                    'titleHoverColor' => array(
                        'type' => "string",
                    ),
                    'titleAlign' => array(
                        'type' => 'string',
                        'default' => 'center'
                    ),
                    'titleLineHeightType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'titleLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'titleFontFamily' => array(
                        'type' => "string"
                    ),
                    'titleFontWeight' => array(
                        'type' => "string"
                    ),
                    'titleFontStyle' => array(
                        'type' => "string"
                    ),
                    'titleTextTransform' => array(
                        'type' => "string"
                    ),
                    'titleTextDecoration' => array(
                        'type' => "string"
                    ),
                    'titleFontSize' => array(
                        'type' => 'number',
                    ),
                    'titleFontSizeType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'titleFontSizeMobile' => array(
                        'type' => "number"
                    ),
                    'titleFontSizeTablet' => array(
                        'type' => "number"
                    ),
                    'titleLineHeight' => array(
                        'type' => "number"
                    ),
                    'titleLineHeightMobile' => array(
                        'type' => "number"
                    ),
                    'titleLineHeightTablet' => array(
                        'type' => "number"
                    ),
                    'titleLetterSpacing' => array(
                        'type' => "number"
                    ),
                    'titleLetterSpacingMobile' => array(
                        'type' => "number"
                    ),
                    'titleLetterSpacingTablet' => array(
                        'type' => "number"
                    ),

                    'titleLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'titleFontSubset' => array(
                        'type' => 'string'
                    ),
                    'titleMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'titleMarginTop' => array(
                        'type' => 'string'
                    ),
                    'titleMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'titleMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'titleMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'titleMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'titleMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'titleMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'titleMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'titleMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'titleMarginRight' => array(
                        'type' => 'string'
                    ),
                    'titleMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'titleMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'titlePaddingTop' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingRight' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'titlePaddingRightTablet' => array(
                        'type' => 'string'
                    ),


                    'descriptionDisplay' => array(
                        'type' => 'boolean',
                        'default' => true
                    ),
                    'descriptionLinesNumber' => array(
                        'type' => "string",
                        'default'    => '',
                    ),
                    'descriptionOrder' => array(
                        'type' => "number"
                    ),
                    'descriptionColor' => array(
                        'type' => "string",
                    ),
                    'descriptionAlign' => array(
                        'type' => 'string',
                        'default' => 'center'
                    ),
                    'descriptionLineHeightType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'descriptionLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'descriptionFontFamily' => array(
                        'type' => "string"
                    ),
                    'descriptionFontWeight' => array(
                        'type' => "string"
                    ),
                    'descriptionFontStyle' => array(
                        'type' => "string"
                    ),
                    'descriptionTextTransform' => array(
                        'type' => "string"
                    ),
                    'descriptionTextDecoration' => array(
                        'type' => "string"
                    ),
                    'descriptionFontSize' => array(
                        'type' => 'number',
                    ),
                    'descriptionFontSizeType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'descriptionFontSizeMobile' => array(
                        'type' => "number"
                    ),
                    'descriptionFontSizeTablet' => array(
                        'type' => "number"
                    ),
                    'descriptionLineHeight' => array(
                        'type' => "number"
                    ),
                    'descriptionLineHeightMobile' => array(
                        'type' => "number"
                    ),
                    'descriptionLineHeightTablet' => array(
                        'type' => "number"
                    ),
                    'descriptionLetterSpacing' => array(
                        'type' => "number"
                    ),
                    'descriptionLetterSpacingMobile' => array(
                        'type' => "number"
                    ),
                    'descriptionLetterSpacingTablet' => array(
                        'type' => "number"
                    ),

                    'descriptionLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'descriptionFontSubset' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'descriptionMarginTop' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginRight' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'descriptionMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'descriptionPaddingTop' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingRight' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'descriptionPaddingRightTablet' => array(
                        'type' => 'string'
                    ),


                    'tagsDisplay' => array(
                        'type' => 'boolean',
                        'default' => true
                    ),
                    'tagsNumber' => array(
                        'type' => "number",
                    ),
                    'tagsOrder' => array(
                        'type' => "number"
                    ),
                    'tagsColor' => array(
                        'type' => "string",
                    ),
                    'tagsLinkColor' => array(
                        'type' => "string",
                    ),
                    'tagsLinkHoverColor' => array(
                        'type' => "string",
                    ),
                    'tagsAlign' => array(
                        'type' => 'string',
                        'default' => 'center'
                    ),
                    'tagsLineHeightType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'tagsLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'tagsFontFamily' => array(
                        'type' => "string"
                    ),
                    'tagsFontWeight' => array(
                        'type' => "string"
                    ),
                    'tagsFontStyle' => array(
                        'type' => "string"
                    ),
                    'tagsTextTransform' => array(
                        'type' => "string"
                    ),
                    'tagsTextDecoration' => array(
                        'type' => "string"
                    ),
                    'tagsFontSize' => array(
                        'type' => 'number',
                    ),
                    'tagsFontSizeType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'tagsFontSizeMobile' => array(
                        'type' => "number"
                    ),
                    'tagsFontSizeTablet' => array(
                        'type' => "number"
                    ),
                    'tagsLineHeight' => array(
                        'type' => "number"
                    ),
                    'tagsLineHeightMobile' => array(
                        'type' => "number"
                    ),
                    'tagsLineHeightTablet' => array(
                        'type' => "number"
                    ),
                    'tagsLetterSpacing' => array(
                        'type' => "number"
                    ),
                    'tagsLetterSpacingMobile' => array(
                        'type' => "number"
                    ),
                    'tagsLetterSpacingTablet' => array(
                        'type' => "number"
                    ),

                    'tagsLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'tagsFontSubset' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'tagsMarginTop' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginRight' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'tagsMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'tagsPaddingTop' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingRight' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'tagsPaddingRightTablet' => array(
                        'type' => 'string'
                    ),


                    'categoriesDisplay' => array(
                        'type' => 'boolean',
                        'default' => true
                    ),
                    'categoriesOrder' => array(
                        'type' => "number"
                    ),
                    'categoriesNumber' => array(
                        'type' => "number",
                    ),
                    'categoriesColor' => array(
                        'type' => "string",
                    ),
                    'categoriesLinkColor' => array(
                        'type' => "string",
                    ),
                    'categoriesLinkHoverColor' => array(
                        'type' => "string",
                    ),
                    'categoriesAlign' => array(
                        'type' => 'string',
                        'default' => 'center'
                    ),
                    'categoriesLineHeightType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'categoriesLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'categoriesFontFamily' => array(
                        'type' => "string"
                    ),
                    'categoriesFontWeight' => array(
                        'type' => "string"
                    ),
                    'categoriesFontStyle' => array(
                        'type' => "string"
                    ),
                    'categoriesTextTransform' => array(
                        'type' => "string"
                    ),
                    'categoriesTextDecoration' => array(
                        'type' => "string"
                    ),
                    'categoriesFontSize' => array(
                        'type' => 'number',
                    ),
                    'categoriesFontSizeType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'categoriesFontSizeMobile' => array(
                        'type' => "number"
                    ),
                    'categoriesFontSizeTablet' => array(
                        'type' => "number"
                    ),
                    'categoriesLineHeight' => array(
                        'type' => "number"
                    ),
                    'categoriesLineHeightMobile' => array(
                        'type' => "number"
                    ),
                    'categoriesLineHeightTablet' => array(
                        'type' => "number"
                    ),
                    'categoriesLetterSpacing' => array(
                        'type' => "number"
                    ),
                    'categoriesLetterSpacingMobile' => array(
                        'type' => "number"
                    ),
                    'categoriesLetterSpacingTablet' => array(
                        'type' => "number"
                    ),

                    'categoriesLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'categoriesFontSubset' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'categoriesMarginTop' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginRight' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'categoriesMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'categoriesPaddingTop' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingRight' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'categoriesPaddingRightTablet' => array(
                        'type' => 'string'
                    ),


                    'buttonDisplay' => array(
                        'type' => 'boolean',
                        'default' => true
                    ),
                    'buttonContent' => array(
                        'type' => 'string',
                        'default' => 'iconText'
                    ),
                    'buttonOrder' => array(
                        'type' => "number"
                    ),
                    'buttonAlign' => array(
                        'type' => 'string',
                        'default' => 'center',
                    ),
                    'buttonVerticalAlign' => array(
                        'type' => 'string',
                        'default' => 'center',
                    ),
                    'buttonLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'buttonFontFamily' => array(
                        'type' => 'string'
                    ),
                    'buttonFontWeight' => array(
                        'type' => 'string'
                    ),
                    'buttonFontSubset' => array(
                        'type' => 'string'
                    ),
                    'buttonFontStyle' => array(
                        'type' => 'string'
                    ),
                    'buttonTextTransform' => array(
                        'type' => 'string'
                    ),
                    'buttonTextDecoration' => array(
                        'type' => 'string'
                    ),
                    'buttonFontSizeType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'buttonFontSize' => array(
                        'type' => 'number'
                    ),
                    'buttonFontSizeMobile' => array(
                        'type' => 'number'
                    ),
                    'buttonFontSizeTablet' => array(
                        'type' => 'number'
                    ),
                    'buttonLineHeightType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'buttonLineHeight' => array(
                        'type' => 'number'
                    ),
                    'buttonLineHeightMobile' => array(
                        'type' => 'number'
                    ),
                    'buttonLineHeightTablet' => array(
                        'type' => 'number'
                    ),
                    'buttonLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'buttonLetterSpacing' => array(
                        'type' => 'number'
                    ),
                    'buttonLetterSpacingMobile' => array(
                        'type' => 'number'
                    ),
                    'buttonLetterSpacingTablet' => array(
                        'type' => 'number'
                    ),

                    'buttonColorHover' => array(
                        'type' => 'string'
                    ),
                    'buttonBgColorHover' => array(
                        'type' => 'string'
                    ),

                    'buttonColor' => array(
                        'type' => 'string'
                    ),
                    'buttonBgColor' => array(
                        'type' => 'string'
                    ),

                    'buttonBorderStyle' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'buttonBorderWidthTop' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthTopMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthTopTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthLeft' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthBottom' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthRight' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthRightMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderWidthRightTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'buttonBorderRadiusTop' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusTopMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusTopTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusLeft' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusBottom' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusRight' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusRightMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderRadiusRightTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderColor' => array(
                        'type' => 'string'
                    ),
                    'buttonBorderColorHover' => array(
                        'type' => 'string'
                    ),
                    'buttonShadowHorizontal' => array(
                        'type' => 'number'
                    ),
                    'buttonShadowVertical' => array(
                        'type' => 'number'
                    ),
                    'buttonShadowBlur' => array(
                        'type' => 'number'
                    ),
                    'buttonShadowSpread' => array(
                        'type' => 'number'
                    ),
                    'buttonShadowColor' => array(
                        'type' => 'string'
                    ),
                    'buttonShadowPosition' => array(
                        'type' => 'string'
                    ),

                    'buttonPaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'buttonPaddingTop' => array(
                        'type' => 'string'
                    ),
                    'buttonPaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonPaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonPaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'buttonPaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonPaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonPaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'buttonPaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonPaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonPaddingRight' => array(
                        'type' => 'string'
                    ),
                    'buttonPaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonPaddingRightTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'buttonMarginTop' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginRight' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'buttonMarginRightTablet' => array(
                        'type' => 'string'
                    ),


                    'starsDisplay' => array(
                        'type' => 'boolean',
                        'default' => true
                    ),
                    'starsOrder' => array(
                        'type' => "number"
                    ),
                    'starsColor' => array(
                        'type' => "string",
                    ),
                    'starsEmptyColor' => array(
                        'type' => "string",
                    ),
                    'starsAlign' => array(
                        'type' => 'string',
                        'default' => 'center'
                    ),
                    'starsSize' => array(
                        'type' => 'number',
                    ),
                    'starsSizeTablet' => array(
                        'type' => 'number',
                    ),
                    'starsSizeMobile' => array(
                        'type' => 'number',
                    ),
                    'starsSpacingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'starsMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'starsMarginTop' => array(
                        'type' => 'string'
                    ),
                    'starsMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'starsMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'starsMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'starsMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'starsMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'starsMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'starsMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'starsMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'starsMarginRight' => array(
                        'type' => 'string'
                    ),
                    'starsMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'starsMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'starsPaddingTop' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingRight' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'starsPaddingRightTablet' => array(
                        'type' => 'string'
                    ),


                    'badgeOutStockDisplay' => array(
                        'type' => 'boolean',
                        'default' => true
                    ),
                    'badgeOutStockColor' => array(
                        'type' => "string",
                    ),
                    'badgeOutStockBgColor' => array(
                        'type' => "string",
                    ),

                    'badgeNewDisplay' => array(
                        'type' => 'boolean',
                        'default' => true
                    ),
                    'badgeNewColor' => array(
                        'type' => "string",
                    ),
                    'badgeNewBgColor' => array(
                        'type' => "string",
                    ),

                    'badgeSaleDisplay' => array(
                        'type' => 'boolean',
                        'default' => true
                    ),
                    'badgeSaleColor' => array(
                        'type' => "string",
                    ),
                    'badgeSaleBgColor' => array(
                        'type' => "string",
                    ),

                    'badgeFeaturedDisplay' => array(
                        'type' => 'boolean',
                        'default' => true
                    ),
                    'badgeFeaturedColor' => array(
                        'type' => "string",
                    ),
                    'badgeFeaturedBgColor' => array(
                        'type' => "string",
                    ),

                    'badgeLineHeightType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'badgeLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'badgeFontFamily' => array(
                        'type' => "string"
                    ),
                    'badgeFontWeight' => array(
                        'type' => "string"
                    ),
                    'badgeFontStyle' => array(
                        'type' => "string"
                    ),
                    'badgeTextTransform' => array(
                        'type' => "string"
                    ),
                    'badgeTextDecoration' => array(
                        'type' => "string"
                    ),
                    'badgeFontSize' => array(
                        'type' => 'number',
                    ),
                    'badgeFontSizeType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'badgeFontSizeMobile' => array(
                        'type' => "number"
                    ),
                    'badgeFontSizeTablet' => array(
                        'type' => "number"
                    ),
                    'badgeLineHeight' => array(
                        'type' => "number"
                    ),
                    'badgeLineHeightMobile' => array(
                        'type' => "number"
                    ),
                    'badgeLineHeightTablet' => array(
                        'type' => "number"
                    ),
                    'badgeLetterSpacing' => array(
                        'type' => "number"
                    ),
                    'badgeLetterSpacingMobile' => array(
                        'type' => "number"
                    ),
                    'badgeLetterSpacingTablet' => array(
                        'type' => "number"
                    ),

                    'badgeLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'badgeFontSubset' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'badgeMarginTop' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginRight' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'badgePaddingTop' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingRight' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'badgePaddingRightTablet' => array(
                        'type' => 'string'
                    ),

                    'badgeBorderStyle' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'badgeBorderWidthTop' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthTopMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthTopTablet' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthLeft' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthBottom' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthRight' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthRightMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderWidthRightTablet' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'badgeBorderRadiusTop' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusTopMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusTopTablet' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusLeft' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusBottom' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusRight' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusRightMobile' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderRadiusRightTablet' => array(
                        'type' => 'string'
                    ),
                    'badgeBorderColor' => array(
                        'type' => 'string'
                    ),
                    'badgeShadowHorizontal' => array(
                        'type' => 'number'
                    ),
                    'badgeShadowVertical' => array(
                        'type' => 'number'
                    ),
                    'badgeShadowBlur' => array(
                        'type' => 'number'
                    ),
                    'badgeShadowSpread' => array(
                        'type' => 'number'
                    ),
                    'badgeShadowColor' => array(
                        'type' => 'string'
                    ),
                    'badgeShadowPosition' => array(
                        'type' => 'string'
                    ),
                    'priceDisplay' => array(
                        'type' => 'boolean',
                        'default' => true
                    ),
                    'priceOrder' => array(
                        'type' => "number"
                    ),
                    'priceAlign' => array(
                        'type' => 'string',
                         'default' => 'center'
                    ),
                    'priceMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'priceMarginTop' => array(
                        'type' => 'string'
                    ),
                    'priceMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'priceMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'priceMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'priceMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'priceMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'priceMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'priceMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'priceMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'priceMarginRight' => array(
                        'type' => 'string'
                    ),
                    'priceMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'priceMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'pricePaddingTop' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingRight' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'pricePaddingRightTablet' => array(
                        'type' => 'string'
                    ),

                    'separatorMargin' => array(
                        'type' => 'number'
                    ),

                    'oldPriceTextColor' => array(
                        'type' => "string",
                    ),
                    'oldPriceLineHeightType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'oldPriceLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'oldPriceFontFamily' => array(
                        'type' => "string"
                    ),
                    'oldPriceFontWeight' => array(
                        'type' => "string"
                    ),
                    'oldPriceFontStyle' => array(
                        'type' => "string"
                    ),
                    'oldPriceTextTransform' => array(
                        'type' => "string"
                    ),
                    'oldPriceTextDecoration' => array(
                        'type' => "string"
                    ),
                    'oldPriceFontSize' => array(
                        'type' => 'number',
                    ),
                    'oldPriceFontSizeType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'oldPriceFontSizeMobile' => array(
                        'type' => "number"
                    ),
                    'oldPriceFontSizeTablet' => array(
                        'type' => "number"
                    ),
                    'oldPriceLineHeight' => array(
                        'type' => "number"
                    ),
                    'oldPriceLineHeightMobile' => array(
                        'type' => "number"
                    ),
                    'oldPriceLineHeightTablet' => array(
                        'type' => "number"
                    ),
                    'oldPriceLetterSpacing' => array(
                        'type' => "number"
                    ),
                    'oldPriceLetterSpacingMobile' => array(
                        'type' => "number"
                    ),
                    'oldPriceLetterSpacingTablet' => array(
                        'type' => "number"
                    ),

                    'oldPriceLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'oldPriceFontSubset' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'oldPriceMarginTop' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginRight' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPriceMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'oldPricePaddingTop' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingRight' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPricePaddingRightTablet' => array(
                        'type' => 'string'
                    ),


                    'oldPriceCurrencyTextColor' => array(
                        'type' => "string",
                    ),
                    'oldPriceCurrencyLineHeightType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'oldPriceCurrencyLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'oldPriceCurrencyFontFamily' => array(
                        'type' => "string"
                    ),
                    'oldPriceCurrencyFontWeight' => array(
                        'type' => "string"
                    ),
                    'oldPriceCurrencyFontStyle' => array(
                        'type' => "string"
                    ),
                    'oldPriceCurrencyTextTransform' => array(
                        'type' => "string"
                    ),
                    'oldPriceCurrencyTextDecoration' => array(
                        'type' => "string"
                    ),
                    'oldPriceCurrencyFontSize' => array(
                        'type' => 'number',
                    ),
                    'oldPriceCurrencyFontSizeType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'oldPriceCurrencyFontSizeMobile' => array(
                        'type' => "number"
                    ),
                    'oldPriceCurrencyFontSizeTablet' => array(
                        'type' => "number"
                    ),
                    'oldPriceCurrencyLineHeight' => array(
                        'type' => "number"
                    ),
                    'oldPriceCurrencyLineHeightMobile' => array(
                        'type' => "number"
                    ),
                    'oldPriceCurrencyLineHeightTablet' => array(
                        'type' => "number"
                    ),
                    'oldPriceCurrencyLetterSpacing' => array(
                        'type' => "number"
                    ),
                    'oldPriceCurrencyLetterSpacingMobile' => array(
                        'type' => "number"
                    ),
                    'oldPriceCurrencyLetterSpacingTablet' => array(
                        'type' => "number"
                    ),

                    'oldPriceCurrencyLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'oldPriceCurrencyFontSubset' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'oldPriceCurrencyMarginTop' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginRight' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'oldPriceCurrencyPosition' => array(
                        'type' => 'string'
                    ),


                    'salePriceTextColor' => array(
                        'type' => "string",
                    ),
                    'salePriceLineHeightType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'salePriceLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'salePriceFontFamily' => array(
                        'type' => "string"
                    ),
                    'salePriceFontWeight' => array(
                        'type' => "string"
                    ),
                    'salePriceFontStyle' => array(
                        'type' => "string"
                    ),
                    'salePriceTextTransform' => array(
                        'type' => "string"
                    ),
                    'salePriceTextDecoration' => array(
                        'type' => "string"
                    ),
                    'salePriceFontSize' => array(
                        'type' => 'number',
                    ),
                    'salePriceFontSizeType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'salePriceFontSizeMobile' => array(
                        'type' => "number"
                    ),
                    'salePriceFontSizeTablet' => array(
                        'type' => "number"
                    ),
                    'salePriceLineHeight' => array(
                        'type' => "number"
                    ),
                    'salePriceLineHeightMobile' => array(
                        'type' => "number"
                    ),
                    'salePriceLineHeightTablet' => array(
                        'type' => "number"
                    ),
                    'salePriceLetterSpacing' => array(
                        'type' => "number"
                    ),
                    'salePriceLetterSpacingMobile' => array(
                        'type' => "number"
                    ),
                    'salePriceLetterSpacingTablet' => array(
                        'type' => "number"
                    ),

                    'salePriceLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'salePriceFontSubset' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'salePriceMarginTop' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginRight' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'salePriceMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'salePricePaddingTop' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingRight' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'salePricePaddingRightTablet' => array(
                        'type' => 'string'
                    ),


                    'salePriceCurrencyTextColor' => array(
                        'type' => "string",
                    ),
                    'salePriceCurrencyLineHeightType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'salePriceCurrencyLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'salePriceCurrencyFontFamily' => array(
                        'type' => "string"
                    ),
                    'salePriceCurrencyFontWeight' => array(
                        'type' => "string"
                    ),
                    'salePriceCurrencyFontStyle' => array(
                        'type' => "string"
                    ),
                    'salePriceCurrencyTextTransform' => array(
                        'type' => "string"
                    ),
                    'salePriceCurrencyTextDecoration' => array(
                        'type' => "string"
                    ),
                    'salePriceCurrencyFontSize' => array(
                        'type' => 'number',
                    ),
                    'salePriceCurrencyFontSizeType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'salePriceCurrencyFontSizeMobile' => array(
                        'type' => "number"
                    ),
                    'salePriceCurrencyFontSizeTablet' => array(
                        'type' => "number"
                    ),
                    'salePriceCurrencyLineHeight' => array(
                        'type' => "number"
                    ),
                    'salePriceCurrencyLineHeightMobile' => array(
                        'type' => "number"
                    ),
                    'salePriceCurrencyLineHeightTablet' => array(
                        'type' => "number"
                    ),
                    'salePriceCurrencyLetterSpacing' => array(
                        'type' => "number"
                    ),
                    'salePriceCurrencyLetterSpacingMobile' => array(
                        'type' => "number"
                    ),
                    'salePriceCurrencyLetterSpacingTablet' => array(
                        'type' => "number"
                    ),

                    'salePriceCurrencyLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'salePriceCurrencyFontSubset' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'salePriceCurrencyMarginTop' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginRight' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'salePriceCurrencyPosition' => array(
                        'type' => 'string'
                    ),


                    'normalPriceTextColor' => array(
                        'type' => "string",
                    ),
                    'normalPriceLineHeightType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'normalPriceLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'normalPriceFontFamily' => array(
                        'type' => "string"
                    ),
                    'normalPriceFontWeight' => array(
                        'type' => "string"
                    ),
                    'normalPriceFontStyle' => array(
                        'type' => "string"
                    ),
                    'normalPriceTextTransform' => array(
                        'type' => "string"
                    ),
                    'normalPriceTextDecoration' => array(
                        'type' => "string"
                    ),
                    'normalPriceFontSize' => array(
                        'type' => 'number',
                    ),
                    'normalPriceFontSizeType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'normalPriceFontSizeMobile' => array(
                        'type' => "number"
                    ),
                    'normalPriceFontSizeTablet' => array(
                        'type' => "number"
                    ),
                    'normalPriceLineHeight' => array(
                        'type' => "number"
                    ),
                    'normalPriceLineHeightMobile' => array(
                        'type' => "number"
                    ),
                    'normalPriceLineHeightTablet' => array(
                        'type' => "number"
                    ),
                    'normalPriceLetterSpacing' => array(
                        'type' => "number"
                    ),
                    'normalPriceLetterSpacingMobile' => array(
                        'type' => "number"
                    ),
                    'normalPriceLetterSpacingTablet' => array(
                        'type' => "number"
                    ),

                    'normalPriceLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'normalPriceFontSubset' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'normalPriceMarginTop' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginRight' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPriceMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'normalPricePaddingTop' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingRight' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPricePaddingRightTablet' => array(
                        'type' => 'string'
                    ),

                    'normalPriceCurrencyTextColor' => array(
                        'type' => "string",
                    ),
                    'normalPriceCurrencyLineHeightType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'normalPriceCurrencyLetterSpacingType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'normalPriceCurrencyFontFamily' => array(
                        'type' => "string"
                    ),
                    'normalPriceCurrencyFontWeight' => array(
                        'type' => "string"
                    ),
                    'normalPriceCurrencyFontStyle' => array(
                        'type' => "string"
                    ),
                    'normalPriceCurrencyTextTransform' => array(
                        'type' => "string"
                    ),
                    'normalPriceCurrencyTextDecoration' => array(
                        'type' => "string"
                    ),
                    'normalPriceCurrencyFontSize' => array(
                        'type' => 'number',
                    ),
                    'normalPriceCurrencyFontSizeType' => array(
                        'type' => 'string',
                        'default' => "px"
                    ),
                    'normalPriceCurrencyFontSizeMobile' => array(
                        'type' => "number"
                    ),
                    'normalPriceCurrencyFontSizeTablet' => array(
                        'type' => "number"
                    ),
                    'normalPriceCurrencyLineHeight' => array(
                        'type' => "number"
                    ),
                    'normalPriceCurrencyLineHeightMobile' => array(
                        'type' => "number"
                    ),
                    'normalPriceCurrencyLineHeightTablet' => array(
                        'type' => "number"
                    ),
                    'normalPriceCurrencyLetterSpacing' => array(
                        'type' => "number"
                    ),
                    'normalPriceCurrencyLetterSpacingMobile' => array(
                        'type' => "number"
                    ),
                    'normalPriceCurrencyLetterSpacingTablet' => array(
                        'type' => "number"
                    ),

                    'normalPriceCurrencyLoadGoogleFonts' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'normalPriceCurrencyFontSubset' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'normalPriceCurrencyMarginTop' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginRight' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'normalPriceCurrencyPosition' => array(
                        'type' => 'string'
                    ),


                    'imageOrder' => array(
                        'type' => "number"
                    ),
                    'imageMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'imageMarginTop' => array(
                        'type' => 'string'
                    ),
                    'imageMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'imageMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'imageMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'imageMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'imageMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'imageMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'imageMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'imageMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'imageMarginRight' => array(
                        'type' => 'string'
                    ),
                    'imageMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'imageMarginRightTablet' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'imagePaddingTop' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingRight' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'imagePaddingRightTablet' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'imageBorderRadiusTop' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusTopMobile' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusTopTablet' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusLeft' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusBottom' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusRight' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusRightMobile' => array(
                        'type' => 'string'
                    ),
                    'imageBorderRadiusRightTablet' => array(
                        'type' => 'string'
                    ),
                    'imageBorderStyle' => array(
                        'type' => 'string'
                    ),
                    'imageBorderColor' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'imageBorderWidthTop' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthTopMobile' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthTopTablet' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthLeft' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthBottom' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthRight' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthRightMobile' => array(
                        'type' => 'string'
                    ),
                    'imageBorderWidthRightTablet' => array(
                        'type' => 'string'
                    ),
                    'imageHeight' => array(
                        'type' => "number",
                    ),

                    'imageHeightTablet' => array(
                        'type' => "number",
                    ),

                    'imageHeightMobile' => array(
                        'type' => "number",
                    ),

                    'imageSpacingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'imageShadowHorizontal' => array(
                        'type' => 'number'
                    ),
                    'imageShadowVertical' => array(
                        'type' => 'number'
                    ),
                    'imageShadowBlur' => array(
                        'type' => 'number'
                    ),
                    'imageShadowSpread' => array(
                        'type' => 'number'
                    ),
                    'imageShadowColor' => array(
                        'type' => 'string'
                    ),
                    'imageShadowPosition' => array(
                        'type' => 'string'
                    ),

                    'postsToShow' => array(
                        'type' => 'number',
                        'default' => 6,
                    ),
                    'order' => array(
                        'type' => 'string',
                        'default' => 'desc',
                    ),
                    'orderBy' => array(
                        'type' => 'string',
                        'default' => 'date',
                    ),
                    'categories' => array(
                        'type' => 'string',
                        'default' => '',
                    ),
                    'tags' => array(
                        'type' => 'string',
                        'default' => '',
                    ),
                    'filterById' => array(
                        'type' => 'string',
                        'default' => ''
                    ),
                    'onlyOutofstock' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'onlyNew' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'onlyFeatured' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'onlyOnSale' => array(
                        'type' => 'boolean',
                        'default' => false
                    ),
                    'productsGridLayout' => array(
                        'type' => 'string',
                        'default' => 'zeguten-products-grid-1'
                    ),


                    //	Block Background
                    'wrapBGColor' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderStyle' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'wrapBorderWidthTop' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthTopMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthTopTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthLeft' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthBottom' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthRight' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthRightMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderWidthRightTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'wrapBorderRadiusTop' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusTopMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusTopTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusLeft' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusBottom' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusRight' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusRightMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderRadiusRightTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapBorderColor' => array(
                        'type' => 'string'
                    ),
                    'wrapShadowHorizontal' => array(
                        'type' => 'number'
                    ),
                    'wrapShadowVertical' => array(
                        'type' => 'number'
                    ),
                    'wrapShadowBlur' => array(
                        'type' => 'number'
                    ),
                    'wrapShadowSpread' => array(
                        'type' => 'number'
                    ),
                    'wrapShadowColor' => array(
                        'type' => 'string'
                    ),
                    'wrapShadowPosition' => array(
                        'type' => 'string'
                    ),

                    //	Spacing
                    'wrapPaddingType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'wrapPaddingTop' => array(
                        'type' => 'string'
                    ),
                    'wrapPaddingTopMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapPaddingTopTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapPaddingLeft' => array(
                        'type' => 'string'
                    ),
                    'wrapPaddingLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapPaddingLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapPaddingBottom' => array(
                        'type' => 'string'
                    ),
                    'wrapPaddingBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapPaddingBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapPaddingRight' => array(
                        'type' => 'string'
                    ),
                    'wrapPaddingRightMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapPaddingRightTablet' => array(
                        'type' => 'string'
                    ),

                    'wrapMarginType' => array(
                        'type' => 'string',
                        'default' => 'px'
                    ),
                    'wrapMarginTop' => array(
                        'type' => 'string'
                    ),
                    'wrapMarginTopMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapMarginTopTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapMarginLeft' => array(
                        'type' => 'string'
                    ),
                    'wrapMarginLeftMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapMarginLeftTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapMarginBottom' => array(
                        'type' => 'string'
                    ),
                    'wrapMarginBottomMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapMarginBottomTablet' => array(
                        'type' => 'string'
                    ),
                    'wrapMarginRight' => array(
                        'type' => 'string'
                    ),
                    'wrapMarginRightMobile' => array(
                        'type' => 'string'
                    ),
                    'wrapMarginRightTablet' => array(
                        'type' => 'string'
                    ),

                    'zIndex' => array(
                        'type' => 'string'
                    ),
                    'responsiveDesktop'=> array(
                        'type'    => 'boolean',
                        'default' => false,
                    ),
                    'responsiveTablet'=> array(
                        'type'    => 'boolean',
                        'default' => false,
                    ),
                    'responsiveMobile'=> array(
                        'type'    => 'boolean',
                        'default' => false,
                    ),
                    'entranceAnimation' => array(
                        'type'    => 'string',
                    ),
                    'entranceAnimationDuration' => array(
                        'type'    => 'string',
                        'default' => '1500ms',
                    ),
                    'entranceAnimationDelay' => array(
                        'type'    => 'string',
                        'default' => '200ms',
                    ),

                ),
                'render_callback' => 'render_products_grid_block',
            )
        );
    }


/**
* Add categories, tags and button link to wc/store/products
*/
function add_additional_fields_to_products($dispatch_result, $request, $route, $handler)
    {

        if ($route !== '/wc/store/products' || !isset($_GET['include_zeguten_data'])) {
            return $dispatch_result;
        }

        $callback = $handler['callback'];
        $response = call_user_func($callback, $request);

        $data = isset($response->data) ? $response->data : null;

        if (!isset($data) || !is_array($data) || count($data) < 1) {
            return $response;
        }


        foreach ($data as $key => $item) {
            
            if (!isset($item['id'])) {
                continue;
            }
            $product = wc_get_product($item['id']);

            if (!isset($product) || !$product) {
                continue;
            }

            $tagsList = wc_get_product_tag_list($item['id'], ", ", "");
            $categoriesList = wc_get_product_category_list($item['id'], ",", "");
            $data[$key]['zeguten_categories'] = $categoriesList;
            $data[$key]['zeguten_tags'] = $tagsList;
            $data[$key]['zeguten_is_featured'] = $product->is_featured();
            $data[$key]['zeguten_date'] = $product->get_date_created();

            if (isset($item['is_purchasable']) && !$item['is_purchasable'] && $product->get_type() !== 'simple') {
                $data[$key]["add_to_cart"]->link = $item['permalink'];
            } elseif (isset($item['is_in_stock']) && !$item['is_in_stock']) {
                $data[$key]["add_to_cart"]->link = esc_url(add_query_arg('add-to-cart', $item['id'], ''));
            } else {
                $data[$key]["add_to_cart"]->link = $item['permalink'];
            }

        }

        $response->data = $data;

        return $response;
    }

    add_filter('rest_dispatch_request', 'add_additional_fields_to_products', 10, 4);
}


