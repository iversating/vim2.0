<?php
/**
 * Newsletter block registration and rendering functions.
 *
 * @package ZeGuten
 */

add_action( 'init', 'zeguten_register_subscribe_block' );
/**
 * Registers the newsletter block.
 */
function zeguten_register_subscribe_block() {

	register_block_type(
		'zeguten/subscribe',
		[
			'attributes'      => zeguten_subscribe_block_attributes(),
			'render_callback' => 'zeguten_render_subscribe_block',
		]
	);
}

/**
 * Renders the newsletter block.
 *
 * @param array $attributes The block attributes.
 * @return string The block HTML.
 */
function zeguten_render_subscribe_block( $attributes ) {

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- False positive. Only used for displaying a message on AMP redirects.
		if ( ! empty( $_GET['zeguten-subscribe-submission-message'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- False positive. Only used for displaying a message on AMP redirects.
			echo '<p class="zeguten-subscribe-submission-message">' . esc_html( urldecode( sanitize_text_field( wp_unslash( $_GET['zeguten-subscribe-submission-message'] ) ) ) );
			return;
		}

		$amp_endpoint = function_exists( 'is_amp_endpoint' ) && is_amp_endpoint();

		$hubspot_installed = defined( 'LEADIN_PLUGIN_VERSION' );

		if ( ! $amp_endpoint && ! $hubspot_installed ) {
			wp_enqueue_script( 'zeguten-subscribe-functions' );
		}

		//Custom Icon
		$icon_label = zeguten_get_icon( $attributes['label_icon'] );
		$icon_button = zeguten_get_icon( $attributes['button_icon'] );

		$defaults = [];
		foreach ( zeguten_subscribe_block_attributes() as $key => $values ) {
			$defaults[ $key ] = isset( $values['default'] ) ? $values['default'] : null;
		}

		$checkbox_form = '';

		if (isset($attributes['enableSubmit']) && $attributes['enableSubmit'] == true){

			$checkbox_form .= sprintf('<div class="zeguten-subscribe__checkbox-wrap"> 

				<input class="zeguten-subscribe-email-checkbox" name="checkbox" type="checkbox">

				<label for="checkbox">%1$s</label></div>', $attributes['confirmation'] );
			}

		$label_icon  = '';

		// Wrap the tags content
		if (isset($attributes['label_icon']) && $attributes['label_icon'] != ''){
			$label_icon .= sprintf('<div class="label-icon">%1$s</div>' , $icon_label);
		}

		$button_icon  = '';

		// Wrap the tags content
		if (isset($attributes['button_icon']) && $attributes['button_icon'] != ''){
			$button_icon .= sprintf('<span class="button-icon">%1$s</span>' , $icon_button);
		}

		$button_text = '';
		$blockAnimation = '';
		$attr_responsive = '';
		$attr_wow = '';

		// Wrap the tags content
		if (isset($attributes['button_text']) && $attributes['button_text'] != ''){
			$button_text .= sprintf('<span class="zeguten-subscribe__text">%1$s</span>', esc_attr( $attributes['button_text'] ));
		}

		$attributes = wp_parse_args( $attributes, $defaults );

		$block_id = 'zeguten-subscribe-' . $attributes['block_id'];

		$baseClass = "zeguten-subscribe zeguten_block";

		$default_class = 'zeguten-block-container';

		$wowDurationData  = $attributes['entranceAnimationDuration']  !== '' ? $attributes['entranceAnimationDuration'] : '2000ms';
		$wowDelayData  = $attributes['entranceAnimationDelay']     !== '' ? $attributes['entranceAnimationDelay']    : '500ms';

		if ( isset( $attributes['entranceAnimation'] ) && ( $attributes['entranceAnimation'] )) {
			$attr_wow .= ' data-wow-duration=' .  esc_attr($wowDurationData) .  '';
			$attr_wow .= ' data-wow-delay=' .  esc_attr($wowDelayData) .  '';
		}

		if ( isset( $attributes['entranceAnimation'] ) && $attributes['entranceAnimation'] ) {
			$blockAnimation = 'animated ' . esc_attr($attributes['entranceAnimation']);
		}

		$responsiveDesktop = $attributes['responsiveDesktop']  !== true ? $attributes['responsiveDesktop'] : 'hidden';
		$responsiveTablet  = $attributes['responsiveTablet']   !== true ? $attributes['responsiveTablet']  : 'hidden';
		$responsiveMobile  = $attributes['responsiveMobile']   !== true ? $attributes['responsiveMobile']  : 'hidden';

		if (isset( $attributes['responsiveDesktop'] ) && ( $attributes['responsiveDesktop'] )) {
			$attr_responsive .= ' data-device-desktop=' .  esc_attr($responsiveDesktop) .  '';
		}

		if  (isset( $attributes['responsiveTablet'] ) && ( $attributes['responsiveTablet'] )){
			$attr_responsive .= ' data-device-tablet='  .  esc_attr($responsiveTablet)  .  '';
		}

		if  (isset( $attributes['responsiveMobile'] ) && ( $attributes['responsiveMobile'] )){
			$attr_responsive .= ' data-device-mobile='  .  esc_attr($responsiveMobile)  .  '';
		}

		$class = 'zeguten-subscribe__wrap';

		$form = '


				<form method="post" action-xhr="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '">

				<div class="zeguten-subscribe__form zeguten-subscribe-' . esc_attr( $attributes['layout'] ) . '-layout">

				<label for="zeguten-subscribe-email-address-' . esc_attr( $attributes['instanceId'] ) . '" class="zeguten-subscribe-label">' . esc_html( $attributes['emailInputLabel'] ) . '</label>

				<div class="zeguten-subscribe__input-group">

					<div class="zeguten-subscribe__input">

						'. ( $label_icon ) . '

						<input type="email" id="zeguten-subscribe-email-address-' . esc_attr( $attributes['instanceId'] ) . '" name="zeguten-subscribe-email-address"  class="zeguten-subscribe-email-address" placeholder= "' . esc_attr( $attributes['placeholder'] ) . '"
						/>
						<div class="zeguten-subscribe-message"></div>

					</div>

					<button type="submit" class="zeguten-subscribe__button" name="submit" 

					id="submit" value="' . esc_attr( $attributes['button_text'] ) . '">'. ( $button_icon ) . ' '. ( $button_text ) . '

					</button>

				</div>

				<div class="zeguten-subscribe__configuration">
					<input type="hidden" name="zeguten-subscribe-mailing-list-provider" value="' . esc_attr( $attributes['mailingListProvider'] ) . '" />
					<input type="hidden" name="zeguten-subscribe-mailing-list" value="' . esc_attr( $attributes['mailingList'] ) . '" />
					<input type="hidden" name="zeguten-subscribe-success-message" value="' . esc_attr( $attributes['successMessage'] ) . '" />
					<input type="hidden" name="zeguten-subscribe-double-opt-in" value="' . esc_attr( $attributes['doubleOptIn'] ) . '" />
					<input type="hidden" name="zeguten-subscribe-amp-endpoint-request" value="' . $amp_endpoint . '" />
					<input type="hidden" name="zeguten-subscribe-form-nonce" value="' . wp_create_nonce( 'zeguten-subscribe-form-nonce' ) . '" />
				</div>

				
				 '. ( $checkbox_form ) . '

				</div>

				</form>';

	return sprintf(

		'<div id="%1$s" class="%2$s %3$s" %4$s %5$s> <div class="%6$s"> <div class="%7$s"> %8$s </div></div></div>',
		esc_attr($block_id),
		esc_attr($baseClass),
		$blockAnimation,
		$attr_responsive,
		$attr_wow,
		$default_class,
		esc_attr( $class ),
		$form	
	);	
}


/**
 * Returns the newsletter block attributes.
 *
 * @return array
 */
function zeguten_subscribe_block_attributes() {
	return [
		'block_id'  => [
			'type' => 'string',
			'default' => 'not_set',
		],
		'block_css'  => [
			'type' => 'string',
		],
		'inputLabelColor' => [
			'type'    => 'string',
		],

		'iconColor'             => [
			'type'    => 'string',
		],
		'iconSize'             => [
			'type'    => 'number',
		],
		'iconSizeTablet'             => [
			'type'    => 'number',
		],
		'iconSizeMobile'             => [
			'type'    => 'number',
		],
		'buttonSizeType'=> [
			'type'    => 'string',
			'default' => 'px',
		],

		'buttonSize'             => [
			'type'    => 'number',
		],
		'buttonSizeTablet'             => [
			'type'    => 'number',
		],
		'buttonSizeMobile'             => [
			'type'    => 'number',
		],
		'buttonSizeType' => [
			'type'    => 'string',
			'default' => 'px',
		],


		'iconMarginType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'iconSizeType'=> [
			'type'    => 'string',
			'default' => 'px',
		],
		'button_icon'=> [
			'type'    => 'string',
			'default' => '',
		],

		'iconMarginTop' => [
			'type'    => 'string'
		],
		'iconMarginTopMobile' => [
			'type'    => 'string'
		],
		'iconMarginTopTablet' => [
			'type'    => 'string'
		],
		'iconMarginLeft' => [
			'type'    => 'string'
		],
		'iconMarginLeftMobile' => [
			'type'    => 'string'
		],
		'iconMarginLeftTablet' => [
			'type'    => 'string'
		],
		'iconMarginBottom' => [
			'type'    => 'string'
		],
		'iconMarginBottomMobile' => [
			'type'    => 'string'
		],
		'iconMarginBottomTablet' => [
			'type'    => 'string'
		],
		'iconMarginRight' => [
			'type'    => 'string'
		],
		'iconMarginRightMobile' => [
			'type'    => 'string'
		],
		'iconMarginRightTablet' => [
			'type'    => 'string'
		],

		'alignContainer' => [
			'type' => 'string',
			'default' => 'flex-start',
		],

		'button_text' => [
			'type'    => 'string',
			'default' => esc_html__( 'Subscribe', 'zeguten' ),
		],
		'confirmation'=> [
			'type'    => 'string',
			'default' => esc_html__( 'I agree with the Terms of service and Privacy policy', 'zeguten' ),
		],
		'instanceId'  => [
			'type'    => 'number',
			'default' => 1,
		],

		'emailInputLabel'             => [
			'type'    => 'string',
			'default' => esc_html__( 'Email Address', 'zeguten' ),
		],
		'successMessage'              => [
			'type'    => 'string',
			'default' => esc_html__( 'Successful submission.', 'zeguten' ),
		],
		'buttonTextProcessing'        => [
			'type'    => 'string',
			'default' => esc_html__( 'Sending...', 'zeguten' ),
		],

		'buttonTextSuccess' => [
			'type'    => 'string',
			'default' => esc_html__( 'Thanks', 'zeguten' ),
		],

		'placeholder'        => [
			'type'    => 'string',
			'default' => esc_html__( '* Enter please your email address', 'zeguten' ),
		],
		
		'mailingList' => [
			'type' => 'string',
		],
		'mailingListProvider'         => [
			'type'    => 'string',
			'default' => 'mailchimp',
		],
		'layout'      => [
			'type'    => 'string',
			'default' => 'inline',
		],
		'doubleOptIn'   => [
			'type'    => 'boolean',
			'default' => false,
		],
		'enableSubmit'   => [
			'type'    => 'boolean',
			'default' => false,
		],
		'label_icon'   => [
			'type'    => 'string',
			'default' => '',
		],
		'widthType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'confirmColor'   => [
			'type'    => 'string',
		],
		'width'   => [
			'type'    => 'number',
			'default' => '',
		],
		'tabletWidth'   => [
			'type'    => 'number',
			'default' => '',
		],
		'mobileWidth'   => [
			'type'    => 'number',
			'default' => '',
		],
		'widthTypeInput'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'widthInput'   => [
			'type'    => 'number',
			'default' => '',
		],
		'tabletWidthInput'   => [
			'type'    => 'number',
			'default' => '',
		],
		'mobileWidthInput'   => [
			'type'    => 'number',
			'default' => '',
		],

		'widthTypeSubmit'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'widthSubmit'   => [
			'type'    => 'number',
			'default' => '',
		],
		'tabletWidthSubmit'   => [
			'type'    => 'number',
			'default' => '',
		],
		'mobileWidthSubmit'   => [
			'type'    => 'number',
			'default' => '',
		],

		'submitBGColor'   => [
			'type'    => 'string',
		],

		'submitColor'   => [
			'type'    => 'string',
		],

		'submitHoverBGColor'   => [
			'type'    => 'string',
		],

		'submitHoverColor'   => [
			'type'    => 'string',
		],

		'wrapBGColor'   => [
			'type'    => 'string',
		],
		'wrapBorderStyle'   => [
			'type'    => 'string',
			'default' => '',
		],
		'wrapBorderWidthType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'wrapBorderWidthTop'   => [
			'type'    => 'string'
		],
		'wrapBorderWidthTopMobile'   => [
			'type'    => 'string'
		],
		'wrapBorderWidthTopTablet'   => [
			'type'    => 'string'
		],
		'wrapBorderWidthLeft'   => [
			'type'    => 'string'
		],
		'wrapBorderWidthLeftMobile'   => [
			'type'    => 'string'
		],
		'wrapBorderWidthLeftTablet'   => [
			'type'    => 'string'
		],
		'wrapBorderWidthBottom'   => [
			'type'    => 'number',
		],
		'wrapBorderWidthBottomMobile'   => [
			'type'    => 'string'
		],
		'wrapBorderWidthBottomTablet'   => [
			'type'    => 'string'
		],
		'wrapBorderWidthRight'   => [
			'type'    => 'string'
		],
		'wrapBorderWidthRightMobile'   => [
			'type'    => 'string'
		],
		'wrapBorderWidthRightTablet'   => [
			'type'    => 'string'
		],

		'wrapBorderRadiusType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'wrapBorderRadiusTop'   => [
			'type'    => 'string'
		],
		'wrapBorderRadiusTopMobile'   => [
			'type'    => 'string'
		],
		'wrapBorderRadiusTopTablet'   => [
			'type'    => 'string'
		],
		'wrapBorderRadiusLeft'   => [
			'type'    => 'string'
		],
		'wrapBorderRadiusLeftMobile'   => [
			'type'    => 'string'
		],
		'wrapBorderRadiusLeftTablet'   => [
			'type'    => 'string'
		],
		'wrapBorderRadiusBottom'   => [
			'type'    => 'string'
		],
		'wrapBorderRadiusBottomMobile'   => [
			'type'    => 'string'
		],
		'wrapBorderRadiusBottomTablet'   => [
			'type'    => 'string'
		],
		'wrapBorderRadiusRight'   => [
			'type'    => 'string'
		],
		'wrapBorderRadiusRightMobile'   => [
			'type'    => 'string'
		],
		'wrapBorderRadiusRightTablet'   => [
			'type'    => 'string'
		],

		'wrapBorderColor' => [
			'type'    => 'string',
		],
		'wrapShadowHorizontal' => [
			'type'    => 'number',
		],
		'wrapShadowVertical' => [
			'type'    => 'number',
		],
		'wrapShadowBlur' => [
			'type'    => 'number',
		],
		'wrapShadowSpread' => [
			'type'    => 'number',
		],
		'wrapShadowColor' => [
			'type'    => 'string',
		],
		'wrapShadowPosition' => [
			'type'    => 'string',
		],

		'inputBorderStyle'   => [
			'type'    => 'string',
			'default' => '',
		],
		'inputBorderWidthType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'inputBorderWidthTop'   => [
			'type'    => 'string'
		],
		'inputBorderWidthTopMobile'   => [
			'type'    => 'string'
		],
		'inputBorderWidthTopTablet'   => [
			'type'    => 'string'
		],
		'inputBorderWidthLeft'   => [
			'type'    => 'string'
		],
		'inputBorderWidthLeftMobile'   => [
			'type'    => 'string'
		],
		'inputBorderWidthLeftTablet'   => [
			'type'    => 'string'
		],
		'inputBorderWidthBottom'   => [
			'type'    => 'string'
		],
		'inputBorderWidthBottomMobile'   => [
			'type'    => 'string'
		],
		'inputBorderWidthBottomTablet'   => [
			'type'    => 'string'
		],
		'inputBorderWidthRight'   => [
			'type'    => 'string'
		],
		'inputBorderWidthRightMobile'   => [
			'type'    => 'string'
		],
		'inputBorderWidthRightTablet'   => [
			'type'    => 'string'
		],
		'inputBorderColor' => [
			'type'    => 'string',
		],
		'inputShadowHorizontal' => [
			'type'    => 'number',
		],
		'inputShadowVertical' => [
			'type'    => 'number',
		],
		'inputShadowBlur' => [
			'type'    => 'number',
		],
		'inputShadowSpread' => [
			'type'    => 'number',
		],
		'inputShadowColor' => [
			'type'    => 'string',
		],
		'inputShadowPosition' => [
			'type'    => 'string',
		],

		'normalBorderStyle'   => [
			'type'    => 'string',
			'default' => '',
		],
		'normalBorderWidthType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'normalBorderWidthTop'   => [
			'type'    => 'string'
		],
		'normalBorderWidthTopMobile'   => [
			'type'    => 'string'
		],
		'normalBorderWidthTopTablet'   => [
			'type'    => 'string'
		],
		'normalBorderWidthLeft'   => [
			'type'    => 'string'
		],
		'normalBorderWidthLeftMobile'   => [
			'type'    => 'string'
		],
		'normalBorderWidthLeftTablet'   => [
			'type'    => 'string'
		],
		'normalBorderWidthBottom'   => [
			'type'    => 'string'
		],
		'normalBorderWidthBottomMobile'   => [
			'type'    => 'string'
		],
		'normalBorderWidthBottomTablet'   => [
			'type'    => 'string'
		],
		'normalBorderWidthRight'   => [
			'type'    => 'string'
		],
		'normalBorderWidthRightMobile'   => [
			'type'    => 'string'
		],
		'normalBorderWidthRightTablet'   => [
			'type'    => 'string'
		],
		'normalBorderColor' => [
			'type'    => 'string',
		],
		'normalShadowHorizontal' => [
			'type'    => 'number',
		],
		'normalShadowVertical' => [
			'type'    => 'number',
		],
		'normalShadowBlur' => [
			'type'    => 'number',
		],
		'normalShadowSpread' => [
			'type'    => 'number',
		],
		'normalShadowColor' => [
			'type'    => 'string',
		],
		'normalShadowPosition' => [
			'type'    => 'string',
		],

		'containerErrorBorderStyle'   => [
			'type'    => 'string',
			'default' => '',
		],
		'containerErrorBorderWidthType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'containerErrorBorderWidthTop'   => [
			'type'    => 'string'
		],
		'containerErrorBorderWidthTopMobile'   => [
			'type'    => 'string'
		],
		'containerErrorBorderWidthTopTablet'   => [
			'type'    => 'string'
		],
		'containerErrorBorderWidthLeft'   => [
			'type'    => 'string'
		],
		'containerErrorBorderWidthLeftMobile'   => [
			'type'    => 'string'
		],
		'containerErrorBorderWidthLeftTablet'   => [
			'type'    => 'string'
		],
		'containerErrorBorderWidthBottom'   => [
			'type'    => 'string'
		],
		'containerErrorBorderWidthBottomMobile'   => [
			'type'    => 'string'
		],
		'containerErrorBorderWidthBottomTablet'   => [
			'type'    => 'string'
		],
		'containerErrorBorderWidthRight'   => [
			'type'    => 'string'
		],
		'containerErrorBorderWidthRightMobile'   => [
			'type'    => 'string'
		],
		'containerErrorBorderWidthRightTablet'   => [
			'type'    => 'string'
		],
		'containerErrorBorderColor' => [
			'type'    => 'string'
		],
		'containerErrorShadowHorizontal' => [
			'type'    => 'string'
		],
		'containerErrorShadowVertical' => [
			'type'    => 'string'
		],
		'containerErrorShadowBlur' => [
			'type'    => 'string'
		],
		'containerErrorShadowSpread' => [
			'type'    => 'string'
		],
		'containerErrorShadowColor' => [
			'type'    => 'string'
		],
		'containerErrorShadowPosition' => [
			'type'    => 'string'
		],

		'submitBorderStyle'   => [
			'type'    => 'string',
			'default' => '',
		],
		'submitBorderWidthType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'submitBorderWidthTop'   => [
			'type'    => 'string'
		],
		'submitBorderWidthTopMobile'   => [
			'type'    => 'string'
		],
		'submitBorderWidthTopTablet'   => [
			'type'    => 'string'
		],
		'submitBorderWidthLeft'   => [
			'type'    => 'string'
		],
		'submitBorderWidthLeftMobile'   => [
			'type'    => 'string'
		],
		'submitBorderWidthLeftTablet'   => [
			'type'    => 'string'
		],
		'submitBorderWidthBottom'   => [
			'type'    => 'string'
		],
		'submitBorderWidthBottomMobile'   => [
			'type'    => 'string'
		],
		'submitBorderWidthBottomTablet'   => [
			'type'    => 'string'
		],
		'submitBorderWidthRight'   => [
			'type'    => 'string'
		],
		'submitBorderWidthRightMobile'   => [
			'type'    => 'string'
		],
		'submitBorderWidthRightTablet'   => [
			'type'    => 'string'
		],
		'submitBorderColor' => [
			'type'    => 'string'
		],
		'submitShadowHorizontal' => [
			'type'    => 'string'
		],
		'submitShadowVertical' => [
			'type'    => 'string'
		],
		'submitShadowBlur' => [
			'type'    => 'string'
		],
		'submitShadowSpread' => [
			'type'    => 'string'
		],
		'submitShadowColor' => [
			'type'    => 'string'
		],
		'submitShadowPosition' => [
			'type'    => 'string'
		],

		'submitHoverBorderStyle'   => [
			'type'    => 'string',
			'default' => '',
		],
		'submitHoverBorderWidthType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'submitHoverBorderWidthTop'   => [
			'type'    => 'string'
		],
		'submitHoverBorderWidthTopMobile'   => [
			'type'    => 'string'
		],
		'submitHoverBorderWidthTopTablet'   => [
			'type'    => 'string'
		],
		'submitHoverBorderWidthLeft'   => [
			'type'    => 'string'
		],
		'submitHoverBorderWidthLeftMobile'   => [
			'type'    => 'string'
		],
		'submitHoverBorderWidthLeftTablet'   => [
			'type'    => 'string'
		],
		'submitHoverBorderWidthBottom'   => [
			'type'    => 'string'
		],
		'submitHoverBorderWidthBottomMobile'   => [
			'type'    => 'string'
		],
		'submitHoverBorderWidthBottomTablet'   => [
			'type'    => 'string'
		],
		'submitHoverBorderWidthRight'   => [
			'type'    => 'string'
		],
		'submitHoverBorderWidthRightMobile'   => [
			'type'    => 'string'
		],
		'submitHoverBorderWidthRightTablet'   => [
			'type'    => 'string'
		],
		'submitHoverBorderColor' => [
			'type'    => 'string'
		],
		'submitHoverShadowHorizontal' => [
			'type'    => 'string'
		],
		'submitHoverShadowVertical' => [
			'type'    => 'string'
		],
		'submitHoverShadowBlur' => [
			'type'    => 'string'
		],
		'submitHoverShadowSpread' => [
			'type'    => 'string'
		],
		'submitHoverShadowColor' => [
			'type'    => 'string'
		],
		'submitHoverShadowPosition' => [
			'type'    => 'string'
		],

		'inputFocusBorderStyle'   => [
			'type'    => 'string',
			'default' => '',
		],
		'inputFocusBorderWidthType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'inputFocusBorderWidthTop'   => [
			'type'    => 'string'
		],
		'inputFocusBorderWidthTopMobile'   => [
			'type'    => 'string'
		],
		'inputFocusBorderWidthTopTablet'   => [
			'type'    => 'string'
		],
		'inputFocusBorderWidthLeft'   => [
			'type'    => 'string'
		],
		'inputFocusBorderWidthLeftMobile'   => [
			'type'    => 'string'
		],
		'inputFocusBorderWidthLeftTablet'   => [
			'type'    => 'string'
		],
		'inputFocusBorderWidthBottom'   => [
			'type'    => 'string'
		],
		'inputFocusBorderWidthBottomMobile'   => [
			'type'    => 'string'
		],
		'inputFocusBorderWidthBottomTablet'   => [
			'type'    => 'string'
		],
		'inputFocusBorderWidthRight'   => [
			'type'    => 'string'
		],
		'inputFocusBorderWidthRightMobile'   => [
			'type'    => 'string'
		],
		'inputFocusBorderWidthRightTablet'   => [
			'type'    => 'string'
		],
		'inputFocusBorderColor' => [
			'type'    => 'string',
		],
		'inputFocusShadowHorizontal' => [
			'type'    => 'string'
		],
		'inputFocusShadowVertical' => [
			'type'    => 'number'
		],
		'inputFocusShadowBlur' => [
			'type'    => 'number'
		],
		'inputFocusShadowSpread' => [
			'type'    => 'number'
		],
		'inputFocusShadowColor' => [
			'type'    => 'string',
		],
		'inputFocusShadowPosition' => [
			'type'    => 'string',
		],

		'inputErrorBorderStyle'   => [
			'type'    => 'string',
			'default' => '',
		],
		'inputErrorBorderWidthType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'inputErrorBorderWidthTop'   => [
			'type'    => 'string'
		],
		'inputErrorBorderWidthTopMobile'   => [
			'type'    => 'string'
		],
		'inputErrorBorderWidthTopTablet'   => [
			'type'    => 'string'
		],
		'inputErrorBorderWidthLeft'   => [
			'type'    => 'string'
		],
		'inputErrorBorderWidthLeftMobile'   => [
			'type'    => 'string'
		],
		'inputErrorBorderWidthLeftTablet'   => [
			'type'    => 'string'
		],
		'inputErrorBorderWidthBottom'   => [
			'type'    => 'string'
		],
		'inputErrorBorderWidthBottomMobile'   => [
			'type'    => 'string'
		],
		'inputErrorBorderWidthBottomTablet'   => [
			'type'    => 'string'
		],
		'inputErrorBorderWidthRight'   => [
			'type'    => 'string'
		],
		'inputErrorBorderWidthRightMobile'   => [
			'type'    => 'string'
		],
		'inputErrorBorderWidthRightTablet'   => [
			'type'    => 'string'
		],
		'inputErrorBorderColor' => [
			'type'    => 'string',
		],
		'inputErrorShadowHorizontal' => [
			'type'    => 'number',
		],
		'inputErrorShadowVertical' => [
			'type'    => 'number',
		],
		'inputErrorShadowBlur' => [
			'type'    => 'number',
		],
		'inputErrorShadowSpread' => [
			'type'    => 'number',
		],
		'inputErrorShadowColor' => [
			'type'    => 'string',
		],
		'inputErrorShadowPosition' => [
			'type'    => 'string',
		],


		'successBorderStyle'   => [
			'type'    => 'string',
			'default' => '',
		],
		'successBorderWidthType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'successBorderWidthTop'   => [
			'type'    => 'string'
		],
		'successBorderWidthTopMobile'   => [
			'type'    => 'string'
		],
		'successBorderWidthTopTablet'   => [
			'type'    => 'string'
		],
		'successBorderWidthLeft'   => [
			'type'    => 'string'
		],
		'successBorderWidthLeftMobile'   => [
			'type'    => 'string'
		],
		'successBorderWidthLeftTablet'   => [
			'type'    => 'string'
		],
		'successBorderWidthBottom'   => [
			'type'    => 'string'
		],
		'successBorderWidthBottomMobile'   => [
			'type'    => 'string'
		],
		'successBorderWidthBottomTablet'   => [
			'type'    => 'string'
		],
		'successBorderWidthRight'   => [
			'type'    => 'string'
		],
		'successBorderWidthRightMobile'   => [
			'type'    => 'string'
		],
		'successBorderWidthRightTablet'   => [
			'type'    => 'string'
		],
		'successBorderColor' => [
			'type'    => 'string',
		],
		'successShadowHorizontal' => [
			'type'    => 'number',
		],
		'successShadowVertical' => [
			'type'    => 'number',
		],
		'successShadowBlur' => [
			'type'    => 'number',
		],
		'successShadowSpread' => [
			'type'    => 'number',
		],
		'successShadowColor' => [
			'type'    => 'string',
		],
		'successShadowPosition' => [
			'type'    => 'string',
		],


		'errorBorderStyle'   => [
			'type'    => 'string',
			'default' => '',
		],
		'errorBorderWidthType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'errorBorderWidthTop'   => [
			'type'    => 'string'
		],
		'errorBorderWidthTopMobile'   => [
			'type'    => 'string'
		],
		'errorBorderWidthTopTablet'   => [
			'type'    => 'string'
		],
		'errorBorderWidthLeft'   => [
			'type'    => 'string'
		],
		'errorBorderWidthLeftMobile'   => [
			'type'    => 'string'
		],
		'errorBorderWidthLeftTablet'   => [
			'type'    => 'string'
		],
		'errorBorderWidthBottom'   => [
			'type'    => 'string'
		],
		'errorBorderWidthBottomMobile'   => [
			'type'    => 'string'
		],
		'errorBorderWidthBottomTablet'   => [
			'type'    => 'string'
		],
		'errorBorderWidthRight'   => [
			'type'    => 'string'
		],
		'errorBorderWidthRightMobile'   => [
			'type'    => 'string'
		],
		'errorBorderWidthRightTablet'   => [
			'type'    => 'string'
		],
		'errorBorderColor' => [
			'type'    => 'string',
		],
		'errorShadowHorizontal' => [
			'type'    => 'number',
		],
		'errorShadowVertical' => [
			'type'    => 'number',
		],
		'errorShadowBlur' => [
			'type'    => 'number',
		],
		'errorShadowSpread' => [
			'type'    => 'number',
		],
		'errorShadowColor' => [
			'type'    => 'string',
		],
		'errorShadowPosition' => [
			'type'    => 'string',
		],


		'wrapPaddingType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'wrapPaddingTop' => [
			'type'    => 'string'
		],
		'wrapPaddingTopMobile' => [
			'type'    => 'string'
		],
		'wrapPaddingTopTablet' => [
			'type'    => 'string'
		],
		'wrapPaddingLeft' => [
			'type'    => 'string'
		],
		'wrapPaddingLeftMobile' => [
			'type'    => 'string'
		],
		'wrapPaddingLeftTablet' => [
			'type'    => 'string'
		],
		'wrapPaddingBottom' => [
			'type'    => 'string'
		],
		'wrapPaddingBottomMobile' => [
			'type'    => 'string'
		],
		'wrapPaddingBottomTablet' => [
			'type'    => 'string'
		],
		'wrapPaddingRight' => [
			'type'    => 'string'
		],
		'wrapPaddingRightMobile' => [
			'type'    => 'string'
		],
		'wrapPaddingRightTablet' => [
			'type'    => 'string'
		],

		'wrapMarginType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'wrapMarginTop' => [
			'type'    => 'string'
		],
		'wrapMarginTopMobile' => [
			'type'    => 'string'
		],
		'wrapMarginTopTablet' => [
			'type'    => 'string'
		],
		'wrapMarginLeft' => [
			'type'    => 'string'
		],
		'wrapMarginLeftMobile' => [
			'type'    => 'string'
		],
		'wrapMarginLeftTablet' => [
			'type'    => 'string'
		],
		'wrapMarginBottom' => [
			'type'    => 'string'
		],
		'wrapMarginBottomMobile' => [
			'type'    => 'string'
		],
		'wrapMarginBottomTablet' => [
			'type'    => 'string'
		],
		'wrapMarginRight' => [
			'type'    => 'string'
		],
		'wrapMarginRightMobile' => [
			'type'    => 'string'
		],
		'wrapMarginRightTablet' => [
			'type'    => 'string'
		],

		'labelLoadGoogleFonts'    => [
			'type'    => 'boolean',
			'default' => false,
		],
		'labelFontFamily' => [
			'type' => 'string',
			'default' => '',
		],
		'labelFontWeight' => [
			'type' => 'string',
			'default' => '',
		],
		'labelFontSubset' => [
			'type' => 'string',
			'default' => '',
		],
		'labelFontSize' => [
			'type'  => 'number',
		],
		'labelFontSizeTablet' => [
			'type'  => 'number',
		],
		'labelFontSizeMobile' => [
			'type'  => 'number',
		],
		'labelLineHeight' => [
			'type'  => 'number',
		],
		'labelLineHeightTablet' => [
			'type'  => 'number',
		],
		'labelLineHeightMobile' => [
			'type'  => 'number',
		],
		'labelFontSizeType' => [
			'type'    => 'string',
			'default' => 'px',
		],
		'labelLineHeightType' => [
			'type'    => 'string',
			'default' => 'em',
		],
		'labelLetterSpacingType'  => [
			'type'    => 'string',
			'default' => 'em',
		],
		'labelLetterSpacing' => [
			'type'    => 'number',
		],
		'labelLetterSpacingTablet' => [
			'type'  => 'number',
		],
		'labelLetterSpacingMobile' => [
			'type'  => 'number',
		],
		'labelLetterSpacingType'  => [
			'type'    => 'string',
			'default' => 'em',
		],
		'labelTextTransform'     => [
			'type'    => 'string',
		],
		'labelFontStyle'     => [
			'type'    => 'string',
		],
		'labelTextDecoration'     => [
			'type'    => 'string',
		],

		'submitLoadGoogleFonts'    => [
			'type'    => 'boolean',
			'default' => false,
		],
		'submitFontFamily' => [
			'type' => 'string',
			'default' => '',
		],
		'submitFontWeight' => [
			'type' => 'string',
			'default' => '',
		],
		'submitFontSubset' => [
			'type' => 'string',
			'default' => '',
		],
		'submitFontSize' => [
			'type'  => 'number',
		],
		'submitFontSizeTablet' => [
			'type'  => 'number',
		],
		'submitFontSizeMobile' => [
			'type'  => 'number',
		],
		'submitLineHeight' => [
			'type'  => 'number',
		],
		'submitLineHeightTablet' => [
			'type'  => 'number',
		],
		'submitLineHeightMobile' => [
			'type'  => 'number',
		],
		'submitFontSizeType' => [
			'type'    => 'string',
			'default' => 'px',
		],
		'submitLineHeightType' => [
			'type'    => 'string',
			'default' => 'em',
		],
		'submitLetterSpacingType'  => [
			'type'    => 'string',
			'default' => 'em',
		],
		'submitLetterSpacing' => [
			'type'    => 'number',
		],
		'submitLetterSpacingTablet' => [
			'type'  => 'number',
		],
		'submitLetterSpacingMobile' => [
			'type'  => 'number',
		],

		'submitTextTransform'     => [
			'type'    => 'string',
		],
		'submitFontStyle'     => [
			'type'    => 'string',
		],
		'submitTextDecoration'     => [
			'type'    => 'string',
		],

		'successColor'     => [
			'type'    => 'string',
		],
		'successBGColor'     => [
			'type'    => 'string',
		],
		'errorColor'     => [
			'type'    => 'string',
		],
		'errorBGColor'     => [
			'type'    => 'string',
		],

		'successLoadGoogleFonts'    => [
			'type'    => 'boolean',
			'default' => false,
		],
		'successFontFamily' => [
			'type' => 'string',
			'default' => '',
		],
		'successFontWeight' => [
			'type' => 'string',
			'default' => '',
		],
		'successFontSubset' => [
			'type' => 'string',
			'default' => '',
		],
		'successFontSize' => [
			'type'  => 'number',
		],
		'successFontSizeTablet' => [
			'type'  => 'number',
		],
		'successFontSizeMobile' => [
			'type'  => 'number',
		],
		'successLineHeight' => [
			'type'  => 'number',
		],
		'successLineHeightTablet' => [
			'type'  => 'number',
		],
		'successLineHeightMobile' => [
			'type'  => 'number',
		],
		'successFontSizeType' => [
			'type'    => 'string',
			'default' => 'px',
		],
		'successLineHeightType' => [
			'type'    => 'string',
			'default' => 'px',
		],
		'successLetterSpacingType'  => [
			'type'    => 'string',
			'default' => 'px',
		],
		'successLetterSpacing' => [
			'type'    => 'number',
		],
		'successLetterSpacingTablet' => [
			'type'  => 'number',
		],
		'successLetterSpacingMobile' => [
			'type'  => 'number',
		],
		'successLetterSpacingType'  => [
			'type'    => 'string',
			'default' => 'px',
		],
		'successTextTransform'     => [
			'type'    => 'string',
		],
		'successFontStyle'     => [
			'type'    => 'string',
		],
		'successTextDecoration'     => [
			'type'    => 'string',
		],
		'errorLoadGoogleFonts'    => [
			'type'    => 'boolean',
			'default' => false,
		],
		'errorFontFamily' => [
			'type' => 'string',
			'default' => '',
		],
		'errorFontWeight' => [
			'type' => 'string',
			'default' => '',
		],
		'errorFontSubset' => [
			'type' => 'string',
			'default' => '',
		],
		'errorFontSize' => [
			'type'  => 'number',
		],
		'errorFontSizeTablet' => [
			'type'  => 'number',
		],
		'errorFontSizeMobile' => [
			'type'  => 'number',
		],
		'errorLineHeight' => [
			'type'  => 'number',
		],
		'errorLineHeightTablet' => [
			'type'  => 'number',
		],
		'errorLineHeightMobile' => [
			'type'  => 'number',
		],
		'errorFontSizeType' => [
			'type'    => 'string',
			'default' => 'px',
		],
		'errorLineHeightType' => [
			'type'    => 'string',
			'default' => 'px',
		],
		'errorLetterSpacingType'  => [
			'type'    => 'string',
			'default' => 'px',
		],
		'errorLetterSpacing' => [
			'type'    => 'number',
		],
		'errorLetterSpacingTablet' => [
			'type'  => 'number',
		],
		'errorLetterSpacingMobile' => [
			'type'  => 'number',
		],
		'errorLetterSpacingType'  => [
			'type'    => 'string',
			'default' => 'em',
		],
		'errorTextTransform'     => [
			'type'    => 'string',
		],
		'errorFontStyle'     => [
			'type'    => 'string',
		],
		'errorTextDecoration'     => [
			'type'    => 'string',
		],

		'confirmLoadGoogleFonts'    => [
			'type'    => 'boolean',
			'default' => false,
		],
		'confirmFontFamily' => [
			'type' => 'string',
			'default' => '',
		],
		'confirmFontWeight' => [
			'type' => 'string',
			'default' => '',
		],
		'confirmFontSubset' => [
			'type' => 'string',
			'default' => '',
		],
		'confirmFontSize' => [
			'type'  => 'number',
		],
		'confirmFontSizeTablet' => [
			'type'  => 'number',
		],
		'confirmFontSizeMobile' => [
			'type'  => 'number',
		],
		'confirmLineHeight' => [
			'type'  => 'number',
		],
		'confirmLineHeightTablet' => [
			'type'  => 'number',
		],
		'confirmLineHeightMobile' => [
			'type'  => 'number',
		],
		'confirmFontSizeType' => [
			'type'    => 'string',
			'default' => 'px',
		],
		'confirmLineHeightType' => [
			'type'    => 'string',
			'default' => 'px',
		],
		'confirmLetterSpacingType'  => [
			'type'    => 'string',
			'default' => 'px',
		],
		'confirmLetterSpacing' => [
			'type'    => 'number',
		],
		'confirmLetterSpacingTablet' => [
			'type'  => 'number',
		],
		'confirmLetterSpacingMobile' => [
			'type'  => 'number',
		],
		'confirmLetterSpacingType'  => [
			'type'    => 'string',
			'default' => 'px',
		],
		'confirmTextTransform'     => [
			'type'    => 'string',
		],
		'confirmFontStyle'     => [
			'type'    => 'string',
		],
		'confirmTextDecoration'     => [
			'type'    => 'string',
		],

		'inputLoadGoogleFonts'    => [
			'type'    => 'boolean',
			'default' => false,
		],
		'inputFontFamily' => [
			'type' => 'string',
			'default' => '',
		],
		'inputFontWeight' => [
			'type' => 'string',
			'default' => '',
		],
		'inputFontSubset' => [
			'type' => 'string',
			'default' => '',
		],
		'inputFontSize' => [
			'type'  => 'number',
		],
		'inputFontSizeTablet' => [
			'type'  => 'number',
		],
		'inputFontSizeMobile' => [
			'type'  => 'number',
		],
		'inputLineHeight' => [
			'type'  => 'number',
		],
		'inputLineHeightTablet' => [
			'type'  => 'number',
		],
		'inputLineHeightMobile' => [
			'type'  => 'number',
		],
		'inputFontSizeType' => [
			'type'    => 'string',
			'default' => 'px',
		],
		'inputLineHeightType' => [
			'type'    => 'string',
			'default' => 'em',
		],
		'inputLetterSpacingType'  => [
			'type'    => 'string',
			'default' => 'em',
		],
		'inputLetterSpacing' => [
			'type'    => 'number',
		],
		'inputLetterSpacingTablet' => [
			'type'  => 'number',
		],
		'inputLetterSpacingMobile' => [
			'type'  => 'number',
		],
		'inputLetterSpacingType'  => [
			'type'    => 'string',
			'default' => 'em',
		],
		'inputTextTransform'     => [
			'type'    => 'string',
		],
		'inputFontStyle'     => [
			'type'    => 'string',
		],
		'inputTextDecoration'     => [
			'type'    => 'string',
		],
		'inputLabelAlign'     => [
			'type'    => 'string',
			'default' => 'left',
		],
		'inputAlign'     => [
			'type'    => 'string',
			'default' => 'left',
		],

		'alignInput'     => [
			'type'    => 'string',
			'default' => 'flex-start',
		],
		'alignButton'=> [
			'type'    => 'string',
			'default' => 'center',
		],

		'inputPaddingType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'inputPaddingTop' => [
			'type'    => 'string'
		],
		'inputPaddingTopMobile' => [
			'type'    => 'string'
		],
		'inputPaddingTopTablet' => [
			'type'    => 'string'
		],
		'inputPaddingLeft' => [
			'type'    => 'string'
		],
		'inputPaddingLeftMobile' => [
			'type'    => 'string'
		],
		'inputPaddingLeftTablet' => [
			'type'    => 'string'
		],
		'inputPaddingBottom' => [
			'type'    => 'string'
		],
		'inputPaddingBottomMobile' => [
			'type'    => 'string'
		],
		'inputPaddingBottomTablet' => [
			'type'    => 'string'
		],
		'inputPaddingRight' => [
			'type'    => 'string'
		],
		'inputPaddingRightMobile' => [
			'type'    => 'string'
		],
		'inputPaddingRightTablet' => [
			'type'    => 'string'
		],

		'inputMarginType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'inputMarginTop' => [
			'type'    => 'string'
		],
		'inputMarginTopMobile' => [
			'type'    => 'string'
		],
		'inputMarginTopTablet' => [
			'type'    => 'string'
		],
		'inputMarginLeft' => [
			'type'    => 'string'
		],
		'inputMarginLeftMobile' => [
			'type'    => 'string'
		],
		'inputMarginLeftTablet' => [
			'type'    => 'string'
		],
		'inputMarginBottom' => [
			'type'    => 'string'
		],
		'inputMarginBottomMobile' => [
			'type'    => 'string'
		],
		'inputMarginBottomTablet' => [
			'type'    => 'string'
		],
		'inputMarginRight' => [
			'type'    => 'string'
		],
		'inputMarginRightMobile' => [
			'type'    => 'string'
		],
		'inputMarginRightTablet' => [
			'type'    => 'string'
		],
		'inputBorderRadiusType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'errorInputBGColor'   => [
			'type'    => 'string',
		],
		'focusInputBGColor'   => [
			'type'    => 'string',
		],
		'normalInputBGColor'   => [
			'type'    => 'string',
		],

		'errorInputColor'   => [
			'type'    => 'string',
		],
		'focusInputColor'   => [
			'type'    => 'string',
		],
		'normalInputColor'   => [
			'type'    => 'string',
		],

		'inputBorderRadiusTop'   => [
			'type'    => 'string'
		],
		'inputBorderRadiusTopMobile'   => [
			'type'    => 'string'
		],
		'inputBorderRadiusTopTablet'   => [
			'type'    => 'string'
		],
		'inputBorderRadiusLeft'   => [
			'type'    => 'string'
		],
		'inputBorderRadiusLeftMobile'   => [
			'type'    => 'string'
		],
		'inputBorderRadiusLeftTablet'   => [
			'type'    => 'string'
		],
		'inputBorderRadiusBottom'   => [
			'type'    => 'string'
		],
		'inputBorderRadiusBottomMobile'   => [
			'type'    => 'string'
		],
		'inputBorderRadiusBottomTablet'   => [
			'type'    => 'string'
		],
		'inputBorderRadiusRight'   => [
			'type'    => 'string'
		],
		'inputBorderRadiusRightMobile'   => [
			'type'    => 'string'
		],
		'inputBorderRadiusRightTablet'   => [
			'type'    => 'string'
		],

		'successPaddingType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'successPaddingTop' => [
			'type'    => 'string'
		],
		'successPaddingTopMobile' => [
			'type'    => 'string'
		],
		'successPaddingTopTablet' => [
			'type'    => 'string'
		],
		'successPaddingLeft' => [
			'type'    => 'string'
		],
		'successPaddingLeftMobile' => [
			'type'    => 'string'
		],
		'successPaddingLeftTablet' => [
			'type'    => 'string'
		],
		'successPaddingBottom' => [
			'type'    => 'string'
		],
		'successPaddingBottomMobile' => [
			'type'    => 'string'
		],
		'successPaddingBottomTablet' => [
			'type'    => 'string'
		],
		'successPaddingRight' => [
			'type'    => 'string'
		],
		'successPaddingRightMobile' => [
			'type'    => 'string'
		],
		'successPaddingRightTablet' => [
			'type'    => 'string'
		],

		'successMarginType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'successMarginTop' => [
			'type'    => 'string'
		],
		'successMarginTopMobile' => [
			'type'    => 'string'
		],
		'successMarginTopTablet' => [
			'type'    => 'string'
		],
		'successMarginLeft' => [
			'type'    => 'string'
		],
		'successMarginLeftMobile' => [
			'type'    => 'string'
		],
		'successMarginLeftTablet' => [
			'type'    => 'string'
		],
		'successMarginBottom' => [
			'type'    => 'string'
		],
		'successMarginBottomMobile' => [
			'type'    => 'string'
		],
		'successMarginBottomTablet' => [
			'type'    => 'string'
		],
		'successMarginRight' => [
			'type'    => 'string'
		],
		'successMarginRightMobile' => [
			'type'    => 'string'
		],
		'successMarginRightTablet' => [
			'type'    => 'string'
		],
		'successBorderRadiusType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'successBorderRadiusTop'   => [
			'type'    => 'string'
		],
		'successBorderRadiusTopMobile'   => [
			'type'    => 'string'
		],
		'successBorderRadiusTopTablet'   => [
			'type'    => 'string'
		],
		'successBorderRadiusLeft'   => [
			'type'    => 'string'
		],
		'successBorderRadiusLeftMobile'   => [
			'type'    => 'string'
		],
		'successBorderRadiusLeftTablet'   => [
			'type'    => 'string'
		],
		'successBorderRadiusBottom'   => [
			'type'    => 'string'
		],
		'successBorderRadiusBottomMobile'   => [
			'type'    => 'string'
		],
		'successBorderRadiusBottomTablet'   => [
			'type'    => 'string'
		],
		'successBorderRadiusRight'   => [
			'type'    => 'string'
		],
		'successBorderRadiusRightMobile'   => [
			'type'    => 'string'
		],
		'successBorderRadiusRightTablet'   => [
			'type'    => 'string'
		],

		'errorPaddingType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'errorPaddingTop' => [
			'type'    => 'string'
		],
		'errorPaddingTopMobile' => [
			'type'    => 'string'
		],
		'errorPaddingTopTablet' => [
			'type'    => 'string'
		],
		'errorPaddingLeft' => [
			'type'    => 'string'
		],
		'errorPaddingLeftMobile' => [
			'type'    => 'string'
		],
		'errorPaddingLeftTablet' => [
			'type'    => 'string'
		],
		'errorPaddingBottom' => [
			'type'    => 'string'
		],
		'errorPaddingBottomMobile' => [
			'type'    => 'string'
		],
		'errorPaddingBottomTablet' => [
			'type'    => 'string'
		],
		'errorPaddingRight' => [
			'type'    => 'string'
		],
		'errorPaddingRightMobile' => [
			'type'    => 'string'
		],
		'errorPaddingRightTablet' => [
			'type'    => 'string'
		],

		'errorMarginType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'errorMarginTop' => [
			'type'    => 'string'
		],
		'errorMarginTopMobile' => [
			'type'    => 'string'
		],
		'errorMarginTopTablet' => [
			'type'    => 'string'
		],
		'errorMarginLeft' => [
			'type'    => 'string'
		],
		'errorMarginLeftMobile' => [
			'type'    => 'string'
		],
		'errorMarginLeftTablet' => [
			'type'    => 'string'
		],
		'errorMarginBottom' => [
			'type'    => 'string'
		],
		'errorMarginBottomMobile' => [
			'type'    => 'string'
		],
		'errorMarginBottomTablet' => [
			'type'    => 'string'
		],
		'errorMarginRight' => [
			'type'    => 'string'
		],
		'errorMarginRightMobile' => [
			'type'    => 'string'
		],
		'errorMarginRightTablet' => [
			'type'    => 'string'
		],
		'errorBorderRadiusType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'errorBorderRadiusTop'   => [
			'type'    => 'string'
		],
		'errorBorderRadiusTopMobile'   => [
			'type'    => 'string'
		],
		'errorBorderRadiusTopTablet'   => [
			'type'    => 'string'
		],
		'errorBorderRadiusLeft'   => [
			'type'    => 'string'
		],
		'errorBorderRadiusLeftMobile'   => [
			'type'    => 'string'
		],
		'errorBorderRadiusLeftTablet'   => [
			'type'    => 'string'
		],
		'errorBorderRadiusBottom'   => [
			'type'    => 'string'
		],
		'errorBorderRadiusBottomMobile'   => [
			'type'    => 'string'
		],
		'errorBorderRadiusBottomTablet'   => [
			'type'    => 'string'
		],
		'errorBorderRadiusRight'   => [
			'type'    => 'string'
		],
		'errorBorderRadiusRightMobile'   => [
			'type'    => 'string'
		],
		'errorBorderRadiusRightTablet'   => [
			'type'    => 'string'
		],

		'submitPaddingType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'submitPaddingTop' => [
			'type'    => 'string'
		],
		'submitPaddingTopMobile' => [
			'type'    => 'string'
		],
		'submitPaddingTopTablet' => [
			'type'    => 'string'
		],
		'submitPaddingLeft' => [
			'type'    => 'string'
		],
		'submitPaddingLeftMobile' => [
			'type'    => 'string'
		],
		'submitPaddingLeftTablet' => [
			'type'    => 'string'
		],
		'submitPaddingBottom' => [
			'type'    => 'string'
		],
		'submitPaddingBottomMobile' => [
			'type'    => 'string'
		],
		'submitPaddingBottomTablet' => [
			'type'    => 'string'
		],
		'submitPaddingRight' => [
			'type'    => 'string'
		],
		'submitPaddingRightMobile' => [
			'type'    => 'string'
		],
		'submitPaddingRightTablet' => [
			'type'    => 'string'
		],

		'submitMarginType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'submitMarginTop' => [
			'type'    => 'string'
		],
		'submitMarginTopMobile' => [
			'type'    => 'string'
		],
		'submitMarginTopTablet' => [
			'type'    => 'string'
		],
		'submitMarginLeft' => [
			'type'    => 'string'
		],
		'submitMarginLeftMobile' => [
			'type'    => 'string'
		],
		'submitMarginLeftTablet' => [
			'type'    => 'string'
		],
		'submitMarginBottom' => [
			'type'    => 'string'
		],
		'submitMarginBottomMobile' => [
			'type'    => 'string'
		],
		'submitMarginBottomTablet' => [
			'type'    => 'string'
		],
		'submitMarginRight' => [
			'type'    => 'string'
		],
		'submitMarginRightMobile' => [
			'type'    => 'string'
		],
		'submitMarginRightTablet' => [
			'type'    => 'string'
		],
		'submitBorderRadiusType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'submitBorderRadiusTop'   => [
			'type'    => 'string'
		],
		'submitBorderRadiusTopMobile'   => [
			'type'    => 'string'
		],
		'submitBorderRadiusTopTablet'   => [
			'type'    => 'string'
		],
		'submitBorderRadiusLeft'   => [
			'type'    => 'string'
		],
		'submitBorderRadiusLeftMobile'   => [
			'type'    => 'string'
		],
		'submitBorderRadiusLeftTablet'   => [
			'type'    => 'string'
		],
		'submitBorderRadiusBottom'   => [
			'type'    => 'string'
		],
		'submitBorderRadiusBottomMobile'   => [
			'type'    => 'string'
		],
		'submitBorderRadiusBottomTablet'   => [
			'type'    => 'string'
		],
		'submitBorderRadiusRight'   => [
			'type'    => 'string'
		],
		'submitBorderRadiusRightMobile'   => [
			'type'    => 'string'
		],
		'submitBorderRadiusRightTablet'   => [
			'type'    => 'string'
		],
		
		'containerPaddingType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'containerPaddingTop' => [
			'type'    => 'string'
		],
		'containerPaddingTopMobile' => [
			'type'    => 'string'
		],
		'containerPaddingTopTablet' => [
			'type'    => 'string'
		],
		'containerPaddingLeft' => [
			'type'    => 'string'
		],
		'containerPaddingLeftMobile' => [
			'type'    => 'string'
		],
		'containerPaddingLeftTablet' => [
			'type'    => 'string'
		],
		'containerPaddingBottom' => [
			'type'    => 'string'
		],
		'containerPaddingBottomMobile' => [
			'type'    => 'string'
		],
		'containerPaddingBottomTablet' => [
			'type'    => 'string'
		],
		'containerPaddingRight' => [
			'type'    => 'string'
		],
		'containerPaddingRightMobile' => [
			'type'    => 'string'
		],
		'containerPaddingRightTablet' => [
			'type'    => 'string'
		],

		'containerMarginType'   => [
			'type'    => 'string',
			'default' => 'px',
		],

		'containerNormalBGColor' => [
			'type' => 'string'
		],
		'containerErrorHoverBGColor' => [
			'type' => 'string'
		],

		'containerMarginTop' => [
			'type'    => 'string'
		],
		'containerMarginTopMobile' => [
			'type'    => 'string'
		],
		'containerMarginTopTablet' => [
			'type'    => 'string'
		],
		'containerMarginLeft' => [
			'type'    => 'string'
		],
		'containerMarginLeftMobile' => [
			'type'    => 'string'
		],
		'containerMarginLeftTablet' => [
			'type'    => 'string'
		],
		'containerMarginBottom' => [
			'type'    => 'string'
		],
		'containerMarginBottomMobile' => [
			'type'    => 'string'
		],
		'containerMarginBottomTablet' => [
			'type'    => 'string'
		],
		'containerMarginRight' => [
			'type'    => 'string'
		],
		'containerMarginRightMobile' => [
			'type'    => 'string'
		],
		'containerMarginRightTablet' => [
			'type'    => 'string'
		],
		'containerBorderRadiusType'   => [
			'type'    => 'string',
			'default' => 'px',
		],
		'containerBorderRadiusTop'   => [
			'type'    => 'string'
		],
		'containerBorderRadiusTopMobile'   => [
			'type'    => 'string'
		],
		'containerBorderRadiusTopTablet'   => [
			'type'    => 'string'
		],
		'containerBorderRadiusLeft'   => [
			'type'    => 'string'
		],
		'containerBorderRadiusLeftMobile'   => [
			'type'    => 'string'
		],
		'containerBorderRadiusLeftTablet'   => [
			'type'    => 'string'
		],
		'containerBorderRadiusBottom'   => [
			'type'    => 'string'
		],
		'containerBorderRadiusBottomMobile'   => [
			'type'    => 'string'
		],
		'containerBorderRadiusBottomTablet'   => [
			'type'    => 'string'
		],
		'containerBorderRadiusRight'   => [
			'type'    => 'string'
		],
		'containerBorderRadiusRightMobile'   => [
			'type'    => 'string'
		],
		'containerBorderRadiusRightTablet'   => [
			'type'    => 'string'
		],
		'alignMessage'   => [
			'type'    => 'string',
			'default' => 'left',
		],
		'confirmMessage'=> [
			'type'    => 'string',
			'default' => 'left',
		],
		'z_index'	=> [
			'type'    => 'string',
		],
		'responsiveDesktop'=> [
			'type'    => 'boolean',
			'default' => false,
		],
		'responsiveTablet'=> [
			'type'    => 'boolean',
			'default' => false,
		],
		'responsiveMobile'=> [
			'type'    => 'boolean',
			'default' => false,
		],
		'entranceAnimation' => [
			'type'    => 'string',
		],
		'entranceAnimationDuration' => [
			'type'    => 'string',
			'default' => '1500ms',
		],
		'entranceAnimationDelay'=> [
			'type'    => 'string',
			'default' => '200ms',
		],

	];
}
