<?php
/**
 * Server-side rendering for the Contact Form 7 Styler.
 *
 * @since   1.10.0
 * @package UAGB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Adds the Contect Form 7 Custom Post Type to REST.
 *
 * @param array  $args Array of arguments.
 * @param string $post_type Post Type.
 * @since 1.10.0
 */
function zeguten_add_cpts_to_api( $args, $post_type ) {
	if ( 'wpcf7_contact_form' === $post_type ) {
		$args['show_in_rest'] = true;
	}

	return $args;
}

add_filter( 'register_post_type_args', 'zeguten_add_cpts_to_api', 10, 2 );


/**
 * Registers CF7.
 *
 * @since 1.10.0
 */
function zeguten_blocks_register_cf7() {
	// Check if the register function exists.
	if ( ! function_exists( 'register_block_type' ) ) {
		return;
	}

	register_block_type(
		'zeguten/contact-form-7',
		array(
			'attributes'      => array(
				'block_id' => [                 
					'type' => 'string',
					'default' => 'not_set',
				],
				'block_css' => [                 
					'type' => 'string'
				],
				'formId'  => [
					'type'    => 'string',
					'default' => '0',
				],
				'loaderColor'  => [
					'type' => 'string',
				],
				'isHtml'  => [
					'type' => 'boolean',
				],
				'formJson'  => [
					'type'    => 'object',
					'default' => null,
				],
				'formTextsColor' => [
					'type' => 'string',
				],
				'formTextsLoadGoogleFonts'  => [
					'type'    => 'boolean',
					'default' => false,
				],
				'formTextsFontFamily' => [
					'type' => 'string',
					'default' => '',
				],
				'formTextsFontWeight' => [
					'type' => 'string',
					'default' => '',
				],
				'formTextsFontSubset' => [
					'type' => 'string',
					'default' => '',
				],
				'formTextsFontSize' => [
					'type'  => 'number',
				],
				'formTextsFontSizeTablet' => [
					'type'  => 'number',
				],
				'formTextsFontSizeMobile' => [
					'type'  => 'number',
				],
				'formTextsLineHeight' => [
					'type'  => 'number',
				],
				'formTextsLineHeightTablet' => [
					'type'  => 'number',
				],
				'formTextsLineHeightMobile' => [
					'type'  => 'number',
				],
				'formTextsFontSizeType' => [
					'type'    => 'string',
					'default' => 'px',
				],
				'formTextsLineHeightType' => [
					'type'    => 'string',
					'default' => 'em',
				],
				'formTextsLetterSpacingType'  => [
					'type'    => 'string',
					'default' => 'em',
				],
				'formTextsLetterSpacing' => [
					'type'    => 'number',
				],
				'formTextsLetterSpacingTablet' => [
					'type'  => 'number',
				],
				'formTextsLetterSpacingMobile' => [
					'type'  => 'number',
				],
				'formTextsLetterSpacingType'  => [
					'type'    => 'string',
					'default' => 'em',
				],
				'formTextsTextTransform'     => [
					'type'    => 'string',
				],
				'formTextsFontStyle'     => [
					'type'    => 'string',
				],
				'formTextsTextDecoration'     => [
					'type'    => 'string',
				],

				'validColor' => [
					'type' => 'string',
				],
				'validLoadGoogleFonts'  => [
					'type'    => 'boolean',
					'default' => false,
				],
				'validFontFamily' => [
					'type' => 'string',
					'default' => '',
				],
				'validFontWeight' => [
					'type' => 'string',
					'default' => '',
				],
				'validFontSubset' => [
					'type' => 'string',
					'default' => '',
				],
				'validFontSize' => [
					'type'  => 'number',
				],
				'validFontSizeTablet' => [
					'type'  => 'number',
				],
				'validFontSizeMobile' => [
					'type'  => 'number',
				],
				'validLineHeight' => [
					'type'  => 'number',
				],
				'validLineHeightTablet' => [
					'type'  => 'number',
				],
				'validLineHeightMobile' => [
					'type'  => 'number',
				],
				'validFontSizeType' => [
					'type'    => 'string',
					'default' => 'px',
				],
				'validLineHeightType' => [
					'type'    => 'string',
					'default' => 'em',
				],
				'validLetterSpacingType'  => [
					'type'    => 'string',
					'default' => 'em',
				],
				'validLetterSpacing' => [
					'type'    => 'number',
				],
				'validLetterSpacingTablet' => [
					'type'  => 'number',
				],
				'validLetterSpacingMobile' => [
					'type'  => 'number',
				],
				'validLetterSpacingType'  => [
					'type'    => 'string',
					'default' => 'em',
				],
				'validTextTransform'     => [
					'type'    => 'string',
				],
				'validFontStyle'     => [
					'type'    => 'string',
				],
				'validTextDecoration'     => [
					'type'    => 'string',
				],

				'validMarginType'   => [
					'type'    => 'string',
					'default' => 'px',
				],

				'validMarginTop' => [
					'type'    => 'string',
				],
				'validMarginTopMobile' => [
					'type'    => 'string',
				],
				'validMarginTopTablet' => [
					'type'    => 'string',
				],
				'validMarginLeft' => [
					'type'    => 'string',
				],
				'validMarginLeftMobile' => [
					'type'    => 'string',
				],
				'validMarginLeftTablet' => [
					'type'    => 'string',
				],
				'validMarginBottom' => [
					'type'    => 'string',
				],
				'validMarginBottomMobile' => [
					'type'    => 'string',
				],
				'validMarginBottomTablet' => [
					'type'    => 'string',
				],
				'validMarginRight' => [
					'type'    => 'string',
				],
				'validMarginRightMobile' => [
					'type'    => 'string',
				],
				'validMarginRightTablet' => [
					'type'    => 'string',
				],


				'validLabelAlign'     => [
					'type'    => 'string',
					'default' => 'left',
				],

				'inputBorderStyle'   => [
					'type'    => 'string',
				],

				'inputBorderWidthType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'inputBorderWidthTop'   => [
					'type'    => 'string',
				],
				'inputBorderWidthTopMobile'   => [
					'type'    => 'string',
				],
				'inputBorderWidthTopTablet'   => [
					'type'    => 'string',
				],
				'inputBorderWidthLeft'   => [
					'type'    => 'string',
				],
				'inputBorderWidthLeftMobile'   => [
					'type'    => 'string',
				],
				'inputBorderWidthLeftTablet'   => [
					'type'    => 'string',
				],
				'inputBorderWidthBottom'   => [
					'type'    => 'string',
				],
				'inputBorderWidthBottomMobile'   => [
					'type'    => 'string',
				],
				'inputBorderWidthBottomTablet'   => [
					'type'    => 'string',
				],
				'inputBorderWidthRight'   => [
					'type'    => 'string',
				],
				'inputBorderWidthRightMobile'   => [
					'type'    => 'string',
				],
				'inputBorderWidthRightTablet'   => [
					'type'    => 'string',
					'default' => '',
				],
				'inputBorderColor' => [
					'type'    => 'string',
				],
				'inputShadowHorizontal' => [
					'type'    => 'number',
				],
				'inputShadowVertical' => [
					'type'    => 'number',
				],
				'inputShadowBlur' => [
					'type'    => 'number',
				],
				'inputShadowSpread' => [
					'type'    => 'number',
				],
				'inputShadowColor' => [
					'type'    => 'string',
				],
				'inputShadowPosition' => [
					'type'    => 'string',
				],

				'normalInputBGColor'   => [
					'type'    => 'string',
				],

				'normalInputColor'   => [
					'type'    => 'string',
				],
				'placeholderColor'   => [
					'type'    => 'string',
				],

				'inputLoadGoogleFonts'    => [
					'type'    => 'boolean',
					'default' => false,
				],
				'inputFontFamily' => [
					'type' => 'string',
					'default' => '',
				],
				'inputFontWeight' => [
					'type' => 'string',
					'default' => '',
				],
				'inputFontSubset' => [
					'type' => 'string',
					'default' => '',
				],
				'inputFontSize' => [
					'type'  => 'number',
				],
				'inputFontSizeTablet' => [
					'type'  => 'number',
				],
				'inputFontSizeMobile' => [
					'type'  => 'number',
				],
				'inputLineHeight' => [
					'type'  => 'number',
				],
				'inputLineHeightTablet' => [
					'type'  => 'number',
				],
				'inputLineHeightMobile' => [
					'type'  => 'number',
				],
				'inputFontSizeType' => [
					'type'    => 'string',
					'default' => 'px',
				],
				'inputLineHeightType' => [
					'type'    => 'string',
					'default' => 'em',
				],
				'inputLetterSpacingType'  => [
					'type'    => 'string',
					'default' => 'em',
				],
				'inputLetterSpacing' => [
					'type'    => 'number',
				],
				'inputLetterSpacingTablet' => [
					'type'  => 'number',
				],
				'inputLetterSpacingMobile' => [
					'type'  => 'number',
				],
				'inputLetterSpacingType'  => [
					'type'    => 'string',
					'default' => 'em',
				],
				'inputTextTransform'     => [
					'type'    => 'string',
				],
				'inputFontStyle'     => [
					'type'    => 'string',
				],
				'inputTextDecoration'     => [
					'type'    => 'string',
				],

				'inputPaddingType'   => [
					'type'    => 'string',
					'default' => 'px',
				],

				'inputPaddingTop' => [
					'type'    => 'string',
				],
				'inputPaddingTopMobile' => [
					'type'    => 'string',
				],
				'inputPaddingTopTablet' => [
					'type'    => 'string',
				],
				'inputPaddingLeft' => [
					'type'    => 'string',
				],
				'inputPaddingLeftMobile' => [
					'type'    => 'string',
				],
				'inputPaddingLeftTablet' => [
					'type'    => 'string',
				],
				'inputPaddingBottom' => [
					'type'    => 'string',
				],
				'inputPaddingBottomMobile' => [
					'type'    => 'string',
				],
				'inputPaddingBottomTablet' => [
					'type'    => 'string',
				],
				'inputPaddingRight' => [
					'type'    => 'string',
				],
				'inputPaddingRightMobile' => [
					'type'    => 'string',
				],
				'inputPaddingRightTablet' => [
					'type'    => 'string',
				],

				'inputMarginType'   => [
					'type'    => 'string',
					'default' => 'px',
				],

				'inputMarginTop' => [
					'type'    => 'string',
				],
				'inputMarginTopMobile' => [
					'type'    => 'string',
				],
				'inputMarginTopTablet' => [
					'type'    => 'string',
				],
				'inputMarginLeft' => [
					'type'    => 'string',
				],
				'inputMarginLeftMobile' => [
					'type'    => 'string',
				],
				'inputMarginLeftTablet' => [
					'type'    => 'string',
				],
				'inputMarginBottom' => [
					'type'    => 'string',
				],
				'inputMarginBottomMobile' => [
					'type'    => 'string',
				],
				'inputMarginBottomTablet' => [
					'type'    => 'string',
				],
				'inputMarginRight' => [
					'type'    => 'string',
				],
				'inputMarginRightMobile' => [
					'type'    => 'string',
				],
				'inputMarginRightTablet' => [
					'type'    => 'string',
				],

				'inputBorderRadiusType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'inputBorderRadiusTop'   => [
					'type'    => 'string',
				],
				'inputBorderRadiusTopMobile'   => [
					'type'    => 'string',
				],
				'inputBorderRadiusTopTablet'   => [
					'type'    => 'string',
				],
				'inputBorderRadiusLeft'   => [
					'type'    => 'string',
				],
				'inputBorderRadiusLeftMobile'   => [
					'type'    => 'string',
				],
				'inputBorderRadiusLeftTablet'   => [
					'type'    => 'string',
				],
				'inputBorderRadiusBottom'   => [
					'type'    => 'string',
				],
				'inputBorderRadiusBottomMobile'   => [
					'type'    => 'string',
				],
				'inputBorderRadiusBottomTablet'   => [
					'type'    => 'string',
				],
				'inputBorderRadiusRight'   => [
					'type'    => 'string',
				],
				'inputBorderRadiusRightMobile'   => [
					'type'    => 'string',
				],
				'inputBorderRadiusRightTablet'   => [
					'type'    => 'string',
				],

				'focusInputBGColor'   => [
					'type'    => 'string',
				],

				'focusInputColor'   => [
					'type'    => 'string',
				],
				'focusPlaceholderColor'   => [
					'type'    => 'string',
				],
				'inputFocusBorderStyle'   => [
					'type'    => 'string',
					'default' => '',
				],
				'inputFocusBorderWidthType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'inputFocusBorderWidthTop'   => [
					'type'    => 'string',
				],
				'inputFocusBorderWidthTopMobile'   => [
					'type'    => 'string',
				],
				'inputFocusBorderWidthTopTablet'   => [
					'type'    => 'string',
				],
				'inputFocusBorderWidthLeft'   => [
					'type'    => 'string',
				],
				'inputFocusBorderWidthLeftMobile'   => [
					'type'    => 'string',
				],
				'inputFocusBorderWidthLeftTablet'   => [
					'type'    => 'string',
				],
				'inputFocusBorderWidthBottom'   => [
					'type'    => 'string',
				],
				'inputFocusBorderWidthBottomMobile'   => [
					'type'    => 'string',
				],
				'inputFocusBorderWidthBottomTablet'   => [
					'type'    => 'string',
				],
				'inputFocusBorderWidthRight'   => [
					'type'    => 'string',
				],
				'inputFocusBorderWidthRightMobile'   => [
					'type'    => 'string',
				],
				'inputFocusBorderWidthRightTablet'   => [
					'type'    => 'string',
				],
				'inputFocusBorderColor' => [
					'type'    => 'string',
				],
				'inputFocusShadowHorizontal' => [
					'type'    => 'number',
				],
				'inputFocusShadowVertical' => [
					'type'    => 'number',
				],
				'inputFocusShadowBlur' => [
					'type'    => 'number',
				],
				'inputFocusShadowSpread' => [
					'type'    => 'number',
				],
				'inputFocusShadowColor' => [
					'type'    => 'string',
				],
				'inputFocusShadowPosition' => [
					'type'    => 'string',
				],

				'inputErrorBorderStyle'   => [
					'type'    => 'string',
					'default' => '',
				],
				'inputErrorBorderWidthType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'inputErrorBorderWidthTop'   => [
					'type'    => 'string',
				],
				'inputErrorBorderWidthTopMobile'   => [
					'type'    => 'string',
				],
				'inputErrorBorderWidthTopTablet'   => [
					'type'    => 'string',
				],
				'inputErrorBorderWidthLeft'   => [
					'type'    => 'string',
				],
				'inputErrorBorderWidthLeftMobile'   => [
					'type'    => 'string',
				],
				'inputErrorBorderWidthLeftTablet'   => [
					'type'    => 'string',
				],
				'inputErrorBorderWidthBottom'   => [
					'type'    => 'string',
				],
				'inputErrorBorderWidthBottomMobile'   => [
					'type'    => 'string',
				],
				'inputErrorBorderWidthBottomTablet'   => [
					'type'    => 'string',
				],
				'inputErrorBorderWidthRight'   => [
					'type'    => 'string',
				],
				'inputErrorBorderWidthRightMobile'   => [
					'type'    => 'string',
				],
				'inputErrorBorderWidthRightTablet'   => [
					'type'    => 'string',
				],
				'inputErrorBorderColor' => [
					'type'    => 'string',
				],
				'inputErrorShadowHorizontal' => [
					'type'    => 'number',
				],
				'inputErrorShadowVertical' => [
					'type'    => 'number',
				],
				'inputErrorShadowBlur' => [
					'type'    => 'number',
				],
				'inputErrorShadowSpread' => [
					'type'    => 'number',
				],
				'inputErrorShadowColor' => [
					'type'    => 'string',
				],
				'inputErrorShadowPosition' => [
					'type'    => 'string',
				],

				'errorInputBGColor' => [
					'type'    => 'string',
				],

				'errorInputColor' => [
					'type'    => 'string',
				],
				'textareaHeight' => [
					'type'    => 'string',
				],

				'wrapBGColor'   => [
					'type'    => 'string',
				],
				'wrapBorderStyle'   => [
					'type'    => 'string',
					'default' => '',
				],
				'wrapBorderWidthType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'wrapBorderWidthTop'   => [
					'type'    => 'string',
				],
				'wrapBorderWidthTopMobile'   => [
					'type'    => 'string',
				],
				'wrapBorderWidthTopTablet'   => [
					'type'    => 'string',
				],
				'wrapBorderWidthLeft'   => [
					'type'    => 'string',
				],
				'wrapBorderWidthLeftMobile'   => [
					'type'    => 'string',
				],
				'wrapBorderWidthLeftTablet'   => [
					'type'    => 'string',
				],
				'wrapBorderWidthBottom'   => [
					'type'    => 'string',
				],
				'wrapBorderWidthBottomMobile'   => [
					'type'    => 'string',
				],
				'wrapBorderWidthBottomTablet'   => [
					'type'    => 'string',
				],
				'wrapBorderWidthRight'   => [
					'type'    => 'string',
				],
				'wrapBorderWidthRightMobile'   => [
					'type'    => 'string',
				],
				'wrapBorderWidthRightTablet'   => [
					'type'    => 'string',
				],

				'wrapBorderRadiusType'   => [
					'type'    => 'string',
					'default' => 'px',
				],

				'wrapBorderRadiusTop'   => [
					'type'    => 'string',
				],
				'wrapBorderRadiusTopMobile'   => [
					'type'    => 'string',
				],
				'wrapBorderRadiusTopTablet'   => [
					'type'    => 'string',
				],
				'wrapBorderRadiusLeft'   => [
					'type'    => 'string',
				],
				'wrapBorderRadiusLeftMobile'   => [
					'type'    => 'string',
				],
				'wrapBorderRadiusLeftTablet'   => [
					'type'    => 'string',
				],
				'wrapBorderRadiusBottom'   => [
					'type'    => 'string',
				],
				'wrapBorderRadiusBottomMobile'   => [
					'type'    => 'string',
				],
				'wrapBorderRadiusBottomTablet'   => [
					'type'    => 'string',
				],
				'wrapBorderRadiusRight'   => [
					'type'    => 'string',
				],
				'wrapBorderRadiusRightMobile'   => [
					'type'    => 'string',
				],
				'wrapBorderRadiusRightTablet'   => [
					'type'    => 'string',
				],

				'wrapBorderColor' => [
					'type'    => 'string',
				],
				'wrapShadowHorizontal' => [
					'type'    => 'number',
				],
				'wrapShadowVertical' => [
					'type'    => 'number',
				],
				'wrapShadowBlur' => [
					'type'    => 'number',
				],
				'wrapShadowSpread' => [
					'type'    => 'number',
				],
				'wrapShadowColor' => [
					'type'    => 'string',
				],
				'wrapShadowPosition' => [
					'type'    => 'string',
				],

				'wrapMarginType'   => [
					'type'    => 'string',
					'default' => 'px',
				],

				'wrapPaddingType'   => [
					'type'    => 'string',
					'default' => 'px',
				],

				'wrapPaddingTop' => [
					'type'    => 'string',
				],
				'wrapPaddingTopMobile' => [
					'type'    => 'string',
				],
				'wrapPaddingTopTablet' => [
					'type'    => 'string',
				],
				'wrapPaddingLeft' => [
					'type'    => 'string',
				],
				'wrapPaddingLeftMobile' => [
					'type'    => 'string',
				],
				'wrapPaddingLeftTablet' => [
					'type'    => 'string',
				],
				'wrapPaddingBottom' => [
					'type'    => 'string',
				],
				'wrapPaddingBottomMobile' => [
					'type'    => 'string',
				],
				'wrapPaddingBottomTablet' => [
					'type'    => 'string',
				],
				'wrapPaddingRight' => [
					'type'    => 'string',
				],
				'wrapPaddingRightMobile' => [
					'type'    => 'string',
				],
				'wrapPaddingRightTablet' => [
					'type'    => 'string',
				],

				'wrapMarginType'   => [
					'type'    => 'string',
					'default' => 'px',
				],

				'wrapMarginTop' => [
					'type'    => 'string',
				],
				'wrapMarginTopMobile' => [
					'type'    => 'string',
				],
				'wrapMarginTopTablet' => [
					'type'    => 'string',
				],
				'wrapMarginLeft' => [
					'type'    => 'string',
				],
				'wrapMarginLeftMobile' => [
					'type'    => 'string',
				],
				'wrapMarginLeftTablet' => [
					'type'    => 'string',
				],
				'wrapMarginBottom' => [
					'type'    => 'string',
				],
				'wrapMarginBottomMobile' => [
					'type'    => 'string',
				],
				'wrapMarginBottomTablet' => [
					'type'    => 'string',
				],
				'wrapMarginRight' => [
					'type'    => 'string',
				],
				'wrapMarginRightMobile' => [
					'type'    => 'string',
				],
				'wrapMarginRightTablet' => [
					'type'    => 'string',
				],
				'z_index' => [
					'type'    => 'string',
				],

				'submitLoadGoogleFonts'    => [
					'type'    => 'boolean',
					'default' => false,
				],
				'submitFontFamily' => [
					'type' => 'string',
					'default' => '',
				],
				'submitFontWeight' => [
					'type' => 'string',
					'default' => '',
				],
				'submitFontSubset' => [
					'type' => 'string',
					'default' => '',
				],
				'submitFontSize' => [
					'type'  => 'number',
				],
				'submitFontSizeTablet' => [
					'type'  => 'number',
				],
				'submitFontSizeMobile' => [
					'type'  => 'number',
				],
				'submitLineHeight' => [
					'type'  => 'number',
				],
				'submitLineHeightTablet' => [
					'type'  => 'number',
				],
				'submitLineHeightMobile' => [
					'type'  => 'number',
				],
				'submitFontSizeType' => [
					'type'    => 'string',
					'default' => 'px',
				],
				'submitLineHeightType' => [
					'type'    => 'string',
					'default' => 'em',
				],
				'submitLetterSpacingType'  => [
					'type'    => 'string',
					'default' => 'em',
				],
				'submitLetterSpacing' => [
					'type'    => 'number',
				],
				'submitLetterSpacingTablet' => [
					'type'  => 'number',
				],
				'submitLetterSpacingMobile' => [
					'type'  => 'number',
				],

				'submitTextTransform'     => [
					'type'    => 'string',
				],
				'submitFontStyle'     => [
					'type'    => 'string',
				],
				'submitTextDecoration'     => [
					'type'    => 'string',
				],
				'submitPaddingType'   => [
					'type'    => 'string',
					'default' => 'px',
				],

				'submitPaddingTop' => [
					'type'    => 'string',
				],
				'submitPaddingTopMobile' => [
					'type'    => 'string',
				],
				'submitPaddingTopTablet' => [
					'type'    => 'string',
				],
				'submitPaddingLeft' => [
					'type'    => 'string',
				],
				'submitPaddingLeftMobile' => [
					'type'    => 'string',
				],
				'submitPaddingLeftTablet' => [
					'type'    => 'string',
				],
				'submitPaddingBottom' => [
					'type'    => 'string',
				],
				'submitPaddingBottomMobile' => [
					'type'    => 'string',
				],
				'submitPaddingBottomTablet' => [
					'type'    => 'string',
				],
				'submitPaddingRight' => [
					'type'    => 'string',
				],
				'submitPaddingRightMobile' => [
					'type'    => 'string',
				],
				'submitPaddingRightTablet' => [
					'type'    => 'string',
				],

				'submitMarginType'   => [
					'type'    => 'string',
					'default' => 'px',
				],

				'submitMarginTop' => [
					'type'    => 'string',
				],
				'submitMarginTopMobile' => [
					'type'    => 'string',
				],
				'submitMarginTopTablet' => [
					'type'    => 'string',
				],
				'submitMarginLeft' => [
					'type'    => 'string',
				],
				'submitMarginLeftMobile' => [
					'type'    => 'string',
				],
				'submitMarginLeftTablet' => [
					'type'    => 'string',
				],
				'submitMarginBottom' => [
					'type'    => 'string',
				],
				'submitMarginBottomMobile' => [
					'type'    => 'string',
				],
				'submitMarginBottomTablet' => [
					'type'    => 'string',
				],
				'submitMarginRight' => [
					'type'    => 'string',
				],
				'submitMarginRightMobile' => [
					'type'    => 'string',
				],
				'submitMarginRightTablet' => [
					'type'    => 'string',
				],
				'submitBorderRadiusType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'submitBorderRadiusTop'   => [
					'type'    => 'string',
				],
				'submitBorderRadiusTopMobile'   => [
					'type'    => 'string',
				],
				'submitBorderRadiusTopTablet'   => [
					'type'    => 'string',
				],
				'submitBorderRadiusLeft'   => [
					'type'    => 'string',
				],
				'submitBorderRadiusLeftMobile'   => [
					'type'    => 'string',
				],
				'submitBorderRadiusLeftTablet'   => [
					'type'    => 'string',
				],
				'submitBorderRadiusBottom'   => [
					'type'    => 'string',
				],
				'submitBorderRadiusBottomMobile'   => [
					'type'    => 'string',
				],
				'submitBorderRadiusBottomTablet'   => [
					'type'    => 'string',
				],
				'submitBorderRadiusRight'   => [
					'type'    => 'string',
				],
				'submitBorderRadiusRightMobile'   => [
					'type'    => 'string',
				],
				'submitBorderRadiusRightTablet'   => [
					'type'    => 'string',
				],
				'fullwidthSubmit'=> [
					'type'    => 'string',
					'default' => '',
				],

				'submitBGColor'   => [
					'type'    => 'string',
				],

				'submitColor'   => [
					'type'    => 'string',
				],

				'submitHoverBGColor'   => [
					'type'    => 'string',
				],

				'submitHoverColor'   => [
					'type'    => 'string',
				],

				'submitBorderStyle'   => [
					'type'    => 'string',
					'default' => '',
				],
				'submitBorderWidthType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'submitBorderWidthTop'   => [
					'type'    => 'string',
				],
				'submitBorderWidthTopMobile'   => [
					'type'    => 'string',
				],
				'submitBorderWidthTopTablet'   => [
					'type'    => 'string',
				],
				'submitBorderWidthLeft'   => [
					'type'    => 'string',
				],
				'submitBorderWidthLeftMobile'   => [
					'type'    => 'string',
				],
				'submitBorderWidthLeftTablet'   => [
					'type'    => 'string',
				],
				'submitBorderWidthBottom'   => [
					'type'    => 'string',
				],
				'submitBorderWidthBottomMobile'   => [
					'type'    => 'string',
				],
				'submitBorderWidthBottomTablet'   => [
					'type'    => 'string',
				],
				'submitBorderWidthRight'   => [
					'type'    => 'string',
				],
				'submitBorderWidthRightMobile'   => [
					'type'    => 'string',
				],
				'submitBorderWidthRightTablet'   => [
					'type'    => 'string',
				],
				'submitBorderColor' => [
					'type'    => 'string',
				],
				'submitShadowHorizontal' => [
					'type'    => 'number',
				],
				'submitShadowVertical' => [
					'type'    => 'number',
				],
				'submitShadowBlur' => [
					'type'    => 'number',
				],
				'submitShadowSpread' => [
					'type'    => 'number',
				],
				'submitShadowColor' => [
					'type'    => 'string',
				],
				'submitShadowPosition' => [
					'type'    => 'string',
				],

				'submitHoverBorderStyle'   => [
					'type'    => 'string',
					'default' => '',
				],
				'submitHoverBorderWidthType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'submitHoverBorderWidthTop'   => [
					'type'    => 'string',
				],
				'submitHoverBorderWidthTopMobile'   => [
					'type'    => 'string',
				],
				'submitHoverBorderWidthTopTablet'   => [
					'type'    => 'string',
				],
				'submitHoverBorderWidthLeft'   => [
					'type'    => 'string',
				],
				'submitHoverBorderWidthLeftMobile'   => [
					'type'    => 'string',
				],
				'submitHoverBorderWidthLeftTablet'   => [
					'type'    => 'string',
				],
				'submitHoverBorderWidthBottom'   => [
					'type'    => 'string',
				],
				'submitHoverBorderWidthBottomMobile'   => [
					'type'    => 'string',
				],
				'submitHoverBorderWidthBottomTablet'   => [
					'type'    => 'string',
				],
				'submitHoverBorderWidthRight'   => [
					'type'    => 'string',
				],
				'submitHoverBorderWidthRightMobile'   => [
					'type'    => 'string',
				],
				'submitHoverBorderWidthRightTablet'   => [
					'type'    => 'string',
				],
				'submitHoverBorderColor' => [
					'type'    => 'string',
				],
				'submitHoverShadowHorizontal' => [
					'type'    => 'number',
				],
				'submitHoverShadowVertical' => [
					'type'    => 'number',
				],
				'submitHoverShadowBlur' => [
					'type'    => 'number',
				],
				'submitHoverShadowSpread' => [
					'type'    => 'number',
				],
				'submitHoverShadowColor' => [
					'type'    => 'string',
				],
				'submitHoverShadowPosition' => [
					'type'    => 'string',
				],
				'alertsBorderStyle'   => [
					'type'    => 'string',
					'default' => '',
				],
				'alertsBorderWidthType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'alertsBorderWidthTop'   => [
					'type'    => 'string',
				],
				'alertsBorderWidthTopMobile'   => [
					'type'    => 'string',
				],
				'alertsBorderWidthTopTablet'   => [
					'type'    => 'string',
				],
				'alertsBorderWidthLeft'   => [
					'type'    => 'string',
				],
				'alertsBorderWidthLeftMobile'   => [
					'type'    => 'string',
				],
				'alertsBorderWidthLeftTablet'   => [
					'type'    => 'string',
				],
				'alertsBorderWidthBottom'   => [
					'type'    => 'string',
				],
				'alertsBorderWidthBottomMobile'   => [
					'type'    => 'string',
				],
				'alertsBorderWidthBottomTablet'   => [
					'type'    => 'string',
				],
				'alertsBorderWidthRight'   => [
					'type'    => 'string',
				],
				'alertsBorderWidthRightMobile'   => [
					'type'    => 'string',
				],
				'alertsBorderWidthRightTablet'   => [
					'type'    => 'string',
				],
				'alertsBorderColor' => [
					'type'    => 'string',
				],
				'alertsPaddingType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'alertsPaddingTop' => [
					'type'    => 'string',
				],
				'alertsPaddingTopMobile' => [
					'type'    => 'string',
				],
				'alertsPaddingTopTablet' => [
					'type'    => 'string',
				],
				'alertsPaddingLeft' => [
					'type'    => 'string',
				],
				'alertsPaddingLeftMobile' => [
					'type'    => 'string',
				],
				'alertsPaddingLeftTablet' => [
					'type'    => 'string',
				],
				'alertsPaddingBottom' => [
					'type'    => 'string',
				],
				'alertsPaddingBottomMobile' => [
					'type'    => 'string',
				],
				'alertsPaddingBottomTablet' => [
					'type'    => 'string',
				],
				'alertsPaddingRight' => [
					'type'    => 'string',
				],
				'alertsPaddingRightMobile' => [
					'type'    => 'string',
				],
				'alertsPaddingRightTablet' => [
					'type'    => 'string',
				],

				'alertsMarginType'   => [
					'type'    => 'string',
					'default' => 'px',
				],

				'alertsMarginTop' => [
					'type'    => 'string',
				],
				'alertsMarginTopMobile' => [
					'type'    => 'string',
				],
				'alertsMarginTopTablet' => [
					'type'    => 'string',
				],
				'alertsMarginLeft' => [
					'type'    => 'string',
				],
				'alertsMarginLeftMobile' => [
					'type'    => 'string',
				],
				'alertsMarginLeftTablet' => [
					'type'    => 'string',
				],
				'alertsMarginBottom' => [
					'type'    => 'string',
				],
				'alertsMarginBottomMobile' => [
					'type'    => 'string',
				],
				'alertsMarginBottomTablet' => [
					'type'    => 'string',
				],
				'alertsMarginRight' => [
					'type'    => 'string',
				],
				'alertsMarginRightMobile' => [
					'type'    => 'string',
				],
				'alertsMarginRightTablet' => [
					'type'    => 'string',
				],
				'alertsBorderRadiusType'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusTop'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusTopMobile'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusTopTablet'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusLeft'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusLeftMobile'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusLeftTablet'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusBottom'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusBottomMobile'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusBottomTablet'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusRight'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusRightMobile'   => [
					'type'    => 'string',
				],
				'alertsBorderRadiusRightTablet'   => [
					'type'    => 'string',
				],

				'alertsLoadGoogleFonts'    => [
					'type'    => 'boolean',
					'default' => false,
				],
				'alertsFontFamily' => [
					'type' => 'string',
					'default' => '',
				],
				'alertsFontWeight' => [
					'type' => 'string',
					'default' => '',
				],
				'alertsFontSubset' => [
					'type' => 'string',
					'default' => '',
				],
				'alertsFontSize' => [
					'type'  => 'number',
				],
				'alertsFontSizeTablet' => [
					'type'  => 'number',
				],
				'alertsFontSizeMobile' => [
					'type'  => 'number',
				],
				'alertsLineHeight' => [
					'type'  => 'number',
				],
				'alertsLineHeightTablet' => [
					'type'  => 'number',
				],
				'alertsLineHeightMobile' => [
					'type'  => 'number',
				],
				'alertsFontSizeType' => [
					'type'    => 'string',
					'default' => 'px',
				],
				'alertsLineHeightType' => [
					'type'    => 'string',
					'default' => 'em',
				],
				'alertsLetterSpacingType'  => [
					'type'    => 'string',
					'default' => 'em',
				],
				'alertsLetterSpacing' => [
					'type'    => 'number',
				],
				'alertsLetterSpacingTablet' => [
					'type'  => 'number',
				],
				'alertsLetterSpacingMobile' => [
					'type'  => 'number',
				],

				'alertsTextTransform'     => [
					'type'    => 'string',
				],
				'alertsFontStyle'     => [
					'type'    => 'string',
				],
				'alertsTextDecoration'     => [
					'type'    => 'string',
				],

				'successBorderStyle'   => [
					'type'    => 'string',
					'default' => '',
				],
				'successBorderWidthType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'successBorderWidthTop'   => [
					'type'    => 'string',
				],
				'successBorderWidthTopMobile'   => [
					'type'    => 'string',
				],
				'successBorderWidthTopTablet'   => [
					'type'    => 'string',
				],
				'successBorderWidthLeft'   => [
					'type'    => 'string',
				],
				'successBorderWidthLeftMobile'   => [
					'type'    => 'string',
				],
				'successBorderWidthLeftTablet'   => [
					'type'    => 'string',
				],
				'successBorderWidthBottom'   => [
					'type'    => 'string',
				],
				'successBorderWidthBottomMobile'   => [
					'type'    => 'string',
				],
				'successBorderWidthBottomTablet'   => [
					'type'    => 'string',
				],
				'successBorderWidthRight'   => [
					'type'    => 'string',
				],
				'successBorderWidthRightMobile'   => [
					'type'    => 'string',
				],
				'successBorderWidthRightTablet'   => [
					'type'    => 'string',
				],
				'successBorderColor' => [
					'type'    => 'string',
				],
				'successShadowHorizontal' => [
					'type'    => 'number',
				],
				'successShadowVertical' => [
					'type'    => 'number',
				],
				'successShadowBlur' => [
					'type'    => 'number',
				],
				'successShadowSpread' => [
					'type'    => 'number',
				],
				'successShadowColor' => [
					'type'    => 'string',
				],
				'successShadowPosition' => [
					'type'    => 'string',
				],

				'successColor' => [
					'type'    => 'string',
				],
				'successBGColor' => [
					'type'    => 'string',
				],

				'errorBorderStyle'   => [
					'type'    => 'string',
					'default' => '',
				],
				'errorBorderWidthType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'errorBorderWidthTop'   => [
					'type'    => 'string',
				],
				'errorBorderWidthTopMobile'   => [
					'type'    => 'string',
				],
				'errorBorderWidthTopTablet'   => [
					'type'    => 'string',
				],
				'errorBorderWidthLeft'   => [
					'type'    => 'string',
				],
				'errorBorderWidthLeftMobile'   => [
					'type'    => 'string',
				],
				'errorBorderWidthLeftTablet'   => [
					'type'    => 'string',
				],
				'errorBorderWidthBottom'   => [
					'type'    => 'string',
				],
				'errorBorderWidthBottomMobile'   => [
					'type'    => 'string',
				],
				'errorBorderWidthBottomTablet'   => [
					'type'    => 'string',
				],
				'errorBorderWidthRight'   => [
					'type'    => 'string',
				],
				'errorBorderWidthRightMobile'   => [
					'type'    => 'string',
				],
				'errorBorderWidthRightTablet'   => [
					'type'    => 'string',
				],
				'errorBorderColor' => [
					'type'    => 'string',
				],
				'errorShadowHorizontal' => [
					'type'    => 'number',
				],
				'errorShadowVertical' => [
					'type'    => 'number',
				],
				'errorShadowBlur' => [
					'type'    => 'number',
				],
				'errorShadowSpread' => [
					'type'    => 'number',
				],
				'errorShadowColor' => [
					'type'    => 'string',
				],
				'errorShadowPosition' => [
					'type'    => 'string',
				],

				'errorColor' => [
					'type'    => 'string',
				],
				'errorBGColor' => [
					'type'    => 'string',
				],

				'validBorderStyle'   => [
					'type'    => 'string',
					'default' => '',
				],
				'validBorderWidthType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'validBorderWidthTop'   => [
					'type'    => 'string',
				],
				'validBorderWidthTopMobile'   => [
					'type'    => 'string',
				],
				'validBorderWidthTopTablet'   => [
					'type'    => 'string',
				],
				'validBorderWidthLeft'   => [
					'type'    => 'string',
				],
				'validBorderWidthLeftMobile'   => [
					'type'    => 'string',
				],
				'validBorderWidthLeftTablet'   => [
					'type'    => 'string',
				],
				'validBorderWidthBottom'   => [
					'type'    => 'string',
				],
				'validBorderWidthBottomMobile'   => [
					'type'    => 'string',
				],
				'validBorderWidthBottomTablet'   => [
					'type'    => 'string',
				],
				'validBorderWidthRight'   => [
					'type'    => 'string',
				],
				'validBorderWidthRightMobile'   => [
					'type'    => 'string',
				],
				'validBorderWidthRightTablet'   => [
					'type'    => 'string',
				],
				'validBorderColor' => [
					'type'    => 'string',
				],
				'validShadowHorizontal' => [
					'type'    => 'number',
				],
				'validShadowVertical' => [
					'type'    => 'number',
				],
				'validShadowBlur' => [
					'type'    => 'number',
				],
				'validShadowSpread' => [
					'type'    => 'number',
				],
				'validShadowColor' => [
					'type'    => 'string',
				],
				'validShadowPosition' => [
					'type'    => 'string',
				],

				'notValidColor' => [
					'type'    => 'string',
				],
				'validBGColor' => [
					'type'    => 'string',
				],
				'spamBorderStyle'   => [
					'type'    => 'string',
					'default' => '',
				],
				'spamBorderWidthType'   => [
					'type'    => 'string',
					'default' => 'px',
				],
				'spamBorderWidthTop'   => [
					'type'    => 'string',
				],
				'spamBorderWidthTopMobile'   => [
					'type'    => 'string',
				],
				'spamBorderWidthTopTablet'   => [
					'type'    => 'string',
				],
				'spamBorderWidthLeft'   => [
					'type'    => 'string',
				],
				'spamBorderWidthLeftMobile'   => [
					'type'    => 'string',
				],
				'spamBorderWidthLeftTablet'   => [
					'type'    => 'string',
				],
				'spamBorderWidthBottom'   => [
					'type'    => 'string',
				],
				'spamBorderWidthBottomMobile'   => [
					'type'    => 'string',
				],
				'spamBorderWidthBottomTablet'   => [
					'type'    => 'string',
				],
				'spamBorderWidthRight'   => [
					'type'    => 'string',
				],
				'spamBorderWidthRightMobile'   => [
					'type'    => 'string',
				],
				'spamBorderWidthRightTablet'   => [
					'type'    => 'string',
				],
				'spamBorderColor' => [
					'type'    => 'string',
				],
				'spamShadowHorizontal' => [
					'type'    => 'number',
				],
				'spamShadowVertical' => [
					'type'    => 'number',
				],
				'spamShadowBlur' => [
					'type'    => 'number',
				],
				'spamShadowSpread' => [
					'type'    => 'number',
				],
				'spamShadowColor' => [
					'type'    => 'string',
				],
				'spamShadowPosition' => [
					'type'    => 'string',
				],

				'spamColor' => [
					'type'    => 'string',
				],
				'spamBGColor' => [
					'type'    => 'string',
				],
				'alertsAlign' => [
					'type'    => 'string',
					'default' => 'left',
				],

				'radioSize' => [
					'type'    => 'number',
				],
				'inputAlign' => [
					'type' => 'string',
					'default' => 'left',
				],

				'radioLoadGoogleFonts'    => [
					'type'    => 'boolean',
					'default' => false,
				],
				'radioFontFamily' => [
					'type' => 'string',
					'default' => '',
				],
				'radioFontWeight' => [
					'type' => 'string',
					'default' => '',
				],
				'radioFontSubset' => [
					'type' => 'string',
					'default' => '',
				],
				'radioFontSize' => [
					'type'  => 'number',
				],
				'radioFontSizeTablet' => [
					'type'  => 'number',
				],
				'radioFontSizeMobile' => [
					'type'  => 'number',
				],
				'radioLineHeight' => [
					'type'  => 'number',
				],
				'radioLineHeightTablet' => [
					'type'  => 'number',
				],
				'radioLineHeightMobile' => [
					'type'  => 'number',
				],
				'radioFontSizeType' => [
					'type'    => 'string',
					'default' => 'px',
				],
				'radioLineHeightType' => [
					'type'    => 'string',
					'default' => 'em',
				],
				'radioLetterSpacingType'  => [
					'type'    => 'string',
					'default' => 'em',
				],
				'radioLetterSpacing' => [
					'type'    => 'number',
				],
				'radioLetterSpacingTablet' => [
					'type'  => 'number',
				],
				'radioLetterSpacingMobile' => [
					'type'  => 'number',
				],

				'radioTextTransform'     => [
					'type'    => 'string',
				],
				'radioFontStyle'     => [
					'type'    => 'string',
				],
				'radioTextDecoration'     => [
					'type'    => 'string',
				],
				'checkboxLoadGoogleFonts'    => [
					'type'    => 'boolean',
					'default' => false,
				],
				'checkboxFontFamily' => [
					'type' => 'string',
					'default' => '',
				],
				'checkboxFontWeight' => [
					'type' => 'string',
					'default' => '',
				],
				'checkboxFontSubset' => [
					'type' => 'string',
					'default' => '',
				],
				'checkboxFontSize' => [
					'type'  => 'number',
				],
				'checkboxFontSizeTablet' => [
					'type'  => 'number',
				],
				'checkboxFontSizeMobile' => [
					'type'  => 'number',
				],
				'checkboxLineHeight' => [
					'type'  => 'number',
				],
				'checkboxLineHeightTablet' => [
					'type'  => 'number',
				],
				'checkboxLineHeightMobile' => [
					'type'  => 'number',
				],
				'checkboxFontSizeType' => [
					'type'    => 'string',
					'default' => 'px',
				],
				'checkboxLineHeightType' => [
					'type'    => 'string',
					'default' => 'em',
				],
				'checkboxLetterSpacingType'  => [
					'type'    => 'string',
					'default' => 'em',
				],
				'checkboxLetterSpacing' => [
					'type'    => 'number',
				],
				'checkboxLetterSpacingTablet' => [
					'type'  => 'number',
				],
				'checkboxLetterSpacingMobile' => [
					'type'  => 'number',
				],

				'checkboxTextTransform'     => [
					'type'    => 'string',
				],
				'checkboxFontStyle'     => [
					'type'    => 'string',
				],
				'checkboxTextDecoration'     => [
					'type'    => 'string',
				],
				'z_index'	=> [
					'type'    => 'string',
				],
				'responsiveDesktop'=> [
					'type'    => 'boolean',
					'default' => false,
				],
				'responsiveTablet'=> [
					'type'    => 'boolean',
					'default' => false,
				],
				'responsiveMobile'=> [
					'type'    => 'boolean',
					'default' => false,
				],
				'entranceAnimation' => [
					'type'    => 'string',
				],
				'entranceAnimationDuration' => [
					'type'    => 'string',
					'default' => '1500ms',
				],
				'entranceAnimationDelay'=> [
					'type'    => 'string',
					'default' => '200ms',
				],
			),
			'render_callback' => 'zeguten_render_cf7',
		)
	);
}
add_action( 'init', 'zeguten_blocks_register_cf7' );

/**
 * Render CF7 HTML.
 *
 * @param array $attributes Array of block attributes.
 *
 * @since 1.0.10
 */


function zeguten_render_cf7( $attributes ) {
	$block_id = 'zeguten-cf7-' . $attributes['block_id'];
	$formId = $attributes['formId'];
	$classname  = 'zeguten-cf7-block';
	$default_class = 'zeguten-block-container';

	$blockAnimation = '';
	$attr_responsive = '';
	$attr_wow = '';

	$baseClass = "zeguten-cf7 zeguten_block";

	$output = sprintf( '%s', do_shortcode( '[contact-form-7 id="' . $formId . '"]' ) );

	$wowDurationData  = $attributes['entranceAnimationDuration']  !== '' ? $attributes['entranceAnimationDuration'] : '2000ms';
	$wowDelayData  = $attributes['entranceAnimationDelay']     !== '' ? $attributes['entranceAnimationDelay']    : '500ms';

	if ( isset( $attributes['entranceAnimation'] ) && ( $attributes['entranceAnimation'] )) {
		$attr_wow .= ' data-wow-duration=' .  esc_attr($wowDurationData) .  '';
		$attr_wow .= ' data-wow-delay=' .  esc_attr($wowDelayData) .  '';
	}

	if ( isset( $attributes['entranceAnimation'] ) && $attributes['entranceAnimation'] ) {
		$blockAnimation = 'animated ' . esc_attr($attributes['entranceAnimation']);
	}

	$responsiveDesktop = $attributes['responsiveDesktop']  !== true ? $attributes['responsiveDesktop'] : 'hidden';
	$responsiveTablet  = $attributes['responsiveTablet']   !== true ? $attributes['responsiveTablet']  : 'hidden';
	$responsiveMobile  = $attributes['responsiveMobile']   !== true ? $attributes['responsiveMobile']  : 'hidden';


	if (isset( $attributes['responsiveDesktop'] ) && ( $attributes['responsiveDesktop'] )) {
		$attr_responsive .= ' data-device-desktop=' .  esc_attr($responsiveDesktop) .  '';
	}

	if  (isset( $attributes['responsiveTablet'] ) && ( $attributes['responsiveTablet'] )){
		$attr_responsive .= ' data-device-tablet='  .  esc_attr($responsiveTablet)  .  '';
	}

	if  (isset( $attributes['responsiveMobile'] ) && ( $attributes['responsiveMobile'] )){
		$attr_responsive .= ' data-device-mobile='  .  esc_attr($responsiveMobile)  .  '';
	}
	
	if ($formId && 0 != $formId && -1 != $formId) {

		return sprintf(
			'<div id="%1$s" class="%2$s %3$s" %4$s %5$s> <div class="%6$s"> <div class="%7$s"> %8$s </div> </div> </div>',
			esc_attr($block_id),
			$baseClass,
			$blockAnimation,
			$attr_responsive,
			$attr_wow,
			$default_class,
			$classname,
			$output 
		);
		
	}
	
}




