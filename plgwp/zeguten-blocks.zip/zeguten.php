<?php
/**
 * Plugin Name: ZeGuten for Gutenberg
 * Plugin URI: https://zeguten.zemez.io/
 * Description: The extra blocks addon for native WordPress visual editor Gutenberg
 * Version:     1.1.5
 * Author:      Gutenix
 * Author URI:  https://zeguten.zemez.io/
 * Text Domain: zeguten
 * License:  GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Domain Path: /languages/
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

define( 'ZEGUTEN_FILE', __FILE__ );
define( 'ZEGUTEN_PATH', trailingslashit( plugin_dir_path( ZEGUTEN_FILE ) ) );
define( 'ZEGUTEN_URL', plugins_url( '/', ZEGUTEN_FILE ) );

define( 'ZEGUTEN_VERSION', '1.1.5' );

require_once ZEGUTEN_PATH . 'includes/plugin.php';


