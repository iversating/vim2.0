<?php

//namespace ZeGuten;

class ZeGutenDashboard {

	public function __construct() {
		$this->addActions();
	}

	protected function addActions() {
		add_action('admin_menu', [$this, 'register_zeguten_dashboard']);
	}

	function register_zeguten_dashboard() {
		add_menu_page( 
			esc_html__( 'ZeGuten plugin options', 'zeguten' ), 
			esc_html__( 'ZeGuten', 'zeguten' ), 
			'manage_options', 
			'zeguten-dashboard',
			array( $this, 'zeguten_dashboard' ), 
			plugins_url('zeguten/assets/img/zegutelogo.svg'), 
			81 
		); 
	}

	function zeguten_dashboard() {

		$updated = false;

		if ( isset( $_POST['zeguten_google_api_key'] ) ) {
			$key     = esc_attr( $_POST['zeguten_google_api_key'] );
			$updated = update_option( 'zeguten_google_api_key', $key );
		}

		if ( isset( $_POST['zeguten_mailchimp_api_key'] ) ) {
			$key     = esc_attr( $_POST['zeguten_mailchimp_api_key'] );
			$updated = update_option( 'zeguten_mailchimp_api_key', $key );
		}

		if ( isset( $_POST['zeguten_svg_enable'] ) ) {
			$svg_enable_key     = esc_attr( $_POST['zeguten_svg_enable'] );
			$svg_enable_updated = update_option( 'zeguten_svg_enable', $svg_enable_key );
		}

		if ( isset( $_POST['zeguten_css_print_method'] ) ) {
			$key     = esc_attr( $_POST['zeguten_css_print_method'] );
			$updated = update_option( 'zeguten_css_print_method', $key );
		}

		if ( isset( $_POST['zeguten_breakpoints_tablet'] ) ) {
			$key     = esc_attr( $_POST['zeguten_breakpoints_tablet'] );
			$updated = update_option( 'zeguten_breakpoints_tablet', $key );
		}

		if ( isset( $_POST['zeguten_breakpoints_mobile'] ) ) {
			$key     = esc_attr( $_POST['zeguten_breakpoints_mobile'] );
			$updated = update_option( 'zeguten_breakpoints_mobile', $key );
		}

		if ( isset( $_POST['zeguten_content_width'] ) ) {
			$key     = esc_attr( $_POST['zeguten_content_width'] );
			$updated = update_option( 'zeguten_content_width', $key );
		}

		?>

		<div class="wrap" style="padding: 15px 30px; background-color: white;"> 

			<h2><?php echo get_admin_page_title() ?></h2>

				<div class="zeguten-dashoptions-wrapp">

				 <ul class="tab-header">
				     <li class="tab-header__item zeguten-tab-trigger active" data-tab="1">General</li>
				     <li class="tab-header__item zeguten-tab-trigger" data-tab="2">Layout Settings</li>
				</ul>

				<ul class="tab-content">

				<li class="tab-content__item zeguten-tab-content active" data-tab="1">

				<form method="post" action="admin.php?page=zeguten-dashboard">

				<div class="dashboard-settings-form">


					<h3> 
						<?php echo esc_html__( 'Google maps API key' , 'zeguten' ); 
							$newKey = get_option( 'zeguten_google_api_key', '' );
							if ( strlen($newKey) == 39 ){
								echo esc_html__( ' is active!', 'zeguten' ); } 
							else {
								echo esc_html__( ' is not set!', 'zeguten' );
							}
						?>
					</h3>
					<p>
						<?php echo sprintf( esc_html__( 'Create own API key %shere%s!', 'zeguten' ), '<a target="_blank" href=\'https://developers.google.com/maps/documentation/javascript/get-api-key\'>', '</a>');
						?>
					</p>
					<p>
						<?php if ( strlen($newKey) == 39 ) {
								echo esc_html__( 'Open the Advanced map block settings and click "Attempt block recovery" if youve been using this block before on the page. ', 'zeguten'); 
							}
						?>
					</p>

					<label for="zeguten_google_api_key"></label>
					<input type="text" id="zeguten_google_api_key" class="widefat" name="zeguten_google_api_key" value="<?php echo esc_attr( get_option( 'zeguten_google_api_key' ) ); ?>" placeholder="Google maps API key">

					</div>


					<div class="dashboard-settings-form">

					<h3><?php esc_html_e( ' Mailchimp API Key', 'zeguten' ); ?> </h3>

					 <?php $zeguten_mailchimp_api_key_link = sprintf(
							'<p class="zeguten-settings-description">%2$s<a href="%1$s" target="_blank" rel="noreferrer noopener">%3$s</a>%4$s</p>',
							'https://mailchimp.com/help/about-api-keys/',
							esc_html__( 'Open your ', 'zeguten' ),
							esc_html__( 'MailChimp account ', 'zeguten' ),
							esc_html__( 'to get an API Key.', 'zeguten' )
						);
						echo wp_kses_post( $zeguten_mailchimp_api_key_link );
					?>

					<input type="text" id="zeguten_mailchimp_api_key" class="widefat" name="zeguten_mailchimp_api_key" value="<?php echo esc_attr( get_option( 'zeguten_mailchimp_api_key' ) ); ?>" placeholder="Mailchimp API Key">

					</div>

					<div class="dashboard-settings-form">


					<h3><?php esc_html_e( 'Enable SVG files uploads', 'zeguten' ); ?> </h3>

					<label for="zeguten_svg_enable"></label>
					<select name="zeguten_svg_enable">
						<option value="disabled" <?php selected( get_option( 'zeguten_svg_enable' ), "disabled"); ?>><?php esc_html_e( 'Disabled', 'zeguten' ); ?></option>
						<option value="enabled" <?php selected( get_option( 'zeguten_svg_enable' ), "enabled"); ?>><?php esc_html_e( 'Enabled', 'zeguten' ); ?></option>
					</select>

					</div>

					<div class="dashboard-settings-form">


					<h3><?php esc_html_e( 'CSS Print Method', 'zeguten' ); ?> </h3>

					<div class="zeguten_css_print_method">

						<label for="zeguten_css_print_method"></label>

						<select name="zeguten_css_print_method">

							<option value="external" <?php selected( get_option( 'zeguten_css_print_method' ), "external"); ?>><?php esc_html_e( 'External File', 'zeguten' ); ?></option>
							<option value="internal" <?php selected( get_option( 'zeguten_css_print_method' ), "internal"); ?>><?php esc_html_e( 'Internal Embedding', 'zeguten' ); ?></option>

						</select>

						<p class="zeguten-css-print-method-description" data-value="external" style="display: none"> <?php esc_html_e( 'Use external CSS files for all generated stylesheets. Choose this setting for better performance (recommended )' , 'zeguten' ) ?>  </p>

						<p class="zeguten-css-print-method-description" data-value="internal" style="display: none"> <?php esc_html_e( 'Use internal CSS that is embedded in the head of the page. For troubleshooting server configuration conflicts and managing development environments.', 'zeguten' ) ?> </p>

					</div>
					</div>

					<?php submit_button();  ?>
					</form>

				</div>

				</li>

				<li class="tab-content__item zeguten-tab-content" data-tab="2">

				<form method="post" action="admin.php?page=zeguten-dashboard">

				<div class="dashboard-settings-form">

				<h3><?php esc_html_e( 'Breakpoints (px)', 'zeguten' ); ?> </h3>
				<h4><?php esc_html_e( 'Tablet', 'zeguten' ); ?> </h4>

				<?php $zeguten_breakpoints_tablet = get_option( 'zeguten_breakpoints_tablet', '768' );
					  $zeguten_breakpoints_mobile = get_option( 'zeguten_breakpoints_mobile', '1025' ); 
				?>

				<input type="number" id="zeguten_breakpoints_tablet" class="zeguten_breakpoints" style="min-width: 100px;" name="zeguten_breakpoints_tablet" 
				value="<?php echo esc_attr( ( ! empty( $zeguten_breakpoints_tablet ) ) ? $zeguten_breakpoints_tablet : '1025' ); ?>" placeholder="1025">

				<h4><?php esc_html_e( 'Mobile', 'zeguten' ); ?> </h4>

				<input type="number" id="zeguten_breakpoints_mobile" class="zeguten_breakpoints" style="min-width: 100px;" name="zeguten_breakpoints_mobile" 
				value="<?php echo esc_attr( ( ! empty( $zeguten_breakpoints_mobile ) ) ? $zeguten_breakpoints_mobile : '768' ); ?>" placeholder="768">

				</div>

				<div class="dashboard-settings-form">

				<h3><?php esc_html_e( 'Content Width (px)', 'zeguten' ); ?> </h3>

				<?php $zeguten_content_width = get_option( 'zeguten_content_width', '1200' ); ?>

				<input type="number" id="zeguten_content_width" class="zeguten_breakpoints" style="min-width: 100px;" name="zeguten_content_width" 
				value="<?php echo esc_attr( ( ! empty( $zeguten_content_width ) ) ? $zeguten_content_width : '1200' ); ?>" placeholder="1200">

				</div>

				<?php submit_button();  ?>
				</form>

				</li>
			</ul>
			</div>
		</div>
		<?php 
	}
}


new ZeGutenDashboard();
