<?php
/**
* ZeGuten Helper.
*
* @package ZeGuten
*/

if ( ! class_exists( 'ZeGuten_Helper' ) ) {
	
	/**
	* Class ZeGuten_Helper.
	*/
	final class ZeGuten_Helper {
		
		
		/**
		* Member Variable
		*
		* @since 0.0.1
		* @var instance
		*/
		private static $instance;
		
		/**
		* Member Variable
		*
		* @since 0.0.1
		* @var instance
		*/
		public static $block_list;
		
		/**
		* Current Block List
		*
		* @since 1.13.4
		* @var current_block_list
		*/
		public static $current_block_list = array();
		
		/**
		* UAG Block Flag
		*
		* @since 1.13.4
		* @var zeguten_flag
		*/
		public static $zeguten_flag = false;
		
		/**
		* Stylesheet
		*
		* @since 1.13.4
		* @var stylesheet
		*/
		public static $stylesheet;
		
		/**
		* Script
		*
		* @since 1.13.4
		* @var script
		*/
		public static $script;
		
		/**
		* Store Json variable
		*
		* @since 1.8.1
		* @var instance
		*/
		public static $icon_json;
		
		/**
		* Page Blocks Variable
		*
		* @since 1.6.0
		* @var instance
		*/
		public static $page_blocks;
		
		/**
		* Google fonts to enqueue
		*
		* @var array
		*/
		public static $gfonts = array();
		
		/**
		* ZeGuten File Generation Flag
		*
		* @since 1.0.15
		* @var file_generation
		*/
		public static $file_generation = 'external';
		
		/**
		* ZeGuten File Generation Fallback Flag for CSS
		*
		* @since 1.0.15
		* @var file_generation
		*/
		public static $fallback_css = false;
		
		/**
		* Enque Style and Script Variable
		*
		* @since 1.0.15
		* @var instance
		*/
		public static $css_file_handler = array();
		
		const UPLOADS_DIR = 'zeguten/';
		
		/**
		*  Initiator
		*
		* @since 0.0.1
		*/
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self;
			}
			return self::$instance;
		}
		
		/**
		* Constructor
		*/
		public function __construct() {
			
			//self::$block_list = ZeGuten_Config::get_zeguten_block_attributes();
			
			self::$file_generation = self::allow_file_generation();
			
			add_action( 'wp', array( $this, 'generate_stylesheet' ), 10 );
			add_action( 'wp', array( $this, 'generate_script' ), 11 );
			add_action( 'wp_head', array( $this, 'frontend_gfonts' ), 120 );
			add_action( 'wp_head', array( $this, 'print_stylesheet' ), 80 );
			add_action( 'wp_footer', array( $this, 'print_script' ), 1000 );
			
			add_action( 'wp_enqueue_scripts', array( $this, 'generate_asset_files' ), 1 );
			add_action( 'wp_enqueue_scripts', array( $this, 'block_assets' ), 10 );
		}
		
		
		
		/**
		* @since  1.0.15
		* @access public
		*/
		
		public function generate_asset_files() {
			
			global $content_width;
			
			self::$stylesheet = str_replace( '#CONTENT_WIDTH#', $content_width . 'px', self::$stylesheet );
			if ( '' !== self::$script ) {
				self::$script = 'document.addEventListener("DOMContentLoaded", function(){( function( $ ) { ' . self::$script . ' })(jQuery)})';
			}
			
			if ( 'external' === self::$file_generation ) {
				self::file_write( self::$stylesheet, 'css' );
			}
		}
		
		/**
		* @since  1.0.15
		* @access public
		*/
		
		public function block_assets() {
			
			if ( 'external' === self::$file_generation ) {
				$file_handler = self::$css_file_handler;
				
				if ( isset( $file_handler['css_url'] ) ) {
					wp_enqueue_style( 'zeguten-style', $file_handler['css_url'], array(), ZEGUTEN_VERSION, 'all' );
				} else {
					self::$fallback_css = true;
				}
			}
			
		}
		
		
		/**
		* Print the Script in footer.
		*/
		public function print_script() {
			
			if ( is_null( self::$script ) || '' === self::$script ) {
				return;
			}
			
			ob_start();
			?>
			<script type="text/javascript" id="zeguten-script-frontend">( function( $ ) { <?php echo self::$script; ?> })(jQuery) </script>
			<?php
			ob_end_flush();
		}
		
		
		/**
		* Print the Stylesheet in header.
		*/
		public function print_stylesheet() {
			
			if ( 'external' === self::$file_generation && ! self::$fallback_css ) {
				return;
			}
			
			if ( is_null( self::$stylesheet ) || '' === self::$stylesheet ) {
				return;
			}
			
			ob_start();
			?>
			<style id="zeguten-style-frontend"><?php echo self::$stylesheet; //phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped ?></style>
			<?php
			ob_end_flush();
		}
		
		/**
		* @since  1.0.15
		* @access public
		*/
		
		public static function dir_path() {
			
			$upload_dir = wp_upload_dir(); // Array of key => value pairs
			
			// Build the paths.
			$base_dir = [
				'path' => $upload_dir['basedir'] . '/' .  self::UPLOADS_DIR,
				'url'  => $upload_dir['baseurl'] . '/' .  self::UPLOADS_DIR,
			];
			
			// Create the upload dir if it doesn't exist.
			if ( ! file_exists( $base_dir['path'] ) ) {
				// Create the directory.
				$wp_filesystem = self::get_instance()->get_filesystem();
				$wp_filesystem->mkdir( $base_dir['path'] );
			}
			
			return apply_filters( 'zeguten_dir_path', $base_dir );
			
		}
		
		/**
		* @since  1.0.15
		* @access public
		*/
		public static function get_asset_info( $data, $type, $timestamp ) {
			
			global $blog_id;
			
			$uploads_dir = self::dir_path();
			$css_suffix  = 'post';
			$url       = [];
			
			
			$url['css']     = $uploads_dir['path'] . $css_suffix . '-' . $blog_id . '-' . $timestamp . '.css';
			$url['css_url'] = $uploads_dir['url'] . $css_suffix . '-' . $blog_id . '-' . $timestamp . '.css';
			
			
			return $url;
		}

		
		/**
		* @since  1.0.15
		* @access public
		*/
		
		public static function create_file( $assets_info, $style_data, $timestamp, $type ) {
			$file_system = self::get_instance()->get_filesystem();
			
			// Create a new file.
			$result = $file_system->put_contents( $assets_info[ $type ], $style_data, FS_CHMOD_FILE );
			
			if ( $result ) {
				// Update meta with current timestamp.
				update_post_meta( get_the_ID(), 'start_timestamp-' . $type, $timestamp );
			}
			
			return $result;
		}
		
		/**
		* @since  1.0.15
		* @access public
		*/

		
		public static function file_write( $style_data, $type ) {
			
			$post_timestamp = get_post_meta( get_the_ID(), 'start_timestamp-' . $type, true );
			$type           = 'css';
			$date           = new DateTime();
			$new_timestamp  = $date->getTimestamp();
			$file_system    = self::get_instance()->get_filesystem();
			
			// Get timestamp - Already saved OR new one.
			$post_timestamp  = ( '' === $post_timestamp || false === $post_timestamp ) ? '' : $post_timestamp;
			$assets_info     = self::get_asset_info( $style_data, $type, $post_timestamp );
			$new_assets_info = self::get_asset_info( $style_data, $type, $new_timestamp );
			
			$relative_src_path = $assets_info[ $type ];
			
			if ( '' === $style_data ) {
				/**
				* This is when the generated CSS is blank.
				* This means this page does not use ZeGuten block.
				* In this scenario we need to delete the existing file.
				* This will ensure there are no extra files added for user.
				*/
				
				if ( file_exists( $relative_src_path ) ) {
					// Delete old file.
					wp_delete_file( $relative_src_path );
				}
				
				return true;

			}


			/**
			 * Timestamp present but file does not exists.
			 * This is the case where somehow the files are delete or not created in first place.
			 * Here we attempt to create them again.
			 */
			if ( ! $file_system->exists( $relative_src_path ) && '' !== $post_timestamp ) {

				$did_create = self::create_file( $assets_info, $style_data, $post_timestamp, $type );

				if ( $did_create ) {
					self::$css_file_handler = array_merge( self::$css_file_handler, $assets_info );
				}

				return $did_create;
			}

			/**
			 * Need to create new assets.
			 * No such assets present for this current page.
			 */
			if ( '' === $post_timestamp ) {

				// Create a new file.
				$did_create = self::create_file( $new_assets_info, $style_data, $new_timestamp, $type );

				if ( $did_create ) {
					self::$css_file_handler = array_merge( self::$css_file_handler, $new_assets_info );
				}

				return $did_create;

			}

			/**
			 * File already exists.
			 * Need to match the content.
			 * If new content is present we update the current assets.
			 */
			if ( file_exists( $relative_src_path ) ) {

				$old_data = $file_system->get_contents( $relative_src_path );

				if ( $old_data !== $style_data ) {

					// Delete old file.
					wp_delete_file( $relative_src_path );

					// Create a new file.
					$did_create = self::create_file( $new_assets_info, $style_data, $new_timestamp, $type );

					if ( $did_create ) {
						self::$css_file_handler = array_merge( self::$css_file_handler, $new_assets_info );
					}

					return $did_create;
				}
			}

			self::$css_file_handler = array_merge( self::$css_file_handler, $assets_info );

			return true;
		}

		
		/**
		* @since  1.0.15
		* @access public
		*/
		
		public function get_filesystem() {
			global $wp_filesystem;
			
			require_once ABSPATH . '/wp-admin/includes/file.php';
			
			WP_Filesystem();
			
			return $wp_filesystem;
		}
		
		/**
		* @since  1.0.15
		* @access public
		*/
		
		public static function allow_file_generation() {
			return get_option( 'zeguten_css_print_method', 'external' );
		}
		
		
		/**
		* Load the front end Google Fonts.
		*/
		public function frontend_gfonts() {
			
			if ( empty( self::$gfonts ) ) {
				return;
			}
			
			$show_google_fonts = apply_filters( 'zeguten_blocks_show_google_fonts', true );
			if ( ! $show_google_fonts ) {
				return;
			}
			$link    = '';
			$subsets = array();
			foreach ( self::$gfonts as $key => $gfont_values ) {
				if ( ! empty( $link ) ) {
					$link .= '%7C'; // Append a new font to the string.
				}
				$link .= $gfont_values['fontfamily'];
				if ( ! empty( $gfont_values['fontvariants'] ) ) {
					$link .= ':';
					$link .= implode( ',', $gfont_values['fontvariants'] );
				}
				if ( ! empty( $gfont_values['fontsubsets'] ) ) {
					foreach ( $gfont_values['fontsubsets'] as $subset ) {
						if ( ! in_array( $subset, $subsets, true ) ) {
							array_push( $subsets, $subset );
						}
					}
				}
			}
			if ( ! empty( $subsets ) ) {
				$link .= '&amp;subset=' . implode( ',', $subsets );
			}
			echo '<link href="//fonts.googleapis.com/css?family=' . esc_attr( str_replace( '|', '%7C', $link ) ) . '" rel="stylesheet">';
		}
		
		
		/**
		* Parse CSS into correct CSS syntax.
		*
		* @param array  $selectors The block selectors.
		* @param string $id The selector ID.
		* @since 0.0.1
		*/
		public static function generate_zeguten_css( $selectors, $id ) {
			
			$styling_css = '';
			
			
			if ( empty( $selectors ) ) {
				return;
			}
			
			foreach ( $selectors as $key => $value ) {
				
				$css = '';
				
				foreach ( $value as $j => $val ) {
					
					if ( ! empty( $val ) || 0 === $val ) {
						$css .= $j . ': ' . $val . ';';
					}
				}
				
				if ( ! empty( $css ) ) {
					$styling_css .= $id;
					$styling_css .= $key . '{';
						$styling_css .= $css . '}';
					}
				}
				
				return $styling_css;
			}
			
			/**
			* Get CSS value
			*
			* Syntax:
			*
			*  get_css_value( VALUE, UNIT );
			*
			* E.g.
			*
			*  get_css_value( VALUE, 'em' );
			*
			* @param string $value  CSS value.
			* @param string $unit  CSS unit.
			* @since 1.13.4
			*/
			public static function get_zeguten_css_value( $value = '', $unit = '' ) {
				
				// @codingStandardsIgnoreStart
				
				
				
				if ( '' == $value ) {
					return $value;
				}
				
				// @codingStandardsIgnoreEnd
				
				$css_val = '';
				
				if ( ! empty( $value ) ) {
					$css_val = esc_attr( $value ) . $unit;
				}
				
				return $css_val;
			}
			
			/**
			* Generates CSS recurrsively.
			*
			* @param object $block The block object.
			* @since 0.0.1
			*/
			public function get_block_css( $block ) {
				
				// @codingStandardsIgnoreStart
				
				$block = ( array ) $block;
				
				$name = $block['blockName'];
				$css  = array();
				
				if( ! isset( $name ) ) {
					return;
				}
				
				if ( isset( $block['attrs'] ) && is_array( $block['attrs'] ) ) {
					$blockattr = $block['attrs'];
					if ( isset( $blockattr['block_id'] ) ) {
						$block_id = $blockattr['block_id'];
						$block_css = $blockattr['block_css'];
					}
				}
				
				self::$current_block_list[] = $name;
				
				if ( strpos( $name, 'zeguten/' ) !== false ) {
					self::$zeguten_flag = true;
				}
				
				switch ( $name ) {
					case 'zeguten/section':
						$css += array(
							"block_styles" =>  $block_css
						);
					break;
					case 'zeguten/posts':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_post_gfont( $blockattr );
					break;
					case 'zeguten/banner':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_banner_gfont( $blockattr );
					break;
					case 'zeguten/countdown-timer':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_countdown_timer_gfont($blockattr);
					break;
					case 'zeguten/circle-progress':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_circle_progress_gfont($blockattr);
					break;
					case 'zeguten/progress-bar':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_circle_progress_gfont($blockattr);
					break;
					case 'zeguten/column':
						$css += array(
							"block_styles" =>  $block_css
						);
					break;
					
					case 'zeguten/logo':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_logo_gfont( $blockattr );
					break;
					
					case 'zeguten/heading':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_heading_gfont( $blockattr );
					break;
					
					case 'zeguten/icon-list':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_icon_list_gfont( $blockattr );
					break;
					
					case 'zeguten/blurbs':
						$css += array(
							"block_styles" => $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_blurbs_gfont( $blockattr );
					break;
					
					case 'zeguten/image-comparison':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_image_comparison_gfont( $blockattr );
					break;
					
					case 'zeguten/button':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_button_gfont( $blockattr );
					break;
					case 'zeguten/carousel':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_carousel_gfont( $blockattr );
					break;
					
					case 'zeguten/map':
						$css += array(
							"block_styles" =>  $block_css
						);
					break;
					
					case 'zeguten/pricing-table':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_pricing_table_gfont($blockattr);
					break;
					
					case 'zeguten/animated-box':
						$css += array(
							"block_styles" => $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_animated_box_gfont($blockattr);
					break;
					
					case 'zeguten/subscribe':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_subscribe_gfont($blockattr);
					break;
					
					case 'zeguten/contact-form-7':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_cf7_gfont($blockattr);
					break;
					
					case 'zeguten/tabs':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_tabs_gfont($blockattr);
					break;
					
					case 'zeguten/team-member':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_team_member_gfont($blockattr);
					break;
					
					case 'zeguten/testimonials':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_testimonials_gfont( $blockattr );
					break;
					
					case 'zeguten/slider':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_slider_gfont($blockattr);
					break;
					
					case 'zeguten/slider-slide-content':
						$css += array(
							"block_styles" =>  $block_css
						);
					break;
					
					case 'zeguten/products-grid':
						$css += array(
							"block_styles" =>  $block_css
						);
						ZeGuten_Block_Helper::blocks_zeguten_products_grid_gfont($blockattr);
					break;
					case 'zeguten/social-icons':
						$css += array(
							"block_styles" =>  $block_css
						);
					break;
					
					default:
					// Nothing to do here.
				break;
			}
			
			if ( isset( $block['innerBlocks'] ) ) {
				foreach ( $block['innerBlocks'] as $j => $inner_block ) {
					if ( 'core/block' == $inner_block['blockName'] ) {
						$id = ( isset( $inner_block['attrs']['ref'] ) ) ? $inner_block['attrs']['ref'] : 0;
						
						if ( $id ) {
							$content = get_post_field( 'post_content', $id );
							
							$reusable_blocks = $this->parse( $content );
							
							self::$stylesheet .= $this->get_stylesheet( $reusable_blocks );
						}
					} else {
						// Get CSS for the Block.
						$inner_block_css = $this->get_block_css( $inner_block );
						
						$css_styles = ( isset( $css['block_styles'] ) ? $css['block_styles'] : '' );
						
						if( isset( $inner_block_css['block_styles'] ) ){
							$css['block_styles'] = $css_styles . $inner_block_css['block_styles'];
						}
					}
				}
			}
			
			self::$current_block_list = array_unique( self::$current_block_list );
			
			return $css;
			
			// @codingStandardsIgnoreEnd
		}
		
		/**
		* Adds Google fonts all blocks.
		*
		* @param array $load_google_font the blocks attr.
		* @param array $font_family the blocks attr.
		* @param array $font_weight the blocks attr.
		* @param array $font_subset the blocks attr.
		*/
		public static function blocks_google_font( $load_google_font, $font_family, $font_weight, $font_subset ) {
			
			if ( true === $load_google_font ) {
				if ( ! array_key_exists( $font_family, self::$gfonts ) ) {
					$add_font                     = array(
						'fontfamily'   => $font_family,
						'fontvariants' => ( isset( $font_weight ) && ! empty( $font_weight ) ? array( $font_weight ) : array() ),
						'fontsubsets'  => ( isset( $font_subset ) && ! empty( $font_subset ) ? array( $font_subset ) : array() ),
					);
					self::$gfonts[ $font_family ] = $add_font;
				} else {
					if ( isset( $font_weight ) && ! empty( $font_weight ) ) {
						if ( ! in_array( $font_weight, self::$gfonts[ $font_family ]['fontvariants'], true ) ) {
							array_push( self::$gfonts[ $font_family ]['fontvariants'], $font_weight );
						}
					}
					if ( isset( $font_subset ) && ! empty( $font_subset ) ) {
						if ( ! in_array( $font_subset, self::$gfonts[ $font_family ]['fontsubsets'], true ) ) {
							array_push( self::$gfonts[ $font_family ]['fontsubsets'], $font_subset );
						}
					}
				}
			}
		}
		
		/**
		* Generates stylesheet and appends in head tag.
		*
		* @since 0.0.1
		*/
		public function generate_stylesheet() {
			
			$this_post = array();
			
			if ( class_exists( 'WooCommerce' ) ) {
				
				if ( is_cart() ) {
					
					$id        = get_option( 'woocommerce_cart_page_id' );
					$this_post = get_post( $id );
					
				} elseif ( is_account_page() ) {
					
					$id        = get_option( 'woocommerce_myaccount_page_id' );
					$this_post = get_post( $id );
					
				} elseif ( is_checkout() ) {
					
					$id        = get_option( 'woocommerce_checkout_page_id' );
					$this_post = get_post( $id );
					
				} elseif ( is_checkout_pay_page() ) {
					
					$id        = get_option( 'woocommerce_pay_page_id' );
					$this_post = get_post( $id );
					
				} elseif ( is_shop() ) {
					
					$id        = get_option( 'woocommerce_shop_page_id' );
					$this_post = get_post( $id );
				}
				
				if ( is_object( $this_post ) ) {
					$this->_generate_stylesheet( $this_post );
					return;
				}
			}
			
			if ( is_single() || is_page() ) {
				
				global $post;
				$this_post = $post;
				
				if ( ! is_object( $this_post ) ) {
					return;
				}
				$this->_generate_stylesheet( $this_post );
				
			} elseif ( is_404() ) {
				
				$theme_gutenx = wp_get_theme();
				if ( class_exists( 'Gutenix_Pro' ) && $theme_gutenx->name === 'Gutenix' ) { 
					$id        = gutenix_theme()->customizer->get_value( 'page404_template' );
					$this_post = get_post( $id );
					$this->_generate_stylesheet( $this_post );
				}
				
			} elseif ( is_archive() || is_home() || is_search() ) {
				
				global $wp_query;
				
				foreach ( $wp_query as $post ) {
					$this->_generate_stylesheet( $post );
				}
			}
		}
		
		/**
		* Generates stylesheet in loop.
		*
		* @param object $this_post Current Post Object.
		* @since 1.7.0
		*/
		public function _generate_stylesheet( $this_post ) {
			
			if ( ! is_object( $this_post ) ) {
				return;
			}
			
			if ( ! isset( $this_post->ID ) ) {
				return;
			}
			
			if ( has_blocks( $this_post->ID ) ) {
				
				if ( isset( $this_post->post_content ) ) {
					
					$blocks            = $this->parse( $this_post->post_content );
					self::$page_blocks = $blocks;
					
					if ( ! is_array( $blocks ) || empty( $blocks ) ) {
						return;
					}
					
					self::$stylesheet .= $this->get_stylesheet( $blocks );
				}
			}
		}
		
		/**
		* Generates scripts and appends in footer tag.
		*
		* @since 1.5.0
		*/
		public function generate_script() {
			
			$blocks = self::$page_blocks;
			
			if ( ! is_array( $blocks ) || empty( $blocks ) ) {
				return;
			}
			
			$this->get_scripts( $blocks );
		}
		
		/**
		* Parse Guten Block.
		*
		* @param string $content the content string.
		* @since 1.1.0
		*/
		public function parse( $content ) {
			
			global $wp_version;
			
			return ( version_compare( $wp_version, '5', '>=' ) ) ? parse_blocks( $content ) : gutenberg_parse_blocks( $content );
		}
		
		/**
		* Generates stylesheet for reusable blocks.
		*
		* @param array $blocks Blocks array.
		* @since 1.1.0
		*/
		public function get_stylesheet( $blocks ) {
			
			$block_css = '';
			
			foreach ( $blocks as $i => $block ) {
				
				if ( is_array( $block ) ) {
					
					if ( '' === $block['blockName'] ) {
						continue;
					}
					if ( 'core/block' === $block['blockName'] ) {
						$id = ( isset( $block['attrs']['ref'] ) ) ? $block['attrs']['ref'] : 0;
						
						if ( $id ) {
							$content = get_post_field( 'post_content', $id );
							
							$reusable_blocks = $this->parse( $content );
							
							self::$stylesheet .= $this->get_stylesheet( $reusable_blocks );
							
						}
					} else {
						// Get CSS for the Block.
						$css = $this->get_block_css( $block );
						if ( isset( $css['block_styles'] ) ) {
							$block_css .= $css['block_styles'];
						}
					}
				}
			}
			return $block_css;
		}
		
		
		/**
		* Generates scripts for reusable blocks.
		*
		* @param array $blocks Blocks array.
		* @since 1.6.0
		*/
		public function get_scripts( $blocks ) {
			
			foreach ( $blocks as $i => $block ) {
				if ( is_array( $block ) ) {
					if ( 'core/block' === $block['blockName'] ) {
						$id = ( isset( $block['attrs']['ref'] ) ) ? $block['attrs']['ref'] : 0;
						
						if ( $id ) {
							$content = get_post_field( 'post_content', $id );
							
							$reusable_blocks = $this->parse( $content );
							
							$this->get_scripts( $reusable_blocks );
						}
					} else {
						// Get JS for the Block.
						//self::$script .= $this->get_block_js( $block );
					}
				}
			}
		}
		
		/**
		* Get Json Data.
		*
		* @since 1.8.1
		* @return Array
		*/
		public static function backend_load_font_awesome_icons() {
			
			$json_file = ZEGUTEN_PATH . 'src/components/icon-picker/ZeGutenIconPicker.json';
			
			if ( ! file_exists( $json_file ) ) {
				return array();
			}
			
			// Function has already run.
			if ( null !== self::$icon_json ) {
				return self::$icon_json;
			}
			
			$str             = file_get_contents( $json_file );
			self::$icon_json = json_decode( $str, true );
			return self::$icon_json;
		}
		
		/**
		* Generate SVG.
		*
		* @since 1.8.1
		* @param  array $icon Decoded fontawesome json file data.
		* @return string
		*/
		public static function render_svg_html( $icon ) {
			$icon = str_replace( 'far', '', $icon );
			$icon = str_replace( 'fas', '', $icon );
			$icon = str_replace( 'fab', '', $icon );
			$icon = str_replace( 'fa-', '', $icon );
			$icon = str_replace( 'fa', '', $icon );
			$icon = sanitize_text_field( esc_attr( $icon ) );
			
			$json = ZeGuten_Helper::backend_load_font_awesome_icons();
			$path = isset( $json[ $icon ]['svg']['brands'] ) ? $json[ $icon ]['svg']['brands']['path'] : $json[ $icon ]['svg']['solid']['path'];
			$view = isset( $json[ $icon ]['svg']['brands'] ) ? $json[ $icon ]['svg']['brands']['viewBox'] : $json[ $icon ]['svg']['solid']['viewBox'];
			if ( $view ) {
				$view = implode( ' ', $view );
			}
			$htm = '<svg xmlns="http://www.w3.org/2000/svg" viewBox= "' . $view . '"><path d="' . $path . '"></path></svg>';
			return $htm;
		}
		
		
		
		/**
		* Get size information for all currently-registered image sizes.
		*
		* @global $_wp_additional_image_sizes
		* @uses   get_intermediate_image_sizes()
		* @link   https://codex.wordpress.org/Function_Reference/get_intermediate_image_sizes
		* @since  1.9.0
		* @return array $sizes Data for all currently-registered image sizes.
		*/
		public static function get_zeguten_image_sizes() {
			
			global $_wp_additional_image_sizes;
			
			$sizes       = get_intermediate_image_sizes();
			$image_sizes = array();
			
			$image_sizes[] = array(
				'value' => 'full',
				'label' => esc_html__( 'Full', 'zeguten'),
			);
			
			foreach ( $sizes as $size ) {
				if ( in_array( $size, array( 'thumbnail', 'medium', 'medium_large', 'large' ), true ) ) {
					$image_sizes[] = array(
						'value' => $size,
						'label' => ucwords( trim( str_replace( array( '-', '_' ), array( ' ', ' ' ), $size ) ) ),
					);
				} else {
					$image_sizes[] = array(
						'value' => $size,
						'label' => sprintf(
							'%1$s (%2$sx%3$s)',
							ucwords( trim( str_replace( array( '-', '_' ), array( ' ', ' ' ), $size ) ) ),
							$_wp_additional_image_sizes[ $size ]['width'],
							$_wp_additional_image_sizes[ $size ]['height']
						),
					);
				}
			}
			
			$image_sizes = apply_filters( 'zeguten_post_featured_image_sizes', $image_sizes );
			
			return $image_sizes;
		}
		
		/**
		* Get Post Types.
		*
		* @since 1.11.0
		* @access public
		*/
		public static function get_zeguten_post_types() {
			
			$post_types = get_post_types(
				array(
					'public'       => true,
					'show_in_rest' => true,
				),
				'objects'
			);
			
			$options = array();
			
			foreach ( $post_types as $post_type ) {
				if ( 'product' === $post_type->name ) {
					continue;
				}
				
				$options[] = array(
					'value' => $post_type->name,
					'label' => $post_type->label,
				);
			}
			
			return apply_filters( 'zeguten_loop_post_types', $options );
		}
		
		
		/**
		*  Get - RGBA Color
		*
		*  Get HEX color and return RGBA. Default return RGB color.
		*
		* @param  var   $color      Gets the color value.
		* @param  var   $opacity    Gets the opacity value.
		* @param  array $is_array Gets an array of the value.
		* @since   1.11.0
		*/
		public static function hex2rgba( $color, $opacity = false, $is_array = false ) {
			
			$default = $color;
			
			// Return default if no color provided.
			if ( empty( $color ) ) {
				return $default;
			}
			
			// Sanitize $color if "#" is provided.
			if ( '#' === $color[0] ) {
				$color = substr( $color, 1 );
			}
			
			// Check if color has 6 or 3 characters and get values.
			if ( strlen( $color ) === 6 ) {
				$hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
			} elseif ( strlen( $color ) === 3 ) {
				$hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
			} else {
				return $default;
			}
			
			// Convert hexadec to rgb.
			$rgb = array_map( 'hexdec', $hex );
			
			// Check if opacity is set(rgba or rgb).
			if ( false !== $opacity && '' !== $opacity ) {
				if ( abs( $opacity ) >= 1 ) {
					$opacity = $opacity / 100;
				}
				$output = 'rgba(' . implode( ',', $rgb ) . ',' . $opacity . ')';
			} else {
				$output = 'rgb(' . implode( ',', $rgb ) . ')';
			}
			
			if ( $is_array ) {
				return $rgb;
			} else {
				// Return rgb(a) color string.
				return $output;
			}
		}
	}
	
	ZeGuten_Helper::get_instance();
}
