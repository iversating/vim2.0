<?php

/**
 * ZeGuten Block Helper.
 *
 * @package ZeGuten
 */
if (!class_exists('ZeGuten_Block_Helper')) {

	/**
	 * Class ZeGuten_Block_Helper.
	 */
	class ZeGuten_Block_Helper {


		/**
		 * Adds Google fonts for Icon List block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_icon_list_gfont( $attr ) {

			$list_load_google_font     = isset( $attr['listLoadGoogleFonts'] ) ? $attr['listLoadGoogleFonts'] : '';
			$list_font_family          = isset( $attr['listFontFamily'] ) ? $attr['listFontFamily'] : '';
			$list_font_weight          = isset( $attr['listFontWeight'] ) ? $attr['listFontWeight'] : '';
			$list_font_subset          = isset( $attr['listFontSubset'] ) ? $attr['listFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $list_load_google_font, $list_font_family, $list_font_weight, $list_font_subset );

		}
		
		/**
		 * Adds Google fonts for Heading block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_heading_gfont( $attr ) {

			$heading_text_load_google_font  = isset( $attr['textLoadGoogleFonts'] ) ? $attr['textLoadGoogleFonts'] : '';
			$heading_text_font_family       = isset( $attr['textFontFamily'] ) ? $attr['textFontFamily'] : '';
			$heading_text_font_weight       = isset( $attr['textFontWeight'] ) ? $attr['textFontWeight'] : '';
			$heading_text_font_subset       = isset( $attr['textFontSubset'] ) ? $attr['textFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $heading_text_load_google_font, $heading_text_font_family, $heading_text_font_weight, $heading_text_font_subset );

		}

		/**
         * Adds Google fonts for Products Grid block.
         *
         * @since 1.0.0
         * @param array $attr the blocks attr.
         */
        public static function blocks_zeguten_products_grid_gfont( $attr ) {

            $titleGoogleFonts     = isset( $attr['titleGoogleFonts'] ) ? $attr['titleGoogleFonts'] : '';
            $titleFontFamily          = isset( $attr['titleFontFamily'] ) ? $attr['titleFontFamily'] : '';
            $titleFontWeight          = isset( $attr['titleFontWeight'] ) ? $attr['titleFontWeight'] : '';
            $titleFontSubset          = isset( $attr['titleFontSubset'] ) ? $attr['titleFontSubset'] : '';

            $descriptionGoogleFonts     = isset( $attr['descriptionGoogleFonts'] ) ? $attr['descriptionGoogleFonts'] : '';
            $descriptionFontFamily          = isset( $attr['descriptionFontFamily'] ) ? $attr['descriptionFontFamily'] : '';
            $descriptionFontWeight          = isset( $attr['descriptionFontWeight'] ) ? $attr['descriptionFontWeight'] : '';
            $descriptionFontSubset          = isset( $attr['descriptionFontSubset'] ) ? $attr['descriptionFontSubset'] : '';

            $tagsGoogleFonts     = isset( $attr['tagsGoogleFonts'] ) ? $attr['tagsGoogleFonts'] : '';
            $tagsFontFamily          = isset( $attr['tagsFontFamily'] ) ? $attr['tagsFontFamily'] : '';
            $tagsFontWeight          = isset( $attr['tagsFontWeight'] ) ? $attr['tagsFontWeight'] : '';
            $tagsFontSubset          = isset( $attr['tagsFontSubset'] ) ? $attr['tagsFontSubset'] : '';

            $categoriesGoogleFonts     = isset( $attr['categoriesGoogleFonts'] ) ? $attr['categoriesGoogleFonts'] : '';
            $categoriesFontFamily          = isset( $attr['categoriesFontFamily'] ) ? $attr['categoriesFontFamily'] : '';
            $categoriesFontWeight          = isset( $attr['categoriesFontWeight'] ) ? $attr['categoriesFontWeight'] : '';
            $categoriesFontSubset          = isset( $attr['categoriesFontSubset'] ) ? $attr['categoriesFontSubset'] : '';

            $buttonGoogleFonts     = isset( $attr['buttonGoogleFonts'] ) ? $attr['buttonGoogleFonts'] : '';
            $buttonFontFamily          = isset( $attr['buttonFontFamily'] ) ? $attr['buttonFontFamily'] : '';
            $buttonFontWeight          = isset( $attr['buttonFontWeight'] ) ? $attr['buttonFontWeight'] : '';
            $buttonFontSubset          = isset( $attr['buttonFontSubset'] ) ? $attr['buttonFontSubset'] : '';

            $badgeGoogleFonts     = isset( $attr['badgeGoogleFonts'] ) ? $attr['badgeGoogleFonts'] : '';
            $badgeFontFamily          = isset( $attr['badgeFontFamily'] ) ? $attr['badgeFontFamily'] : '';
            $badgeFontWeight          = isset( $attr['badgeFontWeight'] ) ? $attr['badgeFontWeight'] : '';
            $badgeFontSubset          = isset( $attr['badgeFontSubset'] ) ? $attr['badgeFontSubset'] : '';

            $oldPriceGoogleFonts     = isset( $attr['oldPriceGoogleFonts'] ) ? $attr['oldPriceGoogleFonts'] : '';
            $oldPriceFontFamily          = isset( $attr['oldPriceFontFamily'] ) ? $attr['oldPriceFontFamily'] : '';
            $oldPriceFontWeight          = isset( $attr['oldPriceFontWeight'] ) ? $attr['oldPriceFontWeight'] : '';
            $oldPriceFontSubset          = isset( $attr['oldPriceFontSubset'] ) ? $attr['oldPriceFontSubset'] : '';

            $oldPriceCurrencyGoogleFonts     = isset( $attr['oldPriceCurrencyGoogleFonts'] ) ? $attr['oldPriceCurrencyGoogleFonts'] : '';
            $oldPriceCurrencyFontFamily          = isset( $attr['oldPriceCurrencyFontFamily'] ) ? $attr['oldPriceCurrencyFontFamily'] : '';
            $oldPriceCurrencyFontWeight          = isset( $attr['oldPriceCurrencyFontWeight'] ) ? $attr['oldPriceCurrencyFontWeight'] : '';
            $oldPriceCurrencyFontSubset          = isset( $attr['oldPriceCurrencyFontSubset'] ) ? $attr['oldPriceCurrencyFontSubset'] : '';

            $normalPriceGoogleFonts     = isset( $attr['normalPriceGoogleFonts'] ) ? $attr['normalPriceGoogleFonts'] : '';
            $normalPriceFontFamily          = isset( $attr['normalPriceFontFamily'] ) ? $attr['normalPriceFontFamily'] : '';
            $normalPriceFontWeight          = isset( $attr['normalPriceFontWeight'] ) ? $attr['normalPriceFontWeight'] : '';
            $normalPriceFontSubset          = isset( $attr['normalPriceFontSubset'] ) ? $attr['normalPriceFontSubset'] : '';

            $normalPriceCurrencyGoogleFonts     = isset( $attr['normalPriceCurrencyGoogleFonts'] ) ? $attr['normalPriceCurrencyGoogleFonts'] : '';
            $normalPriceCurrencyFontFamily          = isset( $attr['normalPriceCurrencyFontFamily'] ) ? $attr['normalPriceCurrencyFontFamily'] : '';
            $normalPriceCurrencyFontWeight          = isset( $attr['normalPriceCurrencyFontWeight'] ) ? $attr['normalPriceCurrencyFontWeight'] : '';
            $normalPriceCurrencyFontSubset          = isset( $attr['normalPriceCurrencyFontSubset'] ) ? $attr['normalPriceCurrencyFontSubset'] : '';

            $salePriceGoogleFonts     = isset( $attr['salePriceGoogleFonts'] ) ? $attr['salePriceGoogleFonts'] : '';
            $salePriceFontFamily          = isset( $attr['salePriceFontFamily'] ) ? $attr['salePriceFontFamily'] : '';
            $salePriceFontWeight          = isset( $attr['salePriceFontWeight'] ) ? $attr['salePriceFontWeight'] : '';
            $salePriceFontSubset          = isset( $attr['salePriceFontSubset'] ) ? $attr['salePriceFontSubset'] : '';

            $salePriceCurrencyGoogleFonts     = isset( $attr['salePriceCurrencyGoogleFonts'] ) ? $attr['salePriceCurrencyGoogleFonts'] : '';
            $salePriceCurrencyFontFamily          = isset( $attr['salePriceCurrencyFontFamily'] ) ? $attr['salePriceCurrencyFontFamily'] : '';
            $salePriceCurrencyFontWeight          = isset( $attr['salePriceCurrencyFontWeight'] ) ? $attr['salePriceCurrencyFontWeight'] : '';
            $salePriceCurrencyFontSubset          = isset( $attr['salePriceCurrencyFontSubset'] ) ? $attr['salePriceCurrencyFontSubset'] : '';

            ZeGuten_Helper::blocks_google_font( $titleGoogleFonts, $titleFontFamily, $titleFontWeight, $titleFontSubset );
            ZeGuten_Helper::blocks_google_font( $descriptionGoogleFonts, $descriptionFontFamily, $descriptionFontWeight, $descriptionFontSubset );
            ZeGuten_Helper::blocks_google_font( $tagsGoogleFonts, $tagsFontFamily, $tagsFontWeight, $tagsFontSubset );
            ZeGuten_Helper::blocks_google_font( $categoriesGoogleFonts, $categoriesFontFamily, $categoriesFontWeight, $categoriesFontSubset );
            ZeGuten_Helper::blocks_google_font( $buttonGoogleFonts, $buttonFontFamily, $buttonFontWeight, $buttonFontSubset );
            ZeGuten_Helper::blocks_google_font( $badgeGoogleFonts, $badgeFontFamily, $badgeFontWeight, $badgeFontSubset );
            ZeGuten_Helper::blocks_google_font( $normalPriceGoogleFonts, $normalPriceFontFamily, $normalPriceFontWeight, $normalPriceFontSubset );
            ZeGuten_Helper::blocks_google_font( $normalPriceCurrencyGoogleFonts, $normalPriceCurrencyFontFamily, $normalPriceCurrencyFontWeight, $normalPriceCurrencyFontSubset );
            ZeGuten_Helper::blocks_google_font( $salePriceGoogleFonts, $salePriceFontFamily, $salePriceFontWeight, $salePriceFontSubset );
            ZeGuten_Helper::blocks_google_font( $salePriceCurrencyGoogleFonts, $salePriceCurrencyFontFamily, $salePriceCurrencyFontWeight, $salePriceCurrencyFontSubset );
            ZeGuten_Helper::blocks_google_font( $oldPriceGoogleFonts, $oldPriceFontFamily, $oldPriceFontWeight, $oldPriceFontSubset );
            ZeGuten_Helper::blocks_google_font( $oldPriceCurrencyGoogleFonts, $oldPriceCurrencyFontFamily, $oldPriceCurrencyFontWeight, $oldPriceCurrencyFontSubset );
        }

		/**
		 * Adds Google fonts for Post block.
		 *
		 * @since 1.9.1
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_post_gfont( $attr ) {
			
			$title_load_google_font = isset( $attr['titleLoadGoogleFonts'] ) ? $attr['titleLoadGoogleFonts'] : '';
			$title_font_family      = isset( $attr['titleFontFamily'] ) ? $attr['titleFontFamily'] : '';
			$title_font_weight      = isset( $attr['titleFontWeight'] ) ? $attr['titleFontWeight'] : '';
			$title_font_subset      = isset( $attr['titleFontSubset'] ) ? $attr['titleFontSubset'] : '';

			$categories_load_google_font = isset( $attr['categoriesLoadGoogleFonts'] ) ? $attr['categoriesLoadGoogleFonts'] : '';
			$categories_font_family      = isset( $attr['categoriesFontFamily'] ) ? $attr['categoriesFontFamily'] : '';
			$categories_font_weight      = isset( $attr['categoriesFontWeight'] ) ? $attr['categoriesFontWeight'] : '';
			$categories_font_subset      = isset( $attr['categoriesFontSubset'] ) ? $attr['categoriesFontSubset'] : '';

			$author_load_google_font = isset( $attr['authorLoadGoogleFonts'] ) ? $attr['authorLoadGoogleFonts'] : '';
			$author_font_family      = isset( $attr['authorFontFamily'] ) ? $attr['authorFontFamily'] : '';
			$author_font_weight      = isset( $attr['authorFontWeight'] ) ? $attr['authorFontWeight'] : '';
			$author_font_subset      = isset( $attr['authorFontSubset'] ) ? $attr['authorFontSubset'] : '';

			$date_load_google_font = isset( $attr['dateLoadGoogleFonts'] ) ? $attr['dateLoadGoogleFonts'] : '';
			$date_font_family      = isset( $attr['dateFontFamily'] ) ? $attr['dateFontFamily'] : '';
			$date_font_weight      = isset( $attr['dateFontWeight'] ) ? $attr['dateFontWeight'] : '';
			$date_font_subset      = isset( $attr['dateFontSubset'] ) ? $attr['dateFontSubset'] : '';

			$excerpt_load_google_font = isset( $attr['excerptLoadGoogleFonts'] ) ? $attr['excerptLoadGoogleFonts'] : '';
			$excerpt_font_family      = isset( $attr['excerptFontFamily'] ) ? $attr['excerptFontFamily'] : '';
			$excerpt_font_weight      = isset( $attr['excerptFontWeight'] ) ? $attr['excerptFontWeight'] : '';
			$excerpt_font_subset      = isset( $attr['excerptFontSubset'] ) ? $attr['excerptFontSubset'] : '';

			$button_load_google_font = isset( $attr['buttonLoadGoogleFonts'] ) ? $attr['buttonLoadGoogleFonts'] : '';
			$button_font_family      = isset( $attr['buttonFontFamily'] ) ? $attr['buttonFontFamily'] : '';
			$button_font_weight      = isset( $attr['buttonFontWeight'] ) ? $attr['buttonFontWeight'] : '';
			$button_font_subset      = isset( $attr['buttonFontSubset'] ) ? $attr['buttonFontSubset'] : '';

			$comment_load_google_font = isset( $attr['commentLoadGoogleFonts'] ) ? $attr['commentLoadGoogleFonts'] : '';
			$comment_font_family      = isset( $attr['commentFontFamily'] ) ? $attr['commentFontFamily'] : '';
			$comment_font_weight      = isset( $attr['commentFontWeight'] ) ? $attr['commentFontWeight'] : '';
			$comment_font_subset      = isset( $attr['commentFontSubset'] ) ? $attr['commentFontSubset'] : '';

			$tags_load_google_font = isset( $attr['tagsLoadGoogleFonts'] ) ? $attr['tagsLoadGoogleFonts'] : '';
			$tags_font_family      = isset( $attr['tagsFontFamily'] ) ? $attr['tagsFontFamily'] : '';
			$tags_font_weight      = isset( $attr['tagsFontWeight'] ) ? $attr['tagsFontWeight'] : '';
			$tags_font_subset      = isset( $attr['tagsFontSubset'] ) ? $attr['tagsFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $title_load_google_font, $title_font_family, $title_font_weight, $title_font_subset );

			ZeGuten_Helper::blocks_google_font( $categories_load_google_font, $categories_font_family, $categories_font_weight, $categories_font_subset );

			ZeGuten_Helper::blocks_google_font( $author_load_google_font, $author_font_family, $author_font_weight, $author_font_subset );

			ZeGuten_Helper::blocks_google_font( $date_load_google_font, $date_font_family, $date_font_weight, $date_font_subset );

			ZeGuten_Helper::blocks_google_font( $excerpt_load_google_font, $excerpt_font_family, $excerpt_font_weight, $excerpt_font_subset );

			ZeGuten_Helper::blocks_google_font( $button_load_google_font, $button_font_family, $button_font_weight, $button_font_subset );

			ZeGuten_Helper::blocks_google_font( $comment_load_google_font, $comment_font_family, $comment_font_weight, $comment_font_subset );

			ZeGuten_Helper::blocks_google_font( $tags_load_google_font, $tags_font_family, $tags_font_weight, $tags_font_subset );
		}


		
		/**
		 * Adds Google fonts for Circle Progress block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */

		public static function blocks_zeguten_circle_progress_gfont( $attr ) {

			$value_load_google_font 		= isset( $attr['valueLoadGoogleFonts'] ) ? $attr['valueLoadGoogleFonts'] : '';
			$value_font_family 				= isset( $attr['valueFontFamily'] ) ? $attr['valueFontFamily'] : '';
			$value_font_weight 				= isset( $attr['valueFontWeight'] ) ? $attr['valueFontWeight'] : '';
			$value_font_subset 				= isset( $attr['valueFontSubset'] ) ? $attr['valueFontSubset'] : '';

			$prefix_load_google_font 		= isset( $attr['prefixLoadGoogleFonts'] ) ? $attr['prefixLoadGoogleFonts'] : '';
			$prefix_font_family 			= isset( $attr['prefixFontFamily'] ) ? $attr['prefixFontFamily'] : '';
			$prefix_font_weight 			= isset( $attr['prefixFontWeight'] ) ? $attr['prefixFontWeight'] : '';
			$prefix_font_subset 			= isset( $attr['prefixFontSubset'] ) ? $attr['prefixFontSubset'] : '';

			$suffix_load_google_font 		= isset( $attr['suffixLoadGoogleFonts'] ) ? $attr['suffixLoadGoogleFonts'] : '';
			$suffix_font_family 			= isset( $attr['suffixFontFamily'] ) ? $attr['suffixFontFamily'] : '';
			$suffix_font_weight 			= isset( $attr['suffixFontWeight'] ) ? $attr['suffixFontWeight'] : '';
			$suffix_font_subset 			= isset( $attr['suffixFontSubset'] ) ? $attr['suffixFontSubset'] : '';

			$title_load_google_font 		= isset( $attr['titleLoadGoogleFonts'] ) ? $attr['titleLoadGoogleFonts'] : '';
			$title_font_family 				= isset( $attr['titleFontFamily'] ) ? $attr['titleFontFamily'] : '';
			$title_font_weight 				= isset( $attr['titleFontWeight'] ) ? $attr['titleFontWeight'] : '';
			$title_font_subset 				= isset( $attr['titleFontSubset'] ) ? $attr['titleFontSubset'] : '';

			$subtitle_load_google_font 		= isset( $attr['subtitleLoadGoogleFonts'] ) ? $attr['subtitleLoadGoogleFonts'] : '';
			$subtitle_font_family 			= isset( $attr['subtitleFontFamily'] ) ? $attr['subtitleFontFamily'] : '';
			$subtitle_font_weight 			= isset( $attr['subtitleFontWeight'] ) ? $attr['subtitleFontWeight'] : '';
			$subtitle_font_subset 			= isset( $attr['subtitleFontSubset'] ) ? $attr['subtitleFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $value_load_google_font, $value_font_family, $value_font_weight, $value_font_subset );

			ZeGuten_Helper::blocks_google_font( $prefix_load_google_font, $prefix_font_family, $prefix_font_weight, $prefix_font_subset );
			
			ZeGuten_Helper::blocks_google_font( $suffix_load_google_font, $suffix_font_family, $suffix_font_weight, $suffix_font_subset );

			ZeGuten_Helper::blocks_google_font( $title_load_google_font, $title_font_family, $title_font_weight, $title_font_subset );

			ZeGuten_Helper::blocks_google_font( $subtitle_load_google_font, $subtitle_font_family, $subtitle_font_weight, $subtitle_font_subset );

		}
		
		/**
		 * Adds Google fonts for Banners.
		 *
		 * @since 1.9.1
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_banner_gfont( $attr ) {

			$banner_title_load_google_font = isset( $attr['titleBannerLoadGoogleFonts'] ) ? $attr['titleBannerLoadGoogleFonts'] : '';
			$banner_title_font_family      = isset( $attr['titleFontFamily'] ) ? $attr['titleFontFamily'] : '';
			$banner_title_font_weight      = isset( $attr['titleFontWeight'] ) ? $attr['titleFontWeight'] : '';
			$banner_title_font_subset      = isset( $attr['titleFontSubset'] ) ? $attr['titleFontSubset'] : '';

			$banner_description_load_google_font = isset( $attr['descriptionBannerLoadGoogleFonts'] ) ? $attr['descriptionBannerLoadGoogleFonts'] : '';
			$banner_description_font_family      = isset( $attr['descriptionFontFamily'] ) ? $attr['descriptionFontFamily'] : '';
			$banner_description_font_weight      = isset( $attr['descriptionFontWeight'] ) ? $attr['descriptionFontWeight'] : '';
			$banner_description_font_subset      = isset( $attr['descriptionFontSubset'] ) ? $attr['descriptionFontSubset'] : '';

			$banner_author_load_google_font = isset( $attr['authorBannerLoadGoogleFonts'] ) ? $attr['authorBannerLoadGoogleFonts'] : '';
			$banner_author_font_family      = isset( $attr['authorFontFamily'] ) ? $attr['authorFontFamily'] : '';
			$banner_author_font_weight      = isset( $attr['authorFontWeight'] ) ? $attr['authorFontWeight'] : '';
			$banner_author_font_subset      = isset( $attr['authorFontSubset'] ) ? $attr['authorFontSubset'] : '';

			$banner_buttons_load_google_font = isset( $attr['buttonsBannerLoadGoogleFonts'] ) ? $attr['buttonsBannerLoadGoogleFonts'] : '';
			$banner_buttons_font_family      = isset( $attr['buttonsFontFamily'] ) ? $attr['buttonsFontFamily'] : '';
			$banner_buttons_font_weight      = isset( $attr['buttonsFontWeight'] ) ? $attr['buttonsFontWeight'] : '';
			$banner_buttons_font_subset      = isset( $attr['buttonsFontSubset'] ) ? $attr['buttonsFontSubset'] : '';


			ZeGuten_Helper::blocks_google_font( $banner_title_load_google_font, $banner_title_font_family, $banner_title_font_weight, $banner_title_font_subset );

			ZeGuten_Helper::blocks_google_font( $banner_description_load_google_font, $banner_description_font_family, $banner_description_font_weight, $banner_description_font_subset );

			ZeGuten_Helper::blocks_google_font( $banner_author_load_google_font, $banner_author_font_family, $banner_author_font_weight, $banner_author_font_subset );

			ZeGuten_Helper::blocks_google_font( $banner_buttons_load_google_font, $banner_buttons_font_family, $banner_buttons_font_weight, $banner_buttons_font_subset );

		}
		/**
		 * Adds Google fonts for Countdown Timer.
		 *
		 * @since 1.9.1
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_countdown_timer_gfont( $attr ) {

			$countdown_timer_value_load_google_font = isset( $attr['valueCountLoadGoogleFonts'] ) ? $attr['valueCountLoadGoogleFonts'] : '';
			$countdown_timer_value_font_family      = isset( $attr['valueFontFamily'] ) ? $attr['valueFontFamily'] : '';
			$countdown_timer_value_font_weight      = isset( $attr['valueFontWeight'] ) ? $attr['valueFontWeight'] : '';
			$countdown_timer_value_font_subset      = isset( $attr['valueFontSubset'] ) ? $attr['valueFontSubset'] : '';

			$countdown_timer_label_load_google_font = isset( $attr['labelCountLoadGoogleFonts'] ) ? $attr['labelCountLoadGoogleFonts'] : '';
			$countdown_timer_label_font_family      = isset( $attr['labelFontFamily'] ) ? $attr['labelFontFamily'] : '';
			$countdown_timer_label_font_weight      = isset( $attr['labelFontWeight'] ) ? $attr['labelFontWeight'] : '';
			$countdown_timer_label_font_subset      = isset( $attr['labelFontSubset'] ) ? $attr['labelFontSubset'] : '';

		   
			ZeGuten_Helper::blocks_google_font( $countdown_timer_value_load_google_font, $countdown_timer_value_font_family, $countdown_timer_value_font_weight, $countdown_timer_value_font_subset );

			ZeGuten_Helper::blocks_google_font( $countdown_timer_label_load_google_font, $countdown_timer_label_font_family, $countdown_timer_label_font_weight, $countdown_timer_label_font_subset );

		}


		/**
		 * Adds Google fonts for Progress Bar block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_progress_bar_gfont( $attr ) {

			$value_load_google_font  = isset( $attr['valueLoadGoogleFonts'] ) ? $attr['valueLoadGoogleFonts'] : '';
			$value_font_family        = isset( $attr['valueFontFamily'] ) ? $attr['valueFontFamily'] : '';
			$value_font_weight        = isset( $attr['valueFontWeight'] ) ? $attr['valueFontWeight'] : '';
			$value_font_subset        = isset( $attr['valueFontSubset'] ) ? $attr['valueFontSubset'] : '';

			$suffix_load_google_font    = isset( $attr['suffixLoadGoogleFonts'] ) ? $attr['suffixLoadGoogleFonts'] : '';
			$suffix_font_family      = isset( $attr['suffixFontFamily'] ) ? $attr['suffixFontFamily'] : '';
			$suffix_font_weight      = isset( $attr['suffixFontWeight'] ) ? $attr['suffixFontWeight'] : '';
			$suffix_font_subset      = isset( $attr['suffixFontSubset'] ) ? $attr['suffixFontSubset'] : '';

			$title_load_google_font  = isset( $attr['titleLoadGoogleFonts'] ) ? $attr['titleLoadGoogleFonts'] : '';
			$title_font_family        = isset( $attr['titleFontFamily'] ) ? $attr['titleFontFamily'] : '';
			$title_font_weight        = isset( $attr['titleFontWeight'] ) ? $attr['titleFontWeight'] : '';
			$title_font_subset        = isset( $attr['titleFontSubset'] ) ? $attr['titleFontSubset'] : '';

			$subtitle_load_google_font  = isset( $attr['subtitleLoadGoogleFonts'] ) ? $attr['subtitleLoadGoogleFonts'] : '';
			$subtitle_font_family      = isset( $attr['subtitleFontFamily'] ) ? $attr['subtitleFontFamily'] : '';
			$subtitle_font_weight      = isset( $attr['subtitleFontWeight'] ) ? $attr['subtitleFontWeight'] : '';
			$subtitle_font_subset      = isset( $attr['subtitleFontSubset'] ) ? $attr['subtitleFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $value_load_google_font, $value_font_family, $value_font_weight, $value_font_subset );

			ZeGuten_Helper::blocks_google_font( $suffix_load_google_font, $suffix_font_family, $suffix_font_weight, $suffix_font_subset );

			ZeGuten_Helper::blocks_google_font( $title_load_google_font, $title_font_family, $title_font_weight, $title_font_subset );

			ZeGuten_Helper::blocks_google_font( $subtitle_load_google_font, $subtitle_font_family, $subtitle_font_weight, $subtitle_font_subset );

		}


		/**
		 * Adds Google fonts for Blurbs block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_blurbs_gfont( $attr ) {

			$headerSubtitle_load_google_font        = isset( $attr['headerSubtitleLoadGoogleFonts'] ) ? $attr['headerSubtitleLoadGoogleFonts'] : '';
			$headerSubtitle_font_family             = isset( $attr['headerSubtitleFontFamily'] ) ? $attr['headerSubtitleFontFamily'] : '';
			$headerSubtitle_font_weight             = isset( $attr['headerSubtitleFontWeight'] ) ? $attr['headerSubtitleFontWeight'] : '';
			$headerSubtitle_font_subset             = isset( $attr['headerSubtitleFontSubset'] ) ? $attr['headerSubtitleFontSubset'] : '';

			$headerTitle_load_google_font           = isset( $attr['headerTitleLoadGoogleFonts'] ) ? $attr['headerTitleLoadGoogleFonts'] : '';
			$headerTitle_font_family                = isset( $attr['headerTitleFontFamily'] ) ? $attr['headerTitleFontFamily'] : '';
			$headerTitle_font_weight                = isset( $attr['headerTitleFontWeight'] ) ? $attr['headerTitleFontWeight'] : '';
			$headerTitle_font_subset                = isset( $attr['headerTitleFontSubset'] ) ? $attr['headerTitleFontSubset'] : '';

			$headerDescr_load_google_font           = isset( $attr['headerDescrLoadGoogleFonts'] ) ? $attr['headerDescrLoadGoogleFonts'] : '';
			$headerDescr_font_family                = isset( $attr['headerDescrFontFamily'] ) ? $attr['headerDescrFontFamily'] : '';
			$headerDescr_font_weight                = isset( $attr['headerDescrFontWeight'] ) ? $attr['headerDescrFontWeight'] : '';
			$headerDescr_font_subset                = isset( $attr['headerDescrFontSubset'] ) ? $attr['headerDescrFontSubset'] : '';

			$middleSubtitle_load_google_font        = isset( $attr['middleSubtitleLoadGoogleFonts'] ) ? $attr['middleSubtitleLoadGoogleFonts'] : '';
			$middleSubtitle_font_family             = isset( $attr['middleSubtitleFontFamily'] ) ? $attr['middleSubtitleFontFamily'] : '';
			$middleSubtitle_font_weight             = isset( $attr['middleSubtitleFontWeight'] ) ? $attr['middleSubtitleFontWeight'] : '';
			$middleSubtitle_font_subset             = isset( $attr['middleSubtitleFontSubset'] ) ? $attr['middleSubtitleFontSubset'] : '';

			$middleTitle_load_google_font           = isset( $attr['middleTitleLoadGoogleFonts'] ) ? $attr['middleTitleLoadGoogleFonts'] : '';
			$middleTitle_font_family                = isset( $attr['middleTitleFontFamily'] ) ? $attr['middleTitleFontFamily'] : '';
			$middleTitle_font_weight                = isset( $attr['middleTitleFontWeight'] ) ? $attr['middleTitleFontWeight'] : '';
			$middleTitle_font_subset                = isset( $attr['middleTitleFontSubset'] ) ? $attr['middleTitleFontSubset'] : '';

			$middleDescr_load_google_font           = isset( $attr['middleDescrLoadGoogleFonts'] ) ? $attr['middleDescrLoadGoogleFonts'] : '';
			$middleDescr_font_family                = isset( $attr['middleDescrFontFamily'] ) ? $attr['middleDescrFontFamily'] : '';
			$middleDescr_font_weight                = isset( $attr['middleDescrFontWeight'] ) ? $attr['middleDescrFontWeight'] : '';
			$middleDescr_font_subset                = isset( $attr['middleDescrFontSubset'] ) ? $attr['middleDescrFontSubset'] : '';

			$button1_load_google_font               = isset( $attr['button1LoadGoogleFonts'] ) ? $attr['button1LoadGoogleFonts'] : '';
			$button1_font_family                    = isset( $attr['button1FontFamily'] ) ? $attr['button1FontFamily'] : '';
			$button1_font_weight                    = isset( $attr['button1FontWeight'] ) ? $attr['button1FontWeight'] : '';
			$button1_font_subset                    = isset( $attr['button1FontSubset'] ) ? $attr['button1FontSubset'] : '';

			$button2_load_google_font               = isset( $attr['button2LoadGoogleFonts'] ) ? $attr['button2LoadGoogleFonts'] : '';
			$button2_font_family                    = isset( $attr['button2FontFamily'] ) ? $attr['button2FontFamily'] : '';
			$button2_font_weight                    = isset( $attr['button2FontWeight'] ) ? $attr['button2FontWeight'] : '';
			$button2_font_subset                    = isset( $attr['button2FontSubset'] ) ? $attr['button2FontSubset'] : '';


			ZeGuten_Helper::blocks_google_font( $headerSubtitle_load_google_font, $headerSubtitle_font_family, $headerSubtitle_font_weight, $headerSubtitle_font_subset );
			ZeGuten_Helper::blocks_google_font( $headerTitle_load_google_font, $headerTitle_font_family, $headerTitle_font_weight, $headerTitle_font_subset );
			ZeGuten_Helper::blocks_google_font( $headerDescr_load_google_font, $headerDescr_font_family, $headerDescr_font_weight, $headerDescr_font_subset );

			ZeGuten_Helper::blocks_google_font( $middleSubtitle_load_google_font, $middleSubtitle_font_family, $middleSubtitle_font_weight, $middleSubtitle_font_subset );
			ZeGuten_Helper::blocks_google_font( $middleTitle_load_google_font, $middleTitle_font_family, $middleTitle_font_weight, $middleTitle_font_subset );
			ZeGuten_Helper::blocks_google_font( $middleDescr_load_google_font, $middleDescr_font_family, $middleDescr_font_weight, $middleDescr_font_subset );

			ZeGuten_Helper::blocks_google_font( $button1_load_google_font, $button1_font_family, $button1_font_weight, $button1_font_subset );
			
			ZeGuten_Helper::blocks_google_font( $button2_load_google_font, $button2_font_family, $button2_font_weight, $button2_font_subset );

		}

		/**
		 * Adds Google fonts for Image Comparison block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_image_comparison_gfont( $attr ) {

			$beforeTitle_load_google_font       = isset( $attr['beforeTitleLoadGoogleFonts'] ) ? $attr['beforeTitleLoadGoogleFonts'] : '';
			$beforeTitle_font_family            = isset( $attr['beforeTitleFontFamily'] ) ? $attr['beforeTitleFontFamily'] : '';
			$beforeTitle_font_weight            = isset( $attr['beforeTitleFontWeight'] ) ? $attr['beforeTitleFontWeight'] : '';
			$beforeTitle_font_subset            = isset( $attr['beforeTitleFontSubset'] ) ? $attr['beforeTitleFontSubset'] : '';

			$beforeDescr_load_google_font       = isset( $attr['beforeDescrLoadGoogleFonts'] ) ? $attr['beforeDescrLoadGoogleFonts'] : '';
			$beforeDescr_font_family            = isset( $attr['beforeDescrFontFamily'] ) ? $attr['beforeDescrFontFamily'] : '';
			$beforeDescr_font_weight            = isset( $attr['beforeDescrFontWeight'] ) ? $attr['beforeDescrFontWeight'] : '';
			$beforeDescr_font_subset            = isset( $attr['beforeDescrFontSubset'] ) ? $attr['beforeDescrFontSubset'] : '';

			$afterTitle_load_google_font        = isset( $attr['afterTitleLoadGoogleFonts'] ) ? $attr['afterTitleLoadGoogleFonts'] : '';
			$afterTitle_font_family             = isset( $attr['afterTitleFontFamily'] ) ? $attr['afterTitleFontFamily'] : '';
			$afterTitle_font_weight             = isset( $attr['afterTitleFontWeight'] ) ? $attr['afterTitleFontWeight'] : '';
			$afterTitle_font_subset             = isset( $attr['afterTitleFontSubset'] ) ? $attr['afterTitleFontSubset'] : '';

			$afterDescr_load_google_font        = isset( $attr['afterDescrLoadGoogleFonts'] ) ? $attr['afterDescrLoadGoogleFonts'] : '';
			$afterDescr_font_family             = isset( $attr['afterDescrFontFamily'] ) ? $attr['afterDescrFontFamily'] : '';
			$afterDescr_font_weight             = isset( $attr['afterDescrFontWeight'] ) ? $attr['afterDescrFontWeight'] : '';
			$afterDescr_font_subset             = isset( $attr['afterDescrFontSubset'] ) ? $attr['afterDescrFontSubset'] : '';


			ZeGuten_Helper::blocks_google_font( $beforeTitle_load_google_font, $beforeTitle_font_family, $beforeTitle_font_weight, $beforeTitle_font_subset );
			
			ZeGuten_Helper::blocks_google_font( $beforeDescr_load_google_font, $beforeDescr_font_family, $beforeDescr_font_weight, $beforeDescr_font_subset );

			ZeGuten_Helper::blocks_google_font( $afterTitle_load_google_font, $afterTitle_font_family, $afterTitle_font_weight, $afterTitle_font_subset );
			
			ZeGuten_Helper::blocks_google_font( $afterDescr_load_google_font, $afterDescr_font_family, $afterDescr_font_weight, $afterDescr_font_subset );

		}

        /**
         * Adds Google fonts for Image Comparison block.
         *
         * @since 1.0.0
         * @param array $attr the blocks attr.
         */
        public static function blocks_zeguten_button_gfont( $attr ) {

            $button_load_google_font       = isset( $attr['buttonLoadGoogleFonts'] ) ? $attr['buttonLoadGoogleFonts'] : '';
            $button_font_family            = isset( $attr['buttonFontFamily'] ) ? $attr['buttonFontFamily'] : '';
            $button_font_weight            = isset( $attr['buttonFontWeight'] ) ? $attr['buttonFontWeight'] : '';
            $button_font_subset            = isset( $attr['buttonFontSubset'] ) ? $attr['buttonFontSubset'] : '';


            ZeGuten_Helper::blocks_google_font( $button_load_google_font, $button_font_family, $button_font_weight, $button_font_subset );

        }

       	/**
		 * Adds Google fonts for Blurbs block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_carousel_gfont( $attr ) {

			$headerSubtitle_load_google_font        = isset( $attr['headerSubtitleLoadGoogleFonts'] ) ? $attr['headerSubtitleLoadGoogleFonts'] : '';
			$headerSubtitle_font_family             = isset( $attr['headerSubtitleFontFamily'] ) ? $attr['headerSubtitleFontFamily'] : '';
			$headerSubtitle_font_weight             = isset( $attr['headerSubtitleFontWeight'] ) ? $attr['headerSubtitleFontWeight'] : '';
			$headerSubtitle_font_subset             = isset( $attr['headerSubtitleFontSubset'] ) ? $attr['headerSubtitleFontSubset'] : '';

			$headerTitle_load_google_font           = isset( $attr['headerTitleLoadGoogleFonts'] ) ? $attr['headerTitleLoadGoogleFonts'] : '';
			$headerTitle_font_family                = isset( $attr['headerTitleFontFamily'] ) ? $attr['headerTitleFontFamily'] : '';
			$headerTitle_font_weight                = isset( $attr['headerTitleFontWeight'] ) ? $attr['headerTitleFontWeight'] : '';
			$headerTitle_font_subset                = isset( $attr['headerTitleFontSubset'] ) ? $attr['headerTitleFontSubset'] : '';

			$headerDescr_load_google_font           = isset( $attr['headerDescrLoadGoogleFonts'] ) ? $attr['headerDescrLoadGoogleFonts'] : '';
			$headerDescr_font_family                = isset( $attr['headerDescrFontFamily'] ) ? $attr['headerDescrFontFamily'] : '';
			$headerDescr_font_weight                = isset( $attr['headerDescrFontWeight'] ) ? $attr['headerDescrFontWeight'] : '';
			$headerDescr_font_subset                = isset( $attr['headerDescrFontSubset'] ) ? $attr['headerDescrFontSubset'] : '';

			$middleSubtitle_load_google_font        = isset( $attr['middleSubtitleLoadGoogleFonts'] ) ? $attr['middleSubtitleLoadGoogleFonts'] : '';
			$middleSubtitle_font_family             = isset( $attr['middleSubtitleFontFamily'] ) ? $attr['middleSubtitleFontFamily'] : '';
			$middleSubtitle_font_weight             = isset( $attr['middleSubtitleFontWeight'] ) ? $attr['middleSubtitleFontWeight'] : '';
			$middleSubtitle_font_subset             = isset( $attr['middleSubtitleFontSubset'] ) ? $attr['middleSubtitleFontSubset'] : '';

			$middleTitle_load_google_font           = isset( $attr['middleTitleLoadGoogleFonts'] ) ? $attr['middleTitleLoadGoogleFonts'] : '';
			$middleTitle_font_family                = isset( $attr['middleTitleFontFamily'] ) ? $attr['middleTitleFontFamily'] : '';
			$middleTitle_font_weight                = isset( $attr['middleTitleFontWeight'] ) ? $attr['middleTitleFontWeight'] : '';
			$middleTitle_font_subset                = isset( $attr['middleTitleFontSubset'] ) ? $attr['middleTitleFontSubset'] : '';

			$middleDescr_load_google_font           = isset( $attr['middleDescrLoadGoogleFonts'] ) ? $attr['middleDescrLoadGoogleFonts'] : '';
			$middleDescr_font_family                = isset( $attr['middleDescrFontFamily'] ) ? $attr['middleDescrFontFamily'] : '';
			$middleDescr_font_weight                = isset( $attr['middleDescrFontWeight'] ) ? $attr['middleDescrFontWeight'] : '';
			$middleDescr_font_subset                = isset( $attr['middleDescrFontSubset'] ) ? $attr['middleDescrFontSubset'] : '';

			$button1_load_google_font               = isset( $attr['button1LoadGoogleFonts'] ) ? $attr['button1LoadGoogleFonts'] : '';
			$button1_font_family                    = isset( $attr['button1FontFamily'] ) ? $attr['button1FontFamily'] : '';
			$button1_font_weight                    = isset( $attr['button1FontWeight'] ) ? $attr['button1FontWeight'] : '';
			$button1_font_subset                    = isset( $attr['button1FontSubset'] ) ? $attr['button1FontSubset'] : '';

			$button2_load_google_font               = isset( $attr['button2LoadGoogleFonts'] ) ? $attr['button2LoadGoogleFonts'] : '';
			$button2_font_family                    = isset( $attr['button2FontFamily'] ) ? $attr['button2FontFamily'] : '';
			$button2_font_weight                    = isset( $attr['button2FontWeight'] ) ? $attr['button2FontWeight'] : '';
			$button2_font_subset                    = isset( $attr['button2FontSubset'] ) ? $attr['button2FontSubset'] : '';


			ZeGuten_Helper::blocks_google_font( $headerSubtitle_load_google_font, $headerSubtitle_font_family, $headerSubtitle_font_weight, $headerSubtitle_font_subset );
			ZeGuten_Helper::blocks_google_font( $headerTitle_load_google_font, $headerTitle_font_family, $headerTitle_font_weight, $headerTitle_font_subset );
			ZeGuten_Helper::blocks_google_font( $headerDescr_load_google_font, $headerDescr_font_family, $headerDescr_font_weight, $headerDescr_font_subset );

			ZeGuten_Helper::blocks_google_font( $middleSubtitle_load_google_font, $middleSubtitle_font_family, $middleSubtitle_font_weight, $middleSubtitle_font_subset );
			ZeGuten_Helper::blocks_google_font( $middleTitle_load_google_font, $middleTitle_font_family, $middleTitle_font_weight, $middleTitle_font_subset );
			ZeGuten_Helper::blocks_google_font( $middleDescr_load_google_font, $middleDescr_font_family, $middleDescr_font_weight, $middleDescr_font_subset );

			ZeGuten_Helper::blocks_google_font( $button1_load_google_font, $button1_font_family, $button1_font_weight, $button1_font_subset );
			
			ZeGuten_Helper::blocks_google_font( $button2_load_google_font, $button2_font_family, $button2_font_weight, $button2_font_subset );

		}
        

        /**
		 * Adds Google fonts for Animated Box block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_animated_box_gfont( $attr ) {

			$fTF_1_load_google_font        = isset( $attr['fTF_1_LoadGoogleFonts'] ) ? $attr['fTF_1_LoadGoogleFonts'] : '';
			$fTF_1_font_family             = isset( $attr['fTF_1_FontFamily'] ) ? $attr['fTF_1_FontFamily'] : '';
			$fTF_1_font_weight             = isset( $attr['fTF_1_FontWeight'] ) ? $attr['fTF_1_FontWeight'] : '';
			$fTF_1_font_subset             = isset( $attr['fTF_1_FontSubset'] ) ? $attr['fTF_1_FontSubset'] : '';

			$fTF_2_load_google_font        = isset( $attr['fTF_2_LoadGoogleFonts'] ) ? $attr['fTF_2_LoadGoogleFonts'] : '';
			$fTF_2_font_family             = isset( $attr['fTF_2_FontFamily'] ) ? $attr['fTF_2_FontFamily'] : '';
			$fTF_2_font_weight             = isset( $attr['fTF_2_FontWeight'] ) ? $attr['fTF_2_FontWeight'] : '';
			$fTF_2_font_subset             = isset( $attr['fTF_2_FontSubset'] ) ? $attr['fTF_2_FontSubset'] : '';

			$fTF_3_load_google_font        = isset( $attr['fTF_3_LoadGoogleFonts'] ) ? $attr['fTF_3_LoadGoogleFonts'] : '';
			$fTF_3_font_family             = isset( $attr['fTF_3_FontFamily'] ) ? $attr['fTF_3_FontFamily'] : '';
			$fTF_3_font_weight             = isset( $attr['fTF_3_FontWeight'] ) ? $attr['fTF_3_FontWeight'] : '';
			$fTF_3_font_subset             = isset( $attr['fTF_3_FontSubset'] ) ? $attr['fTF_3_FontSubset'] : '';

			$fTF_4_load_google_font        = isset( $attr['fTF_4_LoadGoogleFonts'] ) ? $attr['fTF_4_LoadGoogleFonts'] : '';
			$fTF_4_font_family             = isset( $attr['fTF_4_FontFamily'] ) ? $attr['fTF_4_FontFamily'] : '';
			$fTF_4_font_weight             = isset( $attr['fTF_4_FontWeight'] ) ? $attr['fTF_4_FontWeight'] : '';
			$fTF_4_font_subset             = isset( $attr['fTF_4_FontSubset'] ) ? $attr['fTF_4_FontSubset'] : '';


			$bTF_1_load_google_font        = isset( $attr['bTF_1_LoadGoogleFonts'] ) ? $attr['bTF_1_LoadGoogleFonts'] : '';
			$bTF_1_font_family             = isset( $attr['bTF_1_FontFamily'] ) ? $attr['bTF_1_FontFamily'] : '';
			$bTF_1_font_weight             = isset( $attr['bTF_1_FontWeight'] ) ? $attr['bTF_1_FontWeight'] : '';
			$bTF_1_font_subset             = isset( $attr['bTF_1_FontSubset'] ) ? $attr['bTF_1_FontSubset'] : '';

			$bTF_2_load_google_font        = isset( $attr['bTF_2_LoadGoogleFonts'] ) ? $attr['bTF_2_LoadGoogleFonts'] : '';
			$bTF_2_font_family             = isset( $attr['bTF_2_FontFamily'] ) ? $attr['bTF_2_FontFamily'] : '';
			$bTF_2_font_weight             = isset( $attr['bTF_2_FontWeight'] ) ? $attr['bTF_2_FontWeight'] : '';
			$bTF_2_font_subset             = isset( $attr['bTF_2_FontSubset'] ) ? $attr['bTF_2_FontSubset'] : '';

			$bTF_3_load_google_font        = isset( $attr['bTF_3_LoadGoogleFonts'] ) ? $attr['bTF_3_LoadGoogleFonts'] : '';
			$bTF_3_font_family             = isset( $attr['bTF_3_FontFamily'] ) ? $attr['bTF_3_FontFamily'] : '';
			$bTF_3_font_weight             = isset( $attr['bTF_3_FontWeight'] ) ? $attr['bTF_3_FontWeight'] : '';
			$bTF_3_font_subset             = isset( $attr['bTF_3_FontSubset'] ) ? $attr['bTF_3_FontSubset'] : '';

			$bTF_4_load_google_font        = isset( $attr['bTF_4_LoadGoogleFonts'] ) ? $attr['bTF_4_LoadGoogleFonts'] : '';
			$bTF_4_font_family             = isset( $attr['bTF_4_FontFamily'] ) ? $attr['bTF_4_FontFamily'] : '';
			$bTF_4_font_weight             = isset( $attr['bTF_4_FontWeight'] ) ? $attr['bTF_4_FontWeight'] : '';
			$bTF_4_font_subset             = isset( $attr['bTF_4_FontSubset'] ) ? $attr['bTF_4_FontSubset'] : '';

			$button1_load_google_font               = isset( $attr['button1LoadGoogleFonts'] ) ? $attr['button1LoadGoogleFonts'] : '';
			$button1_font_family                    = isset( $attr['button1FontFamily'] ) ? $attr['button1FontFamily'] : '';
			$button1_font_weight                    = isset( $attr['button1FontWeight'] ) ? $attr['button1FontWeight'] : '';
			$button1_font_subset                    = isset( $attr['button1FontSubset'] ) ? $attr['button1FontSubset'] : '';

			$button2_load_google_font               = isset( $attr['button2LoadGoogleFonts'] ) ? $attr['button2LoadGoogleFonts'] : '';
			$button2_font_family                    = isset( $attr['button2FontFamily'] ) ? $attr['button2FontFamily'] : '';
			$button2_font_weight                    = isset( $attr['button2FontWeight'] ) ? $attr['button2FontWeight'] : '';
			$button2_font_subset                    = isset( $attr['button2FontSubset'] ) ? $attr['button2FontSubset'] : '';


			ZeGuten_Helper::blocks_google_font( $fTF_1_load_google_font, $fTF_1_font_family, $fTF_1_font_weight, $fTF_1_font_subset );
			ZeGuten_Helper::blocks_google_font( $fTF_2_load_google_font, $fTF_2_font_family, $fTF_2_font_weight, $fTF_2_font_subset );
			ZeGuten_Helper::blocks_google_font( $fTF_3_load_google_font, $fTF_3_font_family, $fTF_3_font_weight, $fTF_3_font_subset );
			ZeGuten_Helper::blocks_google_font( $fTF_4_load_google_font, $fTF_4_font_family, $fTF_4_font_weight, $fTF_4_font_subset );

			ZeGuten_Helper::blocks_google_font( $bTF_1_load_google_font, $bTF_1_font_family, $bTF_1_font_weight, $bTF_1_font_subset );
			ZeGuten_Helper::blocks_google_font( $bTF_2_load_google_font, $bTF_2_font_family, $bTF_2_font_weight, $bTF_2_font_subset );
			ZeGuten_Helper::blocks_google_font( $bTF_3_load_google_font, $bTF_3_font_family, $bTF_3_font_weight, $bTF_3_font_subset );
			ZeGuten_Helper::blocks_google_font( $bTF_4_load_google_font, $bTF_4_font_family, $bTF_4_font_weight, $bTF_4_font_subset );

			ZeGuten_Helper::blocks_google_font( $button1_load_google_font, $button1_font_family, $button1_font_weight, $button1_font_subset );
			ZeGuten_Helper::blocks_google_font( $button2_load_google_font, $button2_font_family, $button2_font_weight, $button2_font_subset );


		}

		/**
		 * Adds Google fonts for Blurbs block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_pricing_table_gfont( $attr ) {


			$badgeText_load_google_font        = isset( $attr['badgeTextLoadGoogleFonts'] ) ? $attr['badgeTextLoadGoogleFonts'] : '';
			$badgeText_font_family             = isset( $attr['badgeTextFontFamily'] ) ? $attr['badgeTextFontFamily'] : '';
			$badgeText_font_weight             = isset( $attr['badgeTextFontWeight'] ) ? $attr['badgeTextFontWeight'] : '';
			$badgeText_font_subset             = isset( $attr['badgeTextFontSubset'] ) ? $attr['badgeTextFontSubset'] : '';

			$headerSubtitle_load_google_font        = isset( $attr['headerSubtitleLoadGoogleFonts'] ) ? $attr['headerSubtitleLoadGoogleFonts'] : '';
			$headerSubtitle_font_family             = isset( $attr['headerSubtitleFontFamily'] ) ? $attr['headerSubtitleFontFamily'] : '';
			$headerSubtitle_font_weight             = isset( $attr['headerSubtitleFontWeight'] ) ? $attr['headerSubtitleFontWeight'] : '';
			$headerSubtitle_font_subset             = isset( $attr['headerSubtitleFontSubset'] ) ? $attr['headerSubtitleFontSubset'] : '';

			$headerTitle_load_google_font           = isset( $attr['headerTitleLoadGoogleFonts'] ) ? $attr['headerTitleLoadGoogleFonts'] : '';
			$headerTitle_font_family                = isset( $attr['headerTitleFontFamily'] ) ? $attr['headerTitleFontFamily'] : '';
			$headerTitle_font_weight                = isset( $attr['headerTitleFontWeight'] ) ? $attr['headerTitleFontWeight'] : '';
			$headerTitle_font_subset                = isset( $attr['headerTitleFontSubset'] ) ? $attr['headerTitleFontSubset'] : '';

			$headerDescr_load_google_font           = isset( $attr['headerDescrLoadGoogleFonts'] ) ? $attr['headerDescrLoadGoogleFonts'] : '';
			$headerDescr_font_family                = isset( $attr['headerDescrFontFamily'] ) ? $attr['headerDescrFontFamily'] : '';
			$headerDescr_font_weight                = isset( $attr['headerDescrFontWeight'] ) ? $attr['headerDescrFontWeight'] : '';
			$headerDescr_font_subset                = isset( $attr['headerDescrFontSubset'] ) ? $attr['headerDescrFontSubset'] : '';



			$pricePrefix_load_google_font           = isset( $attr['priceValLoadGoogleFonts'] ) ? $attr['priceValLoadGoogleFonts'] : '';
			$pricePrefix_font_family                = isset( $attr['pricePrefixFontFamily'] ) ? $attr['pricePrefixFontFamily'] : '';
			$pricePrefix_font_weight                = isset( $attr['pricePrefixFontWeight'] ) ? $attr['pricePrefixFontWeight'] : '';
			$pricePrefix_font_subset                = isset( $attr['pricePrefixFontSubset'] ) ? $attr['pricePrefixFontSubset'] : '';

			$priceVal_load_google_font           = isset( $attr['priceValLoadGoogleFonts'] ) ? $attr['priceValLoadGoogleFonts'] : '';
			$priceVal_font_family                = isset( $attr['priceValFontFamily'] ) ? $attr['priceValFontFamily'] : '';
			$priceVal_font_weight                = isset( $attr['priceValFontWeight'] ) ? $attr['priceValFontWeight'] : '';
			$priceVal_font_subset                = isset( $attr['priceValFontSubset'] ) ? $attr['priceValFontSubset'] : '';

			$priceSuffix_load_google_font           = isset( $attr['priceSuffixLoadGoogleFonts'] ) ? $attr['priceSuffixLoadGoogleFonts'] : '';
			$priceSuffix_font_family             = isset( $attr['priceSuffixFontFamily'] ) ? $attr['priceSuffixFontFamily'] : '';
			$priceSuffix_font_weight             = isset( $attr['priceSuffixFontWeight'] ) ? $attr['priceSuffixFontWeight'] : '';
			$priceSuffix_font_subset             = isset( $attr['priceSuffixFontSubset'] ) ? $attr['priceSuffixFontSubset'] : '';

			$priceDesc_load_google_font           = isset( $attr['priceDescLoadGoogleFonts'] ) ? $attr['priceDescLoadGoogleFonts'] : '';
			$priceDesc_font_family                = isset( $attr['priceDescFontFamily'] ) ? $attr['priceDescFontFamily'] : '';
			$priceDesc_font_weight                = isset( $attr['priceDescFontWeight'] ) ? $attr['priceDescFontWeight'] : '';
			$priceDesc_font_subset                = isset( $attr['priceDescFontSubset'] ) ? $attr['priceDescFontSubset'] : '';


			$loadActionsButton1_load_google_font       = isset( $attr['button1LoadGoogleFonts'] ) ? $attr['button1LoadGoogleFonts'] : '';
			$button1_font_family                = isset( $attr['button1FontFamily'] ) ? $attr['button1FontFamily'] : '';
			$button1_font_weight                = isset( $attr['button1FontWeight'] ) ? $attr['button1FontWeight'] : '';
			$button1_font_subset                = isset( $attr['button1FontSubset'] ) ? $attr['button1FontSubset'] : '';


			$loadActions2_load_google_font       = isset( $attr['button2LoadGoogleFonts'] ) ? $attr['button2LoadGoogleFonts'] : '';
			$button2_font_family                = isset( $attr['button2FontFamily'] ) ? $attr['button2FontFamily'] : '';
			$button2_font_weight                = isset( $attr['button2FontWeight'] ) ? $attr['button2FontWeight'] : '';
			$button2_font_subset                = isset( $attr['button2FontSubset'] ) ? $attr['button2FontSubset'] : '';



			$footerPrefix_load_google_font      = isset( $attr['footerPrefixLoadGoogleFonts'] ) ? $attr['footerPrefixLoadGoogleFonts'] : '';
			$footerPrefix_font_family           = isset( $attr['footerPrefixFontFamily'] ) ? $attr['footerPrefixFontFamily'] : '';
			$footerPrefix_font_weight           = isset( $attr['footerPrefixFontWeight'] ) ? $attr['footerPrefixFontWeight'] : '';
			$footerPrefix_font_subset           = isset( $attr['footerPrefixFontSubset'] ) ? $attr['footerPrefixFontSubset'] : '';

			$footerLink_load_google_font        = isset( $attr['footerLinkLoadGoogleFonts'] ) ? $attr['footerLinkLoadGoogleFonts'] : '';
			$footerLink_font_family             = isset( $attr['footerLinkFontFamily'] ) ? $attr['footerLinkFontFamily'] : '';
			$footerLink_font_weight             = isset( $attr['footerLinkFontWeight'] ) ? $attr['footerLinkFontWeight'] : '';
			$footerLink_font_subset             = isset( $attr['footerLinkFontSubset'] ) ? $attr['footerLinkFontSubset'] : '';


			$featuresItem_load_google_font        = isset( $attr['featuresItemLoadGoogleFonts'] ) ? $attr['featuresItemLoadGoogleFonts'] : '';
			$featuresItem_font_family             = isset( $attr['featuresItemFontFamily'] ) ? $attr['featuresItemFontFamily'] : '';
			$featuresItem_font_weight             = isset( $attr['featuresItemFontWeight'] ) ? $attr['featuresItemFontWeight'] : '';
			$featuresItem_font_subset             = isset( $attr['featuresItemFontSubset'] ) ? $attr['featuresItemFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $badgeText_load_google_font, $badgeText_font_family, $badgeText_font_weight, $badgeText_font_subset );
			ZeGuten_Helper::blocks_google_font( $headerSubtitle_load_google_font, $headerSubtitle_font_family, $headerSubtitle_font_weight, $headerSubtitle_font_subset );
			ZeGuten_Helper::blocks_google_font( $headerTitle_load_google_font, $headerTitle_font_family, $headerTitle_font_weight, $headerTitle_font_subset );
			ZeGuten_Helper::blocks_google_font( $headerDescr_load_google_font, $headerDescr_font_family, $headerDescr_font_weight, $headerDescr_font_subset );


			ZeGuten_Helper::blocks_google_font( $pricePrefix_load_google_font, $pricePrefix_font_family, $pricePrefix_font_weight, $pricePrefix_font_subset );
			ZeGuten_Helper::blocks_google_font( $priceVal_load_google_font, $priceVal_font_family, $priceVal_font_weight, $priceVal_font_subset );
			ZeGuten_Helper::blocks_google_font( $priceSuffix_load_google_font, $priceSuffix_font_family, $priceSuffix_font_weight, $priceSuffix_font_subset );
			ZeGuten_Helper::blocks_google_font( $priceDesc_load_google_font, $priceDesc_font_family, $priceDesc_font_weight, $priceDesc_font_subset );

			ZeGuten_Helper::blocks_google_font( $loadActionsButton1_load_google_font, $button1_font_family, $button1_font_weight, $button1_font_subset );
			ZeGuten_Helper::blocks_google_font( $loadActions2_load_google_font, $button2_font_family, $button2_font_weight, $button2_font_subset );


			ZeGuten_Helper::blocks_google_font( $footerPrefix_load_google_font, $footerPrefix_font_family, $footerPrefix_font_weight, $footerPrefix_font_subset );
			ZeGuten_Helper::blocks_google_font( $footerLink_load_google_font, $footerLink_font_family, $footerLink_font_weight, $footerLink_font_subset );


			ZeGuten_Helper::blocks_google_font( $featuresItem_load_google_font, $featuresItem_font_family, $featuresItem_font_weight, $featuresItem_font_subset );


		}

        /**
         * Adds Google fonts for Subscribe block.
         *
         * @since 1.0.0
         * @param array $attr the blocks attr.
         */
        public static function blocks_zeguten_subscribe_gfont( $attr ) {

            $label_load_google_font       = isset( $attr['labelLoadGoogleFonts'] ) ? $attr['labelLoadGoogleFonts'] : '';
            $label_font_family            = isset( $attr['labelFontFamily'] ) ? $attr['labelFontFamily'] : '';
            $label_font_weight            = isset( $attr['labelFontWeight'] ) ? $attr['labelFontWeight'] : '';
            $label_font_subset            = isset( $attr['labelFontSubset'] ) ? $attr['labelFontSubset'] : '';

            $input_load_google_font       = isset( $attr['inputLoadGoogleFonts'] ) ? $attr['inputLoadGoogleFonts'] : '';
            $input_font_family            = isset( $attr['inputFontFamily'] ) ? $attr['inputFontFamily'] : '';
            $input_font_weight            = isset( $attr['inputFontWeight'] ) ? $attr['inputFontWeight'] : '';
            $input_font_subset            = isset( $attr['inputFontSubset'] ) ? $attr['inputFontSubset'] : '';

            $submit_load_google_font       = isset( $attr['submitLoadGoogleFonts'] ) ? $attr['submitLoadGoogleFonts'] : '';
            $submit_font_family            = isset( $attr['submitFontFamily'] ) ? $attr['submitFontFamily'] : '';
            $submit_font_weight            = isset( $attr['submitFontWeight'] ) ? $attr['submitFontWeight'] : '';
            $submit_font_subset            = isset( $attr['submitFontSubset'] ) ? $attr['submitFontSubset'] : '';

            $error_load_google_font       = isset( $attr['errorLoadGoogleFonts'] ) ? $attr['errorLoadGoogleFonts'] : '';
            $error_font_family            = isset( $attr['errorFontFamily'] ) ? $attr['errorFontFamily'] : '';
            $error_font_weight            = isset( $attr['errorFontWeight'] ) ? $attr['errorFontWeight'] : '';
            $error_font_subset            = isset( $attr['errorFontSubset'] ) ? $attr['errorFontSubset'] : '';

            $success_load_google_font       = isset( $attr['successLoadGoogleFonts'] ) ? $attr['successLoadGoogleFonts'] : '';
            $success_font_family            = isset( $attr['successFontFamily'] ) ? $attr['successFontFamily'] : '';
            $success_font_weight            = isset( $attr['successFontWeight'] ) ? $attr['successFontWeight'] : '';
            $success_font_subset            = isset( $attr['successFontSubset'] ) ? $attr['successFontSubset'] : '';

            $confirm_load_google_font       = isset( $attr['confirmLoadGoogleFonts'] ) ? $attr['confirmLoadGoogleFonts'] : '';
            $confirm_font_family            = isset( $attr['confirmFontFamily'] ) ? $attr['confirmFontFamily'] : '';
            $confirm_font_weight            = isset( $attr['confirmFontWeight'] ) ? $attr['confirmFontWeight'] : '';
            $confirm_font_subset            = isset( $attr['confirmFontSubset'] ) ? $attr['confirmFontSubset'] : '';



            ZeGuten_Helper::blocks_google_font( $label_load_google_font, $label_font_family, $label_font_weight, $label_font_subset );
            ZeGuten_Helper::blocks_google_font( $input_load_google_font, $input_font_family, $input_font_weight, $input_font_subset );
            ZeGuten_Helper::blocks_google_font( $submit_load_google_font, $submit_font_family, $submit_font_weight, $submit_font_subset );
            ZeGuten_Helper::blocks_google_font( $success_load_google_font, $success_font_family, $success_font_weight, $success_font_subset );
            ZeGuten_Helper::blocks_google_font( $error_load_google_font, $error_font_family, $error_font_weight, $error_font_subset );
            ZeGuten_Helper::blocks_google_font( $confirm_load_google_font, $confirm_font_family, $confirm_font_weight, $confirm_font_subset );

        }


		 /**
         * Adds Google fonts for Сontact Form 7 block.
         *
         * @since 1.0.0
         * @param array $attr the blocks attr.
         */
        public static function blocks_zeguten_cf7_gfont( $attr ) {

        	$formTexts_load_google_font       = isset( $attr['formTextsLoadGoogleFonts'] ) ? $attr['formTextsLoadGoogleFonts'] : '';
            $formTexts_font_family            = isset( $attr['formTextsFontFamily'] ) ? $attr['formTextsFontFamily'] : '';
            $formTexts_font_weight            = isset( $attr['formTextsFontWeight'] ) ? $attr['formTextsFontWeight'] : '';
            $formTexts_font_subset            = isset( $attr['formTextsFontSubset'] ) ? $attr['formTextsFontSubset'] : '';

            $valid_load_google_font       = isset( $attr['validLoadGoogleFonts'] ) ? $attr['validLoadGoogleFonts'] : '';
            $valid_font_family            = isset( $attr['validFontFamily'] ) ? $attr['validFontFamily'] : '';
            $valid_font_weight            = isset( $attr['validFontWeight'] ) ? $attr['validFontWeight'] : '';
            $valid_font_subset            = isset( $attr['validFontSubset'] ) ? $attr['validFontSubset'] : '';

            $input_load_google_font       = isset( $attr['inputLoadGoogleFonts'] ) ? $attr['inputLoadGoogleFonts'] : '';
            $input_font_family            = isset( $attr['inputFontFamily'] ) ? $attr['inputFontFamily'] : '';
            $input_font_weight            = isset( $attr['inputFontWeight'] ) ? $attr['inputFontWeight'] : '';
            $input_font_subset            = isset( $attr['inputFontSubset'] ) ? $attr['inputFontSubset'] : '';

            $submit_load_google_font       = isset( $attr['submitLoadGoogleFonts'] ) ? $attr['submitLoadGoogleFonts'] : '';
            $submit_font_family            = isset( $attr['submitFontFamily'] ) ? $attr['submitFontFamily'] : '';
            $submit_font_weight            = isset( $attr['submitFontWeight'] ) ? $attr['submitFontWeight'] : '';
            $submit_font_subset            = isset( $attr['submitFontSubset'] ) ? $attr['submitFontSubset'] : '';

            $alerts_load_google_font       = isset( $attr['alertsLoadGoogleFonts'] ) ? $attr['alertsLoadGoogleFonts'] : '';
            $alerts_font_family            = isset( $attr['alertsFontFamily'] ) ? $attr['alertsFontFamily'] : '';
            $alerts_font_weight            = isset( $attr['alertsFontWeight'] ) ? $attr['alertsFontWeight'] : '';
            $alerts_font_subset            = isset( $attr['alertsFontSubset'] ) ? $attr['alertsFontSubset'] : '';

            $radio_load_google_font       = isset( $attr['radioLoadGoogleFonts'] ) ? $attr['radioLoadGoogleFonts'] : '';
            $radio_font_family            = isset( $attr['radioFontFamily'] ) ? $attr['radioFontFamily'] : '';
            $radio_font_weight            = isset( $attr['radioFontWeight'] ) ? $attr['radioFontWeight'] : '';
            $radio_font_subset            = isset( $attr['radioFontSubset'] ) ? $attr['radioFontSubset'] : '';


            $checkbox_load_google_font       = isset( $attr['checkboxLoadGoogleFonts'] ) ? $attr['checkboxLoadGoogleFonts'] : '';
            $checkbox_font_family            = isset( $attr['checkboxFontFamily'] ) ? $attr['checkboxFontFamily'] : '';
            $checkbox_font_weight            = isset( $attr['checkboxFontWeight'] ) ? $attr['checkboxFontWeight'] : '';
            $checkbox_font_subset            = isset( $attr['checkboxFontSubset'] ) ? $attr['checkboxFontSubset'] : '';


            ZeGuten_Helper::blocks_google_font( $formTexts_load_google_font, $formTexts_font_family, $formTexts_font_weight, $formTexts_font_subset );
            ZeGuten_Helper::blocks_google_font( $valid_load_google_font, $valid_font_family, $valid_font_weight, $valid_font_subset );
            ZeGuten_Helper::blocks_google_font( $input_load_google_font, $input_font_family, $input_font_weight, $input_font_subset );
            ZeGuten_Helper::blocks_google_font( $submit_load_google_font, $submit_font_family, $submit_font_weight, $submit_font_subset );
            ZeGuten_Helper::blocks_google_font( $alerts_load_google_font, $alerts_font_family, $alerts_font_weight, $alerts_font_subset );
            ZeGuten_Helper::blocks_google_font( $radio_load_google_font, $radio_font_family, $radio_font_weight, $radio_font_subset );
            ZeGuten_Helper::blocks_google_font( $checkbox_load_google_font, $checkbox_font_family, $checkbox_font_weight, $checkbox_font_subset );

        }

		/**
		 * Adds Google fonts for Tabs block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */
		public static function blocks_zeguten_tabs_gfont( $attr ) {

			$tabTxt_load_google_font     = isset( $attr['tabTxtLoadGoogleFonts'] ) ? $attr['tabTxtLoadGoogleFonts'] : '';
			$tabTxt_font_family          = isset( $attr['tabTxtFontFamily'] ) ? $attr['tabTxtFontFamily'] : '';
			$tabTxt_font_weight          = isset( $attr['tabTxtFontWeight'] ) ? $attr['tabTxtFontWeight'] : '';
			$tabTxt_font_subset          = isset( $attr['tabTxtFontSubset'] ) ? $attr['tabTxtFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $tabTxt_load_google_font, $tabTxt_font_family, $tabTxt_font_weight, $tabTxt_font_subset );

		}


		/**
		 * Adds Google fonts for Team Member block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */
		
		public static function blocks_zeguten_team_member_gfont( $attr ) {

			$memberName_load_google_font     = isset( $attr['memberNameLoadGoogleFonts'] ) ? $attr['memberNameLoadGoogleFonts'] : '';
			$memberName_font_family          = isset( $attr['memberNameFontFamily'] ) ? $attr['memberNameFontFamily'] : '';
			$memberName_font_weight          = isset( $attr['memberNameFontWeight'] ) ? $attr['memberNameFontWeight'] : '';
			$memberName_font_subset          = isset( $attr['memberNameFontSubset'] ) ? $attr['memberNameFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $memberName_load_google_font, $memberName_font_family, $memberName_font_weight, $memberName_font_subset );

			$memberPosition_load_google_font     = isset( $attr['memberPositionLoadGoogleFonts'] ) ? $attr['memberPositionLoadGoogleFonts'] : '';
			$memberPosition_font_family          = isset( $attr['memberPositionFontFamily'] ) ? $attr['memberPositionFontFamily'] : '';
			$memberPosition_font_weight          = isset( $attr['memberPositionFontWeight'] ) ? $attr['memberPositionFontWeight'] : '';
			$memberPosition_font_subset          = isset( $attr['memberPositionFontSubset'] ) ? $attr['memberPositionFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $memberPosition_load_google_font, $memberPosition_font_family, $memberPosition_font_weight, $memberPosition_font_subset );

			$memberDescription_load_google_font     = isset( $attr['memberDescriptionLoadGoogleFonts'] ) ? $attr['memberDescriptionLoadGoogleFonts'] : '';
			$memberDescription_font_family          = isset( $attr['memberDescriptionFontFamily'] ) ? $attr['memberDescriptionFontFamily'] : '';
			$memberDescription_font_weight          = isset( $attr['memberDescriptionFontWeight'] ) ? $attr['memberDescriptionFontWeight'] : '';
			$memberDescription_font_subset          = isset( $attr['memberDescriptionFontSubset'] ) ? $attr['memberDescriptionFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $memberDescription_load_google_font, $memberDescription_font_family, $memberDescription_font_weight, $memberDescription_font_subset );

			$infoText_load_google_font     = isset( $attr['infoTextLoadGoogleFonts'] ) ? $attr['infoTextLoadGoogleFonts'] : '';
			$infoText_font_family          = isset( $attr['infoTextFontFamily'] ) ? $attr['infoTextFontFamily'] : '';
			$infoText_font_weight          = isset( $attr['infoTextFontWeight'] ) ? $attr['infoTextFontWeight'] : '';
			$infoText_font_subset          = isset( $attr['infoTextFontSubset'] ) ? $attr['infoTextFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $infoText_load_google_font, $infoText_font_family, $infoText_font_weight, $infoText_font_subset );

			$button1Load_load_google_font     = isset( $attr['button1LoadLoadGoogleFonts'] ) ? $attr['button1LoadLoadGoogleFonts'] : '';
			$button1Load_font_family          = isset( $attr['button1LoadFontFamily'] ) ? $attr['button1LoadFontFamily'] : '';
			$button1Load_font_weight          = isset( $attr['button1LoadFontWeight'] ) ? $attr['button1LoadFontWeight'] : '';
			$button1Load_font_subset          = isset( $attr['button1LoadFontSubset'] ) ? $attr['button1LoadFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $button1Load_load_google_font, $button1Load_font_family, $button1Load_font_weight, $button1Load_font_subset );

			$button2Load_load_google_font     = isset( $attr['button2LoadLoadGoogleFonts'] ) ? $attr['button2LoadLoadGoogleFonts'] : '';
			$button2Load_font_family          = isset( $attr['button2LoadFontFamily'] ) ? $attr['button2LoadFontFamily'] : '';
			$button2Load_font_weight          = isset( $attr['button2LoadFontWeight'] ) ? $attr['button2LoadFontWeight'] : '';
			$button2Load_font_subset          = isset( $attr['button2LoadFontSubset'] ) ? $attr['button2LoadFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $button2Load_load_google_font, $button2Load_font_family, $button2Load_font_weight, $button2Load_font_subset );

		}


        /**
         * Adds Google fonts for Testimonials block.
         *
         * @since 1.0.0
         * @param array $attr the blocks attr.
         */
        public static function blocks_zeguten_testimonials_gfont( $attr ) {


            $titleGoogleFonts     = isset( $attr['titleGoogleFonts'] ) ? $attr['titleGoogleFonts'] : '';
            $titleFontFamily          = isset( $attr['titleFontFamily'] ) ? $attr['titleFontFamily'] : '';
            $titleFontWeight          = isset( $attr['titleFontWeight'] ) ? $attr['titleFontWeight'] : '';
            $titleFontSubset          = isset( $attr['titleFontSubset'] ) ? $attr['titleFontSubset'] : '';

            $authorNameGoogleFonts     = isset( $attr['authorNameGoogleFonts'] ) ? $attr['authorNameGoogleFonts'] : '';
            $authorNameFontFamily          = isset( $attr['authorNameFontFamily'] ) ? $attr['authorNameFontFamily'] : '';
            $authorNameFontWeight          = isset( $attr['authorNameFontWeight'] ) ? $attr['authorNameFontWeight'] : '';
            $authorNameFontSubset          = isset( $attr['authorNameFontSubset'] ) ? $attr['authorNameFontSubset'] : '';


            $descriptionGoogleFonts     = isset( $attr['descriptionGoogleFonts'] ) ? $attr['descriptionGoogleFonts'] : '';
            $descriptionFontFamily          = isset( $attr['descriptionFontFamily'] ) ? $attr['descriptionFontFamily'] : '';
            $descriptionFontWeight          = isset( $attr['descriptionFontWeight'] ) ? $attr['descriptionFontWeight'] : '';
            $descriptionFontSubset          = isset( $attr['descriptionFontSubset'] ) ? $attr['descriptionFontSubset'] : '';


            $positionGoogleFonts     = isset( $attr['positionGoogleFonts'] ) ? $attr['positionGoogleFonts'] : '';
            $positionFontFamily          = isset( $attr['positionFontFamily'] ) ? $attr['positionFontFamily'] : '';
            $positionFontWeight          = isset( $attr['positionFontWeight'] ) ? $attr['positionFontWeight'] : '';
            $positionFontSubset          = isset( $attr['positionFontSubset'] ) ? $attr['positionFontSubset'] : '';


            $dateGoogleFonts     = isset( $attr['dateGoogleFonts'] ) ? $attr['dateGoogleFonts'] : '';
            $dateFontFamily          = isset( $attr['dateFontFamily'] ) ? $attr['dateFontFamily'] : '';
            $dateFontWeight          = isset( $attr['dateFontWeight'] ) ? $attr['dateFontWeight'] : '';
            $dateFontSubset          = isset( $attr['dateFontSubset'] ) ? $attr['dateFontSubset'] : '';


            $emailGoogleFonts     = isset( $attr['emailGoogleFonts'] ) ? $attr['emailGoogleFonts'] : '';
            $emailFontFamily          = isset( $attr['emailFontFamily'] ) ? $attr['emailFontFamily'] : '';
            $emailFontWeight          = isset( $attr['emailFontWeight'] ) ? $attr['emailFontWeight'] : '';
            $emailFontSubset          = isset( $attr['emailFontSubset'] ) ? $attr['emailFontSubset'] : '';



            ZeGuten_Helper::blocks_google_font( $titleGoogleFonts, $titleFontFamily, $titleFontWeight, $titleFontSubset );
            ZeGuten_Helper::blocks_google_font( $authorNameGoogleFonts, $authorNameFontFamily, $authorNameFontWeight, $authorNameFontSubset );
            ZeGuten_Helper::blocks_google_font( $descriptionGoogleFonts, $descriptionFontFamily, $descriptionFontWeight, $descriptionFontSubset );
            ZeGuten_Helper::blocks_google_font( $positionGoogleFonts, $positionFontFamily, $positionFontWeight, $positionFontSubset );
            ZeGuten_Helper::blocks_google_font( $dateGoogleFonts, $dateFontFamily, $dateFontWeight, $dateFontSubset );
            ZeGuten_Helper::blocks_google_font( $emailGoogleFonts, $emailFontFamily, $emailFontWeight, $emailFontSubset );

        }


		/**
		 * Adds Google fonts for Slider block.
		 *
		 * @since 1.0.0
		 * @param array $attr the blocks attr.
		 */
		
		public static function blocks_zeguten_slider_gfont( $attr ) {

			$pag_load_google_font     = isset( $attr['pagLoadGoogleFonts'] ) ? $attr['pagLoadGoogleFonts'] : '';
			$pag_font_family          = isset( $attr['pagFontFamily'] ) ? $attr['pagFontFamily'] : '';
			$pag_font_weight          = isset( $attr['pagFontWeight'] ) ? $attr['pagFontWeight'] : '';
			$pag_font_subset          = isset( $attr['pagFontSubset'] ) ? $attr['pagFontSubset'] : '';

			ZeGuten_Helper::blocks_google_font( $pag_load_google_font, $pag_font_family, $pag_font_weight, $pag_font_subset );


		}

    }

}