<?php
/**
 * Class description
 *
 * @package   package_name
 * @author    Gutenix
 * @license   GPL-2.0+
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'ZeGuten_Plugin' ) ) {

	/**
	 * Define ZeGuten_Plugin class
	 */
	class ZeGuten_Plugin {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		private static $instance = null;

		public $ajax_handlers = null;
		public $svg_manager   = null;

		/**
		 * Constructor for the class
		 */
		public function __construct() {

			$this->includes();

			$this->ajax_handlers = new ZeGuten_Ajax_Handlers();
			$this->svg_manager   = new ZeGuten_SVG_Manager();
			$this->register_blocks();
			$this->admin_init();
			$this->define_constants();

			add_action( 'wp_ajax_zeguten_cf7_shortcode', array( $this, 'zeguten_cf7_shortcode' ) );
			add_action( 'wp_ajax_nopriv_zeguten_cf7_shortcode', array( $this, 'zeguten_cf7_shortcode' ) );
			add_action( 'admin_head', array( $this, 'fix_svg_thumb_display' ) );

			add_action( 'admin_enqueue_scripts', array( $this, 'zeguten_dashboard_scripts' ) );

		}


		/**
		 * Defines all constants
		 *
		 * @since 1.0.0
		 */
		public function define_constants() {
			define( 'zeguten_breakpoints_tablet', '1025' );
			define( 'zeguten_breakpoints_mobile', '768' );
		}


		/**
		 * ZeGuten CSS Print Method
		 *
		 * @since 1.0.15
		 */

		public function zeguten_dashboard_scripts() {

			wp_register_script( 				
				'zeguten-dashboard',
				ZEGUTEN_URL . 'assets/lib/zeguten-dashboard.js',
				array( 'jquery', 'jquery-ui-sortable'),
				ZEGUTEN_VERSION,
				true
			);
			wp_enqueue_script('zeguten-dashboard');
		}

		public function register_blocks() {

			if ( ! function_exists( 'register_block_type' ) ) {
				return;
			}

			// Register Scripts.
			wp_register_script(
				'image-comparison',
				ZEGUTEN_URL . 'assets/lib/image-comparison/image-comparison.min.js',
				array(),
				ZEGUTEN_VERSION,
				true
			);


			wp_register_script(
				'zeguten-blocks',
				ZEGUTEN_URL . 'assets/js/public.js',
				array( 'image-comparison', 'jquery', 'wp-a11y' ),
				ZEGUTEN_VERSION,
				true
			);

			wp_register_script(
				'wow',
				ZEGUTEN_URL . 'assets/lib/wow/dist/wow.min.js',
				array( 'jquery', 'wp-a11y' ),
				ZEGUTEN_VERSION,
				true
			);


			wp_register_script(
				'waypoints',
				ZEGUTEN_URL . 'assets/lib/waypoints/jquery.waypoints.min.js',
				array( 'jquery' ),
				'4.0.1',
				true
			);
			
			wp_register_script(
				'slick',
				ZEGUTEN_URL . 'assets/lib/slick/slick.min.js',
				array( 'jquery' ),
				ZEGUTEN_VERSION,
				true
			);

			wp_register_script(
				'popper',
				ZEGUTEN_URL . 'assets/lib/tooltip/popper.min.js',
				array( 'jquery' ),
				ZEGUTEN_VERSION,
				true
			);

			wp_register_script(
				'tippy',
				ZEGUTEN_URL . 'assets/lib/tooltip/tippy-bundle.umd.min.js',
				array( 'jquery' ),
				ZEGUTEN_VERSION,
				true
			);

			wp_register_script(
				'zeguten-blocks-editor',
				ZEGUTEN_URL . 'assets/js/admin.js',
				array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor' ),
				ZEGUTEN_VERSION,
				true
			);

			wp_register_script(
				'swiper',
				ZEGUTEN_URL . 'assets/lib/swiper/swiper.min.js',
				array(),
				'4.5.0',
				true
			);

			// Load View

			$zeguten_ajax_nonce = wp_create_nonce( 'zeguten_ajax_nonce' );

			wp_enqueue_script('waypoints');
	        wp_enqueue_script('slick');
	        wp_enqueue_script('popper');
	        wp_enqueue_script('tippy');
	        wp_enqueue_script('swiper');
	        wp_enqueue_script('wow');

			// Editor Scripts.

			wp_localize_script( 
				'zeguten-blocks-editor',
				'ZeGutenSettings',
				array(
					'imgPlaceholder'    			=> ZEGUTEN_URL . 'assets/img/placeholder.png',
					'ingIconInfo'		 			=> ZEGUTEN_URL . 'assets/img/iconinfo.png',
					'placeholderHeight' 			=> 450,

					'zeguten_breakpoints_tablet' 	=> get_option( 'zeguten_breakpoints_tablet', '1025' ),
					'zeguten_breakpoints_mobile' 	=> get_option( 'zeguten_breakpoints_mobile', '768' ),
					'zeguten_content_width'			=> get_option( 'zeguten_content_width', '1200' ),
					
					'image_sizes' 					=> ZeGuten_Helper::get_zeguten_image_sizes(),
					'zeguten_google_api_key' 		=> get_option( 'zeguten_google_api_key', '' ),
					'zeguten_mailchimp_api_key' 	=> get_option( 'zeguten_mailchimp_api_key', '' ),
					'zeguten_svg_enable' 			=> get_option( 'zeguten_svg_enable', '' ),
					'zeguten_dashboard_page_url' 	=> admin_url( '?page=zeguten-dashboard' ),
					'get_zeguten_cf7'         		=> $this->get_zeguten_cf7(),
					'zeguten_ajax_nonce'   		 	=> $zeguten_ajax_nonce,
					'ajax_url' 						=> admin_url( 'admin-ajax.php' ),
					'is_active_products_grid'		=> class_exists( 'woocommerce' ),
					'is_active_cf7'					=> class_exists( 'WPCF7_ContactForm' ),
				)
			);

			wp_localize_script( 
				'zeguten-blocks',
				'zeguten_subscribe_vars',
				[

					'ajaxurl' => esc_url( admin_url( 'admin-ajax.php' ) ),
					'l10n'    => [
						'button_text_processing' => esc_html( zeguten_subscribe_block_attributes()['buttonTextProcessing']['default'] ),
						'button_text_success' => esc_html( zeguten_subscribe_block_attributes()['buttonTextSuccess']['default'] ),	
						'invalid_configuration'  => esc_html__( 'Set the Mailchimp API in the Settings.', 'zeguten' ),
						'invalid_email'  => esc_html__( 'Invalid email.', 'zeguten' ),
						'empty_field'  => esc_html__( 'Empty field.', 'zeguten' ),
						'a11y'                   => [
							'submission_processing' => esc_html__( 'The submission is being processed.', 'zeguten' ),
							'submission_succeeded'  => esc_html__( 'The submission successfully succeeded.', 'zeguten' ),
							'submission_failed'     => esc_html__( 'The submission failed.', 'zeguten' ),
						],
					],
				]
			);

			// Editor Styles Dashboard.

			wp_register_style( 				
				'zeguten-dashboard_style',
				ZEGUTEN_URL . 'assets/lib/zeguten-dashboard.css',
				array( 'wp-edit-blocks', 'zeguten-font' ),
				ZEGUTEN_VERSION
			);

			// Editor Styles.
			wp_register_style(
				'zeguten-blocks',
				ZEGUTEN_URL . 'assets/css/style.css',
				array(),
				ZEGUTEN_VERSION
			);

			wp_register_style(
				'zeguten-font',
				ZEGUTEN_URL . 'assets/lib/zeguten-font/css/zeguten.css',
				array( 'wp-edit-blocks' ),
				ZEGUTEN_VERSION
			);

			wp_register_style(
				'zeguten-blocks-editor',
				ZEGUTEN_URL . 'assets/css/editor.css',
				array( 'wp-edit-blocks', 'zeguten-font' ),
				ZEGUTEN_VERSION
			);

			wp_register_style(
				'slick_style',
				ZEGUTEN_URL . 'assets/lib/slick/slick.css',
				array( 'wp-edit-blocks' ),
				ZEGUTEN_VERSION
			);

			wp_register_style(
				'slick_theme_style',
				ZEGUTEN_URL . 'assets/lib/slick/slick-theme.css',
				array( 'wp-edit-blocks' ),
				ZEGUTEN_VERSION
			);

			wp_register_style(
				'swiper_style',
				ZEGUTEN_URL . 'assets/lib/swiper/swiper.css',
				array( 'zeguten-blocks' ),
				ZEGUTEN_VERSION
			);

			wp_register_style(
				'animate',
				ZEGUTEN_URL . 'assets/lib/animate.css/animate.min.css',
				array(),
				ZEGUTEN_VERSION
			);

			wp_enqueue_style('swiper_style');
			wp_enqueue_style('slick_style');
            wp_enqueue_style('slick_theme_style');
            wp_enqueue_style('animate');
            wp_enqueue_style( 'zeguten-dashboard_style' );

			$blocks = array(
				'pricing-table',
				'animated-box',
				'banner',
				'circle-progress',
				'countdown-timer',
				'image-comparison',
				'map',
				'progress-bar',
				'section',
				'tabs',
				'team-member',
				'blurbs',
				'carousel',
				'heading',
				'slider',
				'testimonials',
			);

			foreach ( $blocks as $block) {
				register_block_type( 'zeguten/' . $block, array(
					'editor_script' => 'zeguten-blocks-editor',
					'editor_style'  => 'zeguten-blocks-editor',
					'script'        => 'zeguten-blocks',
					'style'         => 'zeguten-blocks',
				) );
			}

		}


		/**
		 * Include required files
		 *
		 * @return void
		 */
		public function includes() {

			require_once ZEGUTEN_PATH . 'includes/zeguten-dashboard.php';

			require_once ZEGUTEN_PATH . 'includes/svg-manager.php';
			require_once ZEGUTEN_PATH . 'includes/ajax-handlers.php';
			
			require_once ZEGUTEN_PATH . 'includes/classes/class-zeguten-block-helper.php';
			require_once ZEGUTEN_PATH . 'includes/classes/class-zeguten-helper.php';


			if ( PHP_VERSION_ID >= 50600 ) {

				if ( ! class_exists( '\DrewM\MailChimp\MailChimp' ) ) {
					require_once ZEGUTEN_PATH . 'includes/libraries/drewm/mailchimp-api/MailChimp.php';
				}

				require_once ZEGUTEN_PATH . 'includes/interfaces/subscribe-provider-interface.php';
				require_once ZEGUTEN_PATH . 'includes/classes/class-zeguten-api-error-exception.php';
				require_once ZEGUTEN_PATH . 'includes/classes/class-zeguten-mailchimp-api-error-exception.php';
				require_once ZEGUTEN_PATH . 'includes/classes/class-zeguten-mailchimp.php';
			}
		}

		/**
		 * Fix thumbnails display
		 *
		 * @return void
		 */
		public function fix_svg_thumb_display() {
			?>
			<style type="text/css">
				td.media-icon img[src$=".svg"],
				img[src$=".svg"].attachment-post-thumbnail,
				td .media-icon img[src*='.svg'] {
					width: 100% !important;
					height: auto !important;
				}
			</style>
			<?php
		}

		/**
		 * Initializtions for admin-only parts
		 *
		 * @return void
		 */
		public function admin_init() {

			if ( ! is_admin() ) {
				return;
			}

			require ZEGUTEN_PATH . 'includes/updater/plugin-update.php';

			new ZeGuten_Plugin_Update( array(
				'version' => ZEGUTEN_VERSION,
				'slug'    => 'zeguten',
			) );

		}

		/**
		 * Function to integrate CF7 Forms.
		 *
		 * @since 1.0.9
		 */
		public static function get_zeguten_cf7() {
				$field_options = array();

				if ( class_exists( 'WPCF7_ContactForm' ) ) {
					$args             = array(
						'post_type'      => 'wpcf7_contact_form',
						'posts_per_page' => -1,
					);
					$forms            = get_posts( $args );
					$field_options[0] = array(
						'value' => -1,
						'label' => __( 'Select Form', 'zeguten' ),
					);
					if ( $forms ) {
						foreach ( $forms as $form ) {
							$field_options[] = array(
								'value' => $form->ID,
								'label' => $form->post_title,
							);
						}
					}
				}

				if ( empty( $field_options ) ) {
					$field_options = array(
						'-1' => __( 'You have not added any Contact Form 7 yet.', 'zeguten' ),
					);
				}
			return $field_options;
		}

		/**
		 * Renders the Contect Form 7 shortcode.
		 *
		 * @since 1.0.9
		 */
		public static function zeguten_cf7_shortcode() {

			check_ajax_referer( 'zeguten_ajax_nonce', 'nonce' );
			
			$id = intval($_POST['formId']);

			if ( $id && 0 !== $id && -1 !== $id ) {
				$data['html'] = do_shortcode( '[contact-form-7 id="' . $id . '" ajax="true"]' );
			} else {
				$data['html'] = '<p>' . __( 'Please select a valid Contact Form 7.', 'zeguten' ) . '</p>';
			}
			wp_send_json_success( $data );
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @return object
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}
			return self::$instance;
		}
	}

}

add_action('plugins_loaded', 'zeguten_gutenberg_loader');
add_action( 'after_setup_theme', 'zeguten_theme_setup' );
add_filter( 'render_block', 'zeguten_wrap_alignment', 10, 2 );
add_action('after_setup_theme', 'get_zeguten_image_sizes');
add_action( 'plugins_loaded', 'zeguten_load_plugin_textdomain' );
add_action('wp_enqueue_scripts', 'ww_load_dashicons', 999);
add_filter( 'wp_prepare_attachment_for_js', 'show_svg_in_media_library' );
//add_filter( 'wpcf7_autop_or_not', '__return_false' );
add_action('admin_init', 'zeguten_redirect');
register_activation_hook( ZEGUTEN_FILE , 'zeguten_activate');

/**
* ZeGuten activation redirect
*
* @since 1.1.0
*/

function zeguten_activate() {
    add_option('zeguten_do_activation_redirect', true);
}

function zeguten_redirect() {
    if (get_option('zeguten_do_activation_redirect', false)) {
        delete_option('zeguten_do_activation_redirect');
        wp_redirect('admin.php?page=zeguten-dashboard');
        exit;
    }
}

/**
* Initialize the blocks
*/
function zeguten_gutenberg_loader() {
/**
 * Load Posts Block
 */
	require_once ZEGUTEN_PATH . 'src/blocks/posts/index.php';
	require_once ZEGUTEN_PATH . 'src/blocks/subscribe/index.php';
	require_once ZEGUTEN_PATH . 'src/blocks/subscribe/subscribe-functions.php';
	require_once ZEGUTEN_PATH . 'src/blocks/contact-form-7/index.php';
	require_once ZEGUTEN_PATH . 'src/blocks/products-grid/index.php';
}


function zeguten_theme_setup() {
	add_theme_support( 'align-wide' );
}

function zeguten_wrap_alignment( $block_content, $block ) {
	if ( isset( $block['attrs']['align'] ) && in_array( $block['attrs']['align'], array( 'wide', 'full' ) ) ) {
		$block_content = sprintf(
			'<div class="%1$s">%2$s</div>',
			'align-wrap align-wrap-' . esc_attr( $block['attrs']['align'] ),
			$block_content
		);
	}
	return $block_content;
}


/**
* Gutenberg block category for ZeGuten.
*
* @param array  $categories Block categories.
* @param object $post Post object.
* @since 1.0.0
*/

add_filter('block_categories', function( $categories, $post ) {
	return array_merge(
		$categories, array(
			array(
				'slug'  => 'zeguten',
				'title' => esc_html__( 'ZeGuten', 'zeguten' ),
			),
		)
	);
},10, 2);

// Adds support for editor color palette.
add_theme_support( 'editor-color-palette', array(
	array(
		'name'  => esc_html__( 'Light gray', 'zeguten'  ),
		'slug'  => 'light-gray',
		'color'	=> '#f5f5f5',
	),
	array(
		'name'  => esc_html__( 'Medium gray', 'zeguten'  ),
		'slug'  => 'medium-gray',
		'color' => '#999',
	),
	array(
		'name' => esc_html__( 'light grayish magenta', 'zeguten' ),
		'slug' => 'light-grayish-magenta',
		'color' => '#d0a5db',
	),
	array(
		'name' => esc_html__( 'very light gray', 'zeguten' ),
		'slug' => 'very-light-gray',
		'color' => '#eee',
	),
	array(
		'name' => esc_html__( 'very dark gray', 'zeguten' ),
		'slug' => 'very-dark-gray',
		'color' => '#444',
	),
) );

/**
 * Add image sizes
 */
function get_zeguten_image_sizes() {
	add_image_size( 'zeguten-blog-image', 700, 525, true );
	add_image_size( 'zeguten-blog-image-small', 260, 195, true );
	add_image_size( 'zeguten-blog-image-640x465', 640, 465, true );
	add_image_size( 'zeguten-blog-image-400x300', 400, 300, false );
	add_image_size( 'zeguten-blog-image-620x715', 620, 715, false );
	add_image_size( 'zeguten-blog-image-510x700', 510, 700, false );
	add_image_size( 'zeguten-blog-image-630x635', 630, 635, false );
}

/**
 * Initialize plugin
 *
 * @return void
 */

add_action( 'init', array( 'ZeGuten_Plugin', 'get_instance' ) );

/**
 * Load the plugin textdomain
 */

function zeguten_load_plugin_textdomain() {
	load_plugin_textdomain( 'zeguten', false, dirname( plugin_basename( ZEGUTEN_PATH ) ) . 'languages' ); 
}
/**
 * Add Dashicons
 */
function ww_load_dashicons(){
	wp_enqueue_style('dashicons');
}

/**
* Visual display svg in library
/**
 * [show_svg_in_media_library description]
 * @param  [type] $response
 * @return [type]
 */
function show_svg_in_media_library( $response ) {
	if ( $response['mime'] === 'image/svg+xml' ) {
		$response['image'] = [
			'src' => $response['url'],
		];
	}

	return $response;
}

/**
 * Adding svg_anable filters
 */
$svg_enable = get_option( 'zeguten_svg_enable' );

if ( $svg_enable === 'enabled' ) {
	add_filter( 'upload_mimes', 'svg_upload_allow' );
	add_filter( 'wp_check_filetype_and_ext', 'fix_svg_mime_type', 10, 5  );	
};

/**
 * [svg_upload_allow description]
 * @param  [type] $mimes
 * @return [type]
 */
function svg_upload_allow( $mimes ) {
	$mimes['svg']  = 'image/svg+xml';

	return $mimes;
}

/**
 * [fix_svg_mime_type description]
 * @param  [type] $data
 * @param  [type] $file
 * @param  [type] $filename
 * @param  [type] $mimes
 * @param  string $real_mime
 * @return [type]
 */
function fix_svg_mime_type( $data, $file, $filename, $mimes, $real_mime = '' ){

	// WP 5.1 +
	if( version_compare( $GLOBALS['wp_version'], '5.1.0', '>=' ) )
		$dosvg = in_array( $real_mime, [ 'image/svg', 'image/svg+xml' ] );
	else
		$dosvg = ( '.svg' === strtolower( substr($filename, -4) ) );

	if( $dosvg ){

		// ALLOW
		if( current_user_can('manage_options') ){

			$data['ext']  = 'svg';
			$data['type'] = 'image/svg+xml';
		}
		// DISALLOW
		else {
			$data['ext'] = $type_and_ext['type'] = false;
		}

	}

	return $data;
}