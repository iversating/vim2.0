# ZeGuten plugin

<h3>A collection of blocks for Gutenberg blocks editor.</h3>

Our official site is <strong><a href="https://zeguten.webcodebuilder.com/" rel="nofollow">ZeGuten</a></strong>.

<h3>Features</h3>

<ul>
  <li><strong>Easy to use</strong>. Everything is extremely easy to tune. You don’t have to be experienced in coding to create beautiful page layouts with custom backgrounds and animations. ZeGuten blocks will let you do everything in mere minutes!</li>
  <li><strong>Dozens of style settings</strong>. With ZeGuten you can style up your content according to your needs to make it suit perfectly your specific purposes and fit the design of your webpage like a glove!</li>
  <li><strong>10+ ZeGuten blocks</strong>.
    <ul>
                <li><a href="https://zeguten.webcodebuilder.com/posts/">Posts</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/sections/">Section</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/banner/">Banner</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/advanced-map/">Advanced map</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/circle-progress/">Circle progress</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/countdown-timer/">Countdown timer</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/icon-list/">Icon list</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/progres-bar/">Progress bar</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/blurbs/">Blurbs</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/headings/">Heading</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/image-comparison/" >Image comparison</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/carousel/">Carousel</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/pricing-table/">Pricing table</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/animated-box/">Animated box</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/subscribe/">Subscribe</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/tabs/">Tabs</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/contact-form-7/">Contact Form 7</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/slider/">Slider</a></li>
                <li><a href="https://zeguten.webcodebuilder.com/product-grid/">Product Grid </a></li>
            </ul>
</li>
<li><strong>Made for WordPress and Gutenberg</strong>. ZeGuten blocks are super easy to use, and don’t require any extra builder to become your go-to asset when building content. Just use them in tandem with WordPress blocks editor, and you’ll be impressed how easy your work with content will become!</li>
</ul>

<h3>Changelog</h3>

<h4>1.1.5 [May 27, 2021]</h4>
<p>
  <ul>
   <ul>
    <li>### Fixed:
       <ul>
            <li> Minor bug fixes</li>
      </ul>
   </li>
   <li>### Added:
       <ul>
            <li> Social Icons block</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.1.4 [May 13, 2021]</h4>
<p>
  <ul>
   <ul>
     <li>### Fixed:
       <ul>
            <li> Default values of attributes of the testimonials block.</li>
      </ul>
   </li>
    <li>### Added:
       <ul>
            <li> The ability to indent carousel pagination of the testismonials block.</li>
      </ul>
   </li>
   <li>### Updated:
       <ul>
            <li> Google fonts.</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.1.3 [April 28, 2021]</h4>
<p>
  <ul>
   <ul>
      <li>### Fixed:
       <ul>
            <li> The responsive issue of the block button.</li>
            <li> Padding and margin on mobile versions  of the headers block tabs.</li>
            <li> Mailchimp key of the block subscribe.</li>
            <li> Font size for all titles of the block product grid.</li>
      </ul>
   </li>
    <li>### Added:
       <ul>
            <li> Full views (100% width) buttons option for layouts of the block product grid.</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.1.2 [March 4, 2021]</h4>
<p>
  <ul>
   <ul>
      <li>### Fixed:
       <ul>
            <li> The issue with css style print method is fixed.</li>
            <li> The scrolling speed of the carousel in the testimonial block.</li>
            <li> The issues with typography for the author field in the testimonial block.</li>
            <li> The issues with typography for buttons and links in the  pricing block.</li>
            <li> The minor bugs in the posts block.</li>
            <li> The issues with the button location on the frontend in the button block.</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.1.1 [February 16, 2021]</h4>
<p>
  <ul>
   <ul>
      <li>### Fixed:
       <ul>
            <li> Minor bugs</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.1.0 [January 29, 2021]</h4>
<p>
  <ul>
   <ul>
    <li>### Updated:
       <ul>
            <li> Design of admin panel blocks</li>
            <li> The components of margin, padding, and border</li>
            <li> The global settings for the page look (breakpoint, section width)</li>
            <li> The repeater</li>
      </ul>
   </li>
   <li>### Added:
       <ul>
            <li> Responsive setting for each block</li>
            <li> Animation setting for each block</li>
            <li> The new options for deleting and duplicating the desired item</li>
      </ul>
   </li>
      <li>### Fixed:
       <ul>
            <li> WordPress 5.6 compatibility</li>
            <li> Minor bugs</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.16 [October 1, 2020]</h4>
<p>
  <ul>
   <ul>
    <li>### Fixed:
       <ul>
            <li> Minor bug fixes</li>
            <li> CSS generator optimization</li>
      </ul>
   </li>
   <li>### Added:
       <ul>
            <li> Product Grid block</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.15 [September 1, 2020]</h4>
<p>
  <ul>
   <ul>
    <li>### Fixed:
       <ul>
            <li> Minor bug fixes</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.14 [August 11, 2020]</h4>
<p>
  <ul>
   <ul>
    <li>### Added:
       <ul>
            <li> Buildable Slider block</li>
            <li> Animations for Section block</li>
            <li> Compatibility with WordPress v.5.5</li>
      </ul>
   </li>
    <li>### Fixed:
       <ul>
            <li> Minor bug fixes.</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.13 [July 2, 2020]</h4>
<p>
  <ul>
   <ul>
    <li>### Added:
       <ul>
            <li> Testimonials block</li>
      </ul>
   </li>
    <li>### Fixed:
       <ul>
            <li> improved the Google Fonts library usage.</li>
            <li> Improved the way the checkbox works for mobile devises in Contact Form block.</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.12 [June 26, 2020]</h4>
<p>
  <ul>
   <ul>
    <li>### Added:
       <ul>
            <li> Team Member block</li>
            <li> wider choice of SVG icon fonts</li>
      </ul>
   </li>
    <li>### Fixed:
       <ul>
            <li> the issue with the Carousel block width.</li>
            <li> minor issue with Posts Carousel pagination element.</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.11 [June 4, 2020]</h4>
<p>
  <ul>
   <ul>
       <li>### Added:
       <ul>
            <li>Added Contact form 7 block</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.10 [June 2, 2020]</h4>
<p>
  <ul>
   <ul>
    <li>### Added:
       <ul>
            <li> Added Tabs block</li>
            <li> Added Section block z-index option</li>
      </ul>
   </li>
    <li>### Fixed:
       <ul>
            <li> Button block mobile settings.</li>
            <li> Button block inline options.</li>
            <li> Carousel block text orientation.</li>
            <li> Heading block letter spacing option.</li>
            <li> Carousel block button full-width option.</li>
            <li> Heading block em and vw size property settings.</li>
            <li> Heading block border option.</li>
            <li> Icon list block text link option.</li>
            <li> Section block background settings.</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.9 [May 18, 2020]</h4>
<p>
  <ul>
   <ul>
       <li>### Added:
       <ul>
            <li> Added Subscribe form block for Mailchimp integration.</li>
      </ul>
   </li>
  </ul>
</p>


<h4>1.0.8 [April 24, 2020]</h4>
<p>
  <ul>
   <ul>
    <li>### Added:
       <ul>
            <li> Added an option for adding an icon for the Button and Blurb blocks.</li>
            <li> Added an option for adding an icon to the Banner block.</li>
            <li> Extended the positionaing, hover and border options for the Button block.</li>
            <li> Added an option for color, hover color, size and positionaing change for and SVG icon.</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.7 [April 15, 2020]</h4>
<p>
  <ul>
   <ul>
    <li>### Fixed:
       <ul>
            <li> improved spacing for icons on tablet and mobile laouts for Carousel block.</li>
            <li> section bug fixes.</li>
      </ul>
   </li>
       <li>### Added:
       <ul>
            <li> block animated-box.</li>
      </ul>
   </li>
  </ul>
</p>


<h4>1.0.6 [April 3, 2020]</h4>
<p>
  <ul>
   <ul>
    <li>### Fixed:
       <ul>
            <li> improved compatibility for WordPress 5.4</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.5 [March 26, 2020]</h4>
<p>
  <ul>

   <ul>
    <li>### Fixed:
       <ul>
            <li> deleted class "has-post-thumbnail" when image is disable in Post block.</li>
            <li> in Carousel block fixed border, padding and shadow option.</li>
            <li> small css bugs in Post block.</li>
      </ul>
   </li>
    <li>### Added:
       <ul>
            <li> Pricing table block.</li>
            <li> responsive option for masonry layout in Post block.</li>
            <li> offset option in Post block.</li>
            <li> Post item shadow in Post block (need regenerate block).</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.4 [March 11, 2020]</h4>
<p>
  <ul>

   <ul>
    <li>### Added:
       <ul>
            <li> block carousel.</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.3 [February 17, 2020]</h4>
<p>
  <ul>

   <ul>
    <li>### Fixed:
       <ul>
            <li> icon-list bug fixes.</li>
            <li> blurbs bug fixes.</li>
            <li> countdown timer label.</li>
            <li> carousel dots bug fixes.</li>
      </ul>
   </li>
       <li>### Added:
       <ul>
            <li> posts block carousel layouts.</li>
      </ul>
   </li>
  </ul>
</p>

<h4>1.0.2 [February 14, 2020]</h4>
<p>
  <ul>

   <ul>
    <li>### Fixed:
       <ul>
            <li> icon-list front-end.</li>
            <li> media library.</li>
            <li> columns gap.</li>
            <li> image comparison front-end.</li>
    </ul>
   </li>
  </ul>
</p>

<h4>1.0.1 [February 13, 2020]</h4>
<p>
  <ul>
    <li>### Added:
        <ul>
            <li> background options for columns.</li>
        </ul>
    </li>
   <ul>
    <li>### Fixed:
       <ul>
            <li> section block options.</li>
       </ul>
   </li>
  </ul>
</p>
